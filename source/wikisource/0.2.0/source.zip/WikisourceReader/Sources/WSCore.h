#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
NSString *WSString(id value);
NSString *WSEncode(NSString *value);
NSString *WSPlain(NSString *html);
NSString *WSEscape(NSString *text);
NSString *WSTitleFromURL(NSURL *url);
NSURL *WSPageURL(NSString *title);
UIColor *WSTint(void);
void WSAlert(UIViewController *vc,NSString *title,NSString *message);
void WSSheet(UIViewController *vc,UIAlertController *sheet,UIBarButtonItem *anchor);
NSString *WSDataDirectory(void);
NSString *WSVariant(void);
@interface WSAPI : NSObject <NSURLSessionDataDelegate>
+ (instancetype)shared;
- (NSURLSessionDataTask *)queryWikipedia:(NSDictionary *)parameters language:(NSString *)language completion:(void (^)(NSDictionary *,NSError *))completion;
- (NSURLSessionDataTask *)query:(NSDictionary *)parameters completion:(void (^)(NSDictionary *,NSError *))completion;
@end
@interface WSStore : NSObject
+ (instancetype)shared;
- (instancetype)initWithDirectory:(NSString *)directory cache:(NSString *)cache;
@property(nonatomic,readonly) NSArray *favorites;
@property(nonatomic,readonly) NSArray *history;
@property(nonatomic,readonly) NSString *error;
- (BOOL)isFavorite:(NSString *)title;
- (BOOL)toggleFavorite:(NSString *)title;
- (void)visit:(NSString *)title progress:(double)progress;
- (void)removeHistory:(NSString *)title;
- (double)progress:(NSString *)title;
- (NSDictionary *)cachedPage:(NSString *)title variant:(NSString *)variant;
- (void)cachePage:(NSDictionary *)page requestedTitle:(NSString *)title variant:(NSString *)variant;
- (void)clearCache;
- (uint64_t)cacheSize;
@end
extern NSString * const WSStoreChanged;
#ifdef WS_TESTING
void WSUseTestStore(WSStore *store);
#endif
