#import "WSCore.h"
NSString *WSWikipediaTitle(NSURL *url);
NSString *WSWikipediaLanguage(NSURL *url);
NSURL *WSWikipediaAppURL(NSURL *url);
void WSOpenWikipedia(UIViewController *from,NSURL *url);
@interface WSWikipediaController : UIViewController <WKNavigationDelegate>
- (instancetype)initWithURL:(NSURL *)url;
@end
