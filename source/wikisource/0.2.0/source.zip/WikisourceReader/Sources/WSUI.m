#import "WSUI.h"
#import <math.h>
static UITableViewCell *WSCell(UITableView *table){UITableViewCell *cell=[table dequeueReusableCellWithIdentifier:@"entry"]?:[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"entry"];cell.textLabel.font=[UIFont systemFontOfSize:18];cell.textLabel.numberOfLines=1;cell.detailTextLabel.font=[UIFont systemFontOfSize:13];cell.detailTextLabel.textColor=[UIColor grayColor];cell.detailTextLabel.numberOfLines=2;cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;return cell;}
@interface WSCategoryController : UITableViewController
@property(nonatomic,copy) NSString *category;
@property(nonatomic,strong) NSArray *rows;
@property(nonatomic,copy) NSString *continuation;
@property(nonatomic,strong) NSURLSessionDataTask *task;
@property(nonatomic,copy) NSString *message;
@end
void WSOpenTitle(UIViewController *from,NSString *title){if(!title.length||title.length>512)return;if([title hasPrefix:@"Category:"]){WSCategoryController *category=[WSCategoryController new];category.category=title;[from.navigationController pushViewController:category animated:YES];}else [from.navigationController pushViewController:[[WSReaderController alloc] initWithTitle:title] animated:YES];}
static void WSAbout(UIViewController *from){UIViewController *vc=[UIViewController new];vc.title=@"关于维基文库阅读器";UITextView *text=[[UITextView alloc] initWithFrame:vc.view.bounds];text.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;text.editable=NO;text.dataDetectorTypes=UIDataDetectorTypeLink;text.font=[UIFont systemFontOfSize:17];text.textContainerInset=UIEdgeInsetsMake(24,20,24,20);text.text=@"维基文库 · 中文阅读器 0.2.0\n\n独立的第三方阅读客户端，非维基媒体基金会官方 App。无需登录，不提交编辑。\n\n使用中文维基文库公开接口提供作品、作者与分类检索。书页保留原文链接、修订号和贡献记录入口。\n\n维基文库页面文本采用知识共享署名—相同方式共享 4.0；各作品底本、插图及扫描件可能采用不同许可，使用时请查阅原文页面的说明。\nhttps://zh.wikisource.org/wiki/Wikisource:版权信息\nhttps://creativecommons.org/licenses/by-sa/4.0/deed.zh\n\n最近阅读最多 30 项，收藏最多 200 项。阅读进度按页面和文字位置保存；源文结构变动时位置可能略有偏移。\n\nAa 提供字号、日夜、简洁及竖排模式。竖排时左滑下一页、右滑上一页。简繁／原文转换会在当前页面替换正文并恢复文字位置。百科链接可在卡片内预览和展开，也能从更多菜单打开 Wikipedia App。\n\n正文缓存最多 16 MiB、40 个页面，不包含完整图书或所有图片。缓存被淘汰后需重新联网；超大作品请按分卷或章节阅读。\n\n网络连接由设备直接访问维基文库。无法连通时可阅读已缓存的正文，或用右侧“原文”交给 Safari。";[vc.view addSubview:text];[from.navigationController pushViewController:vc animated:YES];}

@interface WSHomeController ()
@property(nonatomic,strong) NSArray *groups;
@property(nonatomic,strong) NSArray *headings;
@end
@implementation WSHomeController
- (void)viewDidLoad{[super viewDidLoad];self.title=@"维基文库";self.tableView.rowHeight=64;_groups=@[@[@"桃花源記",@"將進酒 (李白)",@"琵琶行",@"唐詩三百首"],@[@"論語",@"孟子",@"道德經",@"莊子"],@[@"史記",@"資治通鑑",@"紅樓夢",@"西遊記"]];_headings=@[@"诗词文章",@"经典著作",@"史书与小说"];self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"关于" style:UIBarButtonItemStylePlain target:self action:@selector(about)];UIView *header=[[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,154)];header.autoresizingMask=UIViewAutoresizingFlexibleWidth;UILabel *heading=[[UILabel alloc] initWithFrame:CGRectMake(20,18,header.bounds.size.width-40,32)];heading.autoresizingMask=UIViewAutoresizingFlexibleWidth;heading.text=@"自由的图书馆";heading.font=[UIFont boldSystemFontOfSize:26];heading.textColor=WSTint();[header addSubview:heading];UILabel *subtitle=[[UILabel alloc] initWithFrame:CGRectMake(20,55,header.bounds.size.width-40,24)];subtitle.autoresizingMask=UIViewAutoresizingFlexibleWidth;subtitle.text=@"读诗文，阅典籍，寻作者。";subtitle.font=[UIFont systemFontOfSize:15];subtitle.textColor=[UIColor grayColor];[header addSubview:subtitle];UIButton *search=[UIButton buttonWithType:UIButtonTypeSystem];search.frame=CGRectMake(20,94,header.bounds.size.width-40,44);search.autoresizingMask=UIViewAutoresizingFlexibleWidth;search.backgroundColor=[UIColor colorWithWhite:0.94 alpha:1];search.layer.cornerRadius=8;[search setTitle:@"搜索作品、作者或分类…" forState:UIControlStateNormal];search.titleLabel.font=[UIFont systemFontOfSize:18];[search addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];[header addSubview:search];self.tableView.tableHeaderView=header;[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changed) name:WSStoreChanged object:nil];}
- (void)changed{[self.tableView reloadData];}- (void)about{WSAbout(self);}- (void)search{self.tabBarController.selectedIndex=1;UINavigationController *nav=self.tabBarController.selectedViewController;WSSearchController *search=(id)nav.viewControllers.firstObject;[nav popToRootViewControllerAnimated:NO];[search loadViewIfNeeded];[(UISearchBar *)[search valueForKey:@"searchBar"] becomeFirstResponder];}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)t{return 5;}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s{return s==0?([WSStore shared].history.count?1:0):s==4?1:[_groups[s-1] count];}
- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s{return s==0?([WSStore shared].history.count?@"继续阅读":nil):s==4?@"发现更多":_headings[s-1];}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p{UITableViewCell *cell=WSCell(t);NSString *title=p.section==0?[WSStore shared].history[0][@"title"]:p.section==4?@"维基文库首页":_groups[p.section-1][p.row];cell.textLabel.text=title;cell.detailTextLabel.text=p.section==0?[NSString stringWithFormat:@"已读约 %.0f%% · 从上次位置继续",[[WSStore shared] progress:title]*100]:p.section==4?@"站点推荐、专题与更多分类":@"打开作品与目录";return cell;}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)p{[t deselectRowAtIndexPath:p animated:YES];NSString *title=p.section==0?[WSStore shared].history[0][@"title"]:p.section==4?@"Wikisource:首页":_groups[p.section-1][p.row];WSOpenTitle(self,title);}
- (void)dealloc{[[NSNotificationCenter defaultCenter] removeObserver:self];}
@end

@interface WSSearchController ()
@property(nonatomic,strong) UISearchBar *searchBar;
@property(nonatomic,strong) NSArray *rows;
@property(nonatomic,strong) NSURLSessionDataTask *task;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSInteger offset;
@property(nonatomic,copy) NSString *queryText;
@property(nonatomic,copy) NSString *message;
@end
@implementation WSSearchController
- (void)viewDidLoad{[super viewDidLoad];self.title=@"搜索";self.tableView.rowHeight=86;_rows=@[];_message=@"输入标题、作者姓名或正文关键词。";_searchBar=[[UISearchBar alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,100)];_searchBar.autoresizingMask=UIViewAutoresizingFlexibleWidth;_searchBar.placeholder=@"作品、作者或关键词";_searchBar.scopeButtonTitles=@[@"作品",@"作者",@"分类"];_searchBar.showsScopeBar=YES;_searchBar.delegate=self;self.tableView.tableHeaderView=_searchBar;self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag;}
- (void)searchBarSearchButtonClicked:(UISearchBar *)bar{[self search];}- (void)searchBar:(UISearchBar *)bar selectedScopeButtonIndexDidChange:(NSInteger)selected{if(bar.text.length)[self search];}
- (void)search{NSString *q=[_searchBar.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];if(!q.length||q.length>200){WSAlert(self,@"请输入关键词",@"关键词最长 200 个字符。");return;}[_searchBar resignFirstResponder];[_task cancel];_generation++;_queryText=q;_rows=@[];_offset=0;_message=@"正在搜索…";[self.tableView reloadData];[self fetch:0];}
- (void)fetch:(NSInteger)offset{NSUInteger generation=_generation;NSMutableDictionary *params=[@{@"action":@"query",@"list":@"search",@"srsearch":_queryText,@"srnamespace":@[@"0",@"102",@"14"][_searchBar.selectedScopeButtonIndex],@"srlimit":@20,@"sroffset":@(offset),@"srprop":@"snippet|wordcount"} mutableCopy];__weak WSSearchController *weak=self;_task=[[WSAPI shared] query:params completion:^(NSDictionary *json,NSError *error){WSSearchController *s=weak;if(!s||s.generation!=generation)return;s.task=nil;id rows=json[@"query"][@"search"];if(error){s.message=error.localizedDescription;}else if([rows isKindOfClass:[NSArray class]]){NSMutableArray *next=[s.rows mutableCopy];for(id row in rows)if([row isKindOfClass:[NSDictionary class]]&&WSString(row[@"title"]).length)[next addObject:row];s.rows=next;s.message=next.count?[NSString stringWithFormat:@"%lu 个结果 · 按相关性排序",(unsigned long)next.count]:@"没有找到，可换用原文标题、简体或繁体关键词。";}s.offset=[json[@"continue"][@"sroffset"] integerValue];[s.tableView reloadData];}];}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s{return _rows.count+(_offset>0?1:0);}
- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s{return _message;}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p{UITableViewCell *cell=WSCell(t);if(p.row==(NSInteger)_rows.count){cell.textLabel.text=_task?@"正在加载…":@"加载更多";cell.detailTextLabel.text=nil;cell.accessoryType=UITableViewCellAccessoryNone;}else{NSDictionary *row=_rows[p.row];cell.textLabel.text=row[@"title"];cell.detailTextLabel.text=WSPlain(row[@"snippet"]);}return cell;}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)p{[t deselectRowAtIndexPath:p animated:YES];if(p.row==(NSInteger)_rows.count){if(!_task)[self fetch:_offset];}else WSOpenTitle(self,_rows[p.row][@"title"]);}
- (void)dealloc{[_task cancel];}
@end

@implementation WSCategoryController
- (void)viewDidLoad{[super viewDidLoad];self.title=[_category substringFromIndex:9];self.tableView.rowHeight=62;_rows=@[];[self fetch];}
- (void)fetch{NSMutableDictionary *p=[@{@"action":@"query",@"list":@"categorymembers",@"cmtitle":_category,@"cmnamespace":@"0|14|102",@"cmlimit":@40,@"cmprop":@"title|type"} mutableCopy];if(_continuation)p[@"cmcontinue"]=_continuation;_message=@"正在加载分类…";__weak WSCategoryController *weak=self;_task=[[WSAPI shared] query:p completion:^(NSDictionary *json,NSError *error){WSCategoryController *s=weak;if(!s)return;s.task=nil;id members=json[@"query"][@"categorymembers"];if([members isKindOfClass:[NSArray class]])s.rows=[s.rows arrayByAddingObjectsFromArray:members];s.continuation=json[@"continue"][@"cmcontinue"];s.message=error?error.localizedDescription:s.rows.count?@"作品、作者与子分类":@"此分类暂无可显示的条目。";[s.tableView reloadData];}];}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s{return _rows.count+(_continuation.length?1:0);}- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s{return _message;}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p{UITableViewCell *cell=WSCell(t);cell.textLabel.text=p.row<(NSInteger)_rows.count?_rows[p.row][@"title"]:@"加载更多";cell.detailTextLabel.text=p.row<(NSInteger)_rows.count?([_rows[p.row][@"type"] isEqual:@"subcat"]?@"子分类":@"打开阅读"):nil;return cell;}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)p{[t deselectRowAtIndexPath:p animated:YES];if(p.row<(NSInteger)_rows.count)WSOpenTitle(self,_rows[p.row][@"title"]);else if(!_task)[self fetch];}
- (void)dealloc{[_task cancel];}
@end

@interface WSLibraryController ()
@property(nonatomic,strong) UISegmentedControl *mode;
@end
@implementation WSLibraryController
- (void)viewDidLoad{[super viewDidLoad];self.title=@"我的";self.tableView.rowHeight=66;_mode=[[UISegmentedControl alloc] initWithItems:@[@"收藏",@"最近阅读"]];_mode.selectedSegmentIndex=0;[_mode addTarget:self action:@selector(changed) forControlEvents:UIControlEventValueChanged];UIView *head=[[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,60)];_mode.frame=CGRectMake(16,14,head.bounds.size.width-32,32);_mode.autoresizingMask=UIViewAutoresizingFlexibleWidth;[head addSubview:_mode];self.tableView.tableHeaderView=head;self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"更多" style:UIBarButtonItemStylePlain target:self action:@selector(more)];[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changed) name:WSStoreChanged object:nil];}
- (NSArray *)rows{return _mode.selectedSegmentIndex==0?[WSStore shared].favorites:[WSStore shared].history;}
- (void)changed{[self.tableView reloadData];}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s{return self.rows.count;}
- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s{return self.rows.count?nil:_mode.selectedSegmentIndex==0?@"阅读时点“收藏”，在这里随时找回。":@"最近读过的 30 个页面会显示在这里。";}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p{UITableViewCell *cell=WSCell(t);NSString *title=self.rows[p.row][@"title"];cell.textLabel.text=title;cell.detailTextLabel.text=[NSString stringWithFormat:@"已读约 %.0f%%",[[WSStore shared] progress:title]*100];return cell;}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)p{[t deselectRowAtIndexPath:p animated:YES];WSOpenTitle(self,self.rows[p.row][@"title"]);}
- (void)tableView:(UITableView *)t commitEditingStyle:(UITableViewCellEditingStyle)style forRowAtIndexPath:(NSIndexPath *)p{NSString *title=self.rows[p.row][@"title"];if(_mode.selectedSegmentIndex==0){if(![[WSStore shared] toggleFavorite:title])WSAlert(self,@"无法保存",[WSStore shared].error);}else [[WSStore shared] removeHistory:title];}
- (void)more{UIAlertController *a=[UIAlertController alertControllerWithTitle:@"我的书库" message:[NSString stringWithFormat:@"正文缓存 %.1f MB / 16 MiB；收藏和阅读进度另行保存。",[WSStore shared].cacheSize/1048576.0] preferredStyle:UIAlertControllerStyleActionSheet];[a addAction:[UIAlertAction actionWithTitle:@"清理正文缓存" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){[[WSStore shared] clearCache];WSAlert(self,@"已清理",@"收藏与阅读进度已保留。");}]];[a addAction:[UIAlertAction actionWithTitle:@"关于与使用说明" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){WSAbout(self);}]];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];WSSheet(self,a,self.navigationItem.rightBarButtonItem);}
- (void)dealloc{[[NSNotificationCenter defaultCenter] removeObserver:self];}
@end
