(function(){
 if(window.WSPosition)return;
 var root=function(){return document.querySelector('article');};
 function visible(n){var e=n.parentElement;return !!(e&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&!e.closest('style,script,footer,.variant-tooltip'));}
 function path(n){var a=[],r=root();while(n&&n!==r){var p=n.parentNode;if(!p)return null;a.unshift(Array.prototype.indexOf.call(p.childNodes,n));n=p;}return n===r?a:null;}
 function node(a){var n=root();for(var i=0;n&&i<a.length;i++)n=n.childNodes[a[i]];return n;}
 function capture(){var r=root(),w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT,null,false),n,range=document.createRange(),best=null;
  while((n=w.nextNode())){if(!n.textContent.replace(/\s/g,'')||!visible(n))continue;range.selectNodeContents(n);var b=range.getBoundingClientRect();if(b.bottom<12||b.top>innerHeight)continue;best=n;break;}
  var a={ratio:pageYOffset/Math.max(1,document.documentElement.scrollHeight-innerHeight)};if(!best)return a;
  var off=0;for(var x=24;x<innerWidth-20;x+=24){var c=document.caretRangeFromPoint?document.caretRangeFromPoint(x,16):null;if(c&&c.startContainer===best){off=c.startOffset;break;}}
  range.setStart(best,off);range.setEnd(best,Math.min(best.length,off+1));a.path=path(best);a.offset=off;a.y=range.getBoundingClientRect().top;return a;}
 function restore(a){if(!a)return;var n=a.path?node(a.path):null;if(n&&n.nodeType===3&&visible(n)){var r=document.createRange(),off=Math.min(a.offset,n.length);r.setStart(n,off);r.setEnd(n,Math.min(n.length,off+1));scrollBy(0,r.getBoundingClientRect().top-a.y);}else scrollTo(0,a.ratio*Math.max(0,document.documentElement.scrollHeight-innerHeight));}
 window.WSPosition={capture:capture,restore:restore};
})();
