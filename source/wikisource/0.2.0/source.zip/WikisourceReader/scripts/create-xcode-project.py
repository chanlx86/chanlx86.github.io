#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent
objects={}
def ident(s):return hashlib.sha1(s.encode()).hexdigest()[:24].upper()
def add(label,isa,**values):
 key=ident(label);objects[key]={'isa':isa,**values};return key
def quote(v):
 if isinstance(v,dict):return '{ '+ ' '.join(quote(k)+' = '+quote(x)+';' for k,x in v.items())+' }'
 if isinstance(v,list):return '( '+', '.join(quote(x) for x in v)+' )'
 return json.dumps(str(v),ensure_ascii=False)
refs=[];sources=[];resources=[];fwbuild=[]
for name in ['Sources/App.m','Sources/WSCore.h','Sources/WSCore.m','Sources/WSUI.h','Sources/WSUI.m','Sources/WSReader.m','Sources/WSWikipedia.h','Sources/WSWikipedia.m','Info.plist']:
 f=add('file'+name,'PBXFileReference',path=name,sourceTree='<group>',lastKnownFileType='sourcecode.c.objc' if name.endswith('.m') else 'sourcecode.c.h' if name.endswith('.h') else 'text.plist.xml');refs.append(f)
 if name.endswith('.m'):sources.append(add('build'+name,'PBXBuildFile',fileRef=f))
for p in sorted((root/'Resources').iterdir()):
 f=add('file'+p.name,'PBXFileReference',path='Resources/'+p.name,sourceTree='<group>',lastKnownFileType='image.png' if p.suffix=='.png' else 'sourcecode.javascript');refs.append(f);resources.append(add('build'+p.name,'PBXBuildFile',fileRef=f))
for name in ['UIKit','Foundation','WebKit','CoreGraphics','QuartzCore']:
 f=add('fw'+name,'PBXFileReference',path='System/Library/Frameworks/'+name+'.framework',sourceTree='SDKROOT',lastKnownFileType='wrapper.framework');refs.append(f);fwbuild.append(add('b'+name,'PBXBuildFile',fileRef=f))
product=add('app','PBXFileReference',explicitFileType='wrapper.application',path='WikisourceReader.app',sourceTree='BUILT_PRODUCTS_DIR')
products=add('products','PBXGroup',children=[product],name='Products',sourceTree='<group>')
main=add('main','PBXGroup',children=refs+[products],sourceTree='<group>')
phases=[add('sources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=sources,runOnlyForDeploymentPostprocessing=0),add('frameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=fwbuild,runOnlyForDeploymentPostprocessing=0),add('resources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=resources,runOnlyForDeploymentPostprocessing=0)]
configs=[]
for name in ['Debug','Release']:
 configs.append(add('config'+name,'XCBuildConfiguration',name=name,buildSettings={'ARCHS':'armv7 arm64','SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'9.0','CLANG_ENABLE_OBJC_ARC':'YES','GCC_C_LANGUAGE_STANDARD':'gnu11','GCC_OPTIMIZATION_LEVEL':'2','INFOPLIST_FILE':'Info.plist','PRODUCT_NAME':'WikisourceReader','PRODUCT_BUNDLE_IDENTIFIER':'local.WikisourceReader','TARGETED_DEVICE_FAMILY':'1,2','HEADER_SEARCH_PATHS':'$(SRCROOT)/Sources','OTHER_LDFLAGS':'-lz','CODE_SIGN_IDENTITY':'','CODE_SIGNING_REQUIRED':'NO'}))
cl=add('configs','XCConfigurationList',buildConfigurations=configs,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
target=add('target','PBXNativeTarget',name='WikisourceReader',productName='WikisourceReader',productReference=product,productType='com.apple.product-type.application',buildConfigurationList=cl,buildPhases=phases,buildRules=[],dependencies=[])
proj=add('project','PBXProject',buildConfigurationList=cl,compatibilityVersion='Xcode 3.2',developmentRegion='en',hasScannedForEncodings=0,knownRegions=['en','zh-Hans'],mainGroup=main,productRefGroup=products,projectDirPath='',projectRoot='',targets=[target],attributes={'LastUpgradeCheck':'0730'})
p=root/'WikisourceReader.xcodeproj';p.mkdir(exist_ok=True)
(p/'project.pbxproj').write_text('// !$*UTF8*$!\n'+quote({'archiveVersion':1,'classes':{},'objectVersion':46,'objects':objects,'rootObject':proj})+'\n')
