#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
WS_DEV="${WS_DEVELOPER_DIR:-/Volumes/OS X/Applications/Xcode.app/Contents/Developer}"
WS_SDK="$WS_DEV/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk"
WS_CC="$WS_DEV/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
mkdir -p build/WikisourceReader.app
WS_EXTRA=(-DWS_BUILD=1)
if [[ "${1:-}" == "--testing" ]]; then WS_EXTRA=(-DWS_TESTING=1 tests/Integration.m); fi
WS_ARCH_ARGS=()
for WS_TARGET_ARCH in ${WS_ARCHS:-armv7 arm64}; do WS_ARCH_ARGS+=(-arch "$WS_TARGET_ARCH"); done
"$WS_CC" "${WS_ARCH_ARGS[@]}" -isysroot "$WS_SDK" -miphoneos-version-min=9.0 -O2 -fobjc-arc -fblocks -Wall -Wextra -Wno-unused-parameter -ISources Sources/App.m Sources/WSCore.m Sources/WSUI.m Sources/WSReader.m "${WS_EXTRA[@]}" -framework UIKit -framework Foundation -framework WebKit -framework CoreGraphics -framework QuartzCore -o build/WikisourceReader.app/WikisourceReader
cp Info.plist build/WikisourceReader.app/
cp Resources/*.png build/WikisourceReader.app/
/usr/bin/plutil -convert binary1 build/WikisourceReader.app/Info.plist
echo "Built: $PWD/build/WikisourceReader.app"
