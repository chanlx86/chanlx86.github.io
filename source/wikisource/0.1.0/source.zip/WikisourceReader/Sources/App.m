#import "WSUI.h"
static UIImage *TabIcon(NSInteger type){UIGraphicsBeginImageContextWithOptions(CGSizeMake(28,28),NO,0);CGContextRef c=UIGraphicsGetCurrentContext();CGContextSetStrokeColorWithColor(c,[UIColor blackColor].CGColor);CGContextSetLineWidth(c,1.7);if(type==1){CGContextStrokeEllipseInRect(c,CGRectMake(3,3,16,16));CGContextMoveToPoint(c,17,17);CGContextAddLineToPoint(c,25,25);CGContextStrokePath(c);}else if(type==0){CGContextStrokeRect(c,CGRectMake(3,5,22,19));CGContextMoveToPoint(c,14,5);CGContextAddLineToPoint(c,14,24);CGContextStrokePath(c);}else{CGContextStrokeRect(c,CGRectMake(4,6,6,18));CGContextStrokeRect(c,CGRectMake(12,3,5,21));CGContextMoveToPoint(c,20,5);CGContextAddLineToPoint(c,26,23);CGContextStrokePath(c);}UIImage *image=UIGraphicsGetImageFromCurrentImageContext();UIGraphicsEndImageContext();return [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];}
#ifdef WS_TESTING
void WSStartTests(UIWindow *window);
static void WSRecordException(NSException *exception){NSDictionary *report=@{@"name":exception.name?:@"",@"reason":exception.reason?:@"",@"stack":exception.callStackSymbols?:@[]};[[NSJSONSerialization dataWithJSONObject:report options:0 error:nil] writeToFile:@"/var/mobile/Media/WikisourceReader-Test/exception.json" atomically:YES];}
#endif
@interface WSAppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@end
@implementation WSAppDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)options{
#ifdef WS_TESTING
 NSSetUncaughtExceptionHandler(WSRecordException);
#endif
_window=[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];_window.backgroundColor=[UIColor whiteColor];_window.tintColor=WSTint();UITabBarController *tabs=[UITabBarController new];NSMutableArray *navs=[NSMutableArray array];NSArray *controllers=@[[WSHomeController new],[WSSearchController new],[WSLibraryController new]],*titles=@[@"书库",@"搜索",@"我的"];for(NSUInteger i=0;i<3;i++){UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:controllers[i]];nav.tabBarItem=[[UITabBarItem alloc] initWithTitle:titles[i] image:TabIcon(i) tag:i];[navs addObject:nav];}tabs.viewControllers=navs;_window.rootViewController=tabs;[_window makeKeyAndVisible];
#ifdef WS_TESTING
 if([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/WikisourceReader-Test/run"]){[[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Media/WikisourceReader-Test/run" error:nil];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{WSStartTests(self.window);});}
#endif
 return YES;}
- (void)applicationWillResignActive:(UIApplication *)app{UINavigationController *nav=(id)[(UITabBarController *)_window.rootViewController selectedViewController];UIViewController *vc=nav.topViewController;if([vc isKindOfClass:[WSReaderController class]])[(WSReaderController *)vc savePosition];}
@end
int main(int argc,char **argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass([WSAppDelegate class]));}}
