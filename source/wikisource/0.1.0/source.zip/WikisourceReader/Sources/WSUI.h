#import "WSCore.h"
void WSOpenTitle(UIViewController *from,NSString *title);
@interface WSHomeController : UITableViewController
@end
@interface WSSearchController : UITableViewController <UISearchBarDelegate>
@end
@interface WSLibraryController : UITableViewController
@end
@interface WSReaderController : UIViewController <WKNavigationDelegate,UIScrollViewDelegate>
- (instancetype)initWithTitle:(NSString *)title;
- (void)savePosition;
@end
