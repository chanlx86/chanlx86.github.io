# 维基文库阅读器 0.1.0

独立的 Objective-C 中文维基文库阅读客户端，适配 iOS 9.0 起的 iPhone / iPad，构建包含 ARMv7 与 ARM64。目标真机：iPad 3、iOS 9.3.6。源码工程独立于 J2ME 模拟器、录屏大师和存档浏览器。

## 功能

- 原生书库与作品入口，另可打开维基文库首页。
- 大搜索框，分别检索作品、作者、分类，按站点相关性排序，支持加载更多。
- 正文通过 MediaWiki Parse API 获取，以简化阅读排版显示；不加载整站导航与编辑工具，不执行正文脚本。
- 原生目录，使用现代 `tocdata` 字段；支持本页章节定位和子页入口，无目录文章的 `null` 字段安全处理。
- 简体、繁体、原文三种文本转换；16–32 号字体及日间／夜间阅读。
- 每页收藏、最近阅读 30 项、阅读位置恢复；收藏最多 200 项。
- 已读正文自动缓存，最多 16 MiB / 40 页。可以离线重新打开仍在缓存中的正文，不承诺整部书或所有插图都已离线。清理缓存不会删除收藏和进度。
- 原文、贡献历史、修订号、许可链接；外部链接由用户选择交给 Safari。

此版本是第三方只读客户端，不提供登录、编辑、全书下载、扫描本校对或 EPUB 导出。超长汇总页超过单次 4 MiB 接口限额时，请按章节阅读；字体、横竖屏或作品修订后，进度位置可能略有偏移。需由设备正常访问 `zh.wikisource.org`，不使用 Mac 代理或证书校验绕过。

## 构建与安装

默认工具链为 Xcode 7.3.1 的 iOS 9.3 SDK，可用 `WS_DEVELOPER_DIR` 指定安装路径。项目可直接在 Xcode 中打开；无证书的越狱设备可按以下流程安装：

```sh
./build.sh
python3 scripts/deploy.py 192.168.1.18
python3 scripts/package.py
python3 scripts/export.py
```

SSH 使用本机密钥或交互输入密码，不在项目中保存凭据。安装脚本将 app 放入 `/Applications/WikisourceReader.app`，在设备使用 ldid 伪签名，注册图标；只更新本应用，不会重启桌面或删除用户数据。第一次通过 Xcode 使用开发者证书构建时，按自身账号调整签名配置。

发布目录固定为 `~/Downloads/Repo/维基文库/<版本号>/`，新版本新建对应目录，保留旧版。工程内 `build`、`dist` 是内部构建产物。

图标为本项目绘制的书本图形，不使用官方维基文库标志。`scripts/Icons.m` 可在 Mac 重新生成不透明 PNG 图标与启动图，资源已包含在工程中。

## 接口与内容来源

- 中文维基文库：https://zh.wikisource.org/wiki/Wikisource:首页
- 搜索 API：https://www.mediawiki.org/wiki/API:Search
- 正文 API：https://www.mediawiki.org/wiki/API:Parsing_wikitext
- 站点 `siteinfo/rightsinfo` 返回文本许可 CC BY-SA 4.0：https://creativecommons.org/licenses/by-sa/4.0/deed.zh

客户端非维基媒体基金会官方产品。各作品底本、图片及扫描件的许可可能不同，应查看原文具体说明；正文保留修订与贡献记录入口。站点内容通过 API 按阅读请求获取，不将全站文库打包进安装文件。

## 数据与诊断

应用数据位于其 Documents/WikisourceReader/library.plist；正文缓存位于 Library/Caches/WikisourceReader。收藏与历史文件损坏时保留原文件并停止写入，不用空文件覆盖。

测试构建用 `./build.sh --testing`，诊断自动化仅在 `/var/mobile/Media/WikisourceReader-Test/run` 存在时启动，使用单独的书库与缓存；导出脚本拒绝将测试二进制打包为正式版。

## 真机验证（2026-10-26）

`tests/results/ipad3-ios9-010.json`：iPad 3 / iOS 9.3.6。设备直接 HTTPS 连接中文维基文库，搜索《桃花源记》、实际读取正文，显示修订号与许可；《唐诗三百首》现代目录字段、章节定位、正文缓存及中点进度恢复通过。字号、夜间模式、作品／作者／分类搜索和原生分类成员列表通过。正文中测试脚本被 CSP 阻止，原生目录控制脚本正常执行。书库损坏保护、收藏、30 项历史上限与缓存预算检查通过。测试数据和设置使用隔离目录并在结束后切回正式书库。

正式包使用 Xcode 7.3.1 / iOS 9.3 SDK 编译 ARMv7 和 ARM64，不包含诊断启动入口。
