#!/usr/bin/env python3
"""Stage, sign and atomically deploy the standalone app over SSH (no stored password)."""
import argparse, pathlib, subprocess, tarfile, shlex
root=pathlib.Path(__file__).resolve().parent.parent
p=argparse.ArgumentParser();p.add_argument('host',nargs='?',default='192.168.1.18');p.add_argument('--socket');p.add_argument('--testing',action='store_true');p.add_argument('--no-build',action='store_true');a=p.parse_args()
if not a.no_build: subprocess.run([str(root/'build.sh')]+(['--testing'] if a.testing else []),cwd=root,check=True)
dev=pathlib.Path('/Volumes/OS X/Applications/Xcode.app/Contents/Developer')
subprocess.run([str(dev/'Toolchains/XcodeDefault.xctoolchain/usr/bin/clang'),'-arch','armv7','-arch','arm64','-isysroot',str(dev/'Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk'),'-miphoneos-version-min=9.0','-fobjc-arc',str(root/'scripts/Register.m'),'-framework','Foundation','-o',str(root/'build/register')],check=True)
ssh=['ssh']+(['-S',a.socket] if a.socket else ['-o','ControlMaster=auto','-o','ControlPath=/tmp/wikisourcereader-%r@%h:%p','-o','ControlPersist=600'])+['root@'+a.host]
def remote(cmd,**kw):return subprocess.run(ssh+[cmd],check=True,**kw)
stage='/var/mobile/wikisource-app-stage'
remote('mkdir -p '+stage+'; chmod 755 '+stage)
with tarfile.open(root/'build/install.tgz','w:gz') as t:
 t.add(root/'build/WikisourceReader.app',arcname='WikisourceReader.app',filter=lambda x:None if x.name.endswith('.DS_Store') else x)
 t.add(root/'build/register',arcname='register')
with (root/'build/install.tgz').open('rb') as f:remote('tar -xzf - -C '+stage,stdin=f)
remote('set -e; ldid -S '+stage+'/WikisourceReader.app/WikisourceReader; ldid -S '+stage+'/register; chmod 755 '+stage+'/register; killall WikisourceReader 2>/dev/null || true')
# Replace the application only after stopping it; executable gets a new inode.
remote('set -e; mkdir -p /Applications/WikisourceReader.app; cp '+stage+'/WikisourceReader.app/WikisourceReader /Applications/WikisourceReader.app/WikisourceReader.next; chmod 755 /Applications/WikisourceReader.app/WikisourceReader.next; mv /Applications/WikisourceReader.app/WikisourceReader.next /Applications/WikisourceReader.app/WikisourceReader; for f in '+stage+'/WikisourceReader.app/*; do case "$f" in */WikisourceReader) ;; *) cp "$f" /Applications/WikisourceReader.app/ ;; esac; done; uicache -p /Applications/WikisourceReader.app || true')
if a.testing:remote('mkdir -p /var/mobile/Media/WikisourceReader-Test; touch /var/mobile/Media/WikisourceReader-Test/run; chown -R mobile:mobile /var/mobile/Media/WikisourceReader-Test')
remote('cd /var/mobile; su mobile -c '+shlex.quote(stage+'/register'))
signed=root/'build/signed';signed.mkdir(exist_ok=True)
for src,name in [(stage+'/WikisourceReader.app/WikisourceReader','WikisourceReader'),(stage+'/register','register')]:
 with (signed/name).open('wb') as f:remote('cat '+src,stdout=f)
print('Deployed to '+a.host+'; signed binaries saved in build/signed.')
