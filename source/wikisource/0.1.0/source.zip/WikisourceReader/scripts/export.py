#!/usr/bin/env python3
"""Export versioned installers, editable sources, notes and hashes to Downloads/Repo."""
from pathlib import Path
import plistlib,zipfile,hashlib,json,shutil
root=Path(__file__).resolve().parent.parent
version=plistlib.loads((root/'Info.plist').read_bytes())['CFBundleShortVersionString']
prefix='维基文库_'+version;dist=root/'dist';out=Path.home()/'Downloads'/'Repo'/'维基文库'/version
out.mkdir(parents=True,exist_ok=True);dist.mkdir(exist_ok=True)
source=dist/(prefix+'_源码.zip')
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ['Sources','Resources','scripts','tests','docs','WikisourceReader.xcodeproj','Info.plist','README.md','build.sh']:
  p=root/name
  for file in sorted(p.rglob('*')) if p.is_dir() else [p]:
   if file.is_file() and file.name!='.DS_Store' and '__pycache__' not in file.parts:z.write(file,'WikisourceReader/'+str(file.relative_to(root)))
notes=dist/(prefix+'_使用说明.md');shutil.copy2(root/'README.md',notes)
files=[dist/(prefix+'_iphoneos-arm.deb'),dist/(prefix+'_越狱版.ipa'),source,notes]
manifest=dist/(prefix+'_SHA256.json');manifest.write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files},ensure_ascii=False,indent=2)+'\n')
for p in files+[manifest]:shutil.copy2(p,out/p.name);print(out/p.name)
