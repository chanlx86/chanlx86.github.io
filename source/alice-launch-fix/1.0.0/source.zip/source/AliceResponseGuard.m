#import <Foundation/Foundation.h>
#import <objc/runtime.h>
static void (*originalResponse)(id,SEL,id,id);
static void record(NSString *s) {
 NSString *line=[NSString stringWithFormat:@"%@ %@\n",[NSDate date],s];
 NSString *path=[NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/AliceResponseGuard.log"];
 NSFileHandle *f=[NSFileHandle fileHandleForWritingAtPath:path];
 if(f){[f seekToEndOfFile];[f writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];[f closeFile];}
 else [line writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}
static void guardedResponse(id self,SEL cmd,id connection,id response){
 @try {originalResponse(self,cmd,connection,response);}
 @catch(NSException *e){
  record([NSString stringWithFormat:@"Caught %@: %@; response=%@ status=%ld host=%@",e.name,e.reason,NSStringFromClass([response class]),(long)([response respondsToSelector:@selector(statusCode)]?[response statusCode]:0),[[response URL] host]]);
  [connection cancel];
 }
}
__attribute__((constructor)) static void installGuard(void){
 @autoreleasepool {
 if(![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"RushingAliceCN"])return;
 Class cls=objc_getClass("MIXCacheHandler");
 Method method=class_getInstanceMethod(cls,@selector(connection:didReceiveResponse:));
 if(method && method_getNumberOfArguments(method)==4){
 originalResponse=(void *)method_setImplementation(method,(IMP)guardedResponse);
 record(@"Installed v1: MIXCacheHandler response guard");
 }
 }
}
