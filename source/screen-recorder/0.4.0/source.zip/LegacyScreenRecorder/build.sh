#!/bin/bash
set -euo pipefail
source "$(dirname "$0")/build-env.sh"
mkdir -p output/LegacyRecorder.app
"$LSR_CC" "${LSR_FLAGS[@]}" ${LSR_DAEMON_FLAGS:-} -std=gnu11 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter RecorderDaemon.m -framework ImageIO -framework OpenGLES -framework Foundation -framework UIKit -framework QuartzCore -framework CoreGraphics -framework CoreVideo -framework CoreMedia -framework AudioToolbox -framework AVFoundation -framework Accelerate -o output/lsr-recorderd
"$LSR_CC" "${LSR_FLAGS[@]}" ${LSR_TAP_FLAGS:-} -std=gnu11 -dynamiclib -Wall -Wextra -Wno-unused-function -Wno-unused-parameter AudioTap.m -framework CoreGraphics -framework QuartzCore -framework MediaToolbox -framework Foundation -framework UIKit -framework AVFoundation -framework CoreMedia -framework AudioToolbox -o output/LegacyRecorderAudio.dylib
"$LSR_CC" "${LSR_FLAGS[@]}" ctl.m -framework Foundation -o output/lsrctl
if [ -f App.m ]; then
 "$LSR_CC" "${LSR_FLAGS[@]}" ${LSR_APP_FLAGS:-} App.m -framework CoreMedia -framework AVKit -framework UIKit -framework Foundation -framework AVFoundation -framework AudioToolbox -framework CoreGraphics -framework QuartzCore -framework QuickLook -o output/LegacyRecorder.app/LegacyRecorder
fi

cp Info.plist output/LegacyRecorder.app/Info.plist
cp Resources/*.png output/LegacyRecorder.app/
