#!/usr/bin/env python3
"""Sign build artifacts on a jailbroken device, without installing them."""
import argparse,subprocess,tempfile,shutil,shlex
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--host',required=True);p.add_argument('--control-path');a=p.parse_args()
root=Path(__file__).resolve().parent.parent;out=root/'output';signed=out/'signed';signed.mkdir(exist_ok=True)
ssh=['ssh','-o','BatchMode=yes'];scp=['scp','-o','BatchMode=yes']
if a.control_path:ssh+=['-S',a.control_path];scp+=['-o','ControlPath='+a.control_path]
host='root@'+a.host
def run(s):return subprocess.check_output(ssh+[host,s],text=True).strip()
remote=run('mktemp -d /var/mobile/lsr-sign.XXXXXX')
assert remote.startswith('/var/mobile/lsr-sign.') and '\n' not in remote
try:
 for f in ['lsr-recorderd','lsrctl','LegacyRecorderAudio.dylib','LegacyRecorder.app']:
  subprocess.run(scp+['-r',str(out/f),host+':'+remote+'/'],check=True)
 subprocess.run(scp+[str(root/'daemon-entitlements.plist'),host+':'+remote+'/'],check=True)
 q=shlex.quote(remote)
 run('cd '+q+' && ldid -Sdaemon-entitlements.plist lsr-recorderd && ldid -S lsrctl && ldid -S LegacyRecorderAudio.dylib && ldid -S LegacyRecorder.app/LegacyRecorder')
 for f in ['lsr-recorderd','lsrctl','LegacyRecorderAudio.dylib','LegacyRecorder.app']:
  dest=signed/f
  if dest.is_dir():shutil.rmtree(dest)
  subprocess.run(scp+['-r',host+':'+remote+'/'+f,str(signed)+'/'],check=True)
finally:run('rm -rf '+shlex.quote(remote))
print(signed)
