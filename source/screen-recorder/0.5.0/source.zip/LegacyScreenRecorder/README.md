# 录屏大师 0.5.0

独立的越狱 iOS 9 / ARMv7 录屏项目，与 J2ME 模拟器及其他补丁无依赖。已验证设备为 iPad 3（iPad3,3）、iOS 9.3.6；不据此宣称兼容其他系统或 64 位应用。

## 使用

安装完整 DEB，打开桌面“录屏大师”，点击红色录制按钮，中心显示三秒倒计时。切到要录制的应用后开始录制；支持注入的前台应用有红色录制状态条，点按可停止，也可返回本软件停止并保存。安装或升级后，需要彻底退出并重新打开要录音的应用。

- 底部“录制”页下方调整内录、麦克风、画质及方向；右上角“更多”提供缓存清理与帮助。麦克风默认关闭，首次开启需要系统授权；同时录内音与讲解建议使用耳机。其他应用占用或中断音频会话时，界面会提示。
- “已保存的视频”可切换列表、中图、画廊。直接查询系统前台应用和注册名称，过滤隐藏服务；旧录像列表也会重新解析名称。新录像的实际文件名包含主要应用名称与时间戳，按前台停留时间选主要应用，不把录屏软件自己计入；仍按创建时间排序。缩略图取视频中点，长按可打开小窗预览、切换声音、分享或删除。点击视频直接播放，画廊下方可切换录像。
- 主页轮播“准备好记录”“记录这一刻”“留住美好时光”；开始录制卡片与设置之间显示最近保存的视频大图，点按播放。它复用中点缩略图缓存，不自动播放或持续抓屏。录制页整体滚动，便于小屏访问设置。
- 视频页左上角“选择”进入多选，右上角可全选／取消全选，工具栏提供分享、存到相册、删除。横向拖动连续选择，或按住约四分之一秒后向任意方向拖动，接近边缘自动滚动；回滑缩小范围。普通竖向滑动仍滚动列表。切换视图保留选择。删除前确认数量；保存相册需授权，按段依次保存并报告成功与失败数量。
- 设置中的“显示录制状态条”可在录制前或录制中切换。关闭后隐藏目标应用的红色状态条，请回到本软件停止；三秒倒计时仍保留。
- 缩略图磁盘缓存最多 8 MB / 128 张，内存缓存最多 6 MB / 24 张；后台及录屏期间暂停生成缩略图。设置中可以清理缓存，不删除录像。
- 默认标准模式：横屏 1024×768、竖屏 768×1024，最高 15 fps，H.264 / MP4。清晰模式：横屏 2048×1536、竖屏 1536×2048，自适应 2–15 fps，Motion JPEG / MOV，文件明显更大，适合桌面等轻负载场景。没有轻量模式。抓屏源仍为原生分辨率，缩小编码尺寸不能消除全部采集开销。
- 标准录制单段上限 30 分钟，清晰录制 10 分钟。开始要求至少 200 MB 可用空间，低于 150 MB 自动停止并保存。自动方向在倒计时结束时确定，单段录制中不随旋转改变视频方向。
- 视频及元数据位于数据分区 `/var/mobile/Media/LegacyScreenRecorder/`，状态与日志位于 `/var/mobile/Library/LegacyScreenRecorder/`。卸载保留录像；保存完成前不要强制关机或卸载。

## 0.5.0 更新

底部改为“录制”和“已保存的视频”两栏，声音与画面设置嵌入录制页，小屏视频库不再被录制卡片挤占。画廊使用 1:1 正方形画布，支持原地播放／暂停和系统全屏播放器；小屏向下滚动可查看标题与胶片条。画廊仅保留一个播放器，离开视频页释放，不增加常驻预览缓存。

图标背景改为纵向蓝色线性渐变。多选只更新可见勾选和边框，不重载视频卡片或清空缩略图；换视图时也尽量保留同一文件的图像。

应用识别独立于目标进程的音频注入，使用系统前台标识和 LaunchServices 名称缓存，并保留老系统查询失败时的插件回退。隐藏服务（如 EscrowSecurityAlert）不会成为标题。新录像如 `Puffin-20261023-100858-194.mp4`；旧录像不批量改名，仅修正列表显示。

红色状态条替代浮标，包含“正在录制”、时长和明暗交替的红点／完整圆环，没有旋转；开启麦克风时显示独立麦克风图案。在普通应用嵌入现有状态栏，保留系统网络与电量图标；在全屏应用显示置顶 20 点细条，不改变游戏画布。点按录制文字可停止，也可返回本软件停止。它是插件绘制的 UI，不调用官方录屏服务，不修改全局通话/定位状态；目前只在已载入插件的应用中显示，不覆盖 SpringBoard 主屏幕。原生状态栏权限接口在测试设备拒绝了请求，已停止该实验路线。

`docs/VALIDATION-0.5.0.md` 记录本次实测。`scripts/preview-iphone4s.py` 可在 LSR_TESTING 构建中，经测试 iPad 生成 320×480 点、640×960 像素的 UIKit 尺寸预览，非 4S 真机或硬件性能测试；当前 macOS 15 无法运行旧模拟器的 32 位进程。

## 0.4.1 界面更新

名称改为“录屏大师”，bundle ID 和数据目录保持不变，直接升级可保留录像和设置。图标保留摄像机，小红点移到右下角并加外环；提供全部九种旧 iOS 图标尺寸。中图在 iPad 横屏约五列、竖屏约四列。多选跨视图保存选择，删除失败会反馈，不把失败项当作成功删除。存到相册逐段处理，减少同时导出占用。

## 音频路径（沿用 0.4.0 修复）

植物大战僵尸的音乐与音效使用不同输出路径。旧版混音窗口只有 4 秒，预先提交的音乐可能领先播放位置约 4.66 秒，超出窗口后丢失。混音窗口改为有界的 8 秒，并分别统计过早、过晚的音频数据。

AAC / MP3 AudioQueue 优先使用原生 Processing Tap，直接复制已解码、按播放时间输出的 PCM，避免额外解码和过早提交。普通 PCM 队列保留原有入队采集，压缩队列原生 tap 不可用时保留解码回退。多个音源通过有界多生产者环形队列发布，避免音乐与音效回调竞争造成丢包。用户已试听确认植物大战僵尸音乐连续、音效不再截断音乐；麦克风语音录像也已试听正常。音频实测见 `docs/VALIDATION-0.4.0.md`，本次界面及管理功能验证见 `docs/VALIDATION-0.4.1.md`。

内录仍是按输出路径适配的实验功能，支持 RemoteIO / OpenAL、AudioQueue、部分 AVPlayer / MPMoviePlayer 客户端，以及时钟和设置的本地铃声试听。不代表支持所有系统服务、受保护媒体或所有播放器。播放器采集尊重已有 audioMix，不绕过受保护内容。

## 架构与权限

Objective-C App 管理录像、设置和麦克风。root launchd 服务通过 CARenderServerRenderDisplay + IOSurface 抓取显示，优先 OpenGL ES 2 / PowerVR GPU 缩放，必要时回退 C/NEON；AVAssetWriter 编码画面与 AAC 44.1 kHz 双声道音频。音频 Substrate 插件在应用进程的输出回调中复制有界数据，通过后台队列与 RocketBootstrap 本地消息桥发送给服务。音频实时回调不执行文件操作、网络发送或等待。

当前设备无法使用公开 ReplayKit。独立服务需要伪签名的显示抓取权限，仅安装 IPA 不足以工作。依赖 Cydia Substrate 与 RocketBootstrap。不修改内核、AMFI 或全局 Jetsam 配置；服务仅将自身内存上限设为 96 MB。无网络监听端口，本地控制 socket 限 root / mobile 使用。空闲时不抓屏、不编码。

## Xcode 7.3.1 构建与打包

`LegacyScreenRecorder.xcodeproj` 可构建 UI App，完整功能必须安装配套服务和插件。完整构建使用 Xcode 7.3.1 的 clang 与 iPhoneOS 9.3 SDK，无 Theos、Java 或 Swift 依赖：

```sh
cd '/Users/luoxian/Documents/LegacyScreenRecorder'
LSR_DEVELOPER_DIR='/Volumes/OS X/Applications/Xcode.app/Contents/Developer' bash build.sh
python3 scripts/prepare-package.py --host 192.168.1.18 --control-path /private/tmp/lsr-ipad18m.socket
python3 scripts/package.py
```

请按自己的机器修改 Xcode 路径及 SSH 地址。构建脚本直接使用 clang，避免现代 macOS 加载旧 xcodebuild 的 libauto.dylib 问题。签名脚本在设备的独立临时目录执行 ldid 并取回文件，不自行替换已安装程序，也不保存密码。daemon 使用 `daemon-entitlements.plist`，其余二进制普通伪签名。

安装 `dist/local.legacy.screenrecorder_0.5.0_iphoneos-arm.deb` 前停止录屏；可用 Filza 或 `dpkg -i` 安装，通过 Cydia 卸载。无需重启 SpringBoard，但要重开目标应用。设备数据分区 `Backups/previous-0.4.1.deb` 保留上一版安装包，可在停止录屏后用 dpkg 回退，不删除录像。

## 维护

- `App.m`、`LibraryUI.h`、`ThumbnailStore.h`、`SettingsUI.h`：控制界面与视频管理。
- `Microphone.h`：系统授权后的可选麦克风采集。
- `RecorderDaemon.m`、`Surface.h`：抓屏、缩放、编码及混音。
- `AudioTap.m`、`PCM.h`、`PacketRing.h`：应用音频采集、转换及并发发布。
- `Protocol.h`、`Control.h`、`ctl.m`：本地控制与数据协议。
- `packaging/`：安装卸载脚本；生成的 `dist/installed-files.sha256.json` 用于核验文件。
- `tests/`、`test-device.py`：开发验证。`LSR_APP_FLAGS=-DLSR_TESTING` 启用测试入口，`LSR_TAP_FLAGS=-DLSR_DIAGNOSTICS` 启用插件诊断；正式包均关闭。历史验证保留在 `docs/`。

参考：[Apple Audio Queue Services](https://developer.apple.com/documentation/audiotoolbox/audio-queue-services)、[RocketBootstrap](https://github.com/rpetrich/RocketBootstrap)。
