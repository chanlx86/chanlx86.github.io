// UI-only recording indicator. Does not assert system recording/location/call state.
@interface LSRRecordingStatusButton:UIButton {UILabel*text;CALayer*badge;CAShapeLayer*ring,*dot,*mic;NSInteger lastSecond;BOOL microphone;}
-(void)setElapsed:(NSInteger)seconds;
-(void)animateRecording:(BOOL)on;
-(void)setMicrophoneEnabled:(BOOL)enabled;
@end
@implementation LSRRecordingStatusButton
-(id)initWithFrame:(CGRect)frame{if((self=[super initWithFrame:frame])){lastSecond=-1;self.backgroundColor=[UIColor colorWithRed:.86 green:.10 blue:.19 alpha:1];text=[UILabel new];text.backgroundColor=[UIColor clearColor];text.opaque=NO;text.textColor=[UIColor whiteColor];text.font=[UIFont boldSystemFontOfSize:12];text.textAlignment=NSTextAlignmentCenter;[self addSubview:text];badge=[CALayer layer];badge.backgroundColor=[UIColor whiteColor].CGColor;badge.cornerRadius=8;[self.layer addSublayer:badge];ring=[CAShapeLayer layer];ring.fillColor=[UIColor clearColor].CGColor;ring.strokeColor=self.backgroundColor.CGColor;ring.lineWidth=1.4;ring.strokeEnd=1;[badge addSublayer:ring];dot=[CAShapeLayer layer];dot.fillColor=self.backgroundColor.CGColor;[badge addSublayer:dot];mic=[CAShapeLayer layer];mic.fillColor=[UIColor whiteColor].CGColor;mic.strokeColor=[UIColor whiteColor].CGColor;mic.lineWidth=1.2;[self.layer addSublayer:mic];self.accessibilityLabel=@"正在录制，点按停止";}return self;}
-(void)setElapsed:(NSInteger)seconds{if(seconds!=lastSecond){lastSecond=seconds;text.text=[NSString stringWithFormat:@"正在录制 %02ld:%02ld",(long)seconds/60,(long)seconds%60];[self setNeedsLayout];}}
-(void)setMicrophoneEnabled:(BOOL)enabled{if(microphone==enabled)return;microphone=enabled;self.accessibilityLabel=enabled?@"正在录制，含麦克风，点按停止":@"正在录制，点按停止";[self setNeedsLayout];}
-(void)layoutSubviews{[super layoutSubviews];CGFloat width=self.bounds.size.width;CGSize size=[text sizeThatFits:CGSizeMake(width-44,20)];CGFloat total=MIN(width,size.width+23+(microphone?18:0)),x=(width-total)/2;badge.frame=CGRectMake(x,2,16,16);ring.frame=badge.bounds;ring.path=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(2,2,12,12)].CGPath;dot.frame=badge.bounds;dot.path=[UIBezierPath bezierPathWithOvalInRect:CGRectMake(5,5,6,6)].CGPath;text.frame=CGRectMake(x+22,0,total-22-(microphone?18:0),20);mic.hidden=!microphone;mic.frame=CGRectMake(x+total-14,3,12,14);UIBezierPath*p=[UIBezierPath bezierPathWithRoundedRect:CGRectMake(4,0,4,7) cornerRadius:2];[p moveToPoint:CGPointMake(2,5)];[p addCurveToPoint:CGPointMake(10,5) controlPoint1:CGPointMake(2,12) controlPoint2:CGPointMake(10,12)];[p moveToPoint:CGPointMake(6,10)];[p addLineToPoint:CGPointMake(6,13)];[p moveToPoint:CGPointMake(3,13)];[p addLineToPoint:CGPointMake(9,13)];mic.path=p.CGPath;
#ifdef LSR_TESTING
 if(self.window){NSDictionary*r=@{@"button":NSStringFromCGRect(self.frame),@"host":NSStringFromCGRect(self.superview.bounds),@"textFrame":NSStringFromCGRect(text.frame),@"textBounds":NSStringFromCGRect(text.bounds),@"text":text.text?:@"",@"hidden":@(text.hidden),@"background":text.backgroundColor.description?:@"nil",@"opaque":@(text.opaque),@"alpha":@(text.alpha),@"transform":NSStringFromCGAffineTransform(self.transform)};NSString*file=[NSString stringWithFormat:@"/var/mobile/Library/LegacyScreenRecorder/status-layout-%@.json",[NSBundle mainBundle].bundleIdentifier];[[NSJSONSerialization dataWithJSONObject:r options:0 error:NULL] writeToFile:file atomically:YES];}
#endif
}
-(void)animateRecording:(BOOL)on{if(!on){[ring removeAllAnimations];[dot removeAllAnimations];return;}[ring removeAnimationForKey:@"rotate"];if(![ring animationForKey:@"breathe"]){for(CALayer*l in @[ring,dot]){CAKeyframeAnimation*a=[CAKeyframeAnimation animationWithKeyPath:@"opacity"];a.values=@[@1,@.25,@1];a.keyTimes=@[@0,@.5,@1];a.duration=1.6;a.repeatCount=HUGE_VALF;[l addAnimation:a forKey:@"breathe"];}}}

@end
static void LSRStopRecordingFromStatus(id sender){uint32_t tag=indicatorTag;dispatch_async(drainQueue,^{if(!remotePort||!tag)return;CFDataRef d=CFDataCreate(NULL,(const UInt8*)&tag,4);CFMessagePortSendRequest(remotePort,3,d,.1,0,NULL,NULL);CFRelease(d);});}
@interface LSRRecordingStatusTarget:NSObject
-(void)stop:(id)sender;
@end
@implementation LSRRecordingStatusTarget
-(void)stop:(id)sender{LSRStopRecordingFromStatus(sender);}
@end
static void LSRUpdateRecordingStatus(NSDictionary*s){
 static LSRRecordingStatusButton*button;static UIView*red;static LSROverlayWindow*window;static LSRRecordingStatusTarget*target;
 UIApplication*app=[UIApplication sharedApplication];uint64_t host=[s[@"host"] unsignedLongLongValue],now=mach_absolute_time();
 BOOL visible=[s[@"tag"] unsignedIntValue]&&(!s[@"showIndicator"]||[s[@"showIndicator"] boolValue])&&now>=host&&app.applicationState==UIApplicationStateActive;
 if(!visible){[red removeFromSuperview];[button removeFromSuperview];[button animateRecording:NO];window.hidden=YES;return;}
 if(!button){button=[[LSRRecordingStatusButton alloc] initWithFrame:CGRectZero];red=[UIView new];red.backgroundColor=button.backgroundColor;red.userInteractionEnabled=NO;target=[LSRRecordingStatusTarget new];[button addTarget:target action:@selector(stop:) forControlEvents:UIControlEventTouchUpInside];}
 UIView*bar=nil;@try{bar=[app valueForKey:@"statusBar"];}@catch(NSException*ignored){}
 BOOL native=bar&&bar.window&&!app.statusBarHidden&&!bar.hidden&&bar.bounds.size.width>100;
 UIView*hostView;
 if(native){window.hidden=YES;hostView=bar;}else{
  if(!window){window=[[LSROverlayWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];window.windowLevel=UIWindowLevelStatusBar+2;UIViewController*c=[UIViewController new];window.rootViewController=c;c.view.backgroundColor=[UIColor clearColor];window.backgroundColor=[UIColor clearColor];}
  hostView=window.rootViewController.view;window.hidden=NO;
 }
 if(red.superview!=hostView){[red removeFromSuperview];[button removeFromSuperview];UIView*foreground=nil;if(native)for(UIView*v in hostView.subviews)if([NSStringFromClass(v.class) rangeOfString:@"Foreground"].location!=NSNotFound){foreground=v;break;}
  if(foreground)[hostView insertSubview:red belowSubview:foreground];else if(native)[hostView insertSubview:red atIndex:0];else[hostView addSubview:red];[hostView addSubview:button];
 }
 CGFloat width=hostView.bounds.size.width;red.frame=CGRectMake(0,0,width,20);CGFloat bw=MIN(200,MAX(160,width-100));button.frame=CGRectMake((width-bw)/2,0,bw,20);[button setElapsed:(NSInteger)((double)(now-host)*timebase.numer/timebase.denom/1e9)];[button setMicrophoneEnabled:[s[@"microphone"] boolValue]];[button animateRecording:YES];
}
