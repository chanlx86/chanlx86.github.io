static NSUserDefaults*LSRDefaults(void){return [NSUserDefaults standardUserDefaults];}
static void LSRRegisterDefaults(void){[LSRDefaults() registerDefaults:@{@"internalAudio":@YES,@"microphone":@NO,@"nativeQuality":@NO,@"orientation":@(-1),@"libraryMode":@1,@"showIndicator":@YES}];}
@interface LSRSettings:UITableViewController
@property(nonatomic)BOOL locked,recordingOnly,maintenanceOnly;
-(CGFloat)recordingHeightForWidth:(CGFloat)width;
@end
@implementation LSRSettings
-(void)setLocked:(BOOL)locked{if(_locked==locked)return;_locked=locked;if(self.isViewLoaded)[self.tableView reloadData];}
-(void)viewDidLoad{[super viewDidLoad];self.title=self.maintenanceOnly?@"更多":@"录制设置";self.tableView.backgroundColor=[UIColor colorWithWhite:.95 alpha:1];}
-(NSInteger)numberOfSectionsInTableView:(UITableView*)t{return self.recordingOnly?2:self.maintenanceOnly?1:3;}
-(CGFloat)footerHeight:(NSInteger)section width:(CGFloat)width{NSString*text=[self tableView:self.tableView titleForFooterInSection:section];CGRect r=[text boundingRectWithSize:CGSizeMake(MAX(100,width-40),CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} context:nil];return ceil(r.size.height)+24;}
-(CGFloat)recordingHeightForWidth:(CGFloat)width{return 5*44+2*32+[self footerHeight:0 width:width]+[self footerHeight:1 width:width]+12;}
-(CGFloat)tableView:(UITableView*)t heightForHeaderInSection:(NSInteger)section{return 32;}
-(CGFloat)tableView:(UITableView*)t heightForFooterInSection:(NSInteger)section{return[self footerHeight:section width:t.bounds.size.width];}
-(NSInteger)tableView:(UITableView*)t numberOfRowsInSection:(NSInteger)s{return self.maintenanceOnly?3:s==0?2:s==1?3:3;}
-(NSString*)tableView:(UITableView*)t titleForHeaderInSection:(NSInteger)s{return self.maintenanceOnly?@"维护与帮助":s==0?@"声音":s==1?@"画面":@"维护与帮助";}
-(NSString*)tableView:(UITableView*)t titleForFooterInSection:(NSInteger)s{
 if(self.maintenanceOnly)s=2;if(self.recordingOnly&&s==0)return@"麦克风需要授权，内录与麦克风同开时建议戴耳机。";
 if(s==0)return@"麦克风默认关闭，首次开启需要系统授权。与内录同时使用时，耳机可避免扬声器的声音再次进入麦克风。音频会话被其他 App 中断时会在主页提示。";
 if(s==1)return@"标准：1024×768、最高15fps、单段30分钟。清晰：2048×1536、自适应2–15fps、单段10分钟，MOV文件较大。自动方向在倒计时结束时确定，录制中固定。关闭状态条后，请回到录屏大师停止录制；三秒倒计时仍会显示。全屏时状态条置顶显示，不改变游戏画布。";
 return@"缩略图取视频中间帧，磁盘缓存上限8MB、内存上限6MB。清理缓存不会删除录像。版本0.5.0。";
}
-(UITableViewCell*)tableView:(UITableView*)t cellForRowAtIndexPath:(NSIndexPath*)p{
 if(self.maintenanceOnly)p=[NSIndexPath indexPathForRow:p.row inSection:2];
 UITableViewCell*c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
 if(p.section==0){NSString*k=p.row?@"microphone":@"internalAudio";c.textLabel.text=p.row?@"麦克风":@"应用内录";UISwitch*sw=[UISwitch new];sw.on=[LSRDefaults() boolForKey:k];sw.tag=p.row;sw.enabled=!self.locked;[sw addTarget:self action:@selector(sound:) forControlEvents:UIControlEventValueChanged];c.accessoryView=sw;}
 else if(p.section==1&&p.row==2){c.textLabel.text=@"显示录制状态条";UISwitch*sw=[UISwitch new];sw.on=[LSRDefaults() boolForKey:@"showIndicator"];[sw addTarget:self action:@selector(indicator:) forControlEvents:UIControlEventValueChanged];c.accessoryView=sw;}
 else if(p.section==1){c.textLabel.text=p.row?@"视频方向":@"录制模式";UISegmentedControl*sc=[[UISegmentedControl alloc] initWithItems:p.row?@[@"自动",@"竖屏",@"横屏"]:@[@"标准",@"清晰"]];sc.tag=p.row;sc.selectedSegmentIndex=p.row?([LSRDefaults() integerForKey:@"orientation"]<0?0:[LSRDefaults() integerForKey:@"orientation"]==1?1:2):[LSRDefaults() boolForKey:@"nativeQuality"];sc.enabled=!self.locked;[sc addTarget:self action:@selector(choice:) forControlEvents:UIControlEventValueChanged];sc.frame=CGRectMake(0,0,MIN(p.row?190:140,self.view.bounds.size.width-130),30);c.accessoryView=sc;}
 else{c.textLabel.text=@[@"清理缩略图缓存",@"录屏测试画面",@"使用说明"][p.row];c.accessoryType=UITableViewCellAccessoryDisclosureIndicator;}
 return c;
}
-(void)indicator:(UISwitch*)s{BOOL visible=s.on;[LSRDefaults() setBool:visible forKey:@"showIndicator"];dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{LSRRequest(@{@"command":@"indicator",@"showIndicator":@(visible)});});}
-(void)sound:(UISwitch*)s{
 if(!s.tag){[LSRDefaults() setBool:s.on forKey:@"internalAudio"];return;}
 if(!s.on){[LSRDefaults() setBool:NO forKey:@"microphone"];return;}
 [[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL granted){dispatch_async(dispatch_get_main_queue(),^{[LSRDefaults() setBool:granted forKey:@"microphone"];[self.tableView reloadData];if(!granted){UIAlertController*a=[UIAlertController alertControllerWithTitle:@"未获得麦克风权限" message:@"可在系统设置的隐私／麦克风中允许录屏大师；应用内录仍可正常使用。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}});}];
}
-(void)choice:(UISegmentedControl*)s{if(!s.tag)[LSRDefaults() setBool:s.selectedSegmentIndex==1 forKey:@"nativeQuality"];else[LSRDefaults() setInteger:s.selectedSegmentIndex==0?-1:s.selectedSegmentIndex==1?1:0 forKey:@"orientation"];}
-(void)tableView:(UITableView*)t didSelectRowAtIndexPath:(NSIndexPath*)p{
 [t deselectRowAtIndexPath:p animated:YES];if(self.maintenanceOnly)p=[NSIndexPath indexPathForRow:p.row inSection:2];if(p.section!=2)return;
 if(p.row==0){[[LSRThumbnailStore shared] clear];UIAlertController*a=[UIAlertController alertControllerWithTitle:@"缩略图缓存已清理" message:@"浏览时会按需重新生成，录像保持不变。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}
 else if(p.row==1){if(!self.locked)[self.navigationController pushViewController:[[LSRPattern alloc] initWithMode:@"au"] animated:YES];}
 else{UIAlertController*a=[UIAlertController alertControllerWithTitle:@"使用说明" message:@"点击红色录制按钮，中心出现3秒倒计时，可切到游戏。点击红色状态条停止，或回到录屏大师停止。状态条可在设置中隐藏。\n\n在底部“已保存的视频”中可切换列表、中图、画廊；点按播放，长按小窗预览。视频页点“选择”，横向滑动或按住拖动可连续选择，再分享、存到相册或删除。画廊为正方形画布，支持原地播放和系统全屏。小窗预览默认静音。\n\n视频保存在数据分区 /var/mobile/Media/LegacyScreenRecorder。内录仍为实验功能，不保证所有音频引擎或受保护内容。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}
}
@end
