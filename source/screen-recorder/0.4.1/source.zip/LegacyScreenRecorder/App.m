#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
#import <Photos/Photos.h>
#import "Control.h"
#import "Pattern.m"
#include <fcntl.h>
#import "Microphone.h"
#import "ThumbnailStore.h"
#import "SettingsUI.h"
#import "LibraryUI.h"
@interface LSRController:UIViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIPopoverPresentationControllerDelegate> {
 NSDictionary*status;NSArray*movies;NSTimer*poll;UICollectionView*library;UICollectionViewFlowLayout*layout;
 UIView*card;UIImageView*galleryImage;UILabel*statusLabel,*detailLabel,*recordLabel,*sectionTitle,*emptyLabel,*galleryCaption,*countdown;
 LSRRecordButton*recordButton;UISegmentedControl*modes;LSRMicrophone*microphone;
 UIBarButtonItem*selectButton,*settingsButton,*allButton,*shareButton,*saveButton,*deleteButton;UIToolbar*batchBar;
 NSMutableSet*chosenPaths;NSString*previousState,*selectedPath;BOOL busy,catalogBusy,catalogAgain,selecting,mediaBusy;
 NSInteger mode,lastCount,phraseIndex;double nextPhrase;dispatch_queue_t catalogQueue;
}
-(void)record;
@end
@implementation LSRController
-(void)viewDidLoad{
 [super viewDidLoad];LSRRegisterDefaults();self.edgesForExtendedLayout=UIRectEdgeNone;
 self.view.backgroundColor=[UIColor colorWithRed:.94 green:.96 blue:.98 alpha:1];
 selectButton=[[UIBarButtonItem alloc] initWithTitle:@"选择" style:UIBarButtonItemStylePlain target:self action:@selector(toggleSelection)];
 settingsButton=[[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStylePlain target:self action:@selector(settings)];
 allButton=[[UIBarButtonItem alloc] initWithTitle:@"全选" style:UIBarButtonItemStylePlain target:self action:@selector(selectAll)];
 self.navigationItem.leftBarButtonItem=selectButton;self.navigationItem.rightBarButtonItem=settingsButton;
 catalogQueue=dispatch_queue_create("local.legacy.recorder.catalog",DISPATCH_QUEUE_SERIAL);movies=@[];chosenPaths=[NSMutableSet set];
 mode=MAX(0,MIN(2,[LSRDefaults() integerForKey:@"libraryMode"]));nextPhrase=CACurrentMediaTime()+4;
 card=[UIView new];card.backgroundColor=[UIColor whiteColor];card.layer.cornerRadius=14;[self.view addSubview:card];
 statusLabel=LSRLabel(28,YES);statusLabel.numberOfLines=2;detailLabel=LSRLabel(13,NO);detailLabel.textColor=[UIColor grayColor];detailLabel.numberOfLines=3;
 [card addSubview:statusLabel];[card addSubview:detailLabel];
 recordButton=[[LSRRecordButton alloc] initWithFrame:CGRectZero];[recordButton addTarget:self action:@selector(record) forControlEvents:UIControlEventTouchUpInside];[card addSubview:recordButton];
 recordLabel=LSRLabel(14,YES);recordLabel.textAlignment=NSTextAlignmentCenter;[card addSubview:recordLabel];
 sectionTitle=LSRLabel(18,YES);sectionTitle.text=@"已保存的视频";[self.view addSubview:sectionTitle];
 modes=[[UISegmentedControl alloc] initWithItems:@[@"列表",@"中图",@"画廊"]];modes.selectedSegmentIndex=mode;[modes addTarget:self action:@selector(changeMode:) forControlEvents:UIControlEventValueChanged];[self.view addSubview:modes];
 layout=[UICollectionViewFlowLayout new];library=[[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];library.backgroundColor=[UIColor clearColor];library.dataSource=self;library.delegate=self;
 [library registerClass:[LSRMovieCell class] forCellWithReuseIdentifier:@"movie"];[self.view addSubview:library];
 [library addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(hold:)]];
 galleryImage=[UIImageView new];galleryImage.backgroundColor=LSRInk();galleryImage.contentMode=UIViewContentModeScaleAspectFit;galleryImage.layer.cornerRadius=10;galleryImage.clipsToBounds=YES;galleryImage.userInteractionEnabled=YES;
 [galleryImage addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playGallery)]];
 [galleryImage addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(holdGallery:)]];[self.view addSubview:galleryImage];
 galleryCaption=LSRLabel(14,NO);galleryCaption.textAlignment=NSTextAlignmentCenter;[self.view addSubview:galleryCaption];
 emptyLabel=LSRLabel(17,NO);emptyLabel.numberOfLines=2;emptyLabel.textAlignment=NSTextAlignmentCenter;emptyLabel.text=@"还没有录像\n点击上方红色按钮开始";[self.view addSubview:emptyLabel];
 batchBar=[UIToolbar new];batchBar.hidden=YES;
 shareButton=[[UIBarButtonItem alloc] initWithTitle:@"分享" style:UIBarButtonItemStylePlain target:self action:@selector(shareSelected)];
 saveButton=[[UIBarButtonItem alloc] initWithTitle:@"存到相册" style:UIBarButtonItemStylePlain target:self action:@selector(saveSelected)];
 deleteButton=[[UIBarButtonItem alloc] initWithTitle:@"删除" style:UIBarButtonItemStylePlain target:self action:@selector(deleteSelected)];deleteButton.tintColor=[UIColor colorWithRed:.85 green:.15 blue:.2 alpha:1];
 UIBarButtonItem*(^flex)(void)=^{return[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];};
 batchBar.items=@[flex(),shareButton,flex(),saveButton,flex(),deleteButton,flex()];[self.view addSubview:batchBar];
 countdown=LSRLabel(100,YES);countdown.textAlignment=NSTextAlignmentCenter;countdown.textColor=[UIColor whiteColor];countdown.backgroundColor=[UIColor colorWithWhite:0 alpha:.65];countdown.layer.cornerRadius=32;countdown.clipsToBounds=YES;countdown.hidden=YES;[self.view addSubview:countdown];
 poll=[NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(refresh) userInfo:nil repeats:YES];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(active) name:UIApplicationDidBecomeActiveNotification object:nil];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(inactive) name:UIApplicationWillResignActiveNotification object:nil];[self refresh];[self reloadMovies];
}
-(void)viewWillAppear:(BOOL)animated{[super viewWillAppear:animated];[self refresh];[self reloadMovies];}
-(void)active{nextPhrase=CACurrentMediaTime()+4;[self refresh];[self reloadMovies];}
-(void)inactive{
 if([self.presentedViewController isKindOfClass:[AVPlayerViewController class]])[((AVPlayerViewController*)self.presentedViewController).player pause];
 if([self.presentedViewController isKindOfClass:[LSRMiniPreview class]])[self dismissViewControllerAnimated:NO completion:nil];
}
-(BOOL)running{return [@[@"recording",@"countdown",@"saving"] containsObject:status[@"state"]?:@""];}
-(void)viewDidLayoutSubviews{
 [super viewDidLayoutSubviews];CGFloat w=self.view.bounds.size.width,h=self.view.bounds.size.height;BOOL narrow=w<560;
 CGFloat ch=narrow?154:164;card.frame=CGRectMake(14,12,w-28,ch);CGFloat cw=card.bounds.size.width;
 recordButton.frame=CGRectMake(cw-(narrow?92:116),18,narrow?72:88,narrow?72:88);
 recordLabel.frame=CGRectMake(cw-(narrow?106:128),narrow?97:116,narrow?100:112,28);
 statusLabel.font=[UIFont boldSystemFontOfSize:narrow?23:29];
 statusLabel.frame=CGRectMake(20,20,MAX(70,cw-(narrow?124:160)),64);
 detailLabel.frame=CGRectMake(20,88,MAX(70,cw-(narrow?124:160)),ch-100);
 CGFloat y=CGRectGetMaxY(card.frame)+12,header=narrow?74:46;
 sectionTitle.frame=CGRectMake(16,y,w-32,28);modes.frame=CGRectMake(narrow?16:w-238,narrow?y+34:y,MIN(narrow?w-32:222,320),30);
 batchBar.frame=CGRectMake(0,h-48,w,48);CGFloat contentY=y+header;
 CGRect area=CGRectMake(14,contentY,w-28,MAX(60,h-contentY-12-(selecting?48:0)));emptyLabel.frame=area;
 galleryImage.hidden=galleryCaption.hidden=mode!=2||!movies.count;
 if(mode==2){CGFloat gh=MAX(60,area.size.height-148);galleryImage.frame=CGRectMake(area.origin.x,area.origin.y,area.size.width,gh);galleryCaption.frame=CGRectMake(14,CGRectGetMaxY(galleryImage.frame)+4,w-28,28);library.frame=CGRectMake(14,CGRectGetMaxY(galleryCaption.frame)+6,w-28,110);layout.scrollDirection=UICollectionViewScrollDirectionHorizontal;layout.minimumLineSpacing=10;layout.itemSize=CGSizeMake(132,98);}
 else{library.frame=area;layout.scrollDirection=UICollectionViewScrollDirectionVertical;layout.minimumLineSpacing=12;layout.minimumInteritemSpacing=12;if(mode==0)layout.itemSize=CGSizeMake(area.size.width,90);else{NSInteger columns=MAX(1,(NSInteger)ceil((area.size.width+12)/202));CGFloat cell=floor((area.size.width-12*(columns-1))/columns);layout.itemSize=CGSizeMake(cell,cell*.66+62);}}
 [layout invalidateLayout];countdown.frame=CGRectMake((w-180)/2,(h-180)/2,180,180);[self.view bringSubviewToFront:countdown];
}
-(void)refresh{
 NSData*d=[NSData dataWithContentsOfFile:@LSR_STATUS];id parsed=d?[NSJSONSerialization JSONObjectWithData:d options:0 error:NULL]:nil;status=[parsed isKindOfClass:[NSDictionary class]]?parsed:@{};
 NSString*s=status[@"state"]?:@"";BOOL running=[self running];[LSRThumbnailStore shared].suspended=running;
 recordButton.recording=running;recordButton.enabled=!busy&&!mediaBusy&&![s isEqualToString:@"saving"];recordLabel.text=running?@"停止并保存":@"开始录屏";
 NSArray*phrases=@[@"准备好记录",@"记录这一刻",@"留住美好时光"];
 BOOL rotate=!running&&CACurrentMediaTime()>=nextPhrase&&self.view.window&&self.navigationController.topViewController==self&&[UIApplication sharedApplication].applicationState==UIApplicationStateActive&&!self.presentedViewController;
 if(rotate){phraseIndex=(phraseIndex+1)%phrases.count;nextPhrase=CACurrentMediaTime()+4;}
 NSString*headline=[s isEqualToString:@"recording"]?[NSString stringWithFormat:@"正在录制 %@",LSRDuration([status[@"elapsed"] doubleValue])]:[s isEqualToString:@"countdown"]?@"即将开始录制":[s isEqualToString:@"saving"]?@"正在保存录像":phrases[phraseIndex];
 if(rotate)[UIView transitionWithView:statusLabel duration:.35 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{self->statusLabel.text=headline;} completion:nil];else statusLabel.text=headline;
 NSString*name=status[@"foregroundName"]?:@"",*warning=status[@"microphoneWarning"]?:@"";
 detailLabel.text=mediaBusy?@"正在处理所选录像，请稍候…":[status[@"error"] length]?status[@"error"]:running?[NSString stringWithFormat:@"%@ · %.1f fps%@%@",name.length?name:@"系统画面",[status[@"actualFPS"] doubleValue],[status[@"microphone"] boolValue]?@" · 麦克风开启":@"",warning.length?[NSString stringWithFormat:@"\n%@",warning]:@""]:@"3秒倒计时后开始\n原声与麦克风可在设置中选择";
 NSInteger n=ceil([status[@"countdown"] doubleValue]);countdown.hidden=n<=0;
 if(n>0&&n!=lastCount){countdown.text=[NSString stringWithFormat:@"%ld",(long)n];countdown.transform=CGAffineTransformMakeScale(1.15,1.15);countdown.alpha=.6;[UIView animateWithDuration:.45 animations:^{self->countdown.transform=CGAffineTransformIdentity;self->countdown.alpha=1;}];}lastCount=n;
 if(![s isEqualToString:previousState]){previousState=s;nextPhrase=CACurrentMediaTime()+4;[self reloadMovies];}
 if(!running&&microphone&&!busy){[microphone stop];microphone=nil;}[self updateSelectionUI];
}
-(void)settings{LSRSettings*c=[[LSRSettings alloc] initWithStyle:UITableViewStyleGrouped];c.locked=[self running];[self.navigationController pushViewController:c animated:YES];}
-(void)record{if(busy||mediaBusy)return;if(selecting)[self endSelection];if([self running]){[self command:@{@"command":@"stop"}];return;}if([LSRDefaults() boolForKey:@"microphone"]){NSError*e=nil;microphone=[LSRMicrophone new];if(![microphone start:&e]){microphone=nil;UIAlertController*a=[UIAlertController alertControllerWithTitle:@"麦克风未能启动" message:e.localizedDescription preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[a addAction:[UIAlertAction actionWithTitle:@"本次不录麦克风" style:UIAlertActionStyleDefault handler:^(UIAlertAction*x){[self begin:NO];}]];[self presentViewController:a animated:YES completion:nil];return;}}[self begin:microphone!=nil];}
-(void)begin:(BOOL)mic{if(self.presentedViewController)[self dismissViewControllerAnimated:NO completion:nil];[self command:@{@"command":@"start",@"audio":@([LSRDefaults() boolForKey:@"internalAudio"]),@"microphone":@(mic),@"fps":@15,@"delay":@3,@"showIndicator":@([LSRDefaults() boolForKey:@"showIndicator"]),@"quality":[LSRDefaults() boolForKey:@"nativeQuality"]?@"native":@"standard",@"orientation":@([LSRDefaults() integerForKey:@"orientation"])}];}
-(void)command:(NSDictionary*)options{busy=YES;recordButton.enabled=NO;dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{NSDictionary*r=LSRRequest(options);dispatch_async(dispatch_get_main_queue(),^{self->busy=NO;if(self->microphone){if([r[@"tag"] unsignedIntValue])[self->microphone setRecordingTag:[r[@"tag"] unsignedIntValue]];else{[self->microphone stop];self->microphone=nil;}}if(!r){UIAlertController*a=[UIAlertController alertControllerWithTitle:@"录屏服务未连接" message:@"请确认完整DEB包已安装并且录屏服务正常运行。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}[self refresh];});});}

-(void)reloadMovies{
 if(catalogBusy){catalogAgain=YES;return;}catalogBusy=YES;NSString*active=[self running]?status[@"path"]:nil;
 dispatch_async(catalogQueue,^{@autoreleasepool{
  NSMutableArray*list=[NSMutableArray array];NSFileManager*fm=[NSFileManager defaultManager];NSDateFormatter*df=[NSDateFormatter new];df.dateFormat=@"MM-dd HH:mm";
  for(NSString*f in [fm contentsOfDirectoryAtPath:@LSR_MOVIES error:NULL])if([@[@"mp4",@"mov"] containsObject:f.pathExtension.lowercaseString]){
   NSString*p=[@LSR_MOVIES stringByAppendingPathComponent:f];if([p isEqualToString:active])continue;
   NSData*d=[NSData dataWithContentsOfFile:[p stringByAppendingString:@".json"]];NSDictionary*meta=d?[NSJSONSerialization JSONObjectWithData:d options:0 error:NULL]:nil;
   NSMutableDictionary*m=[meta isKindOfClass:[NSDictionary class]]?[meta mutableCopy]:[NSMutableDictionary dictionary];m[@"path"]=p;NSMutableArray*names=[NSMutableArray array];
   for(NSDictionary*a in m[@"apps"])if(![a[@"bundle"] isEqualToString:@"local.LegacyScreenRecorder"]&&[a[@"name"] length]&&![names containsObject:a[@"name"]])[names addObject:a[@"name"]];
   m[@"title"]=names.count?[names componentsJoinedByString:@"、"]:@"屏幕录像";NSDictionary*attrs=[fm attributesOfItemAtPath:p error:NULL];
   m[@"detail"]=[NSString stringWithFormat:@"%@ · %@ · %.1f MB",[df stringFromDate:attrs[NSFileCreationDate]?:[NSDate date]],LSRDuration([m[@"elapsed"] doubleValue]),[attrs[NSFileSize] doubleValue]/1048576.];[list addObject:m];
  }
  [list sortUsingComparator:^NSComparisonResult(id a,id b){return[b[@"path"] compare:a[@"path"]];}];
  dispatch_async(dispatch_get_main_queue(),^{
   self->catalogBusy=NO;self->movies=list;NSMutableSet*valid=[NSMutableSet set];for(NSDictionary*m in list)[valid addObject:m[@"path"]];[self->chosenPaths intersectSet:valid];
   self->emptyLabel.hidden=list.count>0;[self->library reloadData];[self updateGallery];[self updateSelectionUI];[self.view setNeedsLayout];
   if(self->catalogAgain){self->catalogAgain=NO;[self reloadMovies];}
  });
 }});
}
-(NSInteger)collectionView:(UICollectionView*)c numberOfItemsInSection:(NSInteger)s{return movies.count;}
-(UICollectionViewCell*)collectionView:(UICollectionView*)c cellForItemAtIndexPath:(NSIndexPath*)p{
 LSRMovieCell*cell=[c dequeueReusableCellWithReuseIdentifier:@"movie" forIndexPath:p];NSDictionary*m=movies[p.item];cell.path=m[@"path"];cell.mode=mode;cell.selectionMode=selecting;cell.checked=selecting?[chosenPaths containsObject:cell.path]:mode==2&&[cell.path isEqualToString:[self selectedMovie][@"path"]];
 cell.title.text=m[@"title"];cell.detail.text=m[@"detail"];cell.thumbnail.image=nil;cell.accessibilityLabel=[NSString stringWithFormat:@"%@，%@%@",m[@"title"],m[@"detail"],selecting?(cell.checked?@"，已选择":@"，未选择"):@""];[cell setNeedsLayout];
 NSString*path=cell.path;__weak LSRMovieCell*weak=cell;[[LSRThumbnailStore shared] imageFor:path completion:^(UIImage*im){LSRMovieCell*v=weak;if([v.path isEqualToString:path])v.thumbnail.image=im;}];return cell;
}
-(void)collectionView:(UICollectionView*)c didSelectItemAtIndexPath:(NSIndexPath*)p{
 [c deselectItemAtIndexPath:p animated:NO];if(mediaBusy)return;NSDictionary*m=movies[p.item];
 if(mode==2)selectedPath=m[@"path"];
 if(selecting){[self toggleMovie:m];if(mode==2)[self updateGallery];}
 else if(mode==2){[self updateGallery];[library reloadData];}else[self play:m];
}
-(NSDictionary*)selectedMovie{for(NSDictionary*m in movies)if([m[@"path"] isEqualToString:selectedPath])return m;return movies.firstObject;}
-(void)updateGallery{
 NSDictionary*m=[self selectedMovie];selectedPath=m[@"path"];galleryCaption.text=m?[NSString stringWithFormat:@"%@ · %@ · %@",m[@"title"],m[@"detail"],selecting?@"点按选择":@"点按播放"]:@"";galleryImage.image=nil;
 if(mode==2&&m){NSString*path=m[@"path"];[[LSRThumbnailStore shared] imageFor:path completion:^(UIImage*im){if([self->selectedPath isEqualToString:path])self->galleryImage.image=im;}];}
}
-(void)changeMode:(UISegmentedControl*)s{mode=s.selectedSegmentIndex;[LSRDefaults() setInteger:mode forKey:@"libraryMode"];[library reloadData];[self.view setNeedsLayout];[self updateGallery];}
-(void)playGallery{NSDictionary*m=[self selectedMovie];if(m){if(selecting){if(!mediaBusy)[self toggleMovie:m];}else[self play:m];}}
-(void)play:(NSDictionary*)m{if([self running]||mediaBusy)return;AVPlayerViewController*p=[AVPlayerViewController new];p.player=[AVPlayer playerWithURL:[NSURL fileURLWithPath:m[@"path"]]];[self presentViewController:p animated:YES completion:^{[p.player play];}];}
-(void)hold:(UILongPressGestureRecognizer*)g{if(selecting||g.state!=UIGestureRecognizerStateBegan)return;NSIndexPath*p=[library indexPathForItemAtPoint:[g locationInView:library]];if(p&&p.item<movies.count)[self preview:movies[p.item] source:[library cellForItemAtIndexPath:p]];}
-(void)holdGallery:(UILongPressGestureRecognizer*)g{if(!selecting&&g.state==UIGestureRecognizerStateBegan&&[self selectedMovie])[self preview:[self selectedMovie] source:galleryImage];}
-(void)preview:(NSDictionary*)m source:(UIView*)source{
 if([self running]||mediaBusy||self.presentedViewController)return;LSRMiniPreview*p=[LSRMiniPreview new];p.movie=m;p.modalPresentationStyle=UIModalPresentationPopover;p.popoverPresentationController.sourceView=source;p.popoverPresentationController.sourceRect=source.bounds;p.popoverPresentationController.delegate=self;
 __weak LSRController*weak=self;p.shareAction=^{[weak shareMovies:@[m]];};p.deleteAction=^{[weak confirmDelete:@[m]];};[self presentViewController:p animated:YES completion:nil];
}
-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController*)c{return UIModalPresentationNone;}
-(void)updateSelectionUI{
 self.title=selecting?[NSString stringWithFormat:@"已选择 %lu 项",(unsigned long)chosenPaths.count]:@"录屏大师";
 selectButton.title=selecting?@"完成":@"选择";selectButton.enabled=!mediaBusy&&![self running]&&(movies.count||selecting);
 self.navigationItem.rightBarButtonItem=selecting?allButton:settingsButton;
 allButton.title=movies.count&&chosenPaths.count==movies.count?@"取消全选":@"全选";allButton.enabled=!mediaBusy&&movies.count>0;
 BOOL enabled=chosenPaths.count>0&&!mediaBusy&&![self running];shareButton.enabled=saveButton.enabled=deleteButton.enabled=enabled;
 settingsButton.enabled=!mediaBusy;batchBar.hidden=!selecting;modes.enabled=!mediaBusy;
}
-(void)toggleSelection{if(mediaBusy||[self running])return;if(selecting){[self endSelection];return;}selecting=YES;[chosenPaths removeAllObjects];[library reloadData];[self updateGallery];[self updateSelectionUI];[self.view setNeedsLayout];}
-(void)endSelection{selecting=NO;[chosenPaths removeAllObjects];[library reloadData];[self updateGallery];[self updateSelectionUI];[self.view setNeedsLayout];}
-(void)toggleMovie:(NSDictionary*)m{NSString*p=m[@"path"];if([chosenPaths containsObject:p])[chosenPaths removeObject:p];else[chosenPaths addObject:p];[library reloadData];[self updateSelectionUI];}
-(void)selectAll{if(mediaBusy)return;BOOL clear=chosenPaths.count==movies.count;[chosenPaths removeAllObjects];if(!clear)for(NSDictionary*m in movies)[chosenPaths addObject:m[@"path"]];[library reloadData];[self updateSelectionUI];}
-(NSArray*)selectedMovies{NSMutableArray*a=[NSMutableArray array];for(NSDictionary*m in movies)if([chosenPaths containsObject:m[@"path"]])[a addObject:m];return a;}
-(void)shareSelected{[self shareMovies:[self selectedMovies]];}
-(void)shareMovies:(NSArray*)items{
 if(!items.count||mediaBusy||[self running])return;NSMutableArray*urls=[NSMutableArray array];for(NSDictionary*m in items)[urls addObject:[NSURL fileURLWithPath:m[@"path"]]];
 UIActivityViewController*a=[[UIActivityViewController alloc] initWithActivityItems:urls applicationActivities:nil];a.popoverPresentationController.sourceView=self.view;a.popoverPresentationController.sourceRect=CGRectMake(self.view.bounds.size.width/2,self.view.bounds.size.height-48,1,1);[self presentViewController:a animated:YES completion:nil];
}
-(void)notice:(NSString*)title message:(NSString*)message{UIAlertController*a=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}
-(void)deleteSelected{[self confirmDelete:[self selectedMovies]];}
-(void)confirmDelete:(NSArray*)items{
 if(!items.count||mediaBusy||[self running])return;UIAlertController*a=[UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"删除 %lu 段录像？",(unsigned long)items.count] message:@"将删除所选录像及其缩略图，无法撤销。已存到相册的副本不受影响。" preferredStyle:UIAlertControllerStyleAlert];
 [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[a addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction*x){[self deleteMovies:items];}]];[self presentViewController:a animated:YES completion:nil];
}
-(void)deleteMovies:(NSArray*)items{
 mediaBusy=YES;[self refresh];dispatch_async(catalogQueue,^{@autoreleasepool{
  NSMutableArray*failed=[NSMutableArray array];NSFileManager*fm=[NSFileManager defaultManager];
  for(NSDictionary*m in items){NSString*p=m[@"path"];NSError*e=nil;if([fm removeItemAtPath:p error:&e]||![fm fileExistsAtPath:p]){[fm removeItemAtPath:[p stringByAppendingString:@".json"] error:NULL];[[LSRThumbnailStore shared] remove:p];}else[failed addObject:m];}
  dispatch_async(dispatch_get_main_queue(),^{self->mediaBusy=NO;self->selectedPath=nil;if(!failed.count)[self endSelection];[self reloadMovies];[self refresh];if(failed.count)[self notice:@"部分录像未能删除" message:[NSString stringWithFormat:@"%lu 段删除失败，请检查文件权限。",(unsigned long)failed.count]];});
 }});
}
-(void)saveSelected{
 NSArray*items=[self selectedMovies];if(!items.count||mediaBusy||[self running])return;mediaBusy=YES;[self refresh];
 [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus permission){dispatch_async(dispatch_get_main_queue(),^{if(permission!=PHAuthorizationStatusAuthorized){self->mediaBusy=NO;[self refresh];[self notice:@"未获得相册权限" message:@"请在系统设置的隐私／照片中允许录屏大师，然后重试。录像仍保存在本应用中。"];return;}[self saveNext:items index:0 succeeded:0];});}];
}
-(void)saveNext:(NSArray*)items index:(NSUInteger)index succeeded:(NSUInteger)succeeded{
 if(index==items.count){
#ifdef LSR_TESTING
 [[NSJSONSerialization dataWithJSONObject:@{@"saved":@(succeeded),@"total":@(items.count)} options:0 error:NULL] writeToFile:@LSR_DIR "/save-test.json" atomically:YES];
#endif
 mediaBusy=NO;[self refresh];[self notice:@"保存完成" message:[NSString stringWithFormat:@"已存到相册 %lu 段%@。",(unsigned long)succeeded,succeeded==items.count?@"":[NSString stringWithFormat:@"，%lu 段未能保存（可能空间不足或格式不受支持）",(unsigned long)(items.count-succeeded)]]];return;}
 NSURL*url=[NSURL fileURLWithPath:items[index][@"path"]];__block BOOL created=NO;
 [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{created=[PHAssetChangeRequest creationRequestForAssetFromVideoAtFileURL:url]!=nil;} completionHandler:^(BOOL success,NSError*error){dispatch_async(dispatch_get_main_queue(),^{[self saveNext:items index:index+1 succeeded:succeeded+(success&&created?1:0)];});}];
}
#ifdef LSR_TESTING
-(void)testUI:(NSString*)name{
 if(catalogBusy){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{[self testUI:name];});return;}
 if([name isEqualToString:@"mic-off"]){[LSRDefaults() setBool:NO forKey:@"microphone"];return;}
 if([name isEqualToString:@"preview"]){if(movies.count)[self preview:movies[0] source:card];return;}
 mode=[name isEqualToString:@"gallery"]?2:[name isEqualToString:@"list"]?0:1;modes.selectedSegmentIndex=mode;[self changeMode:modes];
 if([name hasPrefix:@"select"]||[name hasPrefix:@"fixture"]){[self toggleSelection];NSUInteger n=0;for(NSDictionary*m in movies){if([name hasPrefix:@"fixture"]&&![[m[@"path"] lastPathComponent] hasPrefix:@"LSR-TEST-041-"])continue;[self toggleMovie:m];if(++n==2)break;}}
 if([name isEqualToString:@"select-share"])[self shareSelected];
 if([name isEqualToString:@"select-delete"])[self deleteSelected];
 if([name isEqualToString:@"fixture-delete"]){NSArray*items=[self selectedMovies];if(items.count==2)[self deleteMovies:items];}
 if([name isEqualToString:@"fixture-views"]){NSUInteger n=chosenPaths.count;for(int i=0;i<3;i++){modes.selectedSegmentIndex=i;[self changeMode:modes];NSAssert(chosenPaths.count==n,@"Selection lost across views");}[self selectAll];NSAssert(chosenPaths.count==movies.count,@"Select all failed");[self selectAll];NSAssert(chosenPaths.count==0,@"Deselect all failed");}
 if([name isEqualToString:@"fixture-save"]&&[PHPhotoLibrary authorizationStatus]==PHAuthorizationStatusAuthorized)[self saveSelected];
 NSDictionary*probe=@{@"title":self.title?:@"",@"selected":@(chosenPaths.count),@"photos":@([PHPhotoLibrary authorizationStatus]),@"items":@(movies.count)};
 [[NSJSONSerialization dataWithJSONObject:probe options:0 error:NULL] writeToFile:@LSR_DIR "/ui-test.json" atomically:YES];
}
#endif
-(void)dealloc{[poll invalidate];[[NSNotificationCenter defaultCenter] removeObserver:self];[microphone stop];}
@end
@interface LSRApp:UIResponder<UIApplicationDelegate>@property(nonatomic,strong)UIWindow*window;@property(nonatomic,strong)UINavigationController*navigation;@end
@implementation LSRApp
-(BOOL)application:(UIApplication*)app didFinishLaunchingWithOptions:(NSDictionary*)options{self.window=[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];LSRController*c=[LSRController new];self.navigation=[[UINavigationController alloc] initWithRootViewController:c];self.window.rootViewController=self.navigation;[self.window makeKeyAndVisible];
#ifdef LSR_TESTING
NSString*m=[NSString stringWithContentsOfFile:@LSR_DIR "/test-mode" encoding:NSUTF8StringEncoding error:NULL];m=[m stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];if(m.length)dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{if([m hasPrefix:@"ui-"]){NSString*mode=[m substringFromIndex:3];if([mode isEqualToString:@"settings"])[c settings];else if([mode isEqualToString:@"record"])[c record];else[c testUI:mode];}else[self.navigation pushViewController:[[LSRPattern alloc] initWithMode:m] animated:NO];});
#endif
return YES;}
@end
int main(int argc,char**argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass([LSRApp class]));}}
