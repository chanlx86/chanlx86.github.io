#!/usr/bin/env python3
"""Package pre-signed files from output/signed. Signing is deliberately separate."""
import io,tarfile,time,shutil,json,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent.parent
signed=root/'output/signed';stage=root/'output/package';shutil.rmtree(stage,ignore_errors=True);stage.mkdir(parents=True)
files={'LegacyRecorder.app':'Applications/LegacyRecorder.app','lsr-recorderd':'usr/libexec/lsr-recorderd','lsrctl':'usr/bin/lsrctl','LegacyRecorderAudio.dylib':'Library/MobileSubstrate/DynamicLibraries/LegacyRecorderAudio.dylib'}
for source,dest in files.items():
 p=stage/dest;p.parent.mkdir(parents=True,exist_ok=True)
 if (signed/source).is_dir():shutil.copytree(signed/source,p)
 else:shutil.copy2(signed/source,p)
for source,dest in [('AudioTap.plist','Library/MobileSubstrate/DynamicLibraries/LegacyRecorderAudio.plist'),('LaunchDaemon.plist','Library/LaunchDaemons/local.legacy.recorder.plist'),('README.md','Library/Application Support/LegacyScreenRecorder/README.md')]:
 p=stage/dest;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/source,p)
def archive(base):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w:gz',format=tarfile.USTAR_FORMAT) as tar:
  for p in sorted(base.rglob('*')):
   info=tar.gettarinfo(str(p),'./'+str(p.relative_to(base)));info.uid=info.gid=0;info.uname=info.gname='root';info.mode=0o755 if p.is_dir() or p.name in ['postinst','prerm','postrm','LegacyRecorder','lsrctl','lsr-recorderd'] or p.suffix=='.dylib' else 0o644
   with p.open('rb') if p.is_file() else io.BytesIO() as f:tar.addfile(info,f if p.is_file() else None)
 return out.getvalue()
result=root/'dist';result.mkdir(exist_ok=True);dest=result/'local.legacy.screenrecorder_0.4.1_iphoneos-arm.deb'
with dest.open('wb') as out:
 out.write(b'!<arch>\n')
 for name,data in [('debian-binary',b'2.0\n'),('control.tar.gz',archive(root/'packaging')),('data.tar.gz',archive(stage))]:
  out.write(f'{name+"/":<16}{int(time.time()):<12}{0:<6}{0:<6}{100644:<8}{len(data):<10}`\n'.encode());out.write(data)
  if len(data)%2:out.write(b'\n')
manifest={str(p.relative_to(stage)):hashlib.sha256(p.read_bytes()).hexdigest() for p in stage.rglob('*') if p.is_file()}
(result/'installed-files.sha256.json').write_text(json.dumps(manifest,indent=2));print(dest)
