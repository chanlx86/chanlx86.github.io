// Test-only synthetic touch descriptions, passed directly to the observer.
@interface LSRTestTouch:NSObject
@property(nonatomic)CGPoint point;
@property(nonatomic)UITouchPhase phase;
@property(nonatomic,strong)UIWindow*window;
-(CGPoint)locationInView:(UIView*)view;
@end
@implementation LSRTestTouch
-(CGPoint)locationInView:(UIView*)view{return self.point;}
@end
@interface LSRTestEvent:NSObject
@property(nonatomic,strong)NSSet*allTouches;
-(UIEventType)type;
@end
@implementation LSRTestEvent
-(UIEventType)type{return UIEventTypeTouches;}
@end
@interface LSROverlayCheck:NSObject
+(void)run;
@end
@implementation LSROverlayCheck
+(void)run{LSRRequest(@{@"command":@"start",@"audio":@NO,@"microphone":@NO,@"showIndicator":@YES,@"showTouches":@YES,@"delay":@0});dispatch_after(dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC),dispatch_get_main_queue(),^{NSMutableDictionary*r=[NSMutableDictionary dictionary];UIWindow*w=nil;UIViewController*c=nil;for(UIWindow*window in [UIApplication sharedApplication].windows)if([NSStringFromClass(window.rootViewController.class) isEqualToString:@"LSRRecordingOverlayController"]){w=window;c=window.rootViewController;break;}UIButton*b=[c valueForKey:@"button"];r[@"floatVisible"]=@(w&&!w.hidden&&b&&!b.hidden);r[@"passthrough"]=@(w&&[w hitTest:CGPointMake(3,3) withEvent:nil]==nil);r[@"floatHit"]=@(b&&[w hitTest:[b convertPoint:CGPointMake(60,19) toView:w] withEvent:nil]==b);CALayer*ring=[b valueForKey:@"ring"];r[@"breathing"]=@([ring animationForKey:@"breathe"]!=nil&&![ring animationForKey:@"rotate"]);[c setValue:[NSValue valueWithCGPoint:CGPointMake(2,-1)] forKey:@"relativePosition"];[c setValue:@YES forKey:@"positioned"];[c viewDidLayoutSubviews];r[@"dragClamped"]=@(CGRectContainsRect(c.view.bounds,b.frame));LSRTestEvent*e=[LSRTestEvent new];NSMutableSet*touches=[NSMutableSet set];for(int i=0;i<14;i++){LSRTestTouch*t=[LSRTestTouch new];t.window=[UIApplication sharedApplication].keyWindow;t.point=CGPointMake(130+i*30,230+i*10);t.phase=UITouchPhaseBegan;[touches addObject:t];}e.allTouches=touches;[c performSelector:NSSelectorFromString(@"observeEvent:") withObject:e];NSDictionary*traces=[c valueForKey:@"traces"];r[@"boundedMultitouch"]=@(traces.count==10);UIGraphicsBeginImageContextWithOptions(w.bounds.size,YES,1);[[UIApplication sharedApplication].keyWindow drawViewHierarchyInRect:w.bounds afterScreenUpdates:NO];[w.layer renderInContext:UIGraphicsGetCurrentContext()];[UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext()) writeToFile:@LSR_DIR "/overlay-test.png" atomically:YES];UIGraphicsEndImageContext();for(LSRTestTouch*t in touches)t.phase=UITouchPhaseEnded;[c performSelector:NSSelectorFromString(@"observeEvent:") withObject:e];r[@"endedRemoved"]=@([[c valueForKey:@"traces"] count]==0);LSRRequest(@{@"command":@"touches",@"showTouches":@NO});LSRRequest(@{@"command":@"indicator",@"showIndicator":@NO});dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{r[@"hiddenLive"]=@(w.hidden&&![[c valueForKey:@"touchesEnabled"] boolValue]);LSRRequest(@{@"command":@"indicator",@"showIndicator":@YES});dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{[b sendActionsForControlEvents:UIControlEventTouchUpInside];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{r[@"tapStops"]=@(![LSRRequest(@{@"command":@"status"})[@"state"] isEqual:@"recording"]);[[NSJSONSerialization dataWithJSONObject:r options:0 error:NULL] writeToFile:@LSR_DIR "/overlay-test.json" atomically:YES];});});});});}
@end
