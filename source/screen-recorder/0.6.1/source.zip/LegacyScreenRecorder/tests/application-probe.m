#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <dlfcn.h>
#include <objc/message.h>
#include <objc/runtime.h>
int main(int argc,char**argv){@autoreleasepool{
 void*h=dlopen("/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices",RTLD_NOW);CFStringRef(*front)(void)=h?dlsym(h,"SBSCopyFrontmostApplicationDisplayIdentifier"):NULL;
 printf("front API=%d\n",front!=NULL);if(front){CFStringRef f=front();NSLog(@"front=%@",(__bridge id)f);if(f)CFRelease(f);}
 Class p=NSClassFromString(@"LSApplicationProxy");for(NSString*b in @[@"com.apple.EscrowSecurityAlert",@"com.cloudmosa.PuffinFree",@"com.popcap.ios.chs.PvZiPad",@"com.apple.mobiletimer"]){id a=((id(*)(id,SEL,id))objc_msgSend)(p,NSSelectorFromString(@"applicationProxyForIdentifier:"),b);NSMutableDictionary*d=[NSMutableDictionary dictionaryWithObject:b forKey:@"bundle"];for(NSString*k in @[@"localizedName",@"bundleURL",@"applicationType",@"appTags",@"applicationIdentifier",@"isLaunchProhibited"]){SEL s=NSSelectorFromString(k);if([a respondsToSelector:s]){if([k hasPrefix:@"is"])d[k]=@(((BOOL(*)(id,SEL))objc_msgSend)(a,s));else{ id v=((id(*)(id,SEL))objc_msgSend)(a,s);if(v)d[k]=[v description];}}}NSLog(@"%@",d);}
 Class ac=NSClassFromString(@"SBSStatusBarStyleOverridesAssertion");for(int bit=0;bit<15;bit++){id a=((id(*)(id,SEL,int,int,BOOL,BOOL))objc_msgSend)([ac alloc],NSSelectorFromString(@"initWithStatusBarStyleOverrides:forPID:exclusive:showsWhenForeground:"),1<<bit,getpid(),YES,YES);@try{NSLog(@"FLAG %x %@",1<<bit,[a valueForKey:@"assertionData"]);}@catch(NSException*e){}}
 for(NSString*n in @[@"UIStatusBarServer",@"SBSStatusBarStyleOverridesAssertion"]){Class c=NSClassFromString(n);NSLog(@"class %@=%@",n,c);for(int meta=0;meta<2;meta++){unsigned count=0;Method*ms=class_copyMethodList(meta?object_getClass(c):c,&count);for(unsigned i=0;i<count;i++){const char*name=sel_getName(method_getName(ms[i]));if(strstr(name,"Style")||strstr(name,"style")||strstr(name,"Override")||strstr(name,"Status")||strstr(name,"quire")||strstr(name,"invalidate"))printf("%s %s %s\n",meta?"+":"-",name,method_getTypeEncoding(ms[i]));}free(ms);}}
}return 0;}
