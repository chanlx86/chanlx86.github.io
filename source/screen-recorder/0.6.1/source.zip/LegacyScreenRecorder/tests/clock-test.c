#include "../SampleClock.h"
#include <assert.h>
#include <stdio.h>
int main(void){LSRSampleClock c={0};uint64_t base=1000000000ULL;for(int i=0;i<1000;i++){double sample=i*512.0;uint64_t expected=base+(uint64_t)llround(sample/44100*1e9);int64_t jitter=i==0?0:(i%7-3)*500000;uint64_t got=LSRClockHost(&c,1,44100,expected+jitter,sample,1,512,1e9);assert(got==expected);}uint64_t resume=base+20ULL*1000000000ULL;assert(LSRClockHost(&c,1,44100,resume,512000,1,512,1e9)==resume);assert(LSRClockHost(&c,1,44100,resume+100000000,0,1,512,1e9)==resume+100000000);assert(LSRClockHost(&c,2,44100,resume+200000000,0,0,512,1e9)==resume+200000000);puts("Sample clock: 1000 jittered packets continuous; pause, reset and new recording preserved PASS");}
