#include <stdatomic.h>
#include <stdint.h>
#include <pthread.h>
#include <stdlib.h>
#include <assert.h>
#include <sched.h>
#include <stdio.h>
#include "../Protocol.h"
static _Atomic uint32_t produced,consumed;
#include "../PacketRing.h"
static uint32_t values[LSR_RING];enum {COUNT=100000,THREADS=4};
static void*produce(void*context){uint32_t id=(uint32_t)(uintptr_t)context;for(uint32_t i=0;i<COUNT;i++){uint32_t p;while(!packetReserve(&p))sched_yield();values[p%LSR_RING]=id*COUNT+i;packetPublish(p);}return NULL;}
int main(void){packetRingInit();uint32_t a,b;assert(packetReserve(&a)&&packetReserve(&b));values[b%LSR_RING]=2;packetPublish(b);assert(!packetReady(a));values[a%LSR_RING]=1;packetPublish(a);assert(packetReady(a));packetRelease(a);assert(packetReady(b));packetRelease(b);atomic_store(&produced,0);atomic_store(&consumed,0);packetRingInit();unsigned char*seen=calloc(COUNT*THREADS,1);pthread_t threads[THREADS];for(uintptr_t i=0;i<THREADS;i++)assert(!pthread_create(&threads[i],NULL,produce,(void*)i));uint32_t read=0;while(read<COUNT*THREADS){uint32_t p=atomic_load(&consumed);if(!packetReady(p)){sched_yield();continue;}uint32_t value=values[p%LSR_RING];assert(value<COUNT*THREADS&&!seen[value]);seen[value]=1;packetRelease(p);read++;}for(int i=0;i<THREADS;i++)pthread_join(threads[i],NULL);free(seen);puts("4 concurrent producers: 400000 unique packets, ordered publish and reuse PASS");}
