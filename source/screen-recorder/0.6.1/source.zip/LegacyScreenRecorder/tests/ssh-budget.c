#include <sys/sysctl.h>
#include <sys/types.h>
#include <unistd.h>
#include <dlfcn.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
int main(void){int(*control)(uint32_t,int32_t,uint32_t,void*,size_t)=dlsym(RTLD_DEFAULT,"memorystatus_control");if(!control)return 2;pid_t pid=getppid();for(int i=0;i<8&&pid>1;i++){int mib[]={CTL_KERN,KERN_PROC,KERN_PROC_PID,pid};struct kinfo_proc k;size_t n=sizeof k;if(sysctl(mib,4,&k,&n,NULL,0)||n<sizeof k)break;pid_t parent=k.kp_eproc.e_ppid;if(!strncmp(k.kp_proc.p_comm,"sshd",4)){int before[4]={0};control(8,pid,0,before,sizeof before);printf("diagnostic ssh session pid=%d cap=%d ->32MB rc=%d\n",pid,before[0],control(6,pid,32,NULL,0));}pid=parent;}return 0;}
