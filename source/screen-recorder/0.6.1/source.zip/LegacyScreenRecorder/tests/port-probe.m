#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <unistd.h>
int main(void){int(*m)(unsigned,int,unsigned,void*,size_t)=dlsym(RTLD_DEFAULT,"memorystatus_control");if(m)m(6,getpid(),32,NULL,0);@autoreleasepool{void*h=dlopen("/usr/lib/librocketbootstrap.dylib",RTLD_NOW);CFMessagePortRef(*create)(CFAllocatorRef,CFStringRef)=dlsym(h,"rocketbootstrap_cfmessageportcreateremote");CFMessagePortRef p=create?create(NULL,CFSTR("local.legacy.recorder.audio")):NULL;printf("port=%d\n",p!=NULL);CFDataRef reply=NULL;if(p){int r=CFMessagePortSendRequest(p,1,NULL,1,1,kCFRunLoopDefaultMode,&reply);printf("result=%d\n",r);if(reply){fwrite(CFDataGetBytePtr(reply),1,CFDataGetLength(reply),stdout);CFRelease(reply);}CFRelease(p);}}return 0;}
