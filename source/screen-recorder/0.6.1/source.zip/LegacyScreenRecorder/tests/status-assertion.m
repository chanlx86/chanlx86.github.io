#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <objc/message.h>
#include <unistd.h>
int main(int argc,char**argv){@autoreleasepool{dlopen("/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices",RTLD_NOW);Class c=NSClassFromString(@"SBSStatusBarStyleOverridesAssertion");if(!c)return 2;id a=((id(*)(id,SEL,int,int,BOOL,BOOL))objc_msgSend)([c alloc],NSSelectorFromString(@"initWithStatusBarStyleOverrides:forPID:exclusive:showsWhenForeground:"),4,argc>1?atoi(argv[1]):getpid(),YES,YES);[a setValue:@"◉ 正在录制 00:01" forKey:@"statusString"];((void(*)(id,SEL,id,id))objc_msgSend)(a,NSSelectorFromString(@"acquireWithHandler:invalidationHandler:"),^(BOOL ok){NSLog(@"recording assertion acquired=%d",ok);},^{NSLog(@"recording assertion invalidated");});[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:8]];((void(*)(id,SEL))objc_msgSend)(a,NSSelectorFromString(@"invalidate"));}return 0;}
