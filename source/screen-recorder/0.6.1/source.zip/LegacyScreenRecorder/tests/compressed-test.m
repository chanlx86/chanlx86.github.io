#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
#if !TARGET_OS_IPHONE
#define kAppleSoftwareAudioCodecManufacturer 'appl'
#endif
#include "../CompressedDecoder.h"
int main(int argc,char**argv){@autoreleasepool{if(argc<2)return 2;FILE*out=argc>2?fopen(argv[2],"wb"):NULL;AudioFileID file=NULL;OSStatus e=AudioFileOpenURL((__bridge CFURLRef)[NSURL fileURLWithPath:@(argv[1])],kAudioFileReadPermission,0,&file);if(e)return 3;LSREncodedPacket*p=calloc(1,sizeof *p);UInt32 n=sizeof p->format;AudioFileGetProperty(file,kAudioFilePropertyDataFormat,&n,&p->format);n=sizeof p->cookie;if(!AudioFileGetProperty(file,kAudioFilePropertyMagicCookieData,&n,p->cookie))p->cookieBytes=n;LSRCompressedDecoder*d=[LSRCompressedDecoder new];SInt64 at=0;uint64_t frames=0;for(;;){UInt32 count=17,bytes=sizeof p->data;e=AudioFileReadPacketData(file,false,&bytes,p->descriptions,at,&count,p->data);if(!count)break;p->packets=count;p->bytes=bytes;NSData*pcm=[d decode:p];if(d.lastError){printf("decoder %d\n",(int)d.lastError);return 4;}if(out)fwrite(pcm.bytes,1,pcm.length,out);frames+=pcm.length/4;at+=count;}uint64_t expected=at*p->format.mFramesPerPacket;printf("AAC packets=%lld frames=%llu expected=%llu\n",at,frames,expected);if(out)fclose(out);AudioFileClose(file);free(p);return frames==expected?0:5;}}
