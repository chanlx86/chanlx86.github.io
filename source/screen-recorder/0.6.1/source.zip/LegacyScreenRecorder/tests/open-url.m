#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <dlfcn.h>
int main(int argc,char**argv){@autoreleasepool{if(argc!=2)return 2;NSURL*u=[NSURL URLWithString:@(argv[1])];if(![u.scheme isEqualToString:@"nplayer-http"]||![u.host isEqualToString:@"127.0.0.1"])return 2;dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",RTLD_NOW);id w=((id(*)(id,SEL))objc_msgSend)(NSClassFromString(@"LSApplicationWorkspace"),NSSelectorFromString(@"defaultWorkspace"));SEL s=NSSelectorFromString(@"openURL:withOptions:");if(![w respondsToSelector:s])return 3;BOOL ok=((BOOL(*)(id,SEL,id,id))objc_msgSend)(w,s,u,@{});printf("open=%d\n",ok);return ok?0:4;}}
