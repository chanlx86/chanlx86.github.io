#import <Foundation/Foundation.h>
#include <dlfcn.h>
#include <stdint.h>
int main(int argc,char**argv){@autoreleasepool{dlopen("/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox",RTLD_NOW);dlopen("/System/Library/Frameworks/MediaToolbox.framework/MediaToolbox",RTLD_NOW);NSMutableDictionary*out=[NSMutableDictionary dictionary];for(int i=1;i<argc;i++){uintptr_t p=(uintptr_t)dlsym(RTLD_DEFAULT,argv[i]);if(p){NSData*d=[NSData dataWithBytes:(void*)(p&~1) length:4096];out[@(argv[i])]=@{@"address":@(p),@"data":[d base64EncodedStringWithOptions:0]};}}NSData*d=[NSJSONSerialization dataWithJSONObject:out options:0 error:NULL];fwrite(d.bytes,1,d.length,stdout);}return 0;}
