#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "../ApplicationCatalog.h"
int main(void){@autoreleasepool{
 NSArray*old=@[@{@"bundle":@"com.apple.EscrowSecurityAlert",@"name":@"EscrowSecurityAlert"},@{@"bundle":@"com.cloudmosa.PuffinFree",@"name":@"应用"}];NSCAssert([LSRRecordingTitle(old) isEqualToString:@"Puffin"],@"Hidden service must not win; resolve registered display name");
 NSArray*timed=@[@{@"bundle":@"local.LegacyScreenRecorder",@"name":@"录屏大师",@"seconds":@99},@{@"bundle":@"com.apple.mobiletimer",@"name":@"时钟",@"seconds":@2},@{@"bundle":@"com.cloudmosa.PuffinFree",@"name":@"Puffin",@"seconds":@8}];NSCAssert([LSRRecordingTitle(timed) isEqualToString:@"Puffin"],@"Use longest meaningful app, exclude recorder");
 NSString*s=LSRFilenameComponent(@" ../Puffin:浏览器\\\n 🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥🎥");NSCAssert(s.length<=48&&[s dataUsingEncoding:NSUTF8StringEncoding]&&[s rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\:\n"]].location==NSNotFound,@"Safe Unicode filename component");puts("Hidden service filtering, Puffin display name, duration preference, Unicode filename PASS");}return 0;}
