#ifndef LSR_CAPTURE_POLICY_H
#define LSR_CAPTURE_POLICY_H
#include <string.h>
// iPad (3rd generation): iPad3,1–3; iPad (4th generation): iPad3,4–6.
static int LSRRetinaModel(const char*model){return model&&strlen(model)==7&&!strncmp(model,"iPad3,",6)&&model[6]>='1'&&model[6]<='6';}
static int LSRCaptureDivisor(const char*model,int retina){return LSRRetinaModel(model)&&!retina?2:1;}
static int LSRBitrateLevel(int level){return level<0?0:level>2?2:level;}
static int LSRVideoBitrate(int level){const int rates[]={1200000,2500000,5000000};return rates[LSRBitrateLevel(level)];}
static double LSRJPEGQuality(int level){const double qualities[]={.55,.8,.92};return qualities[LSRBitrateLevel(level)];}
#ifdef __OBJC__
#include <sys/sysctl.h>
static NSString*LSRDeviceModel(void){static NSString*model;static dispatch_once_t once;dispatch_once(&once,^{char buffer[64]={0};size_t size=sizeof buffer;if(!sysctlbyname("hw.machine",buffer,&size,NULL,0))model=[NSString stringWithUTF8String:buffer];else model=@"unknown";});return model;}
static BOOL LSRHasRetinaOption(void){return LSRRetinaModel(LSRDeviceModel().UTF8String);}
#endif
#endif
