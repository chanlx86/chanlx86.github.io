#ifndef LSR_DOWNSAMPLE_H
#define LSR_DOWNSAMPLE_H
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#if defined(__ARM_NEON__)
#include <arm_neon.h>
#endif
// Integer sampling or native-size copy, without temporary allocation.
static void LSRDownsampleBGRA(const void*source,size_t sourceStride,void*dest,size_t destStride,size_t width,size_t height,unsigned step){
 for(size_t y=0;y<height;y++){const uint32_t*s=(const uint32_t*)((const char*)source+y*step*sourceStride);uint32_t*d=(uint32_t*)((char*)dest+y*destStride);if(step==1){memcpy(d,s,width*4);continue;}size_t x=0;
#if defined(__ARM_NEON__)
  for(;step==2&&x+4<=width;x+=4){uint32x4x2_t p=vld2q_u32(s+x*2);vst1q_u32(d+x,p.val[0]);}
#endif
  for(;x<width;x++)d[x]=s[x*step];
 }
}
#endif
