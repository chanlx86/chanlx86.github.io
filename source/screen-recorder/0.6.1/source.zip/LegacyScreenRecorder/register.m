#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <dlfcn.h>
int main(int argc,char**argv){@autoreleasepool{dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",RTLD_NOW);Class cls=NSClassFromString(@"LSApplicationWorkspace");id w=((id(*)(id,SEL))objc_msgSend)(cls,NSSelectorFromString(@"defaultWorkspace"));BOOL registered=((BOOL(*)(id,SEL,id))objc_msgSend)(w,NSSelectorFromString(@"registerApplication:"),[NSURL fileURLWithPath:@"/Applications/LegacyRecorder.app"]);printf("register=%d\n",registered);BOOL launched=((BOOL(*)(id,SEL,id))objc_msgSend)(w,NSSelectorFromString(@"openApplicationWithBundleID:"),(argc>1?@(argv[1]):@"local.LegacyScreenRecorder"));printf("launch=%d\n",launched);return launched?0:2;}}
