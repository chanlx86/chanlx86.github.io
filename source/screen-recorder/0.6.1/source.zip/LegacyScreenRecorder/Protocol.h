#ifndef LSR_PROTOCOL_H
#define LSR_PROTOCOL_H
#include <stdint.h>
#define LSR_DIR "/var/mobile/Library/LegacyScreenRecorder"
#define LSR_MOVIES "/var/mobile/Media/LegacyScreenRecorder"
#define LSR_CONTROL LSR_DIR "/control.sock"
#define LSR_AUDIO LSR_DIR "/audio.sock"
#define LSR_ACTIVE LSR_DIR "/active.json"
#define LSR_STATUS LSR_DIR "/status.json"
#define LSR_MAGIC 0x4c535231u
#define LSR_PACKET_FRAMES 1024
#define LSR_RING 128
#define LSR_RATE 44100
#define LSR_AUDIO_RING (LSR_RATE*8)
typedef struct {uint32_t magic,tag,pid,source,rate,frames;uint64_t host;int16_t samples[LSR_PACKET_FRAMES*2];} LSRPacket;
#endif
