# 2026-10-22 真机验证 / 0.2.0

设备：192.168.1.18，iPad3,3，iOS 9.3.6，ARMv7 / PowerVR SGX 543。独立录屏项目，不修改 J2ME、爱丽丝游戏本体或既有游戏补丁。

## 问题与修复

- 小 UIWindow 在横屏切换时被 UIKit 重排，停止按钮随窗口拉伸，覆盖整个游戏。改为透明全屏、仅按钮区域接收点击的 overlay window；按钮始终保持 92×36，不成为 keyWindow。
- 爱丽丝使用 OpenAL / 图连接输出，未设置原型所依赖的直接 RemoteIO render callback。新增初始化/启动输出单元时注册 PostRender 通知，只采集输出 bus0，不读取麦克风。
- 有直接回调的 App 继续在客户端 PCM 回调采集，避免把最终输出格式误当成客户端格式。队列/最终输出采集做去重，普通/带参数的 AudioQueue 提交做线程内递归去重。
- 通用 vImage 缩放在这台设备上每帧约 194–265 ms。采用 IOSurface → CVOpenGLESTextureCache → GLES2 双线性缩放 → 编码像素缓冲，C/NEON 固定二倍缩小作为回退。
- 录屏服务原 ProcessType=Background 使实际采集约 7.5 fps；改 Standard 普通进程分类后接近设定 15 fps。空闲时没有抓屏/编码 timer，不提升游戏/系统进程优先级。
- 普通调度暴露 Unix socket accept/read 竞态：接受的 fd 继承非阻塞属性，客户端尚未发送就读取失败/关闭。改成带超时的阻塞读取、支持分片 JSON；控制端禁止 SIGPIPE 杀进程。
- 自动方向在倒计时结束、首帧编码前，依据前台 App 上报的 UI 方向确定。录制途中不改变方向。

## 结果

| 测试 | 实测 |
|---|---|
| 爱丽丝旧路径前台基线 | 42 帧 / 13.82 s ≈ 3.04 fps；无内录数据 |
| C/NEON 缩放 / 原后台分类 | 54 帧 / 7.48 s ≈ 7.22 fps |
| GPU 缩放 / 原后台分类 | 约 7.3–7.4 fps；缩放约 8–12 ms |
| GPU 缩放 / Standard 分类 | 111 帧 / 7.46 s ≈ 14.88 fps；缩放约 9.12 ms、抓屏约 28.66 ms |
| 爱丽丝实际跑酷有声片段 | 78 帧 / 10.50 s；455 音频包；解码 PCM RMS 1692.9，峰值 20421（此片段尚用后台分类，约7.4 fps） |
| 最终直接 AudioUnit S16 测试 | 约15 fps；266 音频包；0 晚到样本、0 削波 |
| 最终直接 AudioUnit planar Float32 测试 | 约15 fps；275 音频包；0 晚到样本、0 削波 |
| PCM AudioQueue 测试 | 约15 fps；636 包；0 晚到样本、0 削波 |
| 本地 WAV AVAudioPlayer 测试 | 约15 fps；284 包；0 晚到样本、0 削波 |
| 自动竖屏 | 生成 768×1024 正向画面 |
| 控制接口竞态 | 连续40次状态请求 + 故意延迟/逐字节发送请求均通过 |
| PCM 转换 | 单声道、边界、24位大端、planar Float32、NaN/Inf、8.24 定点、削波验证通过 |

录像/计时/解码波形的原始证据位于本机 output/alice 和 output/tests（不随源码 ZIP 分发）。音轨存在并不代表有声音；静音菜单的 PCM RMS=0，实际跑酷片段非零。音频格式测试还检查左右声道440/880Hz分离。

GPU 初始化日志明确为 PowerVR SGX 543。帧率是短片段实际帧数/时间，不保证所有 App、所有场景达到15fps。解码画面已检查，未把编码设置的帧率当成实测。

## 工具链/范围

Xcode 7.3.1 的 clang + iPhoneOS9.3 SDK 构建通过；Xcode project.pbxproj plutil 检查通过。当前 macOS 直接启动旧 xcodebuild 缺少系统 libauto.dylib，因此使用脚本直接调用该版本 clang；不声称在当前 macOS 成功运行旧 xcodebuild。

Framebuffer GetLayerDefaultSurface 在此 iOS 返回未许可；UIGetScreenImage 约848ms，未作为录屏路径。未改内核、全局 AMFI、系统服务的 Jetsam 配置，不抓取受保护媒体。不保证系统服务代播/流媒体音频。DEB依赖 Substrate/RocketBootstrap；仅测试32位iOS9设备。

## 最终发布包复核

0.2.0 的17个已安装文件 SHA256 全部匹配签名包。发布二进制不含自动测试/诊断写盘逻辑。用户再次进入跑酷后，使用自动方向录制10.27秒：152帧，实测14.81fps；GPU缩放7.04ms；443音频包，其中413包为有声输出；解码RMS=2749.6，峰值=32767，0削波、0晚到样本，MP4可正常解码。方向与画面复核见本机 output/alice/release-alice-3.png。

上一版回退包保留在数据分区 `/var/mobile/Library/LegacyScreenRecorder/Backups/previous-0.1.0.deb`。它存在原型的性能/横屏缺陷，通常不建议回退；如需回退，先停止录像后 dpkg -i 此文件。录像保留。
