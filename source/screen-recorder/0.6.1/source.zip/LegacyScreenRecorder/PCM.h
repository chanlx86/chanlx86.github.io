#ifndef LSR_PCM_H
#define LSR_PCM_H
#include <AudioToolbox/AudioToolbox.h>
#include <math.h>
#include <string.h>
#include <libkern/OSByteOrder.h>
static int16_t LSRReadSample(const unsigned char*p,AudioStreamBasicDescription f){
 unsigned bits=f.mBitsPerChannel;int big=(f.mFormatFlags&kAudioFormatFlagIsBigEndian)!=0;
 if(f.mFormatFlags&kAudioFormatFlagIsFloat){if(bits==32){uint32_t u;memcpy(&u,p,4);if(big)u=OSSwapInt32(u);float v;memcpy(&v,&u,4);if(!isfinite(v))v=0;if(v>1)v=1;if(v< -1)v=-1;return(int16_t)(v*32767);}return 0;}
 int64_t v=0;if(bits==16){uint16_t u;memcpy(&u,p,2);if(big)u=OSSwapInt16(u);v=(int16_t)u;}
 else if(bits==32){uint32_t u;memcpy(&u,p,4);if(big)u=OSSwapInt32(u);v=(int32_t)u;unsigned frac=(f.mFormatFlags&kLinearPCMFormatFlagsSampleFractionMask)>>kLinearPCMFormatFlagsSampleFractionShift;if(frac){if(frac>=15){unsigned shift=frac-15;v=v<0?-((-v)>>shift):(v>>shift);}else v*=1LL<<(15-frac);}else v>>=16;}
 else if(bits==8)v=((f.mFormatFlags&kAudioFormatFlagIsSignedInteger)?(int8_t)*p:(int)*p-128)*256;
 else if(bits==24){int32_t u=big?((int32_t)p[0]<<16)|((int32_t)p[1]<<8)|p[2]:((int32_t)p[2]<<16)|((int32_t)p[1]<<8)|p[0];if(u&0x800000)u|=0xff000000;v=u>>8;}
 if(v>32767)v=32767;if(v< -32768)v=-32768;return(int16_t)v;
}
static int LSRConvert(const AudioBufferList*b,AudioStreamBasicDescription f,uint32_t first,uint32_t count,int16_t*out){
 if(!b||f.mFormatID!=kAudioFormatLinearPCM||!f.mBytesPerFrame||!f.mChannelsPerFrame||f.mChannelsPerFrame>8||!(f.mBitsPerChannel==8||f.mBitsPerChannel==16||f.mBitsPerChannel==24||f.mBitsPerChannel==32))return 0;
 if(f.mBitsPerChannel==16&&f.mChannelsPerFrame==2&&f.mBytesPerFrame==4&&(f.mFormatFlags&kAudioFormatFlagIsSignedInteger)&&!(f.mFormatFlags&(kAudioFormatFlagIsBigEndian|kAudioFormatFlagIsNonInterleaved|kAudioFormatFlagIsFloat))){size_t offset=(size_t)first*4,bytes=(size_t)count*4;if(b->mNumberBuffers<1||!b->mBuffers[0].mData||offset+bytes>b->mBuffers[0].mDataByteSize)return 0;memcpy(out,(const char*)b->mBuffers[0].mData+offset,bytes);return 1;}
 unsigned bytes=f.mBitsPerChannel/8;int planar=(f.mFormatFlags&kAudioFormatFlagIsNonInterleaved)!=0;
 for(uint32_t i=0;i<count;i++)for(unsigned ch=0;ch<2;ch++){unsigned c=f.mChannelsPerFrame==1?0:ch,bi=planar?c:0;if(bi>=b->mNumberBuffers)return 0;const AudioBuffer*buf=&b->mBuffers[bi];size_t offset=(size_t)(first+i)*f.mBytesPerFrame+(planar?0:c*bytes);if(!buf->mData||offset+bytes>buf->mDataByteSize)return 0;out[i*2+ch]=LSRReadSample((unsigned char*)buf->mData+offset,f);}
 return 1;
}
#endif
