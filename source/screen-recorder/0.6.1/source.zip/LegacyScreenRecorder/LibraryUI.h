static UIColor*LSRInk(void){return[UIColor colorWithRed:.12 green:.19 blue:.28 alpha:1];}
static UILabel*LSRLabel(CGFloat size,BOOL bold){UILabel*l=[UILabel new];l.font=bold?[UIFont boldSystemFontOfSize:size]:[UIFont systemFontOfSize:size];l.textColor=LSRInk();return l;}
static NSString*LSRDuration(double t){return[NSString stringWithFormat:@"%02d:%02d",(int)t/60,(int)t%60];}
@interface LSRMovieCell:UICollectionViewCell
@property(nonatomic,strong)UIImageView*thumbnail;
@property(nonatomic,strong)UILabel*title,*detail;
@property(nonatomic,copy)NSString*path;
@property(nonatomic)NSInteger mode;
@property(nonatomic)BOOL selectionMode,checked;
@property(nonatomic,strong)UILabel*checkBadge;
@end
@implementation LSRMovieCell
-(id)initWithFrame:(CGRect)f{if((self=[super initWithFrame:f])){self.backgroundColor=[UIColor whiteColor];self.layer.cornerRadius=10;self.layer.masksToBounds=YES;_thumbnail=[UIImageView new];_thumbnail.contentMode=UIViewContentModeScaleAspectFit;_thumbnail.backgroundColor=[UIColor colorWithWhite:.10 alpha:1];_title=LSRLabel(16,YES);_title.numberOfLines=1;_detail=LSRLabel(12,NO);_detail.textColor=[UIColor grayColor];_detail.numberOfLines=2;[self.contentView addSubview:_thumbnail];[self.contentView addSubview:_title];[self.contentView addSubview:_detail];_checkBadge=LSRLabel(17,YES);_checkBadge.textAlignment=NSTextAlignmentCenter;_checkBadge.textColor=[UIColor whiteColor];_checkBadge.layer.cornerRadius=12;_checkBadge.layer.borderWidth=1.5;_checkBadge.layer.borderColor=[UIColor whiteColor].CGColor;_checkBadge.clipsToBounds=YES;[self.contentView addSubview:_checkBadge];}return self;}
-(void)layoutSubviews{[super layoutSubviews];CGFloat w=self.bounds.size.width,h=self.bounds.size.height;if(self.mode==0){_thumbnail.frame=CGRectMake(8,8,104,h-16);_title.frame=CGRectMake(124,12,w-136,25);_detail.frame=CGRectMake(124,40,w-136,36);}else if(self.mode==2){_thumbnail.frame=CGRectMake(3,3,w-6,h-6);_title.frame=_detail.frame=CGRectZero;}else{_thumbnail.frame=CGRectMake(0,0,w,h-62);_title.frame=CGRectMake(10,h-57,w-20,23);_detail.frame=CGRectMake(10,h-33,w-20,30);}_checkBadge.hidden=!self.selectionMode;_checkBadge.frame=CGRectMake(w-32,8,24,24);_checkBadge.text=self.checked?@"✓":@"";_checkBadge.backgroundColor=self.checked?[UIColor colorWithRed:.23 green:.46 blue:.8 alpha:1]:[UIColor colorWithWhite:0 alpha:.3];self.layer.borderWidth=self.checked?3:0;self.layer.borderColor=[UIColor colorWithRed:.23 green:.46 blue:.8 alpha:1].CGColor;}
-(void)setSelected:(BOOL)value{[super setSelected:value];[self setNeedsLayout];}
@end
@interface LSRRecordButton:UIButton {CAShapeLayer*ring,*mark;}
@property(nonatomic)BOOL recording;
@end
@implementation LSRRecordButton
-(id)initWithFrame:(CGRect)f{if((self=[super initWithFrame:f])){ring=[CAShapeLayer layer];ring.fillColor=[UIColor whiteColor].CGColor;ring.strokeColor=[UIColor colorWithRed:.88 green:.2 blue:.24 alpha:1].CGColor;ring.lineWidth=4;mark=[CAShapeLayer layer];mark.fillColor=ring.strokeColor;[self.layer addSublayer:ring];[self.layer addSublayer:mark];self.accessibilityLabel=@"开始录屏";}return self;}
-(void)layoutSubviews{[super layoutSubviews];ring.path=[UIBezierPath bezierPathWithOvalInRect:CGRectInset(self.bounds,4,4)].CGPath;CGRect r=CGRectInset(self.bounds,self.bounds.size.width*.27,self.bounds.size.height*.27);mark.path=(self.recording?[UIBezierPath bezierPathWithRoundedRect:r cornerRadius:5]:[UIBezierPath bezierPathWithOvalInRect:r]).CGPath;}
-(void)setRecording:(BOOL)value{_recording=value;self.accessibilityLabel=value?@"停止并保存":@"开始录屏";[self setNeedsLayout];}
@end
@interface LSRMiniPreview:UIViewController {AVPlayer*player;AVPlayerLayer*layer;UIButton*sound;}
@property(nonatomic,strong)NSDictionary*movie;
@property(nonatomic,copy)void(^shareAction)(void);
@property(nonatomic,copy)void(^deleteAction)(void);
@end
@implementation LSRMiniPreview
-(void)viewDidLoad{[super viewDidLoad];self.view.backgroundColor=[UIColor whiteColor];self.preferredContentSize=CGSizeMake(440,360);player=[AVPlayer playerWithURL:[NSURL fileURLWithPath:self.movie[@"path"]]];player.muted=YES;layer=[AVPlayerLayer playerLayerWithPlayer:player];layer.videoGravity=AVLayerVideoGravityResizeAspect;layer.backgroundColor=[UIColor blackColor].CGColor;[self.view.layer addSublayer:layer];NSArray*titles=@[@"取消静音",@"分享",@"删除",@"关闭"];for(int i=0;i<4;i++){UIButton*b=[UIButton buttonWithType:UIButtonTypeSystem];b.tag=i;[b setTitle:titles[i] forState:UIControlStateNormal];[b addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:b];if(!i)sound=b;}}
-(void)viewDidLayoutSubviews{[super viewDidLayoutSubviews];CGFloat w=self.view.bounds.size.width,h=self.view.bounds.size.height;layer.frame=CGRectMake(0,0,w,h-54);for(UIView*v in self.view.subviews)if([v isKindOfClass:[UIButton class]])v.frame=CGRectMake(v.tag*w/4,h-54,w/4,54);}
-(void)viewDidAppear:(BOOL)animated{[super viewDidAppear:animated];double t=[self.movie[@"elapsed"] doubleValue];[player seekToTime:CMTimeMakeWithSeconds(MAX(0,t*.5),600) completionHandler:^(BOOL done){if(done)[self->player play];}];}
-(void)action:(UIButton*)b{if(b.tag==0){player.muted=!player.muted;[sound setTitle:player.muted?@"取消静音":@"静音" forState:UIControlStateNormal];return;}[player pause];void(^action)(void)=b.tag==1?self.shareAction:b.tag==2?self.deleteAction:nil;[self dismissViewControllerAnimated:YES completion:action];}
-(void)viewWillDisappear:(BOOL)animated{[super viewWillDisappear:animated];[player pause];}
@end
