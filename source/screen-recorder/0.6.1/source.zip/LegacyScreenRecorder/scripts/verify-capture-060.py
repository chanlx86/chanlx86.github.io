#!/usr/bin/env python3
"""On-device format/bitrate/audio regression. Requires the test pattern foreground."""
import json,subprocess,shlex,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
out=root/'output/validation-060';out.mkdir(exist_ok=True)
ssh=['ssh','-S','/private/tmp/lsr-060.socket','-o','BatchMode=yes','root@192.168.1.18']
def run(c):return subprocess.check_output(ssh+[c],timeout=25)
def ctl(cmd,options=None):return json.loads(run('/usr/bin/lsrctl '+cmd+(' '+shlex.quote(json.dumps(options)) if options is not None else '')))
assert ctl('status')['state'] not in ['recording','saving','countdown']
run('echo ui-quality-scene > /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder || true; /var/mobile/register')
time.sleep(3)
results=[]
try:
 for quality,level,duration in [('standard',0,5),('standard',1,5),('standard',2,5),('native',0,4),('native',2,4)]:
  name=quality+'-'+str(level)
  start=ctl('start',{'quality':quality,'bitrateLevel':level,'delay':1,'orientation':0,'audio':True,'showIndicator':True})
  try:
   assert start['state'] in ['countdown','recording'],start
   time.sleep(duration+1)
  finally:ctl('stop')
  for i in range(40):
   s=ctl('status')
   if s['state']!='saving':break
   time.sleep(.25)
  assert not s['error'],s
  assert [s['width'],s['height']]==([2048,1536] if quality=='native' else [1024,768]),s
  assert s['bitrateLevel']==level and s['frames']>5 and s['audioNonSilentPackets']>0,s
  dest=out/(name+Path(s['path']).suffix)
  dest.write_bytes(run('cat '+shlex.quote(s['path'])))
  m=json.loads(subprocess.check_output([str(root/'output/dr-benchmark/video-metrics'),str(dest)]))
  assert m['audioTracks']>0,m
  results.append({'test':name,'status':s,'media':m});(out/(name+'.json')).write_text(json.dumps(results[-1],ensure_ascii=False,indent=2))
  print(name,'frames',s['frames'],'FPS',round(s['actualFPS'],2),'audio',s['audioNonSilentPackets'],'bytes',dest.stat().st_size,flush=True)
finally:
 run('rm -f /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder || true; /var/mobile/register')
(out/'capture-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
