#!/usr/bin/env python3
"""Non-destructive library selection/playback QA; requires LSR_TESTING and >=4 recordings."""
import subprocess,json,time,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--socket',required=True);a=p.parse_args()
ssh=['ssh','-S',a.socket,'-o','BatchMode=yes','root@192.168.1.18']
def run(c):return subprocess.check_output(ssh+[c],timeout=25,stderr=subprocess.DEVNULL)
out=Path(__file__).resolve().parent.parent/'output/ui-050';out.mkdir(exist_ok=True)
assert json.loads(run('/usr/bin/lsrctl status'))['state'] not in ['recording','countdown','saving']
try:
 for name,file in [('interaction-test','interaction-test.json'),('flicker-test','flicker-test.json'),('latest-play','latest-test.json')]:
  run('rm -f /var/mobile/Library/LegacyScreenRecorder/'+file+'; echo ui-'+name+' > /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder || true; /var/mobile/register')
  for i in range(40):
   try:data=run('cat /var/mobile/Library/LegacyScreenRecorder/'+file);result=json.loads(data);break
   except subprocess.CalledProcessError:time.sleep(.5)
  else:raise RuntimeError(name+' timed out')
  (out/file).write_bytes(data);print(name,result,flush=True)
  if name!='flicker-test':assert all(result.values()),result
  else:assert result['visibleImages']>0 and result['changedImages']==0,result
finally:run('rm -f /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder || true; /var/mobile/register')
