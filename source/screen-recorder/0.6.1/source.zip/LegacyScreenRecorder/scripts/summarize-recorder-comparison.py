#!/usr/bin/env python3
from pathlib import Path
import json,statistics
root=Path(__file__).resolve().parent.parent;out=root/'output/dr-benchmark'
def resources(label,phase):
 data=[json.loads(x) for x in (out/(label+'-'+phase+'.jsonl')).read_text().splitlines()];window=[r for r in data if 1<=r['t']<=(14 if phase=='active' else 5.5)];a,b=window[0],window[-1];dt=b['t']-a['t'];ticks=[y-x for x,y in zip(a['cpuTicks'],b['cpuTicks'])];cpu=100*(sum(ticks)-ticks[2])/sum(ticks);procs={};first={p['pid']:p for p in a['processes']};factor=a['cpuTimeNumer']/a['cpuTimeDenom']
 for p in b['processes']:
  old=first.get(p['pid'])
  if not old or p['rc'] or old['rc']:continue
  time=(p['userTicks']+p['systemTicks']-old['userTicks']-old['systemTicks'])*factor/1e9;values=[v['footprint']/1048576 for r in window for v in r['processes'] if v['pid']==p['pid']]
  procs[p['name']]={'cpuOneCorePercent':100*time/dt,'averageFootprintMB':statistics.mean(values),'peakFootprintMB':max(values)}
 return {'globalCPUPercent':cpu,'windowSeconds':dt,'processes':procs}
results=[]
for run in json.loads((out/'matched-runs.json').read_text()):
 idle=resources(run['label'],'idle');active=resources(run['label'],'active');main='SpringBoard' if run['kind']=='dr' else 'lsr-recorderd';r={**run,'idle':idle,'active':active,'extraGlobalCPUPercentagePoints':active['globalCPUPercent']-idle['globalCPUPercent'],'recordingProcess':main,'extraFootprintMB':active['processes'][main]['averageFootprintMB']-idle['processes'][main]['averageFootprintMB'],'peakExtraFootprintMB':active['processes'][main]['peakFootprintMB']-idle['processes'][main]['averageFootprintMB']};results.append(r)
(out/'comparison-summary.json').write_text(json.dumps(results,indent=2));print(json.dumps([{k:r[k] for k in ['label','extraGlobalCPUPercentagePoints','extraFootprintMB','peakExtraFootprintMB']}|{'globalCPU':r['active']['globalCPUPercent'],'processes':r['active']['processes'],'video':r['metrics']} for r in results],indent=2))
