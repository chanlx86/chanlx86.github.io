#!/usr/bin/env python3
import argparse,subprocess,json,time,shlex
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--duration',type=float,default=8);p.add_argument('--orientation',type=int,default=0);p.add_argument('--launch');p.add_argument('--quality',choices=['standard','native'],default='standard');p.add_argument('--fps',type=int,default=15);p.add_argument('--socket',default='/private/tmp/lsr-ipad18.socket');a=p.parse_args()
root=Path(__file__).resolve().parent.parent;out=root/'output/alice';out.mkdir(exist_ok=True)
ssh=['ssh','-S',a.socket,'-o','BatchMode=yes','root@192.168.1.18']
def run(c):
 r=subprocess.run(ssh+[c],capture_output=True,text=True,timeout=15)
 if r.returncode not in (0,3):raise RuntimeError(r.stderr)
 return r.stdout
def status():
 for attempt in range(20):
  try:return json.loads(run('/usr/bin/lsrctl status'))
  except (RuntimeError,subprocess.CalledProcessError,json.JSONDecodeError):time.sleep(.25)
 raise RuntimeError('Recorder service did not become ready')
assert status()['state'] not in ['recording','countdown','saving']
if a.launch:print(run('/var/mobile/register '+shlex.quote(a.launch)));time.sleep(3)
s=json.loads(run('/usr/bin/lsrctl start '+shlex.quote(json.dumps({'delay':1,'orientation':a.orientation,'fps':a.fps,'quality':a.quality}))))
try:
 assert s['state'] in ['countdown','recording'],s
 time.sleep(a.duration+1)
finally:run('/usr/bin/lsrctl stop')
for i in range(40):
 s=status()
 if s['state'] not in ['saving','recording','countdown']:break
 time.sleep(.25)
(out/(a.label+'-status.json')).write_text(json.dumps(s,indent=2));print(json.dumps(s),flush=True)
if s.get('path'):
 with (out/(a.label+Path(s['path']).suffix)).open('wb') as movie:
  subprocess.run(ssh+['cat '+shlex.quote(s['path'])],stdout=movie,check=True)
 subprocess.run([str(root/'output/inspect'),str(out/(a.label+Path(s['path']).suffix)),str(out/a.label)],check=True)
