#!/usr/bin/env python3
"""Produce a 640x960 UIKit size previews on the iOS 9 test iPad.
Requires an LSR_TESTING build. Does not claim to run/benchmark an actual iPhone 4s.
"""
import subprocess,argparse,json,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--socket',required=True);p.add_argument('--host',default='192.168.1.18');a=p.parse_args()
ssh=['ssh','-S',a.socket,'-o','BatchMode=yes','root@'+a.host]
def run(command):return subprocess.check_output(ssh+[command],timeout=20)
assert json.loads(run('/usr/bin/lsrctl status'))['state'] not in ['recording','countdown','saving']
run('rm -f /var/mobile/Library/LegacyScreenRecorder/iphone4s-*.png; echo ui-iphone4s-preview > /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder || true; /var/mobile/register')
try:
 for _ in range(40):
  if subprocess.run(ssh+['test -f /var/mobile/Library/LegacyScreenRecorder/iphone4s-gallery.png'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('No preview: install an LSR_TESTING build first')
 for name in ['home','settings','library','gallery']:
  out=Path(__file__).resolve().parent.parent/('output/ui-050/iphone4s-'+name+'.png');out.parent.mkdir(exist_ok=True);out.write_bytes(run('cat /var/mobile/Library/LegacyScreenRecorder/iphone4s-'+name+'.png'));print(out)
finally:run('rm -f /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder || true; /var/mobile/register')
