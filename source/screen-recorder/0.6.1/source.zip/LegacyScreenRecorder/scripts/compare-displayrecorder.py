#!/usr/bin/env python3
"""Read-only resource sampling + controlled 15-second A/B recordings. No release changes."""
from pathlib import Path
import subprocess,json,time,shlex,argparse
p=argparse.ArgumentParser();p.add_argument('--socket',required=True);p.add_argument('--matched',action='store_true');a=p.parse_args();root=Path(__file__).resolve().parent.parent;out=root/'output/dr-benchmark';stage=(out/'device-stage').read_text();ssh=['ssh','-S',a.socket,'-o','BatchMode=yes','root@192.168.1.18']
def run(c,timeout=40):return subprocess.check_output(ssh+[c],timeout=timeout)
def obj(c):return json.loads(run(c))
assert obj('/usr/bin/lsrctl status')['state']=='idle';assert obj(stage+'/control status')['recorderStatus']==0
config=json.loads((out/'selected-dr-prefs.json').read_text());original=json.loads((out/'original-dr-prefs.json').read_text());obj(stage+'/control prefs '+shlex.quote(json.dumps(config)));results=[]
try:
 for label,kind in ([('matched-lsr','lsr'),('matched-displayrecorder','dr')] if a.matched else [('lsr-1','lsr'),('displayrecorder-1','dr'),('displayrecorder-2','dr'),('lsr-2','lsr')]):
  prefix=stage+'/'+label
  run(stage+'/sampler 6 > '+prefix+'-idle.jsonl')
  body=stage+'/sampler 16 > '+prefix+'-active.jsonl &\n'+'sample_pid=$!\n'+stage+'/control '+('run' if kind=='dr' else 'lsr-run')+(' 15 1648' if a.matched and kind=='lsr' else ' 15')+' > '+prefix+'-status.json\n'+'capture_rc=$?\nwait "$sample_pid"\nexit "$capture_rc"'
  run('/bin/sh -c '+shlex.quote(body),timeout=40)
  status=obj('cat '+prefix+'-status.json');(out/(label+'-status.json')).write_text(json.dumps(status,indent=2))
  for phase in ['idle','active']:(out/(label+'-'+phase+'.jsonl')).write_bytes(run('cat '+prefix+'-'+phase+'.jsonl'))
  path=status['activeFilePath'] if kind=='dr' else status['path'];video=out/(label+Path(path).suffix)
  with video.open('wb') as f:subprocess.run(ssh+['cat '+shlex.quote(path)],stdout=f,check=True,timeout=30)
  metrics=json.loads(subprocess.check_output([str(out/'video-metrics'),str(video)],timeout=30));(out/(label+'-metrics.json')).write_text(json.dumps(metrics,indent=2))
  assert (metrics['width'],metrics['height'])==((1648,1236) if a.matched else (1024,768)),metrics
  assert metrics['audioTracks']==0 and 14<metrics['duration']<17,metrics
  result={'label':label,'kind':kind,'devicePath':path,'video':str(video),'metrics':metrics};results.append(result);(out/('matched-runs.json' if a.matched else 'runs.json')).write_text(json.dumps(results,indent=2))
  print(label, json.dumps({k:metrics[k] for k in ['duration','measuredFPS','interval95Ms','intervalMaxMs','fileBytes']}),flush=True)
  time.sleep(4)
finally:
 # Both recorders must stop even if sampling, a download or an assertion failed.
 for cmd in ['/usr/bin/lsrctl stop',stage+'/control stop']:
  try:run(cmd)
  except Exception as e:print('Cleanup stop:',str(e),flush=True)
 restore={k:original.get(k,None) for k in config};obj(stage+'/control prefs '+shlex.quote(json.dumps(restore)))
 after=obj(stage+'/control prefs');(out/'restored-dr-prefs.json').write_text(json.dumps(after,indent=2));assert after==original,(after,original)
 print('Original Display Recorder preferences restored.',flush=True)
