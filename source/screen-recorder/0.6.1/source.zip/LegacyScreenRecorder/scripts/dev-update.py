#!/usr/bin/env python3
"""Development-only atomic update; refuses to interrupt a recording."""
from pathlib import Path
import argparse,subprocess,shlex,json
p=argparse.ArgumentParser();p.add_argument('--socket',required=True);p.add_argument('--app',action='store_true');p.add_argument('--plugin',action='store_true');p.add_argument('--daemon',action='store_true');a=p.parse_args();root=Path(__file__).resolve().parent.parent
ssh=['ssh','-S',a.socket,'-o','BatchMode=yes','root@192.168.1.18']
def run(c):
 r=subprocess.run(ssh+[c],capture_output=True,text=True)
 if r.returncode not in (0,3):raise RuntimeError(r.stderr)
 return r.stdout
s=json.loads(run('/usr/bin/lsrctl status'));assert s['state'] not in ['recording','countdown','saving']
stage=run('mktemp -d /var/mobile/LSR-dev.XXXXXX').strip();assert stage.startswith('/var/mobile/LSR-dev.');files=[]
if a.app:files.append(('LegacyRecorder.app/LegacyRecorder','/Applications/LegacyRecorder.app/LegacyRecorder',''))
if a.plugin:files.append(('LegacyRecorderAudio.dylib','/Library/MobileSubstrate/DynamicLibraries/LegacyRecorderAudio.dylib',''))
if a.daemon:files.append(('lsr-recorderd','/usr/libexec/lsr-recorderd','daemon-entitlements.plist'))
q=shlex.quote
try:
 subprocess.run(ssh+['cat > '+q(stage+'/daemon-entitlements.plist')],input=(root/'daemon-entitlements.plist').read_bytes(),check=True)
 for src,dest,ent in files:
  path=stage+'/'+Path(src).name;subprocess.run(ssh+['cat > '+q(path)],input=(root/'output'/src).read_bytes(),check=True)
  run('ldid -S'+(q(stage+'/'+ent) if ent else '')+' '+q(path))
 if a.app:run('killall LegacyRecorder || true')
 if a.daemon:run('launchctl unload /Library/LaunchDaemons/local.legacy.recorder.plist')
 for src,dest,ent in files:run('cp '+q(stage+'/'+Path(src).name)+' '+q(dest+'.next')+' && chmod 755 '+q(dest+'.next')+' && mv '+q(dest+'.next')+' '+q(dest))
 if a.daemon:run('launchctl load /Library/LaunchDaemons/local.legacy.recorder.plist')
finally:run('rm -rf '+q(stage))
print('Updated:',[f[0] for f in files])
