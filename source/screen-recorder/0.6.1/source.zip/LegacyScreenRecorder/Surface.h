#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreVideo/CoreVideo.h>
#include <dlfcn.h>
#include <mach/mach.h>
typedef CFTypeRef LSRIOSurface;
static LSRIOSurface(*LSRSurfaceCreate)(CFDictionaryRef);
static void*(*LSRSurfaceBase)(LSRIOSurface);
static size_t(*LSRSurfaceStride)(LSRIOSurface);
static int(*LSRSurfaceLock)(LSRIOSurface,uint32_t,uint32_t*);
static int(*LSRSurfaceUnlock)(LSRIOSurface,uint32_t,uint32_t*);
static void(*LSRRenderDisplay)(mach_port_t,CFStringRef,LSRIOSurface,int,int);
static void *LSRSurfaceLib;
static NSString *LSRKey(const char *name){CFStringRef*p=dlsym(LSRSurfaceLib,name);return p?(__bridge NSString*)*p:nil;}
static BOOL LSRLoadSurface(void){LSRSurfaceLib=dlopen("/System/Library/PrivateFrameworks/IOSurface.framework/IOSurface",RTLD_NOW);if(!LSRSurfaceLib)LSRSurfaceLib=dlopen("/System/Library/Frameworks/IOSurface.framework/IOSurface",RTLD_NOW);dlopen("/System/Library/Frameworks/QuartzCore.framework/QuartzCore",RTLD_NOW);
#define SYM(field,name) field=dlsym(RTLD_DEFAULT,name)
 SYM(LSRSurfaceCreate,"IOSurfaceCreate");SYM(LSRSurfaceBase,"IOSurfaceGetBaseAddress");SYM(LSRSurfaceStride,"IOSurfaceGetBytesPerRow");SYM(LSRSurfaceLock,"IOSurfaceLock");SYM(LSRSurfaceUnlock,"IOSurfaceUnlock");SYM(LSRRenderDisplay,"CARenderServerRenderDisplay");
#undef SYM
 return LSRSurfaceCreate&&LSRSurfaceBase&&LSRSurfaceStride&&LSRSurfaceLock&&LSRSurfaceUnlock&&LSRRenderDisplay&&LSRKey("kIOSurfaceWidth")&&LSRKey("kIOSurfaceHeight")&&LSRKey("kIOSurfaceBytesPerElement")&&LSRKey("kIOSurfacePixelFormat");}
static LSRIOSurface LSRCreateSurface(size_t w,size_t h){if(!LSRLoadSurface())return NULL;NSDictionary*p=@{LSRKey("kIOSurfaceWidth"):@(w),LSRKey("kIOSurfaceHeight"):@(h),LSRKey("kIOSurfaceBytesPerElement"):@4,LSRKey("kIOSurfacePixelFormat"):@(kCVPixelFormatType_32BGRA),LSRKey("kIOSurfaceIsGlobal"):@YES};return LSRSurfaceCreate((__bridge CFDictionaryRef)p);}
