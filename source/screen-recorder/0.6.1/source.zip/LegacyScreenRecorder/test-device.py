#!/usr/bin/env python3
import subprocess,time,json,shlex,sys,math
from array import array
from pathlib import Path
root=Path(__file__).parent;out=root/'output/tests';out.mkdir(exist_ok=True)
ssh=['ssh','-S','/private/tmp/lsr-ipad18i.socket','-o','BatchMode=yes','root@192.168.1.18']
def run(command):
 r=subprocess.run(ssh+[command],capture_output=True,text=True,timeout=20)
 if r.returncode:raise RuntimeError(command+'\n'+r.stdout+r.stderr)
 return r.stdout
def status():
 for attempt in range(20):
  try:return json.loads(run('/usr/bin/lsrctl status'))
  except RuntimeError:time.sleep(.25)
 raise RuntimeError('Recorder did not become ready')
assert status()['state'] not in ['recording','countdown','saving'], 'Refusing to interrupt an existing recording'
for mode in sys.argv[1:] or ['queue','float','player']:
 assert mode in ['queue','float','player','au','hud','avplayer']
 run('printf '+shlex.quote(mode)+' > /var/mobile/Library/LegacyScreenRecorder/test-mode; killall LegacyRecorder; /var/mobile/register')
 time.sleep(2)
 try:
  started=json.loads(run("/usr/bin/lsrctl start "+shlex.quote(json.dumps({'delay':1,'orientation':1}))))
  assert started['state'] in ['countdown','recording'],started
  time.sleep(6)
 finally:run('/usr/bin/lsrctl stop')
 for n in range(20):
  s=status()
  if s['state'] not in ['saving','recording','countdown']:break
  time.sleep(.25)
 (out/(mode+'-status.json')).write_text(json.dumps(s,indent=2))
 print(mode,json.dumps(s),flush=True)
 if s.get('path'):
  subprocess.run(['scp','-o','ControlPath=/private/tmp/lsr-ipad18i.socket','-o','BatchMode=yes','root@192.168.1.18:'+s['path'],str(out/(mode+'.mp4'))],check=True,timeout=30)
  subprocess.run([str(root/'output/inspect'),str(out/(mode+'.mp4')),str(out/mode)],check=True,timeout=30)
  if mode!='hud':
   assert s.get('audioNonSilentPackets',0)>0, 'Captured audio packets contain only silence'
   pcm=array('h');pcm.frombytes((out/(mode+'.pcm')).read_bytes())
   rms=math.sqrt(sum(v*v for v in pcm)/len(pcm)) if pcm else 0
   assert rms>100, 'Decoded recording is silent: RMS='+str(rms)
   assert not s.get('error'),s['error']
   print(mode,'audio RMS',round(rms,1),'PASS',flush=True)
