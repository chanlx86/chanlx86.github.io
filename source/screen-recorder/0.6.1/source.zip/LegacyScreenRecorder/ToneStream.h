@interface LSRToneStream:NSObject
@property(nonatomic,strong)AVAssetReader*reader;
@property(nonatomic,strong)AVAssetReaderTrackOutput*output;
@property(nonatomic,strong)NSData*pending;
@property(nonatomic)uint32_t offset,source,pid;
@property(nonatomic)uint64_t origin,stop;
@property(nonatomic)double pts;
@property(nonatomic)BOOL finished;
@end
@implementation LSRToneStream
-(void)dealloc{[_reader cancelReading];}
@end
