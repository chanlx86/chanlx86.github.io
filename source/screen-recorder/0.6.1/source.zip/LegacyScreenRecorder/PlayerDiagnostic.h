#ifdef LSR_DIAGNOSTICS
static NSHashTable*diagnosticPlayers;
static BOOL(*oldDiagnosticPlay)(id,SEL);static BOOL diagnosticPlay(id p,SEL s){@synchronized(diagnosticPlayers){[diagnosticPlayers addObject:p];}return oldDiagnosticPlay(p,s);}
static BOOL(*oldDiagnosticPlayAt)(id,SEL,NSTimeInterval);static BOOL diagnosticPlayAt(id p,SEL s,NSTimeInterval t){@synchronized(diagnosticPlayers){[diagnosticPlayers addObject:p];}return oldDiagnosticPlayAt(p,s,t);}
static void installPlayerDiagnostic(void*h){diagnosticPlayers=[NSHashTable weakObjectsHashTable];void(*hook)(Class,SEL,IMP,IMP*)=dlsym(h,"MSHookMessageEx");if(hook){hook([AVAudioPlayer class],@selector(play),(IMP)diagnosticPlay,(IMP*)&oldDiagnosticPlay);hook([AVAudioPlayer class],@selector(playAtTime:),(IMP)diagnosticPlayAt,(IMP*)&oldDiagnosticPlayAt);}}
static NSArray*playerDiagnostic(void){NSMutableArray*r=[NSMutableArray array];NSArray*all;@synchronized(diagnosticPlayers){all=diagnosticPlayers.allObjects;}for(AVAudioPlayer*p in all)[r addObject:@{@"playing":@(p.playing),@"time":@(p.currentTime),@"duration":@(p.duration),@"loops":@(p.numberOfLoops),@"volume":@(p.volume),@"file":p.url.lastPathComponent?:@"data",@"settings":p.settings?:@{}}];return r;}
#else
static void installPlayerDiagnostic(void*h){}
#endif
