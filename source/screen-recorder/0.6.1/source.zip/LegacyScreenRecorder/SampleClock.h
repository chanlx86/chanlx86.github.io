#ifndef LSR_SAMPLECLOCK_H
#define LSR_SAMPLECLOCK_H
#include <stdint.h>
#include <math.h>
typedef struct {uint32_t tag;double rate,sample,nextSample;uint64_t host;int initialized;} LSRSampleClock;
static uint64_t LSRClockHost(LSRSampleClock*c,uint32_t tag,double rate,uint64_t observed,double sample,int valid,uint32_t frames,double ticksPerSecond){
 if(!tag||rate<8000||rate>192000)return observed;
 double pos=valid?sample:c->nextSample;
 if(!c->initialized||c->tag!=tag||c->rate!=rate||!isfinite(pos)||pos<c->nextSample-.5){c->tag=tag;c->rate=rate;c->sample=valid?sample:0;c->nextSample=c->sample;c->host=observed;c->initialized=1;pos=c->sample;}
 double delta=(pos-c->sample)/rate*ticksPerSecond;uint64_t predicted=c->host+(int64_t)llround(delta);
 double drift=(observed>=predicted?(double)(observed-predicted):-(double)(predicted-observed))/ticksPerSecond;
 if(fabs(drift)>.1){c->host=observed;c->sample=pos;predicted=observed;}
 c->nextSample=pos+frames;return predicted;
}
#endif
