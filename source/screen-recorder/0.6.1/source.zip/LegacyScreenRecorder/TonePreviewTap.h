#include <objc/message.h>
static BOOL toneHooksInstalled;static void*toneSubstrate;
static void toneMessage(NSDictionary*event){dispatch_async(drainQueue,^{if(!remotePort||!atomic_load(&activeTag))return;NSMutableDictionary*d=[event mutableCopy];d[@"tag"]=@(atomic_load(&activeTag));d[@"pid"]=@(getpid());CFDataRef b=CFBridgingRetain([NSJSONSerialization dataWithJSONObject:d options:0 error:NULL]);CFMessagePortSendRequest(remotePort,7,b,.05,0,NULL,NULL);CFRelease(b);});}
static void(*oldPreviewPlay)(id,SEL,id);static void(*oldPreviewStop)(id,SEL,BOOL);
static void previewPlay(id self,SEL sel,id identifier){uint64_t host=mach_absolute_time();oldPreviewPlay(self,sel,identifier);
#ifdef LSR_DIAGNOSTICS
[@{ @"identifier":[identifier description]?:@"",@"tag":@(atomic_load(&activeTag))} writeToFile:[[NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES) firstObject] stringByAppendingPathComponent:@"LSR-preview-hit.plist"] atomically:YES];
#endif
if(!atomic_load(&activeTag))return;Class c=NSClassFromString(@"TLToneManager");SEL shared=NSSelectorFromString(@"sharedToneManager"),file=NSSelectorFromString(@"filePathForToneIdentifier:");if(![c respondsToSelector:shared])return;id manager=((id(*)(id,SEL))objc_msgSend)(c,shared);if(![manager respondsToSelector:file])return;NSString*path=((id(*)(id,SEL,id))objc_msgSend)(manager,file,identifier);
#ifdef LSR_DIAGNOSTICS
[@{ @"path":path?:@"",@"identifier":[identifier description]?:@""} writeToFile:[[NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES) firstObject] stringByAppendingPathComponent:@"LSR-preview-path.plist"] atomically:YES];
#endif
if([path isKindOfClass:[NSString class]])toneMessage(@{@"action":@"play",@"path":path,@"host":@(host)});}
static void previewStop(id self,SEL sel,BOOL fade){uint64_t host=mach_absolute_time();oldPreviewStop(self,sel,fade);toneMessage(@{@"action":@"stop",@"host":@(host)});}
static void installTonePreview(void){if(toneHooksInstalled||!toneSubstrate)return;NSString*b=[NSBundle mainBundle].bundleIdentifier;if(![b isEqualToString:@"com.apple.mobiletimer"]&&![b isEqualToString:@"com.apple.Preferences"]&&![b isEqualToString:@"local.LegacyScreenRecorder"])return;Class c=NSClassFromString(@"TKTonePickerController");SEL play=NSSelectorFromString(@"_playToneWithIdentifier:"),stop=NSSelectorFromString(@"stopPlayingWithFadeOut:");void(*hook)(Class,SEL,IMP,IMP*)=dlsym(toneSubstrate,"MSHookMessageEx");if(!c||!hook||!class_getInstanceMethod(c,play)||!class_getInstanceMethod(c,stop))return;hook(c,play,(IMP)previewPlay,(IMP*)&oldPreviewPlay);hook(c,stop,(IMP)previewStop,(IMP*)&oldPreviewStop);toneHooksInstalled=YES;}
