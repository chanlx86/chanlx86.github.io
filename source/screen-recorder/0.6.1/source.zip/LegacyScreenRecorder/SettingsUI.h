#include "CapturePolicy.h"
static NSUserDefaults*LSRDefaults(void){return [NSUserDefaults standardUserDefaults];}
static void LSRRegisterDefaults(void){[LSRDefaults() registerDefaults:@{@"internalAudio":@YES,@"microphone":@NO,@"nativeQuality":@NO,@"orientation":@(-1),@"libraryMode":@1,@"showIndicator":@YES,@"showTouches":@NO,@"bitrateLevel":@1}];}
@interface LSRSettings:UITableViewController
@property(nonatomic)BOOL locked,recordingOnly,maintenanceOnly;
-(CGFloat)recordingHeightForWidth:(CGFloat)width;
@end
@implementation LSRSettings
-(void)setLocked:(BOOL)locked{if(_locked==locked)return;_locked=locked;if(self.isViewLoaded)[self.tableView reloadData];}
-(void)viewDidLoad{[super viewDidLoad];self.title=self.maintenanceOnly?@"更多":@"录制设置";self.tableView.backgroundColor=[UIColor colorWithWhite:.95 alpha:1];}
-(NSInteger)numberOfSectionsInTableView:(UITableView*)t{return self.recordingOnly?2:self.maintenanceOnly?1:3;}
-(CGFloat)footerHeight:(NSInteger)section width:(CGFloat)width{NSString*text=[self tableView:self.tableView titleForFooterInSection:section];CGRect r=[text boundingRectWithSize:CGSizeMake(MAX(100,width-40),CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]} context:nil];return ceil(r.size.height)+24;}
-(CGFloat)recordingHeightForWidth:(CGFloat)width{return 7*44+2*32+[self footerHeight:0 width:width]+[self footerHeight:1 width:width]+12;}
-(CGFloat)tableView:(UITableView*)t heightForHeaderInSection:(NSInteger)section{return 32;}
-(CGFloat)tableView:(UITableView*)t heightForFooterInSection:(NSInteger)section{return[self footerHeight:section width:t.bounds.size.width];}
-(NSInteger)tableView:(UITableView*)t numberOfRowsInSection:(NSInteger)s{return self.maintenanceOnly?4:s==0?2:s==1?5:4;}
-(NSString*)tableView:(UITableView*)t titleForHeaderInSection:(NSInteger)s{return self.maintenanceOnly?@"维护与帮助":s==0?@"声音":s==1?@"画面":@"维护与帮助";}
-(NSString*)tableView:(UITableView*)t titleForFooterInSection:(NSInteger)s{
 if(self.maintenanceOnly)s=2;if(self.recordingOnly&&s==0)return@"麦克风需要授权，内录与麦克风同开时建议戴耳机。";
 if(s==0)return@"麦克风默认关闭，首次开启需要系统授权。与内录同时使用时，耳机可避免扬声器的声音再次进入麦克风。音频会话被其他 App 中断时会在主页提示。";
 if(s==1){CGSize native=[UIScreen mainScreen].nativeBounds.size;int divisor=LSRCaptureDivisor(LSRDeviceModel().UTF8String,NO);NSString*resolution=[NSString stringWithFormat:@"%.0f×%.0f",MAX(native.width,native.height)/divisor,MIN(native.width,native.height)/divisor];return[NSString stringWithFormat:@"标准：%@、最高15fps、单段30分钟。%@\n标准码率低／中／高为1.2／2.5／5Mbps（目标平均值）。%@自动方向在倒计时后确定。浮标可拖动、点按停止；隐藏后回本软件停止。触摸轨迹默认关闭，仅在已载入插件的应用中显示，并会录入视频。",resolution,LSRHasRetinaOption()?@"Retina：2048×1536，自适应2–15fps、单段10分钟，适合轻负载画面。":@"本设备按屏幕原生分辨率录制；Retina档仅供iPad 3／4。",LSRHasRetinaOption()?@"Retina采用MJPEG，三档对应压缩质量，实际码率随画面变化，文件较大。":@""];}

 return@"缩略图取视频中间帧，磁盘缓存上限8MB、内存上限6MB。清理缓存不会删除录像。版本0.6.1。";
}
-(UITableViewCell*)tableView:(UITableView*)t cellForRowAtIndexPath:(NSIndexPath*)p{
 if(self.maintenanceOnly)p=[NSIndexPath indexPathForRow:p.row inSection:2];
 UITableViewCell*c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
 if(p.section==0){NSString*k=p.row?@"microphone":@"internalAudio";c.textLabel.text=p.row?@"麦克风":@"应用内录";UISwitch*sw=[UISwitch new];sw.on=[LSRDefaults() boolForKey:k];sw.tag=p.row;sw.enabled=!self.locked;[sw addTarget:self action:@selector(sound:) forControlEvents:UIControlEventValueChanged];c.accessoryView=sw;}
 else if(p.section==1&&p.row==2){c.textLabel.text=@"显示录制浮标";UISwitch*sw=[UISwitch new];sw.on=[LSRDefaults() boolForKey:@"showIndicator"];[sw addTarget:self action:@selector(indicator:) forControlEvents:UIControlEventValueChanged];c.accessoryView=sw;}
 else if(p.section==1&&p.row==4){c.textLabel.text=@"显示触摸轨迹";UISwitch*sw=[UISwitch new];sw.on=[LSRDefaults() boolForKey:@"showTouches"];[sw addTarget:self action:@selector(touches:) forControlEvents:UIControlEventValueChanged];c.accessoryView=sw;}
 else if(p.section==1){NSInteger row=p.row;c.textLabel.text=row==0?@"录制模式":row==1?@"视频方向":@"码率";NSArray*items=row==0?(LSRHasRetinaOption()?@[@"标准",@"Retina"]:@[@"标准"]):row==1?@[@"自动",@"竖屏",@"横屏"]:@[@"低",@"中",@"高"];UISegmentedControl*sc=[[UISegmentedControl alloc] initWithItems:items];sc.tag=row;sc.selectedSegmentIndex=row==0?(LSRHasRetinaOption()&&[LSRDefaults() boolForKey:@"nativeQuality"]):row==1?([LSRDefaults() integerForKey:@"orientation"]<0?0:[LSRDefaults() integerForKey:@"orientation"]==1?1:2):LSRBitrateLevel((int)[LSRDefaults() integerForKey:@"bitrateLevel"]);sc.enabled=!self.locked;[sc addTarget:self action:@selector(choice:) forControlEvents:UIControlEventValueChanged];sc.frame=CGRectMake(0,0,MIN(row==0?150:190,self.view.bounds.size.width-130),30);c.accessoryView=sc;}
 else{c.textLabel.text=@[@"清理缩略图缓存",@"录屏测试画面",@"使用说明",@"Filza 无线传输指南"][p.row];c.accessoryType=UITableViewCellAccessoryDisclosureIndicator;}

 return c;
}
-(void)indicator:(UISwitch*)s{BOOL visible=s.on;[LSRDefaults() setBool:visible forKey:@"showIndicator"];dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{LSRRequest(@{@"command":@"indicator",@"showIndicator":@(visible)});});}
-(void)touches:(UISwitch*)s{BOOL visible=s.on;[LSRDefaults() setBool:visible forKey:@"showTouches"];dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{LSRRequest(@{@"command":@"touches",@"showTouches":@(visible)});});}
-(void)sound:(UISwitch*)s{
 if(!s.tag){[LSRDefaults() setBool:s.on forKey:@"internalAudio"];return;}
 if(!s.on){[LSRDefaults() setBool:NO forKey:@"microphone"];return;}
 [[AVAudioSession sharedInstance] requestRecordPermission:^(BOOL granted){dispatch_async(dispatch_get_main_queue(),^{[LSRDefaults() setBool:granted forKey:@"microphone"];[self.tableView reloadData];if(!granted){UIAlertController*a=[UIAlertController alertControllerWithTitle:@"未获得麦克风权限" message:@"可在系统设置的隐私／麦克风中允许录屏大师；应用内录仍可正常使用。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}});}];
}
-(void)choice:(UISegmentedControl*)s{if(!s.tag)[LSRDefaults() setBool:s.selectedSegmentIndex==1 forKey:@"nativeQuality"];else if(s.tag==3)[LSRDefaults() setInteger:s.selectedSegmentIndex forKey:@"bitrateLevel"];else[LSRDefaults() setInteger:s.selectedSegmentIndex==0?-1:s.selectedSegmentIndex==1?1:0 forKey:@"orientation"];}
-(void)tableView:(UITableView*)t didSelectRowAtIndexPath:(NSIndexPath*)p{
 [t deselectRowAtIndexPath:p animated:YES];if(self.maintenanceOnly)p=[NSIndexPath indexPathForRow:p.row inSection:2];if(p.section!=2)return;
 if(p.row==0){[[LSRThumbnailStore shared] clear];UIAlertController*a=[UIAlertController alertControllerWithTitle:@"缩略图缓存已清理" message:@"浏览时会按需重新生成，录像保持不变。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}
 else if(p.row==1){if(!self.locked)[self.navigationController pushViewController:[[LSRPattern alloc] initWithMode:@"au"] animated:YES];}
 else if(p.row==3){UIViewController*c=[UIViewController new];c.title=@"Filza 无线传输";UITextView*v=[UITextView new];v.editable=NO;v.selectable=YES;v.font=[UIFont systemFontOfSize:16];v.textContainerInset=UIEdgeInsetsMake(20,16,24,16);v.text=@"用 Filza 下载录像到电脑\n\n1. 让 iPad／iPhone 和电脑连接同一 Wi-Fi。\n\n2. 打开 Filza，进入设置，启用 WebDAV 服务器（有些版本称为空中浏览器）。按需设置用户名和密码。\n\n3. 在电脑浏览器中输入 Filza 显示的完整地址，包括端口。也可在 Mac 的 Finder → 前往 → 连接服务器中输入该地址。不要输入固定的示例 IP，以 Filza 当前显示为准。\n\n4. 在服务器中打开以下录像目录，选择 MP4 或 MOV 文件下载。可长按选中并复制路径：\n\n/var/mobile/Media/LegacyScreenRecorder/\n\n部分版本可先将该目录设为 WebDAV 的主目录，便于直接浏览。若连接不上，请确认地址、Wi-Fi 和 Filza 的服务器开关；传输期间保持设备联网。\n\n传输结束后可关闭 Filza 的 WebDAV 服务。本软件仅提供指南，不启动网络服务器。\n\nFilza 官方使用说明：\nhttps://www.tigisoftware.com/default/?page_id=177";v.dataDetectorTypes=UIDataDetectorTypeLink;c.view=v;[self.navigationController pushViewController:c animated:YES];}
 else{UIAlertController*a=[UIAlertController alertControllerWithTitle:@"使用说明" message:@"点击红色录制按钮，中心出现3秒倒计时，可切到游戏。点按录制浮标停止，拖动可移动；或回到录屏大师停止。浮标与触摸轨迹可分别在设置中隐藏。\n\n在底部“已保存的视频”中可切换列表、中图、画廊；点按播放，长按小窗预览。视频页点“选择”，横向滑动或按住拖动可连续选择，再分享、存到相册或删除。画廊为正方形画布，支持原地播放和系统全屏。小窗预览默认静音。\n\n视频保存在数据分区 /var/mobile/Media/LegacyScreenRecorder。内录仍为实验功能，不保证所有音频引擎或受保护内容。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}
}
@end
