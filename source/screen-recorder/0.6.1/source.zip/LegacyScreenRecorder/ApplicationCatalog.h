#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <dlfcn.h>
@interface LSRApplicationCatalog:NSObject {NSMutableDictionary*cache;CFStringRef(*copyFront)(void);}
+(instancetype)shared;
-(NSDictionary*)application:(NSString*)bundle fallback:(NSString*)name;
-(NSString*)frontBundle;
-(BOOL)hasFrontLookup;
@end
@implementation LSRApplicationCatalog
+(instancetype)shared{static LSRApplicationCatalog*c;static dispatch_once_t once;dispatch_once(&once,^{c=[self new];});return c;}
-(id)init{if((self=[super init])){cache=[NSMutableDictionary dictionary];void*h=dlopen("/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices",RTLD_LAZY);copyFront=h?dlsym(h,"SBSCopyFrontmostApplicationDisplayIdentifier"):NULL;}return self;}
-(BOOL)hasFrontLookup{return copyFront!=NULL;}
-(NSString*)frontBundle{if(!copyFront)return nil;return CFBridgingRelease(copyFront());}
-(NSDictionary*)application:(NSString*)bundle fallback:(NSString*)fallback{
 if(![bundle isKindOfClass:[NSString class]]||!bundle.length||bundle.length>200)return nil;
 NSDictionary*saved=cache[bundle];if(saved)return [saved[@"hidden"] boolValue]?nil:saved;
 Class c=NSClassFromString(@"LSApplicationProxy");SEL find=NSSelectorFromString(@"applicationProxyForIdentifier:");id proxy=[c respondsToSelector:find]?((id(*)(id,SEL,id))objc_msgSend)(c,find,bundle):nil;
 SEL typeSel=NSSelectorFromString(@"applicationType"),nameSel=NSSelectorFromString(@"localizedName");
 NSString*type=[proxy respondsToSelector:typeSel]?((id(*)(id,SEL))objc_msgSend)(proxy,typeSel):nil;
 BOOL hidden=[type isEqualToString:@"Hidden"]||[bundle isEqualToString:@"com.apple.EscrowSecurityAlert"]||[bundle hasPrefix:@"com.apple.WebKit."];
 NSString*name=[proxy respondsToSelector:nameSel]?((id(*)(id,SEL))objc_msgSend)(proxy,nameSel):nil;
 if(![name isKindOfClass:[NSString class]]||!name.length)name=[fallback isKindOfClass:[NSString class]]&&fallback.length?fallback:@"屏幕录像";
 if([bundle isEqualToString:@"com.apple.springboard"]){hidden=NO;name=@"主屏幕";}
 NSDictionary*info=@{@"bundle":bundle,@"name":name,@"hidden":@(hidden)};if(cache.count>=128)[cache removeAllObjects];cache[bundle]=info;return hidden?nil:info;
}
@end
static NSString*LSRRecordingTitle(NSArray*apps){
 NSString*title=nil;double best=-1;for(NSDictionary*app in apps){if(![app isKindOfClass:[NSDictionary class]]||[app[@"bundle"] isEqualToString:@"local.LegacyScreenRecorder"])continue;
 NSDictionary*info=[[LSRApplicationCatalog shared] application:app[@"bundle"] fallback:app[@"name"]];if(!info)continue;
 double duration=[app[@"seconds"] doubleValue];if(!title||duration>best){title=info[@"name"];best=duration;}}
 return title?:@"屏幕录像";
}
static NSString*LSRFilenameComponent(NSString*title){
 NSMutableString*result=[NSMutableString string];NSCharacterSet*bad=[NSCharacterSet characterSetWithCharactersInString:@"/\\:\n\r\t"];
 [title enumerateSubstringsInRange:NSMakeRange(0,title.length) options:NSStringEnumerationByComposedCharacterSequences usingBlock:^(NSString*part,NSRange a,NSRange b,BOOL*stop){if(result.length+part.length>48){*stop=YES;return;}if([part rangeOfCharacterFromSet:bad].location==NSNotFound)[result appendString:part];}];
 NSString*s=[result stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];return s.length&&![s isEqualToString:@"."]&&![s isEqualToString:@".."]?s:@"屏幕录像";
}
