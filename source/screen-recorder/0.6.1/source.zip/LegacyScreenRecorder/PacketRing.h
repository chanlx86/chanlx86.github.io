#ifndef LSR_PACKET_RING_H
#define LSR_PACKET_RING_H
// Bounded, non-waiting multi-producer reservations. A producer owns one slot until publish.
static _Atomic uint32_t packetSequence[LSR_RING];
static void packetRingInit(void){for(uint32_t i=0;i<LSR_RING;i++)atomic_store(&packetSequence[i],i);}
static int packetReserve(uint32_t*position){uint32_t p=atomic_load_explicit(&produced,memory_order_relaxed);for(unsigned attempt=0;attempt<12;attempt++){uint32_t seq=atomic_load_explicit(&packetSequence[p%LSR_RING],memory_order_acquire);int32_t diff=(int32_t)(seq-p);if(diff==0){if(atomic_compare_exchange_weak_explicit(&produced,&p,p+1,memory_order_relaxed,memory_order_relaxed)){*position=p;return 1;}}else if(diff<0)return 0;else p=atomic_load_explicit(&produced,memory_order_relaxed);}return 0;}
static void packetPublish(uint32_t p){atomic_store_explicit(&packetSequence[p%LSR_RING],p+1,memory_order_release);}
static int packetReady(uint32_t r){return atomic_load_explicit(&packetSequence[r%LSR_RING],memory_order_acquire)==r+1;}
static void packetRelease(uint32_t r){atomic_store_explicit(&packetSequence[r%LSR_RING],r+LSR_RING,memory_order_release);atomic_store_explicit(&consumed,r+1,memory_order_relaxed);}
#endif
