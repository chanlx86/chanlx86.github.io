#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
LSR_DEV="${LSR_DEVELOPER_DIR:-$(xcode-select -p)}"
LSR_CC="$LSR_DEV/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
LSR_SDK="$LSR_DEV/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk"
LSR_FLAGS=(-arch armv7 -isysroot "$LSR_SDK" -miphoneos-version-min=9.0 -O2 -fobjc-arc -fblocks)
