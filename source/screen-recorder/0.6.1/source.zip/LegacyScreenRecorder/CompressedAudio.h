#ifndef LSR_COMPRESSED_AUDIO_H
#define LSR_COMPRESSED_AUDIO_H
#include <AudioToolbox/AudioToolbox.h>
#define LSR_ENCODED_BYTES 65536
#define LSR_ENCODED_PACKETS 512
#define LSR_COOKIE_BYTES 4096
#define LSR_ENCODED_RING 16
#define LSR_ENCODED_MAGIC 0x4c534332u
typedef struct {
 uint32_t magic,tag,pid,source,epoch,bytes,packets,cookieBytes,startTrim,endTrim;
 uint64_t host;AudioStreamBasicDescription format;
 unsigned char cookie[LSR_COOKIE_BYTES];AudioStreamPacketDescription descriptions[LSR_ENCODED_PACKETS];
 unsigned char data[LSR_ENCODED_BYTES];
} LSREncodedPacket;
static int LSREncodedFormat(AudioFormatID f){return f==kAudioFormatMPEG4AAC||f==kAudioFormatMPEGLayer3;}
#endif
