#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>
#import <AVFoundation/AVFoundation.h>
#import <Photos/Photos.h>
#import "Control.h"
#import "Pattern.m"
#include <fcntl.h>
#import "Microphone.h"
#import "ThumbnailStore.h"
#import "SettingsUI.h"
#import "LibraryUI.h"
#import "ApplicationCatalog.h"
#ifdef LSR_TESTING
#include "tests/OverlayCheck.h"
#endif
@interface LSRController:UIViewController<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIPopoverPresentationControllerDelegate,UITabBarDelegate,UIGestureRecognizerDelegate> {
 NSDictionary*status;NSArray*movies;NSTimer*poll;UICollectionView*library;UICollectionViewFlowLayout*layout;
 UIView*card;UIImageView*galleryImage;UILabel*statusLabel,*detailLabel,*recordLabel,*sectionTitle,*emptyLabel,*galleryCaption,*countdown;
 LSRRecordButton*recordButton;UISegmentedControl*modes;LSRMicrophone*microphone;
 UIBarButtonItem*selectButton,*settingsButton,*allButton,*shareButton,*saveButton,*deleteButton;UIToolbar*batchBar;
 NSMutableSet*chosenPaths;NSString*previousState,*selectedPath;BOOL busy,catalogBusy,catalogAgain,selecting,mediaBusy;
 NSInteger mode,lastCount,phraseIndex;double nextPhrase;dispatch_queue_t catalogQueue;
 UIScrollView*recordScroll;UIView*latestCard;UIImageView*latestImage;UILabel*latestTitle,*latestAction;NSString*latestPath;UIButton*latestButton;
 UITabBar*tabs;NSInteger page;LSRSettings*inlineSettings;UIScrollView*galleryScroll;
 UIButton*galleryPlay,*galleryFull;AVPlayer*galleryPlayer;AVPlayerLayer*galleryLayer;NSString*playingPath;
 UIPanGestureRecognizer*selectionPan;UILongPressGestureRecognizer*selectionHold,*previewHold;
 NSSet*dragBase;NSInteger dragAnchor;BOOL dragAdding,dragging;CGPoint dragPoint;CADisplayLink*dragClock;
}
-(void)record;
@end
@implementation LSRController
-(void)viewDidLoad{
 [super viewDidLoad];LSRRegisterDefaults();self.edgesForExtendedLayout=UIRectEdgeNone;
 self.view.backgroundColor=[UIColor colorWithRed:.94 green:.96 blue:.98 alpha:1];
 selectButton=[[UIBarButtonItem alloc] initWithTitle:@"选择" style:UIBarButtonItemStylePlain target:self action:@selector(toggleSelection)];
 settingsButton=[[UIBarButtonItem alloc] initWithTitle:@"更多" style:UIBarButtonItemStylePlain target:self action:@selector(settings)];
 allButton=[[UIBarButtonItem alloc] initWithTitle:@"全选" style:UIBarButtonItemStylePlain target:self action:@selector(selectAll)];
 self.navigationItem.leftBarButtonItem=selectButton;self.navigationItem.rightBarButtonItem=settingsButton;
 catalogQueue=dispatch_queue_create("local.legacy.recorder.catalog",DISPATCH_QUEUE_SERIAL);movies=@[];chosenPaths=[NSMutableSet set];
 mode=MAX(0,MIN(2,[LSRDefaults() integerForKey:@"libraryMode"]));nextPhrase=CACurrentMediaTime()+4;
 recordScroll=[UIScrollView new];recordScroll.alwaysBounceVertical=YES;[self.view addSubview:recordScroll];
 card=[UIView new];card.backgroundColor=[UIColor whiteColor];card.layer.cornerRadius=14;[recordScroll addSubview:card];
 statusLabel=LSRLabel(28,YES);statusLabel.numberOfLines=2;detailLabel=LSRLabel(13,NO);detailLabel.textColor=[UIColor grayColor];detailLabel.numberOfLines=3;
 [card addSubview:statusLabel];[card addSubview:detailLabel];
 recordButton=[[LSRRecordButton alloc] initWithFrame:CGRectZero];[recordButton addTarget:self action:@selector(record) forControlEvents:UIControlEventTouchUpInside];[card addSubview:recordButton];
 recordLabel=LSRLabel(14,YES);recordLabel.textAlignment=NSTextAlignmentCenter;[card addSubview:recordLabel];
 sectionTitle=LSRLabel(18,YES);sectionTitle.text=@"已保存的视频";[self.view addSubview:sectionTitle];
 modes=[[UISegmentedControl alloc] initWithItems:@[@"列表",@"中图",@"画廊"]];modes.selectedSegmentIndex=mode;[modes addTarget:self action:@selector(changeMode:) forControlEvents:UIControlEventValueChanged];[self.view addSubview:modes];
 layout=[UICollectionViewFlowLayout new];library=[[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];library.backgroundColor=[UIColor clearColor];library.dataSource=self;library.delegate=self;
 [library registerClass:[LSRMovieCell class] forCellWithReuseIdentifier:@"movie"];[self.view addSubview:library];
 previewHold=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(hold:)];[library addGestureRecognizer:previewHold];
 selectionPan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragSelect:)];selectionPan.delegate=self;selectionPan.enabled=NO;[library addGestureRecognizer:selectionPan];[library.panGestureRecognizer requireGestureRecognizerToFail:selectionPan];
 selectionHold=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(dragSelect:)];selectionHold.minimumPressDuration=.25;selectionHold.enabled=NO;[library addGestureRecognizer:selectionHold];[library.panGestureRecognizer requireGestureRecognizerToFail:selectionHold];
 galleryScroll=[UIScrollView new];[self.view addSubview:galleryScroll];
 galleryImage=[UIImageView new];galleryImage.backgroundColor=[UIColor blackColor];galleryImage.contentMode=UIViewContentModeScaleAspectFit;galleryImage.layer.cornerRadius=10;galleryImage.clipsToBounds=YES;galleryImage.userInteractionEnabled=YES;
 [galleryImage addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(playGallery)]];
 [galleryImage addGestureRecognizer:[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(holdGallery:)]];[galleryScroll addSubview:galleryImage];
 galleryCaption=LSRLabel(14,NO);galleryCaption.textAlignment=NSTextAlignmentCenter;[galleryScroll addSubview:galleryCaption];galleryCaption.numberOfLines=2;
 galleryPlay=[UIButton buttonWithType:UIButtonTypeSystem];[galleryPlay setTitle:@"播放" forState:UIControlStateNormal];[galleryPlay addTarget:self action:@selector(playGallery) forControlEvents:UIControlEventTouchUpInside];[galleryScroll addSubview:galleryPlay];
 galleryFull=[UIButton buttonWithType:UIButtonTypeSystem];[galleryFull setTitle:@"全屏播放" forState:UIControlStateNormal];[galleryFull addTarget:self action:@selector(fullGallery) forControlEvents:UIControlEventTouchUpInside];[galleryScroll addSubview:galleryFull];for(UIButton*b in @[galleryPlay,galleryFull]){b.backgroundColor=[UIColor colorWithWhite:0 alpha:.65];[b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];}
 latestCard=[UIView new];latestCard.backgroundColor=[UIColor whiteColor];latestCard.layer.cornerRadius=12;latestCard.clipsToBounds=YES;[recordScroll addSubview:latestCard];latestTitle=LSRLabel(14,YES);[latestCard addSubview:latestTitle];latestImage=[UIImageView new];latestImage.contentMode=UIViewContentModeScaleAspectFit;latestImage.backgroundColor=[UIColor blackColor];[latestCard addSubview:latestImage];latestAction=LSRLabel(14,YES);latestAction.text=@"▶︎ 查看最近录制";latestAction.textAlignment=NSTextAlignmentCenter;latestAction.textColor=[UIColor whiteColor];latestAction.backgroundColor=[UIColor colorWithWhite:0 alpha:.6];[latestCard addSubview:latestAction];latestButton=[UIButton buttonWithType:UIButtonTypeCustom];[latestButton addTarget:self action:@selector(playLatest) forControlEvents:UIControlEventTouchUpInside];[latestCard addSubview:latestButton];
 inlineSettings=[[LSRSettings alloc] initWithStyle:UITableViewStyleGrouped];inlineSettings.recordingOnly=YES;[self addChildViewController:inlineSettings];[recordScroll addSubview:inlineSettings.view];inlineSettings.tableView.scrollEnabled=NO;[inlineSettings didMoveToParentViewController:self];
 tabs=[UITabBar new];tabs.delegate=self;UITabBarItem*r=[[UITabBarItem alloc] initWithTitle:@"录制" image:[self tabImage:NO] tag:0];UITabBarItem*v=[[UITabBarItem alloc] initWithTitle:@"已保存的视频" image:[self tabImage:YES] tag:1];tabs.items=@[r,v];tabs.selectedItem=r;[self.view addSubview:tabs];
 emptyLabel=LSRLabel(17,NO);emptyLabel.numberOfLines=2;emptyLabel.textAlignment=NSTextAlignmentCenter;emptyLabel.text=@"还没有录像\n前往“录制”开始记录";[self.view addSubview:emptyLabel];
 batchBar=[UIToolbar new];batchBar.hidden=YES;
 shareButton=[[UIBarButtonItem alloc] initWithTitle:@"分享" style:UIBarButtonItemStylePlain target:self action:@selector(shareSelected)];
 saveButton=[[UIBarButtonItem alloc] initWithTitle:@"存到相册" style:UIBarButtonItemStylePlain target:self action:@selector(saveSelected)];
 deleteButton=[[UIBarButtonItem alloc] initWithTitle:@"删除" style:UIBarButtonItemStylePlain target:self action:@selector(deleteSelected)];deleteButton.tintColor=[UIColor colorWithRed:.85 green:.15 blue:.2 alpha:1];
 UIBarButtonItem*(^flex)(void)=^{return[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];};
 batchBar.items=@[flex(),shareButton,flex(),saveButton,flex(),deleteButton,flex()];[self.view addSubview:batchBar];
 countdown=LSRLabel(100,YES);countdown.textAlignment=NSTextAlignmentCenter;countdown.textColor=[UIColor whiteColor];countdown.backgroundColor=[UIColor colorWithWhite:0 alpha:.65];countdown.layer.cornerRadius=32;countdown.clipsToBounds=YES;countdown.hidden=YES;[self.view addSubview:countdown];
 poll=[NSTimer scheduledTimerWithTimeInterval:.5 target:self selector:@selector(refresh) userInfo:nil repeats:YES];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(active) name:UIApplicationDidBecomeActiveNotification object:nil];
 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(inactive) name:UIApplicationWillResignActiveNotification object:nil];[self refresh];[self reloadMovies];
}
-(void)viewWillAppear:(BOOL)animated{[super viewWillAppear:animated];[galleryPlay setTitle:galleryPlayer.rate>0?@"暂停":@"播放" forState:UIControlStateNormal];[self refresh];[self reloadMovies];}
-(void)active{nextPhrase=CACurrentMediaTime()+4;[self refresh];[self reloadMovies];}
-(void)inactive{[self finishDrag:NO];[galleryPlayer pause];[galleryPlay setTitle:@"播放" forState:UIControlStateNormal];
 if([self.presentedViewController isKindOfClass:[AVPlayerViewController class]])[((AVPlayerViewController*)self.presentedViewController).player pause];
 if([self.presentedViewController isKindOfClass:[LSRMiniPreview class]])[self dismissViewControllerAnimated:NO completion:nil];
}
-(BOOL)running{return [@[@"recording",@"countdown",@"saving"] containsObject:status[@"state"]?:@""];}
-(UIImage*)tabImage:(BOOL)video{UIGraphicsBeginImageContextWithOptions(CGSizeMake(26,26),NO,0);[[UIColor blackColor] setStroke];UIBezierPath*p=video?[UIBezierPath bezierPathWithRoundedRect:CGRectMake(2,5,22,17) cornerRadius:2]:[UIBezierPath bezierPathWithOvalInRect:CGRectMake(3,3,20,20)];p.lineWidth=1.8;[p stroke];if(video){UIBezierPath*t=[UIBezierPath bezierPath];[t moveToPoint:CGPointMake(10,9)];[t addLineToPoint:CGPointMake(18,13.5)];[t addLineToPoint:CGPointMake(10,18)];[t closePath];[t fill];}else{[[UIBezierPath bezierPathWithOvalInRect:CGRectMake(7,7,12,12)] fill];}UIImage*im=UIGraphicsGetImageFromCurrentImageContext();UIGraphicsEndImageContext();return im;}
-(void)tabBar:(UITabBar*)bar didSelectItem:(UITabBarItem*)item{if(mediaBusy){bar.selectedItem=bar.items[page];return;}[self showPage:item.tag];}
-(void)showPage:(NSInteger)p{if(page==p)return;[self finishDrag:NO];if(selecting)[self endSelection];[self stopGallery];page=p;tabs.selectedItem=tabs.items[p];[self updateSelectionUI];[self.view setNeedsLayout];}
-(void)viewDidLayoutSubviews{
 [super viewDidLayoutSubviews];CGFloat w=self.view.bounds.size.width,h=self.view.bounds.size.height;BOOL narrow=w<560;CGSize oldItem=layout.itemSize;UICollectionViewScrollDirection oldDirection=layout.scrollDirection;
 tabs.frame=CGRectMake(0,h-49,w,49);CGFloat bottom=h-49;recordScroll.frame=CGRectMake(0,0,w,bottom);recordScroll.hidden=page!=0;
 CGFloat ch=narrow?126:150;card.frame=CGRectMake(12,10,w-24,ch);CGFloat cw=card.bounds.size.width;
 recordButton.frame=CGRectMake(cw-(narrow?84:110),12,narrow?64:82,narrow?64:82);recordLabel.frame=CGRectMake(cw-(narrow?104:124),narrow?80:100,narrow?100:112,28);
 statusLabel.font=[UIFont boldSystemFontOfSize:narrow?21:29];statusLabel.frame=CGRectMake(16,12,MAX(70,cw-(narrow?118:154)),56);detailLabel.font=[UIFont systemFontOfSize:narrow?12:13];detailLabel.frame=CGRectMake(16,70,MAX(70,cw-(narrow?118:154)),ch-76);
 CGFloat y=CGRectGetMaxY(card.frame)+12;latestCard.hidden=!movies.count;if(movies.count){CGFloat imageHeight=MIN(240,(w-24)*.56);latestCard.frame=CGRectMake(12,y,w-24,imageHeight+38);latestTitle.frame=CGRectMake(12,6,w-48,26);latestImage.frame=CGRectMake(0,38,w-24,imageHeight);latestAction.frame=CGRectMake(0,CGRectGetMaxY(latestImage.frame)-32,w-24,32);latestButton.frame=latestImage.frame;y=CGRectGetMaxY(latestCard.frame)+6;}
 CGFloat settingsHeight=[inlineSettings recordingHeightForWidth:w];inlineSettings.view.frame=CGRectMake(0,y,w,settingsHeight);recordScroll.contentSize=CGSizeMake(w,y+settingsHeight+12);
 sectionTitle.hidden=YES;modes.hidden=library.hidden=emptyLabel.hidden=page!=1;emptyLabel.hidden|=movies.count>0;
 modes.frame=CGRectMake(14,10,w-28,30);batchBar.frame=CGRectMake(0,bottom-44,w,44);CGRect area=CGRectMake(12,50,w-24,MAX(0,bottom-58-(selecting?44:0)));emptyLabel.frame=area;
 galleryScroll.hidden=page!=1||mode!=2||!movies.count;
 if(mode==2){galleryScroll.frame=area;CGFloat size=area.size.width;galleryImage.frame=CGRectMake(0,0,size,size);galleryLayer.frame=galleryImage.bounds;
 galleryPlay.frame=CGRectMake(0,size-38,size/2,38);galleryFull.frame=CGRectMake(size/2,size-38,size/2,38);galleryCaption.frame=CGRectMake(0,size+4,size,42);
 if(library.superview!=galleryScroll)[galleryScroll addSubview:library];library.frame=CGRectMake(0,size+52,size,110);galleryScroll.contentSize=CGSizeMake(size,size+170);layout.scrollDirection=UICollectionViewScrollDirectionHorizontal;layout.minimumLineSpacing=10;layout.itemSize=CGSizeMake(132,98);library.hidden=page!=1||!movies.count;}
 else{if(library.superview!=self.view)[self.view insertSubview:library belowSubview:tabs];library.frame=area;layout.scrollDirection=UICollectionViewScrollDirectionVertical;layout.minimumLineSpacing=12;layout.minimumInteritemSpacing=12;if(mode==0)layout.itemSize=CGSizeMake(area.size.width,90);else{NSInteger columns=MAX(1,(NSInteger)ceil((area.size.width+12)/202));CGFloat cell=floor((area.size.width-12*(columns-1))/columns);layout.itemSize=CGSizeMake(cell,cell*.66+62);}}
 if(!CGSizeEqualToSize(oldItem,layout.itemSize)||oldDirection!=layout.scrollDirection)[layout invalidateLayout];countdown.frame=CGRectMake((w-180)/2,(h-180)/2,180,180);[self.view bringSubviewToFront:batchBar];[self.view bringSubviewToFront:tabs];[self.view bringSubviewToFront:countdown];
}
-(void)refresh{
 NSData*d=[NSData dataWithContentsOfFile:@LSR_STATUS];id parsed=d?[NSJSONSerialization JSONObjectWithData:d options:0 error:NULL]:nil;status=[parsed isKindOfClass:[NSDictionary class]]?parsed:@{};
 NSString*s=status[@"state"]?:@"";BOOL running=[self running];[LSRThumbnailStore shared].suspended=running;
 recordButton.recording=running;recordButton.enabled=!busy&&!mediaBusy&&![s isEqualToString:@"saving"];recordLabel.text=running?@"停止并保存":@"开始录屏";
 NSArray*phrases=@[@"准备好记录",@"记录这一刻",@"留住美好时光"];
 BOOL rotate=!running&&CACurrentMediaTime()>=nextPhrase&&self.view.window&&self.navigationController.topViewController==self&&[UIApplication sharedApplication].applicationState==UIApplicationStateActive&&!self.presentedViewController;
 if(rotate){phraseIndex=(phraseIndex+1)%phrases.count;nextPhrase=CACurrentMediaTime()+4;}
 NSString*headline=[s isEqualToString:@"recording"]?[NSString stringWithFormat:@"正在录制 %@",LSRDuration([status[@"elapsed"] doubleValue])]:[s isEqualToString:@"countdown"]?@"即将开始录制":[s isEqualToString:@"saving"]?@"正在保存录像":phrases[phraseIndex];
 if(rotate)[UIView transitionWithView:statusLabel duration:.35 options:UIViewAnimationOptionTransitionCrossDissolve animations:^{self->statusLabel.text=headline;} completion:nil];else statusLabel.text=headline;
 NSString*name=status[@"foregroundName"]?:@"",*warning=status[@"microphoneWarning"]?:@"";
 detailLabel.text=mediaBusy?@"正在处理所选录像，请稍候…":[status[@"error"] length]?status[@"error"]:running?[NSString stringWithFormat:@"%@ · %.1f fps%@%@",name.length?name:@"系统画面",[status[@"actualFPS"] doubleValue],[status[@"microphone"] boolValue]?@" · 麦克风开启":@"",warning.length?[NSString stringWithFormat:@"\n%@",warning]:@""]:@"3秒倒计时后开始\n下方可调整声音与画面";
 NSInteger n=ceil([status[@"countdown"] doubleValue]);countdown.hidden=n<=0;
 if(n>0&&n!=lastCount){countdown.text=[NSString stringWithFormat:@"%ld",(long)n];countdown.transform=CGAffineTransformMakeScale(1.15,1.15);countdown.alpha=.6;[UIView animateWithDuration:.45 animations:^{self->countdown.transform=CGAffineTransformIdentity;self->countdown.alpha=1;}];}lastCount=n;
 if(![s isEqualToString:previousState]){previousState=s;nextPhrase=CACurrentMediaTime()+4;[self reloadMovies];}
 inlineSettings.locked=running;latestButton.enabled=!running&&!mediaBusy;[self.view setNeedsLayout];if(running)[galleryPlayer pause];
 if(!running&&microphone&&!busy){[microphone stop];microphone=nil;}[self updateSelectionUI];
}
-(void)settings{LSRSettings*c=[[LSRSettings alloc] initWithStyle:UITableViewStyleGrouped];c.locked=[self running];c.maintenanceOnly=YES;c.title=@"更多";[self.navigationController pushViewController:c animated:YES];}
-(void)record{if(busy||mediaBusy)return;[self stopGallery];if(selecting)[self endSelection];if([self running]){[self command:@{@"command":@"stop"}];return;}if([LSRDefaults() boolForKey:@"microphone"]){NSError*e=nil;microphone=[LSRMicrophone new];if(![microphone start:&e]){microphone=nil;UIAlertController*a=[UIAlertController alertControllerWithTitle:@"麦克风未能启动" message:e.localizedDescription preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[a addAction:[UIAlertAction actionWithTitle:@"本次不录麦克风" style:UIAlertActionStyleDefault handler:^(UIAlertAction*x){[self begin:NO];}]];[self presentViewController:a animated:YES completion:nil];return;}}[self begin:microphone!=nil];}
-(void)begin:(BOOL)mic{if(self.presentedViewController)[self dismissViewControllerAnimated:NO completion:nil];[self command:@{@"command":@"start",@"audio":@([LSRDefaults() boolForKey:@"internalAudio"]),@"microphone":@(mic),@"fps":@15,@"delay":@3,@"showIndicator":@([LSRDefaults() boolForKey:@"showIndicator"]),@"showTouches":@([LSRDefaults() boolForKey:@"showTouches"]),@"bitrateLevel":@([LSRDefaults() integerForKey:@"bitrateLevel"]),@"quality":LSRHasRetinaOption()&&[LSRDefaults() boolForKey:@"nativeQuality"]?@"native":@"standard",@"orientation":@([LSRDefaults() integerForKey:@"orientation"])}];}
-(void)command:(NSDictionary*)options{busy=YES;recordButton.enabled=NO;dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{NSDictionary*r=LSRRequest(options);dispatch_async(dispatch_get_main_queue(),^{self->busy=NO;if(self->microphone){if([r[@"tag"] unsignedIntValue])[self->microphone setRecordingTag:[r[@"tag"] unsignedIntValue]];else{[self->microphone stop];self->microphone=nil;}}if(!r){UIAlertController*a=[UIAlertController alertControllerWithTitle:@"录屏服务未连接" message:@"请确认完整DEB包已安装并且录屏服务正常运行。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}[self refresh];});});}

-(void)reloadMovies{
 if(catalogBusy){catalogAgain=YES;return;}catalogBusy=YES;NSString*active=[self running]?status[@"path"]:nil;
 dispatch_async(catalogQueue,^{@autoreleasepool{
  NSMutableArray*list=[NSMutableArray array];NSFileManager*fm=[NSFileManager defaultManager];NSDateFormatter*df=[NSDateFormatter new];df.dateFormat=@"MM-dd HH:mm";
  for(NSString*f in [fm contentsOfDirectoryAtPath:@LSR_MOVIES error:NULL])if([@[@"mp4",@"mov"] containsObject:f.pathExtension.lowercaseString]){
   NSString*p=[@LSR_MOVIES stringByAppendingPathComponent:f];if([p isEqualToString:active])continue;
   NSData*d=[NSData dataWithContentsOfFile:[p stringByAppendingString:@".json"]];NSDictionary*meta=d?[NSJSONSerialization JSONObjectWithData:d options:0 error:NULL]:nil;
   NSMutableDictionary*m=[meta isKindOfClass:[NSDictionary class]]?[meta mutableCopy]:[NSMutableDictionary dictionary];m[@"path"]=p;m[@"title"]=LSRRecordingTitle(m[@"apps"]);NSDictionary*attrs=[fm attributesOfItemAtPath:p error:NULL];m[@"sortDate"]=attrs[NSFileCreationDate]?:[NSDate distantPast];
   m[@"detail"]=[NSString stringWithFormat:@"%@ · %@ · %.1f MB",[df stringFromDate:attrs[NSFileCreationDate]?:[NSDate date]],LSRDuration([m[@"elapsed"] doubleValue]),[attrs[NSFileSize] doubleValue]/1048576.];[list addObject:m];
  }
  [list sortUsingComparator:^NSComparisonResult(id a,id b){NSComparisonResult r=[b[@"sortDate"] compare:a[@"sortDate"]];return r==NSOrderedSame?[b[@"path"] compare:a[@"path"]]:r;}];
  dispatch_async(dispatch_get_main_queue(),^{
   self->catalogBusy=NO;self->movies=list;NSMutableSet*valid=[NSMutableSet set];for(NSDictionary*m in list)[valid addObject:m[@"path"]];[self->chosenPaths intersectSet:valid];
   self->emptyLabel.hidden=list.count>0;[self updateLatest];[self->library reloadData];[self updateGallery];[self updateSelectionUI];[self.view setNeedsLayout];
   if(self->catalogAgain){self->catalogAgain=NO;[self reloadMovies];}
  });
 }});
}
-(void)updateLatest{NSDictionary*m=movies.firstObject;NSString*p=m[@"path"];latestTitle.text=m?[NSString stringWithFormat:@"最近录制 · %@",m[@"title"]]:@"";latestButton.accessibilityLabel=latestTitle.text;latestButton.enabled=![self running]&&!mediaBusy;if([latestPath isEqualToString:p]&&latestImage.image)return;latestPath=p;latestImage.image=nil;if(p)[[LSRThumbnailStore shared] imageFor:p completion:^(UIImage*im){if([self->latestPath isEqualToString:p])self->latestImage.image=im;}];}
-(void)playLatest{if(movies.count)[self play:movies.firstObject];}
-(NSInteger)collectionView:(UICollectionView*)c numberOfItemsInSection:(NSInteger)s{return movies.count;}
-(UICollectionViewCell*)collectionView:(UICollectionView*)c cellForItemAtIndexPath:(NSIndexPath*)p{
 LSRMovieCell*cell=[c dequeueReusableCellWithReuseIdentifier:@"movie" forIndexPath:p];NSDictionary*m=movies[p.item];BOOL same=[cell.path isEqualToString:m[@"path"]];cell.path=m[@"path"];cell.mode=mode;cell.selectionMode=selecting;cell.checked=selecting?[chosenPaths containsObject:cell.path]:mode==2&&[cell.path isEqualToString:[self selectedMovie][@"path"]];
 cell.title.text=m[@"title"];cell.detail.text=m[@"detail"];if(!same)cell.thumbnail.image=nil;cell.accessibilityLabel=[NSString stringWithFormat:@"%@，%@%@",m[@"title"],m[@"detail"],selecting?(cell.checked?@"，已选择":@"，未选择"):@""];[cell setNeedsLayout];
 if(same&&cell.thumbnail.image)return cell;NSString*path=cell.path;__weak LSRMovieCell*weak=cell;[[LSRThumbnailStore shared] imageFor:path completion:^(UIImage*im){LSRMovieCell*v=weak;if([v.path isEqualToString:path])v.thumbnail.image=im;}];return cell;
}
-(void)collectionView:(UICollectionView*)c didSelectItemAtIndexPath:(NSIndexPath*)p{
 [c deselectItemAtIndexPath:p animated:NO];if(mediaBusy)return;NSDictionary*m=movies[p.item];
 if(mode==2)selectedPath=m[@"path"];
 if(selecting){[self toggleMovie:m];if(mode==2)[self updateGallery];}
 else if(mode==2){[self updateGallery];[self updateVisibleSelections];}else[self play:m];
}
-(NSDictionary*)selectedMovie{for(NSDictionary*m in movies)if([m[@"path"] isEqualToString:selectedPath])return m;return movies.firstObject;}
-(void)updateGallery{
 NSDictionary*m=[self selectedMovie];selectedPath=m[@"path"];galleryCaption.text=m?[NSString stringWithFormat:@"%@ · %@ · %@",m[@"title"],m[@"detail"],selecting?@"点按选择":@"点按播放"]:@"";if(![playingPath isEqualToString:selectedPath])[self stopGallery];
 if(mode==2&&m&&!galleryPlayer){galleryImage.image=nil;NSString*path=m[@"path"];[[LSRThumbnailStore shared] imageFor:path completion:^(UIImage*im){if([self->selectedPath isEqualToString:path])self->galleryImage.image=im;}];}
}
-(void)changeMode:(UISegmentedControl*)s{[self finishDrag:NO];[self stopGallery];mode=s.selectedSegmentIndex;[LSRDefaults() setInteger:mode forKey:@"libraryMode"];[library reloadData];[self.view setNeedsLayout];[self updateGallery];}
-(void)galleryEnded:(NSNotification*)n{[galleryPlay setTitle:@"重播" forState:UIControlStateNormal];}
-(void)stopGallery{if(galleryPlayer)[[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:galleryPlayer.currentItem];BOOL hadPlayer=galleryPlayer!=nil;[galleryPlayer pause];[galleryLayer removeFromSuperlayer];galleryLayer=nil;galleryPlayer=nil;playingPath=nil;if(hadPlayer&&!microphone)[[AVAudioSession sharedInstance] setActive:NO withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:NULL];[galleryPlay setTitle:@"播放" forState:UIControlStateNormal];}
-(void)prepareGallery{if(galleryPlayer||![self selectedMovie])return;playingPath=[self selectedMovie][@"path"];galleryPlayer=[AVPlayer playerWithURL:[NSURL fileURLWithPath:playingPath]];[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(galleryEnded:) name:AVPlayerItemDidPlayToEndTimeNotification object:galleryPlayer.currentItem];galleryLayer=[AVPlayerLayer playerLayerWithPlayer:galleryPlayer];galleryLayer.videoGravity=AVLayerVideoGravityResizeAspect;galleryLayer.frame=galleryImage.bounds;[galleryImage.layer addSublayer:galleryLayer];[[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:NULL];[[AVAudioSession sharedInstance] setActive:YES error:NULL];}
-(void)playGallery{NSDictionary*m=[self selectedMovie];if(!m||mediaBusy||[self running])return;if(selecting){[self toggleMovie:m];return;}[self prepareGallery];if(galleryPlayer.rate){[galleryPlayer pause];[galleryPlay setTitle:@"播放" forState:UIControlStateNormal];}else{CMTime d=galleryPlayer.currentItem.duration;if(CMTIME_IS_NUMERIC(d)&&CMTimeCompare(galleryPlayer.currentTime,d)>=0)[galleryPlayer seekToTime:kCMTimeZero];[galleryPlayer play];[galleryPlay setTitle:@"暂停" forState:UIControlStateNormal];}}
-(void)fullGallery{if(selecting||mediaBusy||[self running]||![self selectedMovie])return;[self prepareGallery];AVPlayerViewController*c=[AVPlayerViewController new];c.player=galleryPlayer;[self presentViewController:c animated:YES completion:^{[c.player play];}];}
-(void)play:(NSDictionary*)m{if(busy||[self running]||mediaBusy)return;AVPlayerViewController*p=[AVPlayerViewController new];p.player=[AVPlayer playerWithURL:[NSURL fileURLWithPath:m[@"path"]]];[self presentViewController:p animated:YES completion:^{[p.player play];}];}
-(void)hold:(UILongPressGestureRecognizer*)g{if(selecting||g.state!=UIGestureRecognizerStateBegan)return;NSIndexPath*p=[library indexPathForItemAtPoint:[g locationInView:library]];if(p&&p.item<movies.count)[self preview:movies[p.item] source:[library cellForItemAtIndexPath:p]];}
-(void)holdGallery:(UILongPressGestureRecognizer*)g{if(!selecting&&g.state==UIGestureRecognizerStateBegan&&[self selectedMovie])[self preview:[self selectedMovie] source:galleryImage];}
-(void)preview:(NSDictionary*)m source:(UIView*)source{
 if([self running]||mediaBusy||self.presentedViewController)return;LSRMiniPreview*p=[LSRMiniPreview new];p.movie=m;p.modalPresentationStyle=UIModalPresentationPopover;p.popoverPresentationController.sourceView=source;p.popoverPresentationController.sourceRect=source.bounds;p.popoverPresentationController.delegate=self;
 __weak LSRController*weak=self;p.shareAction=^{[weak shareMovies:@[m]];};p.deleteAction=^{[weak confirmDelete:@[m]];};[self presentViewController:p animated:YES completion:nil];
}
-(UIModalPresentationStyle)adaptivePresentationStyleForPresentationController:(UIPresentationController*)c{return UIModalPresentationNone;}
-(void)updateVisibleSelections{
 for(LSRMovieCell*cell in library.visibleCells){cell.selectionMode=selecting;cell.checked=selecting?[chosenPaths containsObject:cell.path]:mode==2&&[cell.path isEqualToString:selectedPath];[cell setNeedsLayout];}
}
-(void)updateSelectionUI{
 self.title=selecting?[NSString stringWithFormat:@"已选择 %lu 项",(unsigned long)chosenPaths.count]:page==1?@"已保存的视频":@"录屏大师";
 self.navigationItem.leftBarButtonItem=page==1?selectButton:nil;
 selectButton.title=selecting?@"完成":@"选择";selectButton.enabled=!mediaBusy&&![self running]&&(movies.count||selecting);
 self.navigationItem.rightBarButtonItem=selecting?allButton:settingsButton;
 allButton.title=movies.count&&chosenPaths.count==movies.count?@"取消全选":@"全选";allButton.enabled=!mediaBusy&&movies.count>0;
 BOOL enabled=chosenPaths.count>0&&!mediaBusy&&![self running];shareButton.enabled=saveButton.enabled=deleteButton.enabled=enabled;
 settingsButton.enabled=!mediaBusy;batchBar.hidden=!selecting||page!=1;modes.enabled=!mediaBusy;selectionPan.enabled=selectionHold.enabled=selecting&&!mediaBusy;previewHold.enabled=!selecting;galleryFull.enabled=galleryPlay.enabled=!mediaBusy&&![self running]&&!selecting;
}
-(void)toggleSelection{if(mediaBusy||[self running])return;[self stopGallery];if(selecting){[self endSelection];return;}selecting=YES;[chosenPaths removeAllObjects];[self updateVisibleSelections];[self updateGallery];[self updateSelectionUI];[self.view setNeedsLayout];}
-(void)endSelection{[self finishDrag:NO];selecting=NO;[chosenPaths removeAllObjects];[self updateVisibleSelections];[self updateGallery];[self updateSelectionUI];[self.view setNeedsLayout];}
-(void)toggleMovie:(NSDictionary*)m{NSString*p=m[@"path"];if([chosenPaths containsObject:p])[chosenPaths removeObject:p];else[chosenPaths addObject:p];[self updateVisibleSelections];[self updateSelectionUI];}
-(void)selectAll{if(mediaBusy)return;BOOL clear=chosenPaths.count==movies.count;[chosenPaths removeAllObjects];if(!clear)for(NSDictionary*m in movies)[chosenPaths addObject:m[@"path"]];[self updateVisibleSelections];[self updateSelectionUI];}
// Selection changes only cell checkmarks; thumbnails stay attached during a drag.
-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer*)g{if(g==selectionPan){CGPoint v=[selectionPan velocityInView:library];return selecting&&!mediaBusy&&fabs(v.x)>fabs(v.y)*1.15;}return selecting&&!mediaBusy;}
-(void)applyDragIndex:(NSInteger)index{if(index<0||index>=movies.count)return;[chosenPaths setSet:dragBase];NSInteger lo=MIN(dragAnchor,index),hi=MAX(dragAnchor,index);for(NSInteger i=lo;i<=hi;i++){NSString*p=movies[i][@"path"];if(dragAdding)[chosenPaths addObject:p];else[chosenPaths removeObject:p];}[self updateVisibleSelections];[self updateSelectionUI];}
-(void)dragSelect:(UIGestureRecognizer*)g{dragPoint=[g locationInView:self.view];CGPoint point=[self.view convertPoint:dragPoint toView:library];NSIndexPath*p=[library indexPathForItemAtPoint:point];if(g.state==UIGestureRecognizerStateBegan){if(!p)return;dragging=YES;dragBase=[chosenPaths copy];dragAnchor=p.item;dragAdding=![chosenPaths containsObject:movies[p.item][@"path"]];dragClock=[CADisplayLink displayLinkWithTarget:self selector:@selector(scrollDrag:)];dragClock.frameInterval=2;[dragClock addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];}if(dragging&&p)[self applyDragIndex:p.item];if(g.state==UIGestureRecognizerStateEnded||g.state==UIGestureRecognizerStateCancelled||g.state==UIGestureRecognizerStateFailed)[self finishDrag:g.state==UIGestureRecognizerStateCancelled];}
-(void)scrollDrag:(CADisplayLink*)clock{if(!dragging)return;CGPoint p=[self.view convertPoint:dragPoint toView:library];BOOL horizontal=mode==2;CGFloat pos=horizontal?p.x-library.contentOffset.x:p.y-library.contentOffset.y,len=horizontal?library.bounds.size.width:library.bounds.size.height;CGFloat delta=pos<36?-6:pos>len-36?6:0;if(!delta)return;CGPoint offset=library.contentOffset;CGFloat max=MAX(0,(horizontal?library.contentSize.width:library.contentSize.height)-len);if(horizontal)offset.x=MAX(0,MIN(max,offset.x+delta));else offset.y=MAX(0,MIN(max,offset.y+delta));library.contentOffset=offset;p=[self.view convertPoint:dragPoint toView:library];NSIndexPath*i=[library indexPathForItemAtPoint:p];if(i)[self applyDragIndex:i.item];}
-(void)finishDrag:(BOOL)cancel{if(cancel&&dragBase){[chosenPaths setSet:dragBase];[self updateVisibleSelections];[self updateSelectionUI];}dragging=NO;dragBase=nil;[dragClock invalidate];dragClock=nil;}
-(NSArray*)selectedMovies{NSMutableArray*a=[NSMutableArray array];for(NSDictionary*m in movies)if([chosenPaths containsObject:m[@"path"]])[a addObject:m];return a;}
-(void)shareSelected{[self shareMovies:[self selectedMovies]];}
-(void)shareMovies:(NSArray*)items{
 if(!items.count||mediaBusy||[self running])return;NSMutableArray*urls=[NSMutableArray array];for(NSDictionary*m in items)[urls addObject:[NSURL fileURLWithPath:m[@"path"]]];
 UIActivityViewController*a=[[UIActivityViewController alloc] initWithActivityItems:urls applicationActivities:nil];a.popoverPresentationController.sourceView=self.view;a.popoverPresentationController.sourceRect=CGRectMake(self.view.bounds.size.width/2,self.view.bounds.size.height-48,1,1);[self presentViewController:a animated:YES completion:nil];
}
-(void)notice:(NSString*)title message:(NSString*)message{UIAlertController*a=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleCancel handler:nil]];[self presentViewController:a animated:YES completion:nil];}
-(void)deleteSelected{[self confirmDelete:[self selectedMovies]];}
-(void)confirmDelete:(NSArray*)items{
 if(!items.count||mediaBusy||[self running])return;UIAlertController*a=[UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"删除 %lu 段录像？",(unsigned long)items.count] message:@"将删除所选录像及其缩略图，无法撤销。已存到相册的副本不受影响。" preferredStyle:UIAlertControllerStyleAlert];
 [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[a addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction*x){[self deleteMovies:items];}]];[self presentViewController:a animated:YES completion:nil];
}
-(void)deleteMovies:(NSArray*)items{
 mediaBusy=YES;[self refresh];dispatch_async(catalogQueue,^{@autoreleasepool{
  NSMutableArray*failed=[NSMutableArray array];NSFileManager*fm=[NSFileManager defaultManager];
  for(NSDictionary*m in items){NSString*p=m[@"path"];NSError*e=nil;if([fm removeItemAtPath:p error:&e]||![fm fileExistsAtPath:p]){[fm removeItemAtPath:[p stringByAppendingString:@".json"] error:NULL];[[LSRThumbnailStore shared] remove:p];}else[failed addObject:m];}
  dispatch_async(dispatch_get_main_queue(),^{self->mediaBusy=NO;self->selectedPath=nil;if(!failed.count)[self endSelection];[self reloadMovies];[self refresh];if(failed.count)[self notice:@"部分录像未能删除" message:[NSString stringWithFormat:@"%lu 段删除失败，请检查文件权限。",(unsigned long)failed.count]];});
 }});
}
-(void)saveSelected{
 NSArray*items=[self selectedMovies];if(!items.count||mediaBusy||[self running])return;mediaBusy=YES;[self refresh];
 [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus permission){dispatch_async(dispatch_get_main_queue(),^{if(permission!=PHAuthorizationStatusAuthorized){self->mediaBusy=NO;[self refresh];[self notice:@"未获得相册权限" message:@"请在系统设置的隐私／照片中允许录屏大师，然后重试。录像仍保存在本应用中。"];return;}[self saveNext:items index:0 succeeded:0];});}];
}
-(void)saveNext:(NSArray*)items index:(NSUInteger)index succeeded:(NSUInteger)succeeded{
 if(index==items.count){
#ifdef LSR_TESTING
 [[NSJSONSerialization dataWithJSONObject:@{@"saved":@(succeeded),@"total":@(items.count)} options:0 error:NULL] writeToFile:@LSR_DIR "/save-test.json" atomically:YES];
#endif
 mediaBusy=NO;[self refresh];[self notice:@"保存完成" message:[NSString stringWithFormat:@"已存到相册 %lu 段%@。",(unsigned long)succeeded,succeeded==items.count?@"":[NSString stringWithFormat:@"，%lu 段未能保存（可能空间不足或格式不受支持）",(unsigned long)(items.count-succeeded)]]];return;}
 NSURL*url=[NSURL fileURLWithPath:items[index][@"path"]];__block BOOL created=NO;
 [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{created=[PHAssetChangeRequest creationRequestForAssetFromVideoAtFileURL:url]!=nil;} completionHandler:^(BOOL success,NSError*error){dispatch_async(dispatch_get_main_queue(),^{[self saveNext:items index:index+1 succeeded:succeeded+(success&&created?1:0)];});}];
}
#ifdef LSR_TESTING
-(void)testUI:(NSString*)name{
 if([name isEqual:@"overlay-test"]){[LSROverlayCheck run];return;}
 if([name isEqual:@"quality-scene"]){[self.navigationController pushViewController:[[LSRPattern alloc] initWithMode:@"au"] animated:NO];return;}
 if([name isEqual:@"webdav-test"]){[self settings];LSRSettings*c=(LSRSettings*)self.navigationController.topViewController;[c tableView:c.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:3 inSection:0]];return;}

 if([name isEqualToString:@"mic-on"]){[LSRDefaults() setBool:YES forKey:@"microphone"];[LSRDefaults() setBool:YES forKey:@"showIndicator"];return;}
 if([name isEqualToString:@"iphone4s-preview"]){
  UIViewController*host=[UIViewController new];host.view.frame=self.view.bounds;[self addChildViewController:host];[self.view addSubview:host.view];[host didMoveToParentViewController:self];host.view.backgroundColor=[UIColor colorWithWhite:.12 alpha:1];
  UIView*phone=[[UIView alloc] initWithFrame:CGRectMake((host.view.bounds.size.width-320)/2,20,320,480)];phone.backgroundColor=[UIColor whiteColor];[host.view addSubview:phone];
  UILabel*mockStatus=LSRLabel(12,NO);mockStatus.frame=CGRectMake(0,0,320,20);mockStatus.text=@"iPhone                       9:41                       100%";mockStatus.textAlignment=NSTextAlignmentCenter;mockStatus.backgroundColor=[UIColor colorWithWhite:.97 alpha:1];[phone addSubview:mockStatus];
  LSRController*c=[LSRController new];UINavigationController*n=[[UINavigationController alloc] initWithRootViewController:c];[host addChildViewController:n];[host setOverrideTraitCollection:[UITraitCollection traitCollectionWithTraitsFromCollections:@[[UITraitCollection traitCollectionWithUserInterfaceIdiom:UIUserInterfaceIdiomPhone],[UITraitCollection traitCollectionWithHorizontalSizeClass:UIUserInterfaceSizeClassCompact],[UITraitCollection traitCollectionWithVerticalSizeClass:UIUserInterfaceSizeClassRegular]]] forChildViewController:n];n.view.frame=CGRectMake(0,20,320,460);[phone addSubview:n.view];[n didMoveToParentViewController:host];
  void(^shot)(NSString*)=^(NSString*name){[phone layoutIfNeeded];UIGraphicsBeginImageContextWithOptions(CGSizeMake(320,480),YES,2);[phone drawViewHierarchyInRect:phone.bounds afterScreenUpdates:YES];NSData*data=UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext());UIGraphicsEndImageContext();[data writeToFile:[@LSR_DIR stringByAppendingPathComponent:name] atomically:YES];};
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{shot(@"iphone4s-home.png");c->recordScroll.contentOffset=CGPointMake(0,c->inlineSettings.view.frame.origin.y);shot(@"iphone4s-settings.png");c->recordScroll.contentOffset=CGPointZero;[c showPage:1];c->modes.selectedSegmentIndex=1;[c changeMode:c->modes];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{shot(@"iphone4s-library.png");c->modes.selectedSegmentIndex=2;[c changeMode:c->modes];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{shot(@"iphone4s-gallery.png");});});});return;
 }
 if(catalogBusy){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{[self testUI:name];});return;}
 [self showPage:1];
 if([name isEqualToString:@"latest-play"]){[self showPage:0];[self.view layoutIfNeeded];NSString*expected=movies.firstObject[@"path"];[latestButton sendActionsForControlEvents:UIControlEventTouchUpInside];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{AVPlayerViewController*c=[self.presentedViewController isKindOfClass:[AVPlayerViewController class]]?(id)self.presentedViewController:nil;AVURLAsset*a=[c.player.currentItem.asset isKindOfClass:[AVURLAsset class]]?(id)c.player.currentItem.asset:nil;NSDictionary*r=@{@"correctMovie":@([a.URL.path isEqualToString:expected]),@"playing":@(c.player.rate>0),@"largeThumbnail":@(self->latestImage.image!=nil)};[[NSJSONSerialization dataWithJSONObject:r options:0 error:NULL] writeToFile:@LSR_DIR "/latest-test.json" atomically:YES];});return;}
 if([name isEqualToString:@"interaction-test"]){[self showPage:1];mode=1;modes.selectedSegmentIndex=1;[self changeMode:modes];[self.view layoutIfNeeded];[library layoutIfNeeded];[self toggleSelection];NSAssert(movies.count>=4,@"Need four recordings for selection QA");dragBase=[chosenPaths copy];dragAnchor=0;dragAdding=YES;[self applyDragIndex:3];BOOL latestCorrect=[latestPath isEqualToString:movies.firstObject[@"path"]]&&latestButton.enabled;BOOL range=chosenPaths.count==4;[self applyDragIndex:1];BOOL reverse=chosenPaths.count==2;dragBase=[chosenPaths copy];dragAnchor=0;dragAdding=NO;[self applyDragIndex:1];BOOL remove=chosenPaths.count==0;dragging=YES;dragBase=[chosenPaths copy];dragAnchor=0;dragAdding=YES;CGRect savedLibraryFrame=library.frame;library.frame=CGRectMake(savedLibraryFrame.origin.x,savedLibraryFrame.origin.y,savedLibraryFrame.size.width,100);[library layoutIfNeeded];library.contentOffset=CGPointZero;CGPoint previousOffset=library.contentOffset;dragPoint=[library convertPoint:CGPointMake(20,library.contentOffset.y+library.bounds.size.height-3) toView:self.view];[self scrollDrag:nil];BOOL autoScroll=library.contentOffset.y>previousOffset.y;library.frame=savedLibraryFrame;[self finishDrag:YES];BOOL cancelRestores=chosenPaths.count==0;[self endSelection];modes.selectedSegmentIndex=2;[self changeMode:modes];[self.view layoutIfNeeded];BOOL square=fabs(galleryImage.bounds.size.width-galleryImage.bounds.size.height)<.1;[self playGallery];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{BOOL playing=self->galleryPlayer.rate>0&&self->galleryLayer.superlayer==self->galleryImage.layer;CMTime current=self->galleryPlayer.currentTime;[self playGallery];BOOL paused=self->galleryPlayer.rate==0;[self fullGallery];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{BOOL fullscreen=[self.presentedViewController isKindOfClass:[AVPlayerViewController class]];[self dismissViewControllerAnimated:NO completion:^{[self showPage:0];[self.view layoutIfNeeded];NSDictionary*r=@{@"latestVideo":@(latestCorrect),@"recordContentReachable":@(self->inlineSettings.view.frame.size.height>300&&CGRectGetMaxY(self->inlineSettings.view.frame)<=self->recordScroll.contentSize.height),@"range":@(range),@"reverse":@(reverse),@"deselect":@(remove),@"edgeAutoScroll":@(autoScroll),@"cancelRestores":@(cancelRestores),@"square":@(square),@"inlinePlaying":@(playing),@"timeAdvanced":@(CMTimeGetSeconds(current)>0),@"paused":@(paused),@"fullscreen":@(fullscreen),@"releasedOnTabChange":@(self->galleryPlayer==nil),@"inlineSettings":@(self->inlineSettings.recordingOnly)};[[NSJSONSerialization dataWithJSONObject:r options:0 error:NULL] writeToFile:@LSR_DIR "/interaction-test.json" atomically:YES];}];});});return;}
 if([name isEqualToString:@"flicker-test"]){[self showPage:1];mode=1;modes.selectedSegmentIndex=1;[self changeMode:modes];[self.view layoutIfNeeded];dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{NSMutableDictionary*images=[NSMutableDictionary dictionary];for(LSRMovieCell*cell in self->library.visibleCells)if(cell.thumbnail.image)images[cell.path]=cell.thumbnail.image;[self toggleSelection];if(self->movies.count)for(int i=0;i<6;i++)[self toggleMovie:self->movies[0]];NSUInteger changed=0;for(LSRMovieCell*cell in self->library.visibleCells)if(images[cell.path]&&cell.thumbnail.image!=images[cell.path])changed++;NSDictionary*r=@{@"visibleImages":@(images.count),@"changedImages":@(changed)};[[NSJSONSerialization dataWithJSONObject:r options:0 error:NULL] writeToFile:@LSR_DIR "/flicker-test.json" atomically:YES];});return;}
 if([name isEqualToString:@"mic-off"]){[LSRDefaults() setBool:NO forKey:@"microphone"];[LSRDefaults() synchronize];return;}
 if([name isEqualToString:@"preview"]){if(movies.count)[self preview:movies[0] source:card];return;}
 mode=[name isEqualToString:@"gallery"]?2:[name isEqualToString:@"list"]?0:1;modes.selectedSegmentIndex=mode;[self changeMode:modes];
 if([name hasPrefix:@"select"]||[name hasPrefix:@"fixture"]){[self toggleSelection];NSUInteger n=0;for(NSDictionary*m in movies){if([name hasPrefix:@"fixture"]&&![[m[@"path"] lastPathComponent] hasPrefix:@"LSR-TEST-041-"])continue;[self toggleMovie:m];if(++n==2)break;}}
 if([name isEqualToString:@"select-share"])[self shareSelected];
 if([name isEqualToString:@"select-delete"])[self deleteSelected];
 if([name isEqualToString:@"fixture-delete"]){NSArray*items=[self selectedMovies];if(items.count==2)[self deleteMovies:items];}
 if([name isEqualToString:@"fixture-views"]){NSUInteger n=chosenPaths.count;for(int i=0;i<3;i++){modes.selectedSegmentIndex=i;[self changeMode:modes];NSAssert(chosenPaths.count==n,@"Selection lost across views");}[self selectAll];NSAssert(chosenPaths.count==movies.count,@"Select all failed");[self selectAll];NSAssert(chosenPaths.count==0,@"Deselect all failed");}
 if([name isEqualToString:@"fixture-save"]&&[PHPhotoLibrary authorizationStatus]==PHAuthorizationStatusAuthorized)[self saveSelected];
 NSDictionary*probe=@{@"title":self.title?:@"",@"selected":@(chosenPaths.count),@"photos":@([PHPhotoLibrary authorizationStatus]),@"items":@(movies.count)};
 [[NSJSONSerialization dataWithJSONObject:probe options:0 error:NULL] writeToFile:@LSR_DIR "/ui-test.json" atomically:YES];
}
#endif
-(void)dealloc{[dragClock invalidate];[poll invalidate];[[NSNotificationCenter defaultCenter] removeObserver:self];[microphone stop];}
@end
@interface LSRApp:UIResponder<UIApplicationDelegate>@property(nonatomic,strong)UIWindow*window;@property(nonatomic,strong)UINavigationController*navigation;@end
@implementation LSRApp
-(BOOL)application:(UIApplication*)app didFinishLaunchingWithOptions:(NSDictionary*)options{self.window=[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];LSRController*c=[LSRController new];self.navigation=[[UINavigationController alloc] initWithRootViewController:c];self.window.rootViewController=self.navigation;[self.window makeKeyAndVisible];
#ifdef LSR_TESTING
NSString*m=[NSString stringWithContentsOfFile:@LSR_DIR "/test-mode" encoding:NSUTF8StringEncoding error:NULL];m=[m stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];if(m.length)dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC),dispatch_get_main_queue(),^{if([m hasPrefix:@"ui-"]){NSString*mode=[m substringFromIndex:3];if([mode isEqualToString:@"settings"])[c settings];else if([mode isEqualToString:@"record"])[c record];else[c testUI:mode];}else[self.navigation pushViewController:[[LSRPattern alloc] initWithMode:m] animated:NO];});
#endif


return YES;}
@end
int main(int argc,char**argv){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass([LSRApp class]));}}
