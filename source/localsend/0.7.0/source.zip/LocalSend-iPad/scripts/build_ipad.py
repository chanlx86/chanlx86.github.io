#!/usr/bin/python3
from pathlib import Path
import subprocess,shlex,concurrent.futures,shutil,plistlib,sys
root=Path(__file__).resolve().parent.parent
build=root/'build';obj=build/'obj';obj.mkdir(parents=True,exist_ok=True)
dev=Path('/Volumes/OS X/Applications/Xcode.app/Contents/Developer');cc=dev/'Toolchains/XcodeDefault.xctoolchain/usr/bin/clang';sdk=dev/'Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk'
common=[str(cc),'-arch','armv7','-isysroot',str(sdk),'-miphoneos-version-min=9.0','-O2','-fblocks','-DMBEDTLS_PLATFORM_MS_TIME_ALT','-I.','-Ivendor/heic-ios/include','-Ivendor/mbedtls-3.6.7/include','-Ivendor/mbedtls-3.6.7/library','-Ivendor/mbedtls-3.6.7/3rdparty/everest/include','-Ivendor/mbedtls-3.6.7/3rdparty/p256-m','-Ivendor/mbedtls-3.6.7/3rdparty/p256-m/p256-m','-Wno-incompatible-pointer-types-discards-qualifiers','-Wno-deprecated-declarations']
sources=['main.m','AppDelegate.m','LSLocalization.m','LSDesign.m','LSFilesystemPicker.m','LSPhotoPicker.m','LSReceiver.m','LSPhotoImporter.m','LSHEICDecoder.c','LSClock.c','LSZip.c','LSTransport.m','LSConnection.m','LSIdentity.m']
sources+=shlex.split((root/'mbedtls-sources.mk').read_text().split(':=',1)[1].replace('\\\n',' '))
if '--testing' in sys.argv:sources+=['tests/Integration.m','tests/Features.m'];common+=['-DLS_TESTING=1']
def compile(source):
 out=obj/(source.replace('/','_')+'.o')
 if out.exists() and out.stat().st_mtime>(root/source).stat().st_mtime and source.startswith('vendor/'):return str(out)
 args=common+(['-fobjc-arc'] if source.endswith('.m') else ['-std=c99'])+['-c',source,'-o',str(out)]
 p=subprocess.run(args,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if p.returncode:raise RuntimeError(source+'\n'+p.stdout.decode(errors='replace'))
 return str(out)
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:objects=list(pool.map(compile,sources))
 app=build/'LocalSend6.app';shutil.rmtree(app,ignore_errors=True);shutil.copytree(root/'Resources',app)
 subprocess.run(common+objects+['-Lvendor/heic-ios/lib','-lheif','-lde265','-lc++','-lz']+sum([['-framework',x] for x in ['UIKit','Foundation','Security','QuartzCore','CoreGraphics','ImageIO','AssetsLibrary','AVFoundation','Photos','MobileCoreServices']],[])+['-o',str(app/'LocalSend6')],cwd=root,check=True)
 shutil.copy(root/'Info.plist',app/'Info.plist')
 ext=app/'PlugIns/LocalSendShare.appex';ext.mkdir(parents=True)
 subprocess.run(common+['-fobjc-arc','-fapplication-extension','-e','_NSExtensionMain','-framework','UIKit','-framework','Foundation','-framework','MobileCoreServices','-framework','CoreGraphics','Share/ShareViewController.m','Share/LegacyExtensionCompatibility.m','-o',str(ext/'LocalSendShare')],cwd=root,check=True)
 shutil.copy(root/'Share/Info.plist',ext/'Info.plist')
 print('Built '+str(app))
except Exception as e:print(e);sys.exit(1)
