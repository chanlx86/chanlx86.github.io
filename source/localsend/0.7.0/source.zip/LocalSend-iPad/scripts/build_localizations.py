"""Build legacy translations and the iPad fork's Simplified Chinese catalog."""
from pathlib import Path
import plistlib,re,json
root=Path(__file__).resolve().parent.parent
rows=(root/'Assets/Translations.tsv').read_text().splitlines()
chinese=(root/'Assets/Chinese.txt').read_text().splitlines()
assert len(chinese)==len(rows)
catalogs={language:{} for language in ('ru','en','uk','zh')}
for row,zh in zip(rows,chinese):
    key,english,ukrainian=[value.replace('\\n','\n') for value in row.split('|')]
    for language,value in [('ru',key),('en',english),('uk',ukrainian),('zh',zh.replace('\\n','\n'))]:
        value=value.replace('LocalSend 6','LocalSend')
        formats=r'%(?:\.\d+|\d+)?(?:lld|lu|ld|s|@|f|d|%)'
        assert re.findall(formats,key)==re.findall(formats,value),(language,key,value)
        catalogs[language][key]=value
        if '0.5.7' in key:
            newkey=key.replace('LocalSend 6 · 0.5.7','LocalSend · 0.7.0')
            catalogs[language][newkey]=value.replace('0.5.7','0.7.0').replace('0.6.0','0.7.0').replace('iOS 6 and later','iOS 9 and later').replace('iOS 6 і новіші','iOS 9 і новіші').replace('iOS 6 и новее','iOS 9 и новее')
for key,english in json.loads((root/"Assets/ExtraTranslations.json").read_text()).items():
    for language,catalog in catalogs.items():catalog[key]=key if language=="zh" else english
for language,catalog in catalogs.items():
    for locale in ([language,'zh-Hans'] if language=='zh' else [language]):
        directory=root/'Resources'/(locale+'.lproj');directory.mkdir(exist_ok=True)
        (directory/'Translations.plist').write_bytes(plistlib.dumps(catalog))
        descriptions={'NSPhotoLibraryUsageDescription':catalog['Выбор фото и видео для отправки и сохранение полученных файлов в Фото.'],'NSPhotoLibraryAddUsageDescription':catalog['Сохранение полученных фото и видео в Фото.']}
        (directory/'InfoPlist.strings').write_bytes(plistlib.dumps(descriptions))
