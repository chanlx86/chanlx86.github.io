#import <AppKit/AppKit.h>
static void LSLogo(CGContextRef c) {

CGContextMoveToPoint(c, 5.5380000, 12.0150000);
CGContextAddCurveToPoint(c, 5.5402085, 8.4483448, 8.4333448, 5.5587902, 12.0000000, 5.5610000);
CGContextAddCurveToPoint(c, 15.5666552, 5.5587902, 18.4597915, 8.4483448, 18.4620000, 12.0150000);
CGContextAddCurveToPoint(c, 18.4160120, 15.5503663, 15.5356645, 18.3914890, 12.0000000, 18.3890000);
CGContextAddCurveToPoint(c, 8.4647249, 18.3909413, 5.5849832, 15.5499766, 5.5390000, 12.0150000);
CGContextAddLineToPoint(c, 5.5380000, 12.0150000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 22.5300000, 6.2620000);
CGContextAddCurveToPoint(c, 21.7226321, 6.7884371, 20.6461958, 6.6055475, 20.0580000, 5.8420000);
CGContextAddCurveToPoint(c, 19.5164677, 5.1380922, 18.8854847, 4.5077816, 18.1810000, 3.9670000);
CGContextAddCurveToPoint(c, 17.4170884, 3.3804328, 17.2336396, 2.3045771, 17.7600000, 1.4980000);
CGContextAddCurveToPoint(c, 19.7709458, 2.5997327, 21.4257371, 4.2524425, 22.5300000, 6.2620000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 3.9430000, 5.8420000);
CGContextAddCurveToPoint(c, 3.3548042, 6.6055475, 2.2783679, 6.7884371, 1.4710000, 6.2620000);
CGContextAddCurveToPoint(c, 2.5752629, 4.2524425, 4.2300542, 2.5997327, 6.2410000, 1.4980000);
CGContextAddCurveToPoint(c, 6.7675797, 2.3043289, 6.5845744, 3.3801384, 5.8210000, 3.9670000);
CGContextAddCurveToPoint(c, 5.1161629, 4.5077147, 4.4848409, 5.1380283, 3.9430000, 5.8420000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 24.0000000, 12.0150000);
CGContextAddCurveToPoint(c, 24.0010000, 13.1550000, 23.8400000, 14.2900000, 23.5200000, 15.3850000);
CGContextAddCurveToPoint(c, 22.5764372, 15.1881504, 21.9436656, 14.2978250, 22.0680000, 13.3420000);
CGContextAddCurveToPoint(c, 22.1830000, 12.4620000, 22.1830000, 11.5690000, 22.0680000, 10.6880000);
CGContextAddCurveToPoint(c, 21.9435985, 9.7324898, 22.5758407, 8.8422963, 23.5190000, 8.6450000);
CGContextAddCurveToPoint(c, 23.8390000, 9.7400000, 24.0010000, 10.8750000, 24.0000000, 12.0150000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 0.0000000, 12.0150000);
CGContextAddCurveToPoint(c, 0.0000000, 10.8750000, 0.1620000, 9.7400000, 0.4820000, 8.6450000);
CGContextAddCurveToPoint(c, 1.4247559, 8.8427427, 2.0564689, 9.7328045, 1.9320000, 10.6880000);
CGContextAddCurveToPoint(c, 1.8170000, 11.5680000, 1.8170000, 12.4610000, 1.9320000, 13.3420000);
CGContextAddCurveToPoint(c, 2.0564689, 14.2971955, 1.4247559, 15.1872573, 0.4820000, 15.3850000);
CGContextAddCurveToPoint(c, 0.1615179, 14.2900428, -0.0007905, 13.1548941, 0.0000000, 12.0140000);
CGContextAddLineToPoint(c, 0.0000000, 12.0150000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 17.7600000, 22.5330000);
CGContextAddCurveToPoint(c, 17.2327897, 21.7264658, 17.4158411, 20.6499491, 18.1800000, 20.0630000);
CGContextAddCurveToPoint(c, 18.8848446, 19.5222939, 19.5161677, 18.8919793, 20.0580000, 18.1880000);
CGContextAddCurveToPoint(c, 20.6461958, 17.4244525, 21.7226321, 17.2415629, 22.5300000, 17.7680000);
CGContextAddCurveToPoint(c, 21.4258889, 19.7779265, 19.7710834, 21.4309974, 17.7600000, 22.5330000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 6.2410000, 22.5330000);
CGContextAddCurveToPoint(c, 4.2300542, 21.4312673, 2.5752629, 19.7785575, 1.4710000, 17.7690000);
CGContextAddCurveToPoint(c, 2.2783679, 17.2425629, 3.3548042, 17.4254525, 3.9430000, 18.1890000);
CGContextAddCurveToPoint(c, 4.4845990, 18.8925554, 5.1155792, 19.5225270, 5.8200000, 20.0630000);
CGContextAddCurveToPoint(c, 6.5850000, 20.6500000, 6.7680000, 21.7260000, 6.2410000, 22.5330000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 12.0010000, 24.0000000);
CGContextAddCurveToPoint(c, 10.8588977, 24.0013154, 9.7224486, 23.8396871, 8.6260000, 23.5200000);
CGContextAddCurveToPoint(c, 8.8246755, 22.5765172, 9.7159829, 21.9448478, 10.6720000, 22.0700000);
CGContextAddCurveToPoint(c, 11.5540000, 22.1850000, 12.4470000, 22.1850000, 13.3290000, 22.0700000);
CGContextAddCurveToPoint(c, 14.2847028, 21.9447799, 15.1758787, 22.5759206, 15.3750000, 23.5190000);
CGContextAddCurveToPoint(c, 14.2790000, 23.8390000, 13.1420000, 24.0010000, 12.0000000, 24.0000000);
CGContextAddLineToPoint(c, 12.0010000, 24.0000000);
CGContextClosePath(c);
CGContextMoveToPoint(c, 13.5070000, 1.9430000);
CGContextAddCurveToPoint(c, 12.5620000, 1.8070000, 11.6190000, 1.8430000, 10.6730000, 1.9300000);
CGContextAddCurveToPoint(c, 9.7168754, 2.0547092, 8.8255641, 1.4233456, 8.6260000, 0.4800000);
CGContextAddCurveToPoint(c, 9.7218198, 0.1605679, 10.8575725, -0.0010571, 11.9990000, -0.0000000);
CGContextAddLineToPoint(c, 12.0010000, 0.0000000);
CGContextAddCurveToPoint(c, 13.1430000, -0.0010000, 14.2780000, 0.1600000, 15.3740000, 0.4800000);
CGContextAddCurveToPoint(c, 15.1891150, 1.3560930, 14.4018872, 1.9729727, 13.5070000, 1.9430000);
CGContextClosePath(c);
 CGContextFillPath(c);
}

int main(int argc,char **argv){@autoreleasepool{
 NSArray *specs=@[@[@"Default.png",@320,@480,@1],@[@"Default@2x.png",@640,@960,@2],@[@"Default-568h@2x.png",@640,@1136,@2],@[@"Default-Portrait~ipad.png",@768,@1004,@1],@[@"Default-Portrait@2x~ipad.png",@1536,@2008,@2],@[@"Default-Landscape~ipad.png",@1024,@748,@1],@[@"Default-Landscape@2x~ipad.png",@2048,@1496,@2]];
 for(NSArray *spec in specs){size_t w=[spec[1] unsignedIntegerValue],h=[spec[2] unsignedIntegerValue];CGFloat scale=[spec[3] doubleValue];
 NSBitmapImageRep *rep=[[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:w pixelsHigh:h bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:0 bitsPerPixel:0];
 CGColorSpaceRef cs=CGColorSpaceCreateDeviceRGB();CGContextRef c=CGBitmapContextCreate(rep.bitmapData,w,h,8,rep.bytesPerRow,cs,kCGImageAlphaPremultipliedLast);CGColorSpaceRelease(cs);
 CGContextSetRGBFillColor(c,.965,.984,.976,1);CGContextFillRect(c,CGRectMake(0,0,w,h));CGFloat side=MIN(w/scale,h/scale)>600?140:110;side*=scale;
 CGContextTranslateCTM(c,(w-side)/2,(h-side)/2);CGContextScaleCTM(c,side/24,side/24);CGContextSetRGBFillColor(c,.0,.57,.45,1);LSLogo(c);CGContextRelease(c);
 NSData *png=[rep representationUsingType:NSPNGFileType properties:@{}];if(![png writeToFile:[@(argv[1]) stringByAppendingPathComponent:spec[0]] atomically:YES])return 2;
 }return 0;}}
