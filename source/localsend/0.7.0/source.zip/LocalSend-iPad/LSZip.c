#include "LSZip.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>
#include <time.h>
#include <fcntl.h>
#include <zlib.h>
typedef struct {char *name;uint32_t crc,size,offset,stamp;int directory;} Entry;
typedef struct {FILE *file;Entry *entries;size_t count;char *error;size_t capacity;} Zip;
static int fail(Zip *z,const char *message){snprintf(z->error,z->capacity,"%s",message);return -1;}
static void word(Zip*z,uint32_t v,int bytes){for(int i=0;i<bytes;i++)fputc((v>>(8*i))&255,z->file);}
static int add(Zip*z,const char*path,const char*name,int depth){
 struct stat st;if(depth>64)return fail(z,"Folder nesting exceeds 64 levels");
 if(lstat(path,&st))return fail(z,strerror(errno));
 if(S_ISLNK(st.st_mode))return fail(z,"Folder contains a symbolic link; choose files directly instead");
 if(!S_ISDIR(st.st_mode)&&!S_ISREG(st.st_mode))return fail(z,"Folder contains a non-regular file");
 size_t n=strlen(name);int dir=S_ISDIR(st.st_mode);off_t offset=ftello(z->file);
 if(z->count>=65535||n+dir>65535||st.st_size>UINT32_MAX||offset<0||(uint64_t)offset>UINT32_MAX)return fail(z,"Archive exceeds ZIP32 limits");
 Entry *grown=realloc(z->entries,(z->count+1)*sizeof(Entry));if(!grown)return fail(z,"Out of memory");z->entries=grown;
 Entry *e=&grown[z->count++];memset(e,0,sizeof(*e));e->name=malloc(n+dir+1);if(!e->name)return fail(z,"Out of memory");memcpy(e->name,name,n);if(dir)e->name[n++]='/';e->name[n]=0;e->directory=dir;e->offset=(uint32_t)offset;
 struct tm t;localtime_r(&st.st_mtime,&t);e->stamp=((uint32_t)((t.tm_year+1900<1980?1980:t.tm_year+1900)-1980)<<25)|((t.tm_mon+1)<<21)|(t.tm_mday<<16)|(t.tm_hour<<11)|(t.tm_min<<5)|(t.tm_sec/2);
 word(z,0x04034b50,4);word(z,20,2);word(z,0x808,2);word(z,0,2);word(z,e->stamp,4);word(z,0,4);word(z,0,4);word(z,0,4);word(z,(uint32_t)n,2);word(z,0,2);fwrite(e->name,1,n,z->file);
 if(!dir){FILE *in=fopen(path,"rb");if(!in)return fail(z,strerror(errno));unsigned char buffer[65536];size_t length;uint64_t total=0;uLong crc=crc32(0,NULL,0);
  while((length=fread(buffer,1,sizeof(buffer),in))){total+=length;if(total>UINT32_MAX||fwrite(buffer,1,length,z->file)!=length){fclose(in);return fail(z,"Archive write failed or too large");}crc=crc32(crc,buffer,(uInt)length);}
  int bad=ferror(in);fclose(in);if(bad)return fail(z,"Source file read failed");e->size=(uint32_t)total;e->crc=(uint32_t)crc;
 }
 word(z,0x08074b50,4);word(z,e->crc,4);word(z,e->size,4);word(z,e->size,4);
 if(ferror(z->file))return fail(z,"Archive write failed");
 if(dir){DIR*d=opendir(path);if(!d)return fail(z,strerror(errno));struct dirent *child;int result=0;
  while((child=readdir(d))){if(!strcmp(child->d_name,".")||!strcmp(child->d_name,".."))continue;char p[PATH_MAX],rel[PATH_MAX];
   if(snprintf(p,sizeof(p),"%s/%s",path,child->d_name)>=sizeof(p)||snprintf(rel,sizeof(rel),"%s/%s",name,child->d_name)>=sizeof(rel)){result=fail(z,"Path too long");break;}
   if((result=add(z,p,rel,depth+1)))break;
  }closedir(d);return result;
 }return 0;
}
int LSZipDirectory(const char *source,const char *output,char *error,size_t capacity){
 Zip z={0};z.error=error;z.capacity=capacity;char src[PATH_MAX],destParent[PATH_MAX],parent[PATH_MAX];struct stat st;
 if(!realpath(source,src)||stat(src,&st)||!S_ISDIR(st.st_mode)){snprintf(error,capacity,"Source is not a readable folder");return -1;}
 snprintf(parent,sizeof(parent),"%s",output);char *slash=strrchr(parent,'/');if(!slash){snprintf(error,capacity,"Output requires an absolute path");return -1;}*slash=0;
 if(!strcmp(src,"/")||!realpath(parent,destParent)||(!strncmp(src,destParent,strlen(src))&&(destParent[strlen(src)]=='/'||destParent[strlen(src)]==0))){snprintf(error,capacity,"Save the archive outside the selected folder");return -1;}
 int fd=open(output,O_WRONLY|O_CREAT|O_EXCL,0600);z.file=fd<0?NULL:fdopen(fd,"wb");if(fd>=0&&!z.file){close(fd);unlink(output);}if(!z.file){snprintf(error,capacity,"%s",strerror(errno));return -1;}
 const char *name=strrchr(src,'/');int result=add(&z,src,name&&name[1]?name+1:"Folder",0);off_t start=ftello(z.file);
 if(!result&&(start<0||(uint64_t)start>UINT32_MAX))result=fail(&z,"Archive exceeds ZIP32 limits");
 if(!result){for(size_t i=0;i<z.count;i++){Entry *e=&z.entries[i];word(&z,0x02014b50,4);word(&z,20,2);word(&z,20,2);word(&z,0x808,2);word(&z,0,2);word(&z,e->stamp,4);word(&z,e->crc,4);word(&z,e->size,4);word(&z,e->size,4);word(&z,(uint32_t)strlen(e->name),2);word(&z,0,2);word(&z,0,2);word(&z,0,2);word(&z,0,2);word(&z,e->directory?16:0,4);word(&z,e->offset,4);fwrite(e->name,1,strlen(e->name),z.file);}
  off_t end=ftello(z.file);if(end<0||(uint64_t)end>UINT32_MAX)result=fail(&z,"Archive exceeds ZIP32 limits");else{word(&z,0x06054b50,4);word(&z,0,2);word(&z,0,2);word(&z,(uint32_t)z.count,2);word(&z,(uint32_t)z.count,2);word(&z,(uint32_t)(end-start),4);word(&z,(uint32_t)start,4);word(&z,0,2);}
 }
 if(ferror(z.file))result=fail(&z,"Archive write failed");if(fclose(z.file)&&!result)result=fail(&z,"Archive close failed");for(size_t i=0;i<z.count;i++)free(z.entries[i].name);free(z.entries);if(result)unlink(output);return result;
}
