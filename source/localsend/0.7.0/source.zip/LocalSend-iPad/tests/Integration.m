#import <UIKit/UIKit.h>
#import <Photos/Photos.h>
#import "AppDelegate.h"
#import "LSLocalization.h"
#import "LSPhotoPicker.h"
#import "LSReceiver.h"
@interface AppDelegate (Test)
- (NSString *)documentsPath;
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)source annotation:(id)annotation;
- (void)chooseFile;
- (void)consumeSharedFiles;
- (void)closeReceive;
- (void)addPeer:(NSDictionary *)peer;
- (void)sendFile:(NSString *)name toHost:(NSString *)host;
@end
static NSMutableDictionary *results;
static void StartOutgoing(AppDelegate *app,NSString *name,NSString *host,int retries){if([[app valueForKey:@"importing"] boolValue]&&retries){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/10),dispatch_get_main_queue(),^{StartOutgoing(app,name,host,retries-1);});return;}[app sendFile:name toHost:host];}

static void Save(void){[NSJSONSerialization dataWithJSONObject:results options:NSJSONWritingPrettyPrinted error:nil];NSData *data=[NSJSONSerialization dataWithJSONObject:results options:NSJSONWritingPrettyPrinted error:nil];[data writeToFile:[[(AppDelegate *)[UIApplication sharedApplication].delegate documentsPath] stringByAppendingPathComponent:@".LocalSend6-test-results.json"] atomically:YES];}
__attribute__((constructor))static void Integration(void){dispatch_async(dispatch_get_main_queue(),^{dispatch_after(dispatch_time(DISPATCH_TIME_NOW,5*NSEC_PER_SEC),dispatch_get_main_queue(),^{
    if([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Library/LocalSend6/cleanup-tests"]){
        AppDelegate *app=(id)[UIApplication sharedApplication].delegate;NSMutableArray *history=[[app valueForKey:@"history"] mutableCopy];
        NSIndexSet *indices=[history indexesOfObjectsPassingTest:^BOOL(NSString *item,NSUInteger index,BOOL *stop){return [item hasPrefix:@"LocalSend-outbound-regression.bin → "];}];[history removeObjectsAtIndexes:indices];[app setValue:history forKey:@"history"];[[NSUserDefaults standardUserDefaults] setObject:history forKey:@"transferHistory"];[[NSUserDefaults standardUserDefaults] synchronize];[[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Library/LocalSend6/cleanup-tests" error:nil];
    }
    if(![[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Library/LocalSend6/run-tests"])return;
    [[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Library/LocalSend6/run-tests" error:nil];
    AppDelegate *app=(id)[UIApplication sharedApplication].delegate;results=[NSMutableDictionary dictionary];
    results[@"iPadFamily"]=@(UI_USER_INTERFACE_IDIOM()==UIUserInterfaceIdiomPad);results[@"screenWidth"]=@(app.window.bounds.size.width);results[@"screenHeight"]=@(app.window.bounds.size.height);results[@"retinaScale"]=@([UIScreen mainScreen].scale);results[@"language"]=LSCurrentLanguage();results[@"chineseTranslation"]=@([LSL(@"Отправить") isEqual:@"发送"]);results[@"storagePath"]=app.documentsPath;results[@"storageWritable"]=@([[NSFileManager defaultManager] isWritableFileAtPath:app.documentsPath]);
    results[@"mobileDocumentsReadable"]=@([[NSFileManager defaultManager] isReadableFileAtPath:@"/var/mobile/Documents"]);
    NSString *openName=@"LocalSend-Filza-open-test.txt";NSString *openSource=[@"/var/mobile/Library/LocalSend6" stringByAppendingPathComponent:openName];NSData *openBytes=[@"LocalSend Open In regression" dataUsingEncoding:NSUTF8StringEncoding];[openBytes writeToFile:openSource atomically:YES];
    results[@"openInURLAccepted"]=@([app application:[UIApplication sharedApplication] openURL:[NSURL fileURLWithPath:openSource] sourceApplication:@"com.tigisoftware.Filza" annotation:nil]);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{NSString *target=[app.documentsPath stringByAppendingPathComponent:openName];results[@"openInFileBytesMatch"]=@([[NSData dataWithContentsOfFile:target] isEqual:openBytes]);[[NSFileManager defaultManager] removeItemAtPath:target error:nil];[[NSFileManager defaultManager] removeItemAtPath:openSource error:nil];Save();});
    NSString *inbox=@"/var/mobile/Library/LocalSend6/ShareInbox";[[NSFileManager defaultManager] createDirectoryAtPath:inbox withIntermediateDirectories:YES attributes:nil error:nil];NSString *test=@"LocalSend-中文导入测试.txt";NSString *source=[inbox stringByAppendingPathComponent:test];NSData *expected=[@"LocalSend 6 iPad import test" dataUsingEncoding:NSUTF8StringEncoding];[expected writeToFile:source atomically:YES];[app consumeSharedFiles];NSString *dest=[app.documentsPath stringByAppendingPathComponent:test];results[@"shareInboxImport"]=@([[NSData dataWithContentsOfFile:dest] isEqual:expected]);[[NSFileManager defaultManager] removeItemAtPath:dest error:nil];[app setValue:nil forKey:@"selectedFile"];
    NSDictionary *network=[NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/LocalSend6/network-config.plist"];
    if(network){
        [[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Library/LocalSend6/network-config.plist" error:nil];
        LSReceiver *receiver=[app valueForKey:@"receiver"];void (^oldHandler)(NSDictionary *)=receiver.eventHandler;
        receiver.eventHandler=^(NSDictionary *state){oldHandler(state);
            if(![state[@"sender"] isEqual:@"LocalSend synthetic regression"])return;
            if([state[@"phase"] isEqual:@"offer"])[receiver respond:YES];
            if([state[@"phase"] isEqual:@"complete"]){NSString *path=state[@"items"][0][@"path"];NSData *actual=[NSData dataWithContentsOfFile:path];NSMutableData *bytes=[NSMutableData dataWithLength:32768];for(NSUInteger i=0;i<bytes.length;i++)((unsigned char *)bytes.mutableBytes)[i]=(i*17)%251;results[@"incomingTLSBytesMatch"]=@([actual isEqual:bytes]);[[NSFileManager defaultManager] removeItemAtPath:path error:nil];[app closeReceive];receiver.eventHandler=oldHandler;Save();}
        };
        NSString *name=@"LocalSend-outbound-regression.bin";NSMutableData *bytes=[NSMutableData dataWithLength:32768];for(NSUInteger i=0;i<bytes.length;i++)((unsigned char *)bytes.mutableBytes)[i]=(i*17)%251;
        NSString *path=[app.documentsPath stringByAppendingPathComponent:name];[bytes writeToFile:path atomically:YES];
        [app addPeer:@{@"ip":network[@"host"],@"alias":@"LocalSend Test Receiver",@"protocol":@"http",@"port":network[@"port"]}];StartOutgoing(app,name,network[@"host"],50);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,15*NSEC_PER_SEC),dispatch_get_main_queue(),^{[[NSFileManager defaultManager] removeItemAtPath:path error:nil];receiver.eventHandler=oldHandler;});
    }
    [app chooseFile];UINavigationController *nav=(id)app.window.rootViewController.presentedViewController;results[@"fileBrowserStartsInDocuments"]=@([[nav.topViewController valueForKey:@"directory"] isEqual:@"/var/mobile/Documents"]);[nav dismissViewControllerAnimated:NO completion:nil];
    [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status){dispatch_async(dispatch_get_main_queue(),^{results[@"photoAuthorization"]=@(status);PHFetchResult *assets=[PHAsset fetchAssetsWithOptions:nil];results[@"assetCount"]=@(assets.count);PHAsset *first=assets.firstObject;if(!first){Save();return;}
        [[PHImageManager defaultManager] requestImageForAsset:first targetSize:CGSizeMake(224,224) contentMode:PHImageContentModeAspectFill options:nil resultHandler:^(UIImage *image,NSDictionary *info){dispatch_async(dispatch_get_main_queue(),^{if(image)results[@"thumbnailDecoded"]=@YES;if(image)results[@"thumbnailWidth"]=@(CGImageGetWidth(image.CGImage));Save();});}];Save();});}];Save();
});});}
