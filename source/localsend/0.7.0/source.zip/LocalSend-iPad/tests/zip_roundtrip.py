"""Exercise the shipping ZIP writer with independent Python decoding."""
from pathlib import Path
import subprocess,tempfile,ctypes,zipfile,os,json
root=Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='localsend-zip-') as temporary:
 t=Path(temporary);lib=t/'zip.dylib'
 subprocess.run(['/usr/bin/clang','-shared','-fPIC',str(root/'LSZip.c'),'-lz','-o',str(lib)],check=True)
 fn=ctypes.CDLL(str(lib)).LSZipDirectory;fn.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_char_p,ctypes.c_size_t]
 source=t/'中文文件夹';(source/'空目录').mkdir(parents=True);payload=bytes(range(256))*1025
 (source/'文件.bin').write_bytes(payload);(source/'zero').touch();(source/'.hidden').write_text('hidden')
 error=ctypes.create_string_buffer(256);out=t/'test.zip'
 assert fn(os.fsencode(source),os.fsencode(out),error,256)==0,error.value
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None
  assert z.read('中文文件夹/文件.bin')==payload
  assert z.read('中文文件夹/zero')==b''
  assert z.read('中文文件夹/.hidden')==b'hidden'
  assert z.getinfo('中文文件夹/空目录/').is_dir()
 assert fn(os.fsencode(source),os.fsencode(out),error,256)!=0 # never overwrite
 assert fn(os.fsencode(source),os.fsencode(source/'recursive.zip'),error,256)!=0
 (source/'link').symlink_to(t)
 bad=t/'symlink.zip';assert fn(os.fsencode(source),os.fsencode(bad),error,256)!=0
 assert not bad.exists()
 report={'unicode':True,'binaryCRC':True,'emptyFile':True,'emptyFolder':True,'hiddenFile':True,'noOverwrite':True,'recursiveOutputRejected':True,'symbolicLinkRejected':True,'partialArchiveRemoved':True}
 (root/'tests/zip-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
