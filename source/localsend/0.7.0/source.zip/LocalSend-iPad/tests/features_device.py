from pathlib import Path
import threading,http.server,ssl,subprocess,tempfile,plistlib,json,hashlib,io,zipfile,time,urllib.parse,uuid
root=Path(__file__).resolve().parent.parent
ssh=['ssh','-S','/private/tmp/localsend-ipad.socket','-o','BatchMode=yes','root@192.168.1.18']
report={'http':{'prepare':0,'files':[]},'https':{'prepare':0,'files':[]}}
class Receiver(http.server.BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def answer(self,status,body):
  body=json.dumps(body).encode();self.send_response(status);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def do_POST(self):
  body=self.rfile.read(int(self.headers.get('Content-Length',0)));r=report[self.server.kind]
  if self.path.endswith('/prepare-upload'):
   meta=json.loads(body)['files'];self.server.meta=meta;r['prepare']+=1;r['metadataCount']=len(meta)
   self.answer(200,{'sessionId':'session&escaped','files':{fid:'token&escaped='+fid for fid in meta}})
  elif '/upload?' in self.path:
   query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query);fid=query['fileId'][0]
   assert query['sessionId']==['session&escaped'];assert query['token']==['token&escaped='+fid]
   meta=self.server.meta[fid];name=meta['fileName'];correct=False
   if name.startswith('binary'):correct=body==bytes((i*17)%251 for i in range(131073))
   elif name.startswith('empty'):correct=body==b''
   elif name.endswith('.zip'):
    with zipfile.ZipFile(io.BytesIO(body)) as z:
     correct=z.testzip() is None and z.read('文件夹/note.txt').decode()=='folder test 中文' and z.getinfo('文件夹/空目录/').is_dir()
   r['files'].append({'name':name,'size':len(body),'sizeMatchesMetadata':len(body)==meta['size'],'bytesCorrect':correct});self.answer(200,{})
  else:self.answer(404,{})
 def do_GET(self):self.answer(200,{'alias':'Test receiver'})
with tempfile.TemporaryDirectory(prefix='localsend-tls-') as tmp:
 tmp=Path(tmp);key=tmp/'key.pem';cert=tmp/'cert.pem'
 subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1','-subj','/CN=LocalSend test'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 servers=[]
 for kind,port in [('http',53319),('https',53320)]:
  server=http.server.HTTPServer(('0.0.0.0',port),Receiver);server.kind=kind
  if kind=='https':
   context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(str(cert),str(key));server.socket=context.wrap_socket(server.socket,server_side=True)
  servers.append(server);threading.Thread(target=server.serve_forever,daemon=True).start()
 host=subprocess.check_output(['ipconfig','getifaddr','en0'],text=True).strip();fp=hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest().upper()
 runID=str(uuid.uuid4());config=plistlib.dumps({'runID':runID,'host':host,'httpPort':'53319','httpsPort':'53320','fingerprint':fp})
 subprocess.run(ssh+['cat > /var/mobile/Library/LocalSend6/feature-config.plist; chown mobile:mobile /var/mobile/Library/LocalSend6/feature-config.plist'],input=config,check=True)
 subprocess.run(ssh+['cd /var/mobile; killall LocalSend6 2>/dev/null || true; su mobile -c /var/mobile/localsend-stage/Device'],check=True,stdout=subprocess.DEVNULL)
 paths=json.loads((root/'build/device-install.json').read_text());resultPath=paths['dataContainerURL']+'/Documents/.LocalSend07-feature-results.json'
 result={}
 for n in range(80):
  time.sleep(1)
  p=subprocess.run(ssh+['test ! -f /var/mobile/Library/LocalSend6/feature-config.plist && cat '+resultPath],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if p.returncode==0:
   try:result=json.loads(p.stdout)
   except ValueError:continue
   if result.get('done') and result.get('runID')==runID:break
 (root/'tests/features-device-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 (root/'tests/features-network-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 for server in servers:server.shutdown()
 print(json.dumps({'device':result,'network':report},ensure_ascii=False,indent=2))
 assert result.get('done') and all(bool(value) for key,value in result.items() if key not in ('batchImportCount','runID')),result
 assert result['batchImportCount']==3
 for r in report.values():assert r['prepare']==1 and r.get('metadataCount')==3 and len(r['files'])==3 and all(f['sizeMatchesMetadata'] and f['bytesCorrect'] for f in r['files']),r
