#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "LSDesign.h"
#import "LSLocalization.h"
#import "LSFilesystemPicker.h"
#import "LSTransport.h"
@interface AppDelegate (Features)
- (NSString *)documentsPath;
- (NSString *)initialAlias;
- (BOOL)isLocalPeer:(NSDictionary *)peer;
- (void)addPeer:(NSDictionary *)peer;
- (void)importChosenURLs:(NSArray *)urls;
- (void)importClipboard:(UIPasteboard *)board;
- (void)clearSelection;
- (void)sendFiles:(NSArray *)names toHost:(NSString *)host;
- (void)layoutInterface;
- (void)buildInterface;
@end
@interface LSFilesystemPicker (Features)
- (void)finishSelection;
- (void)openDirectory:(NSString *)path;
@end
static NSMutableDictionary *R;
static AppDelegate *A;
static void Save(void){[[NSJSONSerialization dataWithJSONObject:R options:NSJSONWritingPrettyPrinted error:nil] writeToFile:[A.documentsPath stringByAppendingPathComponent:@".LocalSend07-feature-results.json"] atomically:YES];}
static void Snapshot(NSString *name){@autoreleasepool{UIGraphicsBeginImageContextWithOptions(A.window.bounds.size,YES,1);[A.window drawViewHierarchyInRect:A.window.bounds afterScreenUpdates:YES];UIImage *image=UIGraphicsGetImageFromCurrentImageContext();UIGraphicsEndImageContext();[UIImagePNGRepresentation(image) writeToFile:[NSTemporaryDirectory() stringByAppendingPathComponent:name] atomically:YES];}}
static void Wait(BOOL(^done)(void),int attempts,void(^next)(BOOL)) {if(done()){next(YES);return;}if(!attempts){next(NO);return;}dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/5),dispatch_get_main_queue(),^{Wait(done,attempts-1,next);});}
__attribute__((constructor))static void Features(void){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,6*NSEC_PER_SEC),dispatch_get_main_queue(),^{
 NSString *flag=@"/var/mobile/Library/LocalSend6/feature-config.plist";NSDictionary *config=[NSDictionary dictionaryWithContentsOfFile:flag];if(!config)return;NSFileManager *fm=[NSFileManager defaultManager];[fm removeItemAtPath:flag error:nil];
 A=(id)[UIApplication sharedApplication].delegate;R=[NSMutableDictionary dictionary];R[@"runID"]=config[@"runID"]?:@"";R[@"defaultReceiveTab"]=@([[A valueForKey:@"activeTab"] integerValue]==0);
 NSString *alias=[A valueForKey:@"deviceAlias"];R[@"aliasPersisted"]=@([alias isEqual:[[NSUserDefaults standardUserDefaults] stringForKey:@"deviceAlias"]]);R[@"aliasStable"]=@([alias isEqual:[A initialAlias]]);
 R[@"selfByIP"]=@([A isLocalPeer:@{@"ip":@"192.168.1.18"}]);NSString *fp=[A valueForKey:@"localFingerprint"]?:@"";R[@"selfByFingerprint"]=@(fp.length&&[A isLocalPeer:@{@"ip":@"192.0.2.99",@"fingerprint":fp.lowercaseString}]);
 NSArray *originalPeers=[[A valueForKey:@"peers"] copy];NSUInteger before=originalPeers.count;[A addPeer:@{@"ip":@"192.168.1.18",@"alias":@"self-test"}];R[@"selfNotInserted"]=@([[A valueForKey:@"peers"] count]==before);
 LSRotatingLogoView *logo=(id)[[A valueForKey:@"receivePanel"] viewWithTag:10];BOOL animations=[[A valueForKey:@"animations"] boolValue];[A setValue:@YES forKey:@"animations"];[A layoutInterface];
 Snapshot(@"LS07-receive.png");R[@"animationStarted"]=@([logo.layer animationForKey:@"slowRotation"]!=nil);[[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationWillResignActiveNotification object:nil];R[@"animationStopsInactive"]=@([logo.layer animationForKey:@"slowRotation"]==nil);[[NSNotificationCenter defaultCenter] postNotificationName:UIApplicationDidBecomeActiveNotification object:nil];R[@"animationResumes"]=@([logo.layer animationForKey:@"slowRotation"]!=nil);
 [A setValue:@1 forKey:@"activeTab"];[A layoutInterface];Snapshot(@"LS07-send.png");R[@"animationStopsOnSendTab"]=@([logo.layer animationForKey:@"slowRotation"]==nil);[A setValue:@0 forKey:@"activeTab"];[A buildInterface];logo=(id)[[A valueForKey:@"receivePanel"] viewWithTag:10];R[@"animationAfterRebuild"]=@([logo.layer animationForKey:@"slowRotation"]!=nil);[A setValue:@(animations) forKey:@"animations"];[A layoutInterface];
 Save();
 NSString *temporary=[NSTemporaryDirectory() stringByAppendingPathComponent:[@"LS07-FeatureTest-" stringByAppendingString:[NSUUID UUID].UUIDString]];
 [fm createDirectoryAtPath:[temporary stringByAppendingPathComponent:@"文件夹/空目录"] withIntermediateDirectories:YES attributes:nil error:nil];
 NSMutableData *payload=[NSMutableData dataWithLength:131073];for(NSUInteger i=0;i<payload.length;i++)((unsigned char*)payload.mutableBytes)[i]=(i*17)%251;
 [payload writeToFile:[temporary stringByAppendingPathComponent:@"binary.bin"] atomically:YES];[@"" writeToFile:[temporary stringByAppendingPathComponent:@"empty.txt"] atomically:YES encoding:NSUTF8StringEncoding error:nil];[@"folder test 中文" writeToFile:[temporary stringByAppendingPathComponent:@"文件夹/note.txt"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
 NSString *pasteName=[NSUUID UUID].UUIDString;UIPasteboard *paste=[UIPasteboard pasteboardWithName:pasteName create:YES];paste.string=@"LocalSend clipboard test";[A clearSelection];[A importClipboard:paste];NSArray *clipboardNames=[[A valueForKey:@"selectedFiles"] copy];R[@"clipboardTextImported"]=@(clipboardNames.count==1&&[[NSString stringWithContentsOfFile:[A.documentsPath stringByAppendingPathComponent:clipboardNames[0]] encoding:NSUTF8StringEncoding error:nil] isEqual:paste.string]);
 for(NSString *name in clipboardNames)[fm removeItemAtPath:[A.documentsPath stringByAppendingPathComponent:name] error:nil];[UIPasteboard removePasteboardWithName:pasteName];[A clearSelection];
 LSFilesystemPicker *picker=[[LSFilesystemPicker alloc] initWithDirectory:temporary documents:A.documentsPath dark:NO accent:0 animations:NO selection:nil];[picker setMultipleSelection:^(NSArray *urls){}];[picker view];
 UINavigationController *browser=[[UINavigationController alloc] initWithRootViewController:picker];[A.window.rootViewController presentViewController:browser animated:NO completion:nil];
 Wait(^BOOL{return [[picker valueForKey:@"entries"] count]==3;},30,^(BOOL loaded){
  NSArray *entries=[picker valueForKey:@"entries"];for(NSUInteger i=0;i<entries.count;i++)if(![entries[i][@"folder"] boolValue])[picker tableView:picker.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
  R[@"pickerMultipleFiles"]=@(loaded&&[[picker valueForKey:@"chosen"] count]==2);
  R[@"pickerLoaded"]=@(loaded);Save();picker.foldersOnly=YES;__block BOOL folderSelected=NO;[picker setMultipleSelection:^(NSArray *urls){folderSelected=urls.count==1&&[[urls[0] path] isEqual:[temporary stringByStandardizingPath]];R[@"folderCallbackCalled"]=@YES;}];[picker finishSelection];
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW,NSEC_PER_SEC/2),dispatch_get_main_queue(),^{R[@"folderPickerSelection"]=@(folderSelected);
   NSArray *sources=@[[NSURL fileURLWithPath:[temporary stringByAppendingPathComponent:@"binary.bin"]],[NSURL fileURLWithPath:[temporary stringByAppendingPathComponent:@"empty.txt"]],[NSURL fileURLWithPath:[temporary stringByAppendingPathComponent:@"文件夹"]]];[A importChosenURLs:sources];
   Wait(^BOOL{return ![[A valueForKey:@"importing"] boolValue];},100,^(BOOL ready){NSArray *names=[[A valueForKey:@"selectedFiles"] copy];R[@"batchImportCount"]=@(names.count);R[@"batchImportReady"]=@(ready&&names.count==3);if(names.count!=3){Save();return;}
    NSString *host=config[@"host"];NSMutableArray *historyObjects=[NSMutableArray array];NSArray *historyBefore=[[A valueForKey:@"history"] copy];
    void(^cleanup)(void)=^{NSMutableArray *history=[A valueForKey:@"history"];for(id entry in historyObjects){NSUInteger index=[history indexOfObjectIdenticalTo:entry];if(index!=NSNotFound)[history removeObjectAtIndex:index];}[[NSUserDefaults standardUserDefaults] setObject:history forKey:@"transferHistory"];[A setValue:[originalPeers mutableCopy] forKey:@"peers"];for(NSString *name in names)[fm removeItemAtPath:[A.documentsPath stringByAppendingPathComponent:name] error:nil];[fm removeItemAtPath:temporary error:nil];[A clearSelection];[A layoutInterface];R[@"done"]=@YES;Save();};
    [A addPeer:@{@"ip":host,@"port":config[@"httpPort"],@"protocol":@"http",@"alias":@"Feature HTTP"}];[A sendFiles:names toHost:host];
    Wait(^BOOL{return ![[A valueForKey:@"sending"] boolValue];},200,^(BOOL finished){R[@"httpFinished"]=@(finished);if(finished&&[[A valueForKey:@"history"] count]){id entry=[A valueForKey:@"history"][0];if([historyBefore indexOfObjectIdenticalTo:entry]==NSNotFound)[historyObjects addObject:entry];}
     [A addPeer:@{@"ip":host,@"port":config[@"httpsPort"],@"protocol":@"https",@"alias":@"Feature HTTPS",@"fingerprint":config[@"fingerprint"]}];[A sendFiles:names toHost:host];
     Wait(^BOOL{return ![[A valueForKey:@"sending"] boolValue];},200,^(BOOL secureFinished){R[@"httpsFinished"]=@(secureFinished);if(secureFinished&&[[A valueForKey:@"history"] count]){id entry=[A valueForKey:@"history"][0];if([historyBefore indexOfObjectIdenticalTo:entry]==NSNotFound)[historyObjects addObject:entry];}
      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{NSURLRequest *request=[NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://%@:%@/api/localsend/v2/info",host,config[@"httpsPort"]]]];NSError *error=nil;NSURLResponse *response=nil;LSHTTPSRequest(request,@"0000000000000000000000000000000000000000000000000000000000000000",&response,&error);dispatch_async(dispatch_get_main_queue(),^{R[@"wrongFingerprintRejected"]=@(error!=nil);cleanup();});});
     });
    });
   });
  });
 });
});}
