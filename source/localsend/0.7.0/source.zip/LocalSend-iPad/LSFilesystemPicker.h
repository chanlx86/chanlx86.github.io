#import <UIKit/UIKit.h>
@interface LSFilesystemPicker : UITableViewController <UIAlertViewDelegate>
- (id)initWithDirectory:(NSString *)directory documents:(NSString *)documents dark:(BOOL)dark accent:(NSInteger)accent animations:(BOOL)animations selection:(void (^)(NSURL *url))selection;
@property(nonatomic,assign) BOOL foldersOnly;
- (void)setMultipleSelection:(void (^)(NSArray *urls))selection;
@end
