#include <stddef.h>
/* Writes a UTF-8, uncompressed ZIP with bounded buffers. No symlinks followed. */
int LSZipDirectory(const char *source, const char *output, char *error, size_t capacity);
