#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <dlfcn.h>
int main(int argc,char **argv){@autoreleasepool{
 dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",RTLD_NOW);
 id w=((id(*)(id,SEL))objc_msgSend)(NSClassFromString(@"LSApplicationWorkspace"),NSSelectorFromString(@"defaultWorkspace"));NSString *cmd=argc>1?@(argv[1]):@"launch";
 if([cmd isEqual:@"info"]){id proxy=((id(*)(id,SEL,id))objc_msgSend)(NSClassFromString(@"LSApplicationProxy"),NSSelectorFromString(@"applicationProxyForIdentifier:"),@"com.unlocalsend.ios6");for(NSString *s in @[@"bundleURL",@"dataContainerURL",@"plugInKitPlugins"]){if([proxy respondsToSelector:NSSelectorFromString(s)])printf("%s=%s\n",s.UTF8String,[[proxy valueForKey:s] description].UTF8String);}id plugins=[proxy valueForKey:@"plugInKitPlugins"];for(id plugin in plugins){for(NSString *key in @[@"dataContainerURL",@"containerURL",@"bundleURL",@"entitlements"]){if([plugin respondsToSelector:NSSelectorFromString(key)])NSLog(@"plugin %@=%@",key,[plugin valueForKey:key]);}}return 0;}
 if([cmd isEqual:@"register"] && argc>2){BOOL ok=((BOOL(*)(id,SEL,id))objc_msgSend)(w,NSSelectorFromString(@"registerApplication:"),[NSURL fileURLWithPath:@(argv[2])]);printf("register=%d\n",ok);return ok?0:2;}
 if([cmd isEqual:@"url"] && argc>2){BOOL ok=((BOOL(*)(id,SEL,id))objc_msgSend)(w,NSSelectorFromString(@"openURL:"),[NSURL URLWithString:@(argv[2])]);printf("openURL=%d\n",ok);return ok?0:2;}
 BOOL ok=((BOOL(*)(id,SEL,id))objc_msgSend)(w,NSSelectorFromString(@"openApplicationWithBundleID:"),@"com.unlocalsend.ios6");printf("launch=%d\n",ok);return ok?0:2;
}}
