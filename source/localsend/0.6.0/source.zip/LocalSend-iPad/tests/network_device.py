from pathlib import Path
import subprocess,threading,http.server,json,hashlib,http.client,ssl,time,plistlib
root=Path(__file__).resolve().parent.parent
ssh=['ssh','-S','/private/tmp/localsend-ipad.socket','root@192.168.1.18']
payload=bytes((i*17)%251 for i in range(32768));report={}
class Receiver(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  body=self.rfile.read(int(self.headers.get('Content-Length','0')))
  if self.path.endswith('/prepare-upload'):
   request=json.loads(body);fid=next(iter(request['files']));answer=json.dumps({'sessionId':'test-session','files':{fid:'test-token'}}).encode();report['outboundMetadataBytes']=request['files'][fid]['size']
  elif '/upload?' in self.path:
   report['outboundBytesMatch']=body==payload;answer=b'{}'
  else:self.send_error(404);return
  self.send_response(200);self.send_header('Content-Length',str(len(answer)));self.end_headers();self.wfile.write(answer)
server=http.server.HTTPServer(('0.0.0.0',53319),Receiver);threading.Thread(target=server.serve_forever,daemon=True).start()
host=subprocess.check_output(['ipconfig','getifaddr','en0'],text=True).strip()
config=plistlib.dumps({'host':host,'port':str(server.server_port)})
subprocess.run(ssh+['cat > /var/mobile/Library/LocalSend6/network-config.plist'],input=config,check=True)
subprocess.run(ssh+['cd /var/mobile; touch /var/mobile/Library/LocalSend6/run-tests; chown mobile:mobile /var/mobile/Library/LocalSend6/run-tests /var/mobile/Library/LocalSend6/network-config.plist; killall LocalSend6 2>/dev/null || true; su mobile -c /var/mobile/localsend-stage/Device'],check=True)
time.sleep(8)
context=ssl._create_unverified_context()
def req(path,data=None):
 c=http.client.HTTPSConnection('192.168.1.18',53317,context=context,timeout=20);body=json.dumps(data).encode() if isinstance(data,dict) else data;c.request('POST' if data is not None else 'GET','/api/localsend/v2/'+path,body,{'Content-Type':'application/json'} if isinstance(data,dict) else {});r=c.getresponse();answer=r.read();status=r.status;c.close();return status,json.loads(answer) if answer else None
status,info=req('info');report['incomingInfoStatus']=status
meta={'id':'test','fileName':'LocalSend-inbound-regression.bin','size':len(payload),'fileType':'application/octet-stream','sha256':hashlib.sha256(payload).hexdigest()}
status,session=req('prepare-upload',{'info':{'alias':'LocalSend synthetic regression','deviceModel':'Test'},'files':{'test':meta}});report['incomingPrepareStatus']=status
if status==200:
 from urllib.parse import urlencode
 status,_=req('upload?'+urlencode({'sessionId':session['sessionId'],'fileId':'test','token':session['files']['test']}),payload);report['incomingUploadStatus']=status
time.sleep(2)
(root/'tests/network-results.json').write_text(json.dumps(report,indent=2)+'\n');server.shutdown();print(json.dumps(report,indent=2))
assert report.get('outboundBytesMatch') and report.get('incomingUploadStatus')==200
