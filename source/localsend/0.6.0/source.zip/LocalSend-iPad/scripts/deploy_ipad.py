#!/usr/bin/python3
from pathlib import Path
import subprocess,tarfile,shlex,zipfile,json,sys,re
r=Path(__file__).resolve().parent.parent
ssh=['ssh','-S','/private/tmp/localsend-ipad.socket','root@192.168.1.18']
def remote(cmd,**kw):return subprocess.run(ssh+['cd /var/mobile; '+cmd],check=True,**kw)
dev=Path('/Volumes/OS X/Applications/Xcode.app/Contents/Developer')
subprocess.run([str(dev/'Toolchains/XcodeDefault.xctoolchain/usr/bin/clang'),'-arch','armv7','-isysroot',str(dev/'Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk'),'-miphoneos-version-min=9.0','-fobjc-arc',str(r/'tests/Device.m'),'-framework','Foundation','-o',str(r/'build/Device')],check=True)
app=r/'build/LocalSend6.app'
if not (app/'LocalSend6').exists() or not (app/'PlugIns/LocalSendShare.appex/LocalSendShare').exists():raise SystemExit('Build both executables first')
stage='/var/mobile/localsend-stage'
with tarfile.open(r/'build/stage.tgz','w:gz') as t:
 t.add(app,arcname='LocalSend6.app');t.add(r/'build/Device',arcname='Device.next')
 t.add(r/'LocalSend6.entitlements',arcname='LocalSend6.entitlements');t.add(r/'Share/Share.entitlements',arcname='Share.entitlements')
with (r/'build/stage.tgz').open('rb') as f:remote('mkdir -p '+stage+'; tar -xzf - -C '+stage,stdin=f)
remote('set -e; ldid -S '+stage+'/Device.next; chmod 755 '+stage+'/Device.next; mv '+stage+'/Device.next '+stage+'/Device; ldid -S'+stage+'/LocalSend6.entitlements '+stage+'/LocalSend6.app/LocalSend6; ldid -S'+stage+'/Share.entitlements '+stage+'/LocalSend6.app/PlugIns/LocalSendShare.appex/LocalSendShare')
for rel in ['LocalSend6','PlugIns/LocalSendShare.appex/LocalSendShare']:
 with (app/rel).open('wb') as f:remote('cat '+stage+'/LocalSend6.app/'+rel,stdout=f)
ipa=r/'build/LocalSend-install.ipa'
with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(app.rglob('*')):
  if f.is_file():z.write(f,'Payload/LocalSend6.app/'+f.relative_to(app).as_posix())
with ipa.open('rb') as f:remote('cat > '+stage+'/LocalSend-install.ipa',stdin=f)
remote('killall LocalSend6 2>/dev/null || true')
p=subprocess.run(ssh+['cd /var/mobile; ipainstaller '+stage+'/LocalSend-install.ipa'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
print(p.stdout)
if 'successfully' not in p.stdout:raise SystemExit('Installer did not report success')
info=remote(stage+'/Device info',stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True).stdout
print(info)
paths=dict(re.findall(r'^(bundleURL|dataContainerURL)=file://([^\n]+)',info,re.M));(r/'build/device-install.json').write_text(json.dumps(paths,indent=2))
if '--testing' in sys.argv:remote('touch /var/mobile/Library/LocalSend6/run-tests; chown mobile:mobile /var/mobile/Library/LocalSend6/run-tests')
if '--no-launch' not in sys.argv:remote('su mobile -c '+stage+'/Device')
