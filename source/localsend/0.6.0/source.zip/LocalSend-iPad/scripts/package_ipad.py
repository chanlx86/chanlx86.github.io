#!/usr/bin/python3
from pathlib import Path
import zipfile,shutil,hashlib,json,plistlib
root=Path(__file__).resolve().parent.parent;app=root/'build/LocalSend6.app';dist=root/'dist';dist.mkdir(exist_ok=True)
info=plistlib.loads((app/'Info.plist').read_bytes());assert info['CFBundleDisplayName']=='LocalSend' and info['UIDeviceFamily']==[1,2]
for binary in [app/'LocalSend6',app/'PlugIns/LocalSendShare.appex/LocalSendShare']:
 data=binary.read_bytes()
 assert not any(x in data for x in [b'run-tests',b'share-error.txt',b'.LocalSend6-test-results.json'])
ipa=dist/'LocalSend_0.6.0_iOS9_越狱版.ipa'
with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(app.rglob('*')):
  if f.is_file():z.write(f,'Payload/LocalSend6.app/'+f.relative_to(app).as_posix())
with zipfile.ZipFile(ipa) as z:
 assert z.testzip() is None
 assert z.getinfo('Payload/LocalSend6.app/LocalSend6').external_attr>>16&0o111
 assert z.getinfo('Payload/LocalSend6.app/PlugIns/LocalSendShare.appex/LocalSendShare').external_attr>>16&0o111
source=dist/'LocalSend_0.6.0_源码.zip'
exclude={'.git','build','dist','packages','previews','__pycache__'}
private_helpers={'PluginText.c','PluginMethods.m','ASL.c','ExtensionProbe.m'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(root.rglob('*')):
  rel=f.relative_to(root)
  if f.is_file() and not any(p in exclude for p in rel.parts) and f.name not in private_helpers and f.name!='.DS_Store' and f.suffix not in ['.pyc','.ipa','.deb']:
   z.write(f,'LocalSend-iPad/'+rel.as_posix())
with zipfile.ZipFile(source) as z:assert z.testzip() is None
readme=dist/'LocalSend_0.6.0_说明.md';shutil.copy(root/'IPAD-README.md',readme)
manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [ipa,source,readme]}
(dist/'LocalSend_0.6.0_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for f in [ipa,source,readme,dist/'LocalSend_0.6.0_SHA256.json']:
 shutil.copy(f,Path('/Users/luoxian/Downloads')/f.name);print(f.name+': '+str(f.stat().st_size)+' bytes')
