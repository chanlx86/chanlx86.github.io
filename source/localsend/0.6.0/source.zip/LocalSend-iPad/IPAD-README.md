# LocalSend：iPad / iOS 9 适配版 0.6.0

基于 https://github.com/theanazerka/unlocalsend ，提交 `90e860ad2c535f86eb1b78b3f6acdba295b73bca`（原版 0.5.7）。保留原项目 GPL-3.0 许可证、作者署名及第三方许可证。本地修改未提交上游。

## 功能

- 名称统一为 LocalSend，保持包标识 `com.unlocalsend.ios6`，可以覆盖更新。
- iPhone / iPad 通用；iPad 支持原生 Retina 分辨率和横竖屏，主界面使用居中的内容列。
- 简体中文，跟随系统；设置中也可选择中文、英文、俄文、乌克兰文。
- Photos 网格显示照片、视频缩略图和视频时长；只为可见格子请求缩略图，复用格子时取消旧请求。不建立额外磁盘缩略图缓存。选中后异步导出原始媒体资源，避免先把整张图片解码再重新压缩。
- Filza 等应用的“打开方式”支持文件导入。
- 系统照片“分享 → 更多”可启用 LocalSend。分享内容先准备，点“打开 LocalSend 选择接收设备”继续；未能自动切换时可返回桌面手动打开。
- 多个分享文件均会导入；本版本延续原项目的逐个选择、发送流程。
- 发送文件浏览器默认从 `/var/mobile/Documents` 开始，可进入根目录或手动输入路径。
- 接收与导入文件仍在 **App 内部 Documents**，不创建公共 Documents/LocalSend6 文件夹。Filza 中可通过应用管理定位容器，iTunes 文件共享仍对应 App Documents。

## 构建与安装

本构建为 ARMv7、最低 iOS 9.0，使用 Xcode 7.3.1 的 iPhoneOS9.3 SDK。内含上游提供的 ARMv7 HEIC 静态库及完整对应源代码。编译器路径在 `scripts/build_ipad.py` 中，按本机安装位置修改。

```
/usr/bin/python3 scripts/build_ipad.py
```

`build/LocalSend6.app` 含主程序和 `PlugIns/LocalSendShare.appex`。安装到越狱设备前，分别使用 `LocalSend6.entitlements` 和 `Share/Share.entitlements` 对两个可执行文件伪签名，再按 Payload/LocalSend6.app 结构打包 IPA。需要设备现有的 AppSync/可安装伪签名 IPA 的环境。

`scripts/deploy_ipad.py` 是本次开发部署脚本，使用已有 SSH 控制连接 `/private/tmp/localsend-ipad.socket`、地址 `192.168.1.18`，不保存密码。它调用设备 ldid 签名，打包后经 ipainstaller 更新，未使用清除数据选项。ipainstaller 旧版即使安装成功也可能返回 1，脚本核对其明确成功输出。

不要只替换 Info.plist 后调用 registerApplication：已安装的 iPhone 模式与扩展信息可能仍被缓存。通过 IPA 安装器更新后才能正确登记设备类型和分享扩展。

## iOS 9 越狱扩展启动兼容

此设备启动伪签名扩展时，`sandbox_container_path_for_pid` 返回 ENOTSUP（45），PlugInKit 的 `checkEnvironment:` 因而直接抛出异常。仅增加普通签名权限不能解决，声明扩展不需要容器又会导致安装器拒绝安装。

`Share/LegacyExtensionCompatibility.m` 只在本扩展标识、iOS 9、且该 API 明确返回 ENOTSUP 时，将**当前扩展进程**的这一启动检查替换为空操作。正常取得容器路径时保留原检查。没有修改系统框架、系统守护进程、内核或其他 App。此兼容路径面向已越狱的测试设备；未验证其他越狱系统。

分享临时文件位于 `/var/mobile/Library/LocalSend6/ShareInbox`，写入时使用隐藏临时文件，完成后原子改名；主程序启动/回前台时移入自身 Documents。该目录用于主程序与扩展之间交接，并不是接收文件的最终目录。权限仅为本项目交接目录声明了路径例外。

## 局域网 HTTP

iOS 9 SDK 开始默认启用 ATS。为兼容广播中明确声明 HTTP 的旧 LocalSend 接收端，Info.plist 声明 NSAllowsArbitraryLoads；HTTPS 设备仍使用上游的 Mbed TLS、设备指纹校验路径。App 不包含内嵌网页浏览器。

## 备份

本次设备原版程序及更新前数据备份留在数据分区：

`/var/mobile/Library/LocalSend6/Backups/`

- `LocalSend6-original-0.5.7.tar.gz`
- `data-before-update.tar.gz`

后续回退时先保存更新后的接收文件。不要把旧数据备份直接覆盖到新数据上。

## 验证

真机测试见 `tests/device-results.json` 及最终测试记录。测试构建通过 `--testing` 选项生成，正式 IPA 不包含自动测试入口。测试只使用合成文本/二进制文件；相册缩略图检查不导出用户图片到开发电脑。
