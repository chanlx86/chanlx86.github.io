#import <UIKit/UIKit.h>
@interface LSPhotoPicker : UICollectionViewController
- (instancetype)initWithSelection:(void (^)(NSURL *))selection;
@end
