#import "LSPhotoPicker.h"
#import "LSLocalization.h"
#import <Photos/Photos.h>
@interface LSPhotoCell : UICollectionViewCell
@property(nonatomic,strong) UIImageView *image;
@property(nonatomic,strong) UILabel *badge;
@property(nonatomic,copy) NSString *assetID;
@property(nonatomic,assign) PHImageRequestID request;
@end
@implementation LSPhotoCell
- (instancetype)initWithFrame:(CGRect)frame {
    if((self=[super initWithFrame:frame])){self.backgroundColor=[UIColor colorWithWhite:.9 alpha:1];self.image=[[UIImageView alloc] initWithFrame:self.contentView.bounds];self.image.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;self.image.contentMode=UIViewContentModeScaleAspectFill;self.image.clipsToBounds=YES;[self.contentView addSubview:self.image];self.badge=[[UILabel alloc] initWithFrame:CGRectMake(3,3,54,22)];self.badge.font=[UIFont systemFontOfSize:11];self.badge.textColor=[UIColor whiteColor];self.badge.backgroundColor=[UIColor colorWithWhite:0 alpha:.45];[self.contentView addSubview:self.badge];}return self;
}
- (void)prepareForReuse {[super prepareForReuse];if(self.request)[[PHImageManager defaultManager] cancelImageRequest:self.request];self.request=0;self.assetID=nil;self.image.image=nil;}
@end
@interface LSPhotoPicker ()
@property(nonatomic,strong) PHFetchResult *assets;
@property(nonatomic,copy) void (^selection)(NSURL *);
@property(nonatomic,assign) BOOL exporting;
@end
@implementation LSPhotoPicker
- (instancetype)initWithSelection:(void (^)(NSURL *))selection {
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];layout.minimumLineSpacing=3;layout.minimumInteritemSpacing=3;
    if((self=[super initWithCollectionViewLayout:layout]))self.selection=selection;return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];self.title=LSL(@"Медиа");self.collectionView.backgroundColor=[UIColor whiteColor];[self.collectionView registerClass:[LSPhotoCell class] forCellWithReuseIdentifier:@"photo"];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:LSL(@"Отмена") style:UIBarButtonItemStylePlain target:self action:@selector(close)];
    [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status){dispatch_async(dispatch_get_main_queue(),^{
        if(status!=PHAuthorizationStatusAuthorized){UILabel *label=[[UILabel alloc] init];label.text=LSL(@"Библиотека фотографий недоступна");label.textAlignment=NSTextAlignmentCenter;label.numberOfLines=0;self.collectionView.backgroundView=label;return;}
        PHFetchOptions *options=[[PHFetchOptions alloc] init];options.sortDescriptors=@[[NSSortDescriptor sortDescriptorWithKey:@"creationDate" ascending:NO]];options.predicate=[NSPredicate predicateWithFormat:@"mediaType == %d OR mediaType == %d",PHAssetMediaTypeImage,PHAssetMediaTypeVideo];self.assets=[PHAsset fetchAssetsWithOptions:options];[self.collectionView reloadData];
    });}];
}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];CGFloat width=self.collectionView.bounds.size.width;NSInteger cols=MAX(3,(NSInteger)(width/110));CGFloat side=floor((width-3*(cols-1))/cols);UICollectionViewFlowLayout *layout=(id)self.collectionViewLayout;if(layout.itemSize.width!=side){layout.itemSize=CGSizeMake(side,side);[layout invalidateLayout];}}
- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section {return self.assets.count;}
- (UICollectionViewCell *)collectionView:(UICollectionView *)view cellForItemAtIndexPath:(NSIndexPath *)path {
    LSPhotoCell *cell=[view dequeueReusableCellWithReuseIdentifier:@"photo" forIndexPath:path];PHAsset *asset=self.assets[path.item];cell.assetID=asset.localIdentifier;cell.image.image=nil;cell.badge.hidden=asset.mediaType!=PHAssetMediaTypeVideo;cell.badge.text=[NSString stringWithFormat:@" %ld:%02ld",(long)asset.duration/60,(long)asset.duration%60];
    PHImageRequestOptions *options=[[PHImageRequestOptions alloc] init];options.deliveryMode=PHImageRequestOptionsDeliveryModeOpportunistic;options.resizeMode=PHImageRequestOptionsResizeModeFast;options.networkAccessAllowed=NO;
    __weak LSPhotoCell *weakCell=cell;
    cell.request=[[PHImageManager defaultManager] requestImageForAsset:asset targetSize:CGSizeMake(224,224) contentMode:PHImageContentModeAspectFill options:options resultHandler:^(UIImage *image,NSDictionary *info){dispatch_async(dispatch_get_main_queue(),^{LSPhotoCell *target=weakCell;if(image && [target.assetID isEqual:asset.localIdentifier])target.image.image=image;});}];return cell;
}
- (void)collectionView:(UICollectionView *)view didSelectItemAtIndexPath:(NSIndexPath *)path {
    if(self.exporting)return;PHAsset *asset=self.assets[path.item];NSArray *resources=[PHAssetResource assetResourcesForAsset:asset];PHAssetResource *chosen=nil;
    for(PHAssetResource *r in resources){if(r.type==PHAssetResourceTypePhoto || r.type==PHAssetResourceTypeVideo){chosen=r;break;}}
    if(!chosen)chosen=resources.firstObject;if(!chosen)return;
    self.exporting=YES;self.title=LSL(@"Импорт файла…");
    NSString *dir=[NSTemporaryDirectory() stringByAppendingPathComponent:[@"LocalSend6-Photo-" stringByAppendingString:[[NSUUID UUID] UUIDString]]];[[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];NSURL *url=[NSURL fileURLWithPath:[dir stringByAppendingPathComponent:chosen.originalFilename.lastPathComponent?:@"Photo.jpg"]];PHAssetResourceRequestOptions *options=[[PHAssetResourceRequestOptions alloc] init];options.networkAccessAllowed=YES;
    [[PHAssetResourceManager defaultManager] writeDataForAssetResource:chosen toFile:url options:options completionHandler:^(NSError *error){dispatch_async(dispatch_get_main_queue(),^{self.exporting=NO;self.title=LSL(@"Медиа");if(error){[[[UIAlertView alloc] initWithTitle:LSL(@"Ошибка") message:error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] show];return;}void(^select)(NSURL *)=self.selection;[self dismissViewControllerAnimated:YES completion:^{if(select)select(url);}];});}];
}
- (void)close {if(!self.exporting)[self dismissViewControllerAnimated:YES completion:nil];}
@end
