#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#include <unistd.h>
#include <errno.h>
// Some iOS 9 jailbreaks launch fakesigned app extensions without a sandbox
// container. PlugInKit aborts on ENOTSUP before loading our view controller.
// Adapt only this extension's local preflight in that precise environment.
// This changes no kernel, daemon, other application, or sandbox policy.
static void LSContainerPreflight(id self,SEL command,id unused) {}
__attribute__((constructor)) static void LSLegacyExtensionCompatibility(void) {
    @autoreleasepool {
        if(![[[NSBundle mainBundle] bundleIdentifier] isEqual:@"com.unlocalsend.ios6.share"])return;
        NSOperatingSystemVersion version=[[NSProcessInfo processInfo] operatingSystemVersion];if(version.majorVersion!=9)return;
        int (*containerPath)(pid_t,char *,size_t)=dlsym(RTLD_DEFAULT,"sandbox_container_path_for_pid");
        if(!containerPath)return;char path[1024]={0};errno=0;int status=containerPath(getpid(),path,sizeof(path));int reason=errno;
        if(status==0 || reason!=ENOTSUP)return;
        dlopen("/System/Library/PrivateFrameworks/PlugInKit.framework/PlugInKit",RTLD_NOW);
        Method check=class_getInstanceMethod(NSClassFromString(@"PKService"),NSSelectorFromString(@"checkEnvironment:"));
        if(check)method_setImplementation(check,(IMP)LSContainerPreflight);
    }
}
