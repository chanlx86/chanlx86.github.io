#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <objc/message.h>
#import <dlfcn.h>
@interface ShareViewController : UIViewController
@property(nonatomic,strong) UILabel *label;
@property(nonatomic,assign) NSInteger pending;
@property(nonatomic,assign) NSInteger saved;
@property(nonatomic,strong) NSOperationQueue *jobs;
@end
@implementation ShareViewController
- (BOOL)chinese {return [[NSLocale preferredLanguages].firstObject hasPrefix:@"zh"];}
- (void)viewDidLoad {
    [super viewDidLoad];self.view.backgroundColor=[UIColor whiteColor];self.label=[[UILabel alloc] initWithFrame:CGRectInset(self.view.bounds,24,40)];self.label.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;self.label.numberOfLines=0;self.label.textAlignment=NSTextAlignmentCenter;self.label.text=self.chinese?@"正在准备发送…":@"Preparing files…";[self.view addSubview:self.label];self.jobs=[[NSOperationQueue alloc] init];self.jobs.maxConcurrentOperationCount=1;
    NSMutableArray *providers=[NSMutableArray array];for(NSExtensionItem *item in self.extensionContext.inputItems)[providers addObjectsFromArray:item.attachments?:@[]];
    self.pending=providers.count;if(!self.pending){[self finish];return;}
    for(NSItemProvider *p in providers){NSString *type=nil;for(NSString *candidate in @[@"public.file-url",@"public.image",@"public.movie",@"public.data",@"public.plain-text",@"public.url"]){if([p hasItemConformingToTypeIdentifier:candidate]){type=candidate;break;}}if(!type){[self completeOne:NO];continue;}
        [p loadItemForTypeIdentifier:type options:nil completionHandler:^(id item,NSError *error){
            [self.jobs addOperationWithBlock:^{BOOL ok=NO;@autoreleasepool{if(!error)ok=[self store:item type:type];}dispatch_async(dispatch_get_main_queue(),^{[self completeOne:ok];});}];
        }];
    }
}
- (BOOL)store:(id)item type:(NSString *)type {
    NSString *inbox=@"/var/mobile/Library/LocalSend6/ShareInbox";NSFileManager *fm=[NSFileManager defaultManager];NSError *error=nil;if(![fm createDirectoryAtPath:inbox withIntermediateDirectories:YES attributes:nil error:&error])return NO;
    NSURL *source=[item isKindOfClass:[NSURL class]]?item:nil;NSString *name=(source.isFileURL?source.lastPathComponent:nil)?:([type isEqual:@"public.image"]?@"Photo.jpg":@"Text.txt");
    NSString *dest=[inbox stringByAppendingPathComponent:name];if([fm fileExistsAtPath:dest])dest=[inbox stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@",[[NSUUID UUID] UUIDString],name]];
    // Write privately, then publish by rename so the host never imports half a file.
    NSString *temp=[inbox stringByAppendingPathComponent:[@"." stringByAppendingString:[[NSUUID UUID] UUIDString]]];
    BOOL ok=NO;if(source.isFileURL){BOOL scope=[source startAccessingSecurityScopedResource];ok=[fm copyItemAtURL:source toURL:[NSURL fileURLWithPath:temp] error:&error];if(scope)[source stopAccessingSecurityScopedResource];}
    else {NSData *data=nil;if([item isKindOfClass:[UIImage class]])data=UIImageJPEGRepresentation(item,.95);else if([item isKindOfClass:[NSData class]])data=item;else if([item isKindOfClass:[NSString class]])data=[item dataUsingEncoding:NSUTF8StringEncoding];else if(source)data=[source.absoluteString dataUsingEncoding:NSUTF8StringEncoding];ok=[data writeToFile:temp options:NSDataWritingAtomic error:&error];}
    if(ok)ok=[fm moveItemAtPath:temp toPath:dest error:&error];if(!ok)[fm removeItemAtPath:temp error:nil];return ok;
}
- (void)completeOne:(BOOL)success {if(success)self.saved++;if(--self.pending==0)[self finish];}
- (void)finish {
    self.label.text=self.saved?(self.chinese?@"文件已准备好，请打开 LocalSend 选择接收设备。":@"Files ready. Open LocalSend to choose a recipient."):(self.chinese?@"未能读取分享内容。请在 Filza 使用“打开方式”。":@"Unable to read the shared files. Try Open In from Filza.");
    UIButton *done=[UIButton buttonWithType:UIButtonTypeSystem];done.frame=CGRectMake(20,20,100,44);[done setTitle:self.chinese?@"完成":@"Done" forState:UIControlStateNormal];[done addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:done];
    if(self.saved){UIButton *open=[UIButton buttonWithType:UIButtonTypeSystem];open.frame=CGRectMake(20,self.view.bounds.size.height-84,self.view.bounds.size.width-40,54);open.autoresizingMask=UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;[open setTitle:self.chinese?@"打开 LocalSend 选择接收设备":@"Open LocalSend to send" forState:UIControlStateNormal];[open addTarget:self action:@selector(openHost) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:open];}
}
- (void)openHost {
    dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",RTLD_NOW);
    Class cls=NSClassFromString(@"LSApplicationWorkspace");SEL workspace=NSSelectorFromString(@"defaultWorkspace");SEL open=NSSelectorFromString(@"openURL:");
    if([cls respondsToSelector:workspace]){id w=((id(*)(id,SEL))objc_msgSend)(cls,workspace);if([w respondsToSelector:open]){BOOL ok=((BOOL(*)(id,SEL,id))objc_msgSend)(w,open,[NSURL URLWithString:@"localsend6://import"]);if(ok){[self close];return;}}}
    self.label.text=self.chinese?@"文件已准备好。请返回桌面打开 LocalSend。":@"Files ready. Open LocalSend from the Home screen.";
}
- (void)close {[self.extensionContext completeRequestReturningItems:nil completionHandler:nil];}
@end
#if LS_TESTING
static void ShareException(NSException *e){NSString *message=[NSString stringWithFormat:@"%@\n%@\n%@",e.name,e.reason,e.callStackSymbols];[message writeToFile:@"/var/mobile/Library/LocalSend6/share-error.txt" atomically:YES encoding:NSUTF8StringEncoding error:nil];NSString *path=[NSHomeDirectory() stringByAppendingPathComponent:@"tmp/LocalSendShare-error.txt"];[message writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];}
__attribute__((constructor))static void ShareDiagnostics(void){NSSetUncaughtExceptionHandler(ShareException);}
#endif
