# Wikipedia 5.5.1 旧接口兼容补丁 0.1.0

适用于已越狱 iOS 9 设备上 `org.wikimedia.wikipedia` 5.5.1（1164）。只载入这个应用，并在运行时再次核对版本；不修改 App 本体、证书或系统网络配置。关闭应用后卸载补丁即可恢复原状。

实测故障：旧版正文请求 `action=mobileview`；服务器 HTTP 200 但返回 API 错误 `badvalue / Unrecognized value for parameter action: mobileview`。同一 iPad 使用 `action=parse` 可成功获取中英文正文。

补丁只替换此版客户端的正文请求参数与响应适配器，把现有 Parse API 正文转成旧客户端的数据结构。文章完整显示，但作为单一正文节交给旧排版器，侧栏不会生成原来的完整章节目录。编辑入口禁用，不生成虚假的最后编辑者／时间；搜索、推荐、图片服务等其他旧接口没有在本补丁中全面重做。

安装 `.deb` 后必须彻底退出 Wikipedia 再打开。不会重启桌面。卸载同样在退出 App 后生效。其他版本不主动尝试套用。

源码参考官方 5.5.1：
https://github.com/wikimedia/wikipedia-ios/tree/releases/5.5.1

构建：`WikipediaCompat/build.sh`（ARMv7 + ARM64 / iOS 9 SDK）。`--testing` 为本机诊断版本，正式包拒绝诊断标记。正式补丁不包含自动打开条目或截屏逻辑。对第三方客户端未来 API 变动不作保证。
