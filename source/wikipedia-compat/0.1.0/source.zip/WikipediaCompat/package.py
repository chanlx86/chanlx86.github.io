#!/usr/bin/env python3
import io,time,tarfile,zipfile,json,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent.parent
binary=r/'build/WikipediaCompat-signed.dylib'
assert binary.exists()
assert b'WikipediaCompat-Test' not in binary.read_bytes(), 'Refusing test dylib'
version='0.1.0';out=Path.home()/'Downloads/Repo/维基百科兼容补丁'/version;out.mkdir(parents=True,exist_ok=True)
def tgz(files):
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w:gz',format=tarfile.USTAR_FORMAT) as t:
  for name,data,mode in files:
   m=tarfile.TarInfo('./'+name);m.size=len(data);m.mode=mode;m.uid=m.gid=0;m.mtime=int(time.time());t.addfile(m,io.BytesIO(data))
 return b.getvalue()
control=f'Package: local.wikipedia.mobileview.compat\nName: Wikipedia 旧版正文兼容\nVersion: {version}\nArchitecture: iphoneos-arm\nSection: Tweaks\nMaintainer: Legacy iOS Tools\nDepends: firmware (>= 9.0), mobilesubstrate\nDescription: Restore read-only article loading in Wikipedia 5.5.1 using the current Parse API.\n'.encode()
deb=out/f'Wikipedia旧版正文兼容_{version}_iphoneos-arm.deb'
with deb.open('wb') as f:
 f.write(b'!<arch>\n')
 for name,data in [('debian-binary',b'2.0\n'),('control.tar.gz',tgz([('control',control,0o644)])),('data.tar.gz',tgz([('Library/MobileSubstrate/DynamicLibraries/WikipediaCompat.dylib',binary.read_bytes(),0o644),('Library/MobileSubstrate/DynamicLibraries/WikipediaCompat.plist',(r/'WikipediaCompat/WikipediaCompat.plist').read_bytes(),0o644)]))]:
  f.write(f'{name+"/":<16}{int(time.time()):<12}{0:<6}{0:<6}{100644:<8}{len(data):<10}`\n'.encode());f.write(data)
  if len(data)%2:f.write(b'\n')
source=out/f'Wikipedia旧版正文兼容_{version}_源码.zip'
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for p in (r/'WikipediaCompat').iterdir():
  if p.is_file():z.write(p,'WikipediaCompat/'+p.name)
notes=out/'使用说明.md';notes.write_bytes((r/'WikipediaCompat/README.md').read_bytes())
(out/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [deb,source,notes]},ensure_ascii=False,indent=2)+'\n')
print(out)
