#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
WS_DEV='/Volumes/OS X/Applications/Xcode.app/Contents/Developer'
args=(-DWIKIPEDIA_COMPAT_RELEASE=1)
if [[ "${1:-}" == '--testing' ]]; then args=(-DWIKIPEDIA_COMPAT_TEST=1); fi
"$WS_DEV/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" -arch armv7 -arch arm64 -isysroot "$WS_DEV/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk" -miphoneos-version-min=9.0 -fobjc-arc -fblocks -O2 -dynamiclib -Wall -Wno-unused-parameter "${args[@]}" WikipediaCompat/WikipediaCompat.m -framework Foundation -framework UIKit -framework WebKit -o build/WikipediaCompat.dylib
