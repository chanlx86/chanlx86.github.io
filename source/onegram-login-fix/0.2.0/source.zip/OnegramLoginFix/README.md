# Onegram Login Fix 0.2.0

适用于越狱、传统 rootful 环境中的 **Onegram 1.4.2 / dev.IllyaGIF.Onegram**，插件构建目标 iOS 9.0 以上、ARMv7 / ARM64。实测设备为 192.168.1.18 的 iPad 3（iOS 9.3.6）。没有测试其他版本；版本不匹配时插件不会启用。

## 定位到的问题

欢迎页可正常绘制，但点击 Continue in English 会先调用 `TGLocalizationSignals applyLocalization:`，通过 Telegram 网络下载语言包。原实现只处理成功回调，没有向订阅者转发请求错误；欢迎页没有超时，进度窗口可能持续覆盖界面。英文 Localizable.strings 已随 App 附带，进入英文登录页不需要下载它。

该版本在 `legacy/TelegraphKit/TGCommon.m` 的 `currentNativeLocalization()` 中，针对 Onegram bundle ID 主动把首次语言设为俄语。这不代表 iPad 不支持中文，也不是本次发现的国行硬件限制。

## 六位验证码输入修复（0.2.0）

`TGLoginCodeController` 原来同时把最大长度和自动提交阈值固定为 5。第 5 位触发验证后 `_inProgress` 又会阻止继续编辑，因此无法输入服务器发送的第 6 位。

现在允许 1–12 位 ASCII 数字，支持删除与粘贴，输入过程不再提交；外部 `applyCode:` 也只填入验证码。最终由用户点击 Next 确认，服务端负责验证真实长度与有效性，兼容 5 位和 6 位验证码。

已在设备进程内用独立的离屏输入框验证：输入第 5 位不提交、第 6 位可输入、6 位粘贴、删除、拒绝非数字、`applyCode:` 不自动提交。合成测试提交次数为 0，结果见 `code-input-tests.json`。没有使用或提交用户的真实验证码。

## 插件实现

- 只加载到 `dev.IllyaGIF.Onegram`，并检查版本等于 1.4.2。
- 对空 lang_pack 的英文语言包请求，使用 App 自己的语言包差分对象提供空增量，交给其原有本地化流程读取随包英文资源、保存语言及更新界面。此路径不等待语言包服务器。
- 其他请求完整交给原实现，不伪造登录、授权、验证码或聊天响应。
- 本地化操作增加 12 秒超时，避免原实现未转发错误时无限等待。
- 发行版本没有自动点击、录屏、诊断日志、网络代理或全局系统 Hook。没有修改原 App Mach-O。

实际分发的插件采用 Objective-C 运行时接口，因为发行程序隐藏了 `setCurrentNativeLocalization` 等 C 符号。源码修复则可直接调用该函数；两种方式作用于相同的本地化路径。

## 验证

在真机上自动验证了以下界面导航（未输入手机号、密码或验证码，未点击 Next）：

```
RMIntroViewController
  → Continue in English（使用随包英文）
TGIOS6QRLoginController
  → phoneButtonPressed
TGLoginPhoneController
```

过程中没有可见的 TGProgressWindow 阻挡，也没有产生 Telegram 崩溃日志。已确认手机号页正确显示英文界面和 China / +86。手机号、验证码提交以及真实服务器登录结果没有代为验证；这部分仍取决于网络、服务端和用户账户状态。本补丁不提供网络连通性或客户端协议层面的修复。

验证码修复诊断版已经载入当前 App；随后安装的正式包会在下次打开时使用。安装操作不主动结束当前 App，以便用户继续完成验证。

## 安装 / 卸载

在 Filza 打开 `OnegramLoginFix_0.2.0_iphoneos-arm.deb` 安装。然后在合适的时候彻底退出 Onegram 并重新打开，使插件载入。安装包不主动结束正在运行的 App，以免打断用户的登录操作；无需重启整个桌面。

Cydia 中可找到 **Onegram Login Fix** 并卸载。卸载后重新打开 Onegram 即不再加载插件；正常选择过的英文语言设置会保留。卸载不删除 App、聊天数据库或账户密钥。

本次设备上预先备份的语言设置位于数据分区：

```
/var/mobile/Library/OnegramLoginFix/backup-before-0.1.0/
```

该目录权限为 700，仅备份已有语言相关文件及偏好设置，未打包进分发文件。需要回退语言设置时应先核对当前数据容器，避免用旧偏好覆盖后来的其他设置。发行包只包含两个文件：

```
/Library/MobileSubstrate/DynamicLibraries/OnegramLoginFix.dylib
/Library/MobileSubstrate/DynamicLibraries/OnegramLoginFix.plist
```

## 构建与源码补丁

执行 `./build.sh`，默认使用 Xcode 7.3.1 的 iOS 9.3 SDK。可用 `OG_DEVELOPER_DIR` 指定其他 Xcode。生成的 Release dylib 需用设备上的 ldid 伪签名，再保存为 `build/OnegramLoginFix-signed.dylib`，然后运行 `python3 package.py`。

`./build.sh --testing` 用于欢迎页导航诊断，`--code-testing` 只运行不联网的离屏输入测试；分发脚本会拒绝包含自动测试标记的二进制。

`onegram-1.4.2-login-fix.patch` 供原工程维护使用，基于 [IllyaGIF/Onegram 的 theos 分支](https://github.com/IllyaGIF/Onegram/tree/theos)，提交 `709b053`（1.4.2）：

- `Telegraph/TGLocalizationSignals.m`：英文直接使用随包资源，并转发其他语言包请求的错误。
- `thirdparty/RMIntro/platform/ios/RMIntroViewController.m`：语言操作 12 秒超时。
- `Telegraph/TGLoginCodeController.m`：取消 5 位限制与自动提交，使用 Next 确认完整验证码。

源码补丁通过了 `git diff --check`，本次没有构建完整 Theos 客户端；实际真机验证的是上述独立插件。中文翻译尚未加入，留待下一阶段处理。
