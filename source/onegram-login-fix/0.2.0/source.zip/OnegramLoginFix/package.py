#!/usr/bin/env python3
import pathlib,io,tarfile,time,zipfile,hashlib,json
r=pathlib.Path(__file__).resolve().parent
signed=r/'build/OnegramLoginFix-signed.dylib'
if not signed.exists():raise SystemExit('Sign the Release dylib with ldid and copy it to build/OnegramLoginFix-signed.dylib first.')
b=signed.read_bytes()
if b'ONEGRAM_TEST' in b or b'OnegramLoginFix-auto-test' in b or b'OnegramLoginFix-code-test.json' in b:raise SystemExit('Refusing a diagnostic binary.')
control='''Package: local.onegram.loginfix
Name: Onegram Login Fix
Version: 0.2.0
Architecture: iphoneos-arm
Section: Tweaks
Priority: optional
Maintainer: Legacy iOS fixes
Depends: mobilesubstrate, firmware (>= 9.0)
Description: Offline bundled English login entry and localization timeout and manual variable-length code entry for Onegram 1.4.2.
'''.encode()
def archive(files):
 out=io.BytesIO()
 with tarfile.open(fileobj=out,mode='w:gz',format=tarfile.USTAR_FORMAT) as t:
  for name,data,mode in files:
   h=tarfile.TarInfo('./'+name);h.uid=h.gid=0;h.uname='root';h.gname='wheel';h.mode=mode;h.size=len(data);h.mtime=int(time.time());t.addfile(h,io.BytesIO(data))
 return out.getvalue()
data=archive([('Library/MobileSubstrate/DynamicLibraries/OnegramLoginFix.dylib',b,0o755),('Library/MobileSubstrate/DynamicLibraries/OnegramLoginFix.plist',(r/'OnegramLoginFix.plist').read_bytes(),0o644)])
dist=r/'dist';dist.mkdir(exist_ok=True);p=dist/'OnegramLoginFix_0.2.0_iphoneos-arm.deb'
with p.open('wb') as f:
 f.write(b'!<arch>\n')
 for n,d in [('debian-binary',b'2.0\n'),('control.tar.gz',archive([('control',control,0o644)])),('data.tar.gz',data)]:
  f.write(f'{n+"/":<16}{int(time.time()):<12}{0:<6}{0:<6}{100644:<8}{len(d):<10}`\n'.encode());f.write(d)
  if len(d)%2:f.write(b'\n')
with zipfile.ZipFile(dist/'OnegramLoginFix_0.2.0_源码与补丁.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['OnegramLoginFix.m','OnegramLoginFix.plist','build.sh','package.py','onegram-1.4.2-login-fix.patch','README.md','code-input-tests.json']:
  z.write(r/name,'OnegramLoginFix/'+name)
(dist/'SHA256.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
print(p)
