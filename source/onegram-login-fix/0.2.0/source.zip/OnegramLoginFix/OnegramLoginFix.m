#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <objc/message.h>
#include <dlfcn.h>

// All interactions stay inside Onegram 1.4.2. No account values are inspected.
@interface OGSignal : NSObject
+ (id)complete;
+ (id)single:(id)value;
+ (id)fail:(id)error;
- (id)initWithGenerator:(id (^)(id subscriber))generator;
- (id)timeout:(NSTimeInterval)seconds onQueue:(id)queue orSignal:(id)alternate;
@end
@interface OGLocalization : NSObject
- (id)initWithVersion:(int32_t)version code:(NSString *)code dict:(NSDictionary *)dict isActive:(bool)active;
@end
@interface OGSubscriber : NSObject
- (void)putCompletion;
- (void)putError:(id)error;
@end
@interface OGCodeUI : NSObject
@property(nonatomic,strong) UITextField *codeField;
@property(nonatomic,copy) NSString *phoneCode;
@property(nonatomic) bool inProgress;
@end
static BOOL (*originalCodeEdit)(id,SEL,UITextField *,NSRange,NSString *);
static id (*originalApply)(id,SEL,NSString *);
static id (*originalRequest)(id,SEL,id);
static Class languageRequestClass;
static Class differenceClass;
#ifdef ONEGRAM_TEST
static NSString *reportPath;
static void Log(NSString *message) {
    NSString *line=[NSString stringWithFormat:@"%@ %@\n",[NSDate date],message];
    NSFileHandle *h=[NSFileHandle fileHandleForWritingAtPath:reportPath]; if(!h) { [line writeToFile:reportPath atomically:YES encoding:NSUTF8StringEncoding error:nil]; return; } [h seekToEndOfFile]; [h writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; [h closeFile];
}
#else
static void Log(NSString *message) {}
#endif
static id Request(id self,SEL cmd,id rpc) {
    if([rpc isKindOfClass:languageRequestClass]) {
        NSString *code=[rpc valueForKey:@"lang_code"];
        NSString *pack=[rpc valueForKey:@"lang_pack"];
        if([code isEqualToString:@"en"] && !pack.length) {
            id difference=[differenceClass new];
            [difference setValue:@"en" forKey:@"lang_code"];
            [difference setValue:@0 forKey:@"from_version"];
            [difference setValue:@0 forKey:@"version"];
            [difference setValue:@[] forKey:@"strings"];
            Log(@"using bundled English; no language-pack network request");
            return [(id)NSClassFromString(@"SSignal") single:difference];
        }
    }
    return originalRequest(self,cmd,rpc);
}
static id Apply(id cls,SEL cmd,NSString *code) {
    id signal=originalApply(cls,cmd,code);
    id queue=((id(*)(id,SEL))objc_msgSend)(NSClassFromString(@"SQueue"),NSSelectorFromString(@"mainQueue"));
    id fail=[(id)NSClassFromString(@"SSignal") fail:@"LOCALIZATION_REQUEST_TIMEOUT"];
    return [(OGSignal *)signal timeout:12 onQueue:queue orSignal:fail];
}
static BOOL CodeEdit(id self,SEL cmd,UITextField *field,NSRange range,NSString *replacement) {
    OGCodeUI *controller=(id)self;
    if(controller.inProgress)return NO;
    if(field!=controller.codeField)return originalCodeEdit(self,cmd,field,range,replacement);
    NSString *old=field.text?:@""; replacement=replacement?:@"";
    if(range.location>old.length || range.length>old.length-range.location)return NO;
    for(NSUInteger i=0;i<replacement.length;i++) { unichar c=[replacement characterAtIndex:i]; if(c<'0'||c>'9')return NO; }
    NSString *text=[old stringByReplacingCharactersInRange:range withString:replacement];
    if(text.length>12)return NO;
    field.text=text; controller.phoneCode=text;
    UITextPosition *position=[field positionFromPosition:field.beginningOfDocument offset:range.location+replacement.length];
    if(position)field.selectedTextRange=[field textRangeFromPosition:position toPosition:position];
    // Never submit a partly typed code; Next remains the explicit confirmation.
    return NO;
}
static void ApplyCode(id self,SEL cmd,NSString *code) {
    OGCodeUI *controller=(id)self;
    if(controller.inProgress||!code.length||code.length>12)return;
    for(NSUInteger i=0;i<code.length;i++) { unichar c=[code characterAtIndex:i];if(c<'0'||c>'9')return; }
    controller.codeField.text=code;controller.phoneCode=code;
}
#ifdef ONEGRAM_CODE_TEST
@interface OGCodeInputTest : OGCodeUI
@property(nonatomic) NSUInteger submissions;
- (void)nextButtonPressed;
@end
@implementation OGCodeUI
@end
@implementation OGCodeInputTest
- (void)nextButtonPressed { _submissions++; }
@end
static void TestCodeInput(void) {
    OGCodeInputTest *c=[OGCodeInputTest new]; c.codeField=[[UITextField alloc] initWithFrame:CGRectZero]; c.codeField.text=@"";
    for(NSUInteger i=0;i<5;i++)CodeEdit(c,NULL,c.codeField,NSMakeRange(i,0),@"1");
    BOOL five=c.codeField.text.length==5&&c.submissions==0;
    CodeEdit(c,NULL,c.codeField,NSMakeRange(5,0),@"2"); BOOL six=c.codeField.text.length==6&&c.phoneCode.length==6&&c.submissions==0;
    NSString *sixText=c.codeField.text; CodeEdit(c,NULL,c.codeField,NSMakeRange(6,0),@"x"); BOOL reject=[sixText isEqual:c.codeField.text];
    CodeEdit(c,NULL,c.codeField,NSMakeRange(5,1),@"");BOOL deletion=c.codeField.text.length==5;
    c.codeField.text=@"";CodeEdit(c,NULL,c.codeField,NSMakeRange(0,0),@"111112");BOOL paste=c.codeField.text.length==6&&c.submissions==0;
    ApplyCode(c,NULL,@"111112"); BOOL applied=c.phoneCode.length==6&&c.submissions==0;
    NSDictionary *r=@{@"fiveDoesNotSubmit":@(five),@"sixAccepted":@(six),@"nonDigitRejected":@(reject),@"deleteWorks":@(deletion),@"sixDigitPaste":@(paste),@"applyCodeDoesNotSubmit":@(applied),@"submissionCount":@(c.submissions)};
    NSData *data=[NSJSONSerialization dataWithJSONObject:r options:NSJSONWritingPrettyPrinted error:nil];
    NSString *path=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"OnegramLoginFix-code-test.json"];
    [data writeToFile:path atomically:YES];
}
#endif
#ifdef ONEGRAM_TEST
static UIViewController *Top(void) {
    UIWindow *w=[UIApplication sharedApplication].delegate.window;
    UIViewController *vc=w.rootViewController;
    if([vc isKindOfClass:[UINavigationController class]])vc=[(UINavigationController *)vc topViewController];
    return vc;
}
static void State(NSString *phase) {
    UIViewController *top=Top(); NSMutableArray *windows=[NSMutableArray array];
    for(UIWindow *w in [UIApplication sharedApplication].windows)if(!w.hidden && w.alpha>0)[windows addObject:NSStringFromClass(w.class)];
    Log([NSString stringWithFormat:@"%@ controller=%@ windows=%@",phase,NSStringFromClass(top.class),[windows componentsJoinedByString:@","]]);
}
static void StartTest(void) {
    NSString *flag=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"OnegramLoginFix-auto-test"];
    if(![[NSFileManager defaultManager] fileExistsAtPath:flag])return;
    [[NSFileManager defaultManager] removeItemAtPath:flag error:nil];
    [UIApplication sharedApplication].idleTimerDisabled=YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,4*NSEC_PER_SEC),dispatch_get_main_queue(),^{
        State(@"before English"); UIViewController *top=Top(); SEL english=NSSelectorFromString(@"alternativeLanguageButtonPressed");
        if([top respondsToSelector:english])((void(*)(id,SEL))objc_msgSend)(top,english);
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,4*NSEC_PER_SEC),dispatch_get_main_queue(),^{
            State(@"after English"); UIViewController *qr=Top(); SEL phone=NSSelectorFromString(@"phoneButtonPressed");
            if([qr respondsToSelector:phone])((void(*)(id,SEL))objc_msgSend)(qr,phone);
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC),dispatch_get_main_queue(),^{State(@"phone page");[UIApplication sharedApplication].idleTimerDisabled=NO;});
        });
    });
}
#endif
__attribute__((constructor)) static void Install(void) {
    @autoreleasepool {
        NSBundle *b=[NSBundle mainBundle];
        if(![b.bundleIdentifier isEqualToString:@"dev.IllyaGIF.Onegram"] || ![[b objectForInfoDictionaryKey:@"CFBundleShortVersionString"] isEqualToString:@"1.4.2"])return;
#ifdef ONEGRAM_TEST
        reportPath=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"OnegramLoginFix-diagnostic.log"];
#endif
        Class cls=NSClassFromString(@"TGLocalizationSignals"); Method m=class_getClassMethod(cls,NSSelectorFromString(@"applyLocalization:"));
        Class networking=NSClassFromString(@"TGTelegramNetworking");
        Method request=class_getInstanceMethod(networking,NSSelectorFromString(@"requestSignal:"));
        languageRequestClass=NSClassFromString(@"TLRPClangpack_getLangPack$langpack_getLangPack");
        differenceClass=NSClassFromString(@"TLLangPackDifference$langPackDifference");
        if(!m || !request || !languageRequestClass || !differenceClass) { Log(@"not installed: required runtime interface absent"); return; }
        Class codeController=NSClassFromString(@"TGLoginCodeController");
        Method edit=class_getInstanceMethod(codeController,NSSelectorFromString(@"textField:shouldChangeCharactersInRange:replacementString:"));
        Method apply=class_getInstanceMethod(codeController,NSSelectorFromString(@"applyCode:"));
        if(edit&&apply) { originalCodeEdit=(void *)method_setImplementation(edit,(IMP)CodeEdit); method_setImplementation(apply,(IMP)ApplyCode); }
#ifdef ONEGRAM_CODE_TEST
        dispatch_async(dispatch_get_main_queue(),^{TestCodeInput();});
#endif
        originalRequest=(void *)method_setImplementation(request,(IMP)Request);
        originalApply=(void *)method_setImplementation(m,(IMP)Apply); Log(@"Onegram 1.4.2 localization fix installed");
#ifdef ONEGRAM_TEST
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification *note){StartTest();}];
#endif
    }
}
