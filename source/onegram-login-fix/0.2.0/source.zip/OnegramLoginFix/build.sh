#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
OG_DEV="${OG_DEVELOPER_DIR:-/Volumes/OS X/Applications/Xcode.app/Contents/Developer}"
OG_EXTRA=(-DOG_BUILD=1)
if [[ "${1:-}" == "--testing" ]]; then OG_EXTRA=(-DONEGRAM_TEST=1); fi
if [[ "${1:-}" == "--code-testing" ]]; then OG_EXTRA=(-DONEGRAM_CODE_TEST=1); fi
mkdir -p build
"$OG_DEV/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" -arch armv7 -arch arm64 -isysroot "$OG_DEV/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk" -miphoneos-version-min=9.0 -fobjc-arc -fblocks -O2 -Wall -Wextra -Wno-unused-parameter -dynamiclib OnegramLoginFix.m "${OG_EXTRA[@]}" -framework UIKit -framework Foundation -framework CoreGraphics -install_name /Library/MobileSubstrate/DynamicLibraries/OnegramLoginFix.dylib -o build/OnegramLoginFix.dylib
