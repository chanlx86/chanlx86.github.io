"""Small local Range fixture, exposed to the test iPad only through SSH forwarding."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import mimetypes,re
root=Path(__file__).resolve().parent.parent/'build/test-fixtures-080'
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  name=self.path.lstrip('/')
  if name not in ['book.pdf','sample.mp3']:
   self.send_error(404);return
  path=root/name;size=path.stat().st_size;start=0;end=size-1
  request=self.headers.get('Range','');m=re.fullmatch(r'bytes=(\d+)-(\d*)',request)
  if m:start=int(m[1]);end=min(int(m[2]) if m[2] else end,end)
  if start>end:self.send_error(416);return
  self.send_response(206 if m else 200)
  self.send_header('Content-Type',mimetypes.guess_type(name)[0] or 'application/octet-stream')
  self.send_header('Accept-Ranges','bytes');self.send_header('Content-Length',str(end-start+1))
  if m:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
  self.end_headers()
  with path.open('rb') as f:f.seek(start);self.wfile.write(f.read(end-start+1))
ThreadingHTTPServer(('127.0.0.1',8790),Handler).serve_forever()
