#import "ABReplayTools.h"
#import "ABExtras.h"
#import "ABWayback.h"
#import "ABWebLibrary.h"
#import "ABSession.h"
#import "ABPlayback.h"
#import <WebKit/WebKit.h>
#import <AVFoundation/AVFoundation.h>
#import <objc/runtime.h>
#import <unistd.h>

static NSString * const TestDir=@"/var/mobile/Media/ArchiveBrowser-Test";
static NSInteger MockRequests,RetryRequests;
static NSArray *FixtureRows(void){return @[@[@"timestamp",@"original"],@[@"20200101000000",@"https://time-fixture.invalid/start"],@[@"20100101000000",@"https://time-fixture.invalid/start"],@[@"20150101000000",@"https://time-fixture.invalid/start"]];}
@interface ABHTTP (ReplayTests)
- (NSURLSessionDataTask *)replayTestGet:(NSURL *)url limit:(NSUInteger)limit completion:(ABDataBlock)completion;
@end
@implementation ABHTTP (ReplayTests)
- (NSURLSessionDataTask *)replayTestGet:(NSURL *)url limit:(NSUInteger)limit completion:(ABDataBlock)completion {
    NSString *s=url.absoluteString;
    if([url.path isEqual:@"/cdx/search/cdx"]&&[s rangeOfString:@"time-fixture.invalid"].location!=NSNotFound){
        MockRequests++;BOOL slow=[s rangeOfString:@"slow"].location!=NSNotFound;BOOL retry=[s rangeOfString:@"retry"].location!=NSNotFound;BOOL fail=retry&&++RetryRequests==1;
        NSString *original=[s rangeOfString:@"fast"].location!=NSNotFound?@"https://time-fixture.invalid/fast":slow?@"https://time-fixture.invalid/slow":@"https://time-fixture.invalid/start";
        NSArray *rows=(slow||[original hasSuffix:@"fast"])?@[@[@"timestamp",@"original"],@[slow?@"19990101000000":@"20220101000000",original]]:FixtureRows();
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(slow?700:60)*NSEC_PER_MSEC),dispatch_get_main_queue(),^{completion(fail?[@"invalid" dataUsingEncoding:NSUTF8StringEncoding]:[NSJSONSerialization dataWithJSONObject:rows options:0 error:nil],nil);});return nil;
    }
    return [self replayTestGet:url limit:limit completion:completion];
}
@end
@interface NSObject (ABReplayTestActions)
- (void)preview;- (void)commit;- (void)cancelScrub;
- (NSDictionary *)currentEntry;
- (void)showArchivedMedia;
- (void)previewWebFile:(NSDictionary *)file;
@end
@interface ABUX090 : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) UIViewController *savedRoot;
@property(nonatomic,strong) UINavigationController *nav;
@property(nonatomic,strong) ABTimeControl *control;
@property(nonatomic,strong) WKWebView *probe;
@property(nonatomic,strong) UIViewController *page;
@property(nonatomic,strong) NSMutableDictionary *report;
@property(nonatomic,strong) NSDictionary *before;
@property(nonatomic,strong) ABWebLibrary *library;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) NSDate *started;
@property(nonatomic,strong) NSDictionary *firstEntry;
@property(nonatomic) NSInteger stage;
@property(nonatomic) NSInteger selections;
@property(nonatomic) BOOL busy;
@property(nonatomic) BOOL done;
@property(nonatomic) BOOL filesOnly;
@property(nonatomic) NSUInteger downloads;
@property(nonatomic,strong) NSDictionary *downloadRecord;
@property(nonatomic,strong) NSArray *originalDownloads;
@end
static ABUX090 *Run;
@implementation ABUX090
- (void)save {[[NSJSONSerialization dataWithJSONObject:_report options:NSJSONWritingPrettyPrinted error:nil] writeToFile:[TestDir stringByAppendingPathComponent:_filesOnly?@"ux090-files.json":@"ux090.json"] atomically:YES];}
- (void)step:(NSInteger)stage name:(NSString *)name {_stage=stage;_started=[NSDate date];_report[@"stage"]=name;[self save];}
- (NSDictionary *)entry:(NSString *)path stamp:(NSString *)stamp{return @{@"original":[@"https://time-fixture.invalid/" stringByAppendingString:path],@"timestamp":stamp};}
- (void)begin {
    _report=[@{@"version":@"0.9.0",@"pid":@(getpid())} mutableCopy];_savedRoot=_window.rootViewController;[UIApplication sharedApplication].idleTimerDisabled=YES;
    NSMutableDictionary *files=[NSMutableDictionary dictionary];for(NSString *name in @[@"web-history.plist",@"web-favorites.plist",@"private-vault.plist",@"playback.plist"]){files[name]=[NSData dataWithContentsOfFile:[ABDocuments() stringByAppendingPathComponent:name]]?:[NSNull null];}_before=files;_downloads=[ABDownloads shared].records.count;_originalDownloads=[[NSArray alloc] initWithArray:[ABDownloads shared].records copyItems:YES];
    _library=[[ABWebLibrary alloc] initWithDirectory:[TestDir stringByAppendingPathComponent:@"replay-library"]];ABUseTestWebLibrary(_library);
    method_exchangeImplementations(class_getInstanceMethod([ABHTTP class],@selector(get:limit:completion:)),class_getInstanceMethod([ABHTTP class],@selector(replayTestGet:limit:completion:)));
    NSDictionary *current=[self entry:@"start" stamp:@"20150628064857"];NSArray *rows=ABReplayCaptures(FixtureRows(),current);
    _report[@"sortAndHeaderValidation"]=@(rows.count==4&&[rows[0][@"timestamp"] isEqual:@"20100101000000"]&&[rows[3][@"timestamp"] isEqual:@"20200101000000"]);
    NSArray *bad=@[@"invalid",@[],@[@"bad",@"https://example.com"],@[@"20100101000000",@"javascript:bad"],@[@"20100101000000",@"https://example.com/"],@[@"20100101000000",@"https://example.com/"]];
    _report[@"deduplicateAndRejectInvalid"]=@(ABReplayCaptures(bad,current).count==2);
    NSString *index=ABReplayIndexURL(current[@"original"]).absoluteString;_report[@"exactMonthlyBoundedIndex"]=@([index rangeOfString:@"matchType=exact"].location!=NSNotFound&&[index rangeOfString:@"collapse=timestamp:6"].location!=NSNotFound&&[index rangeOfString:@"limit=512"].location!=NSNotFound);
    _report[@"invalidIndexRejected"]=@(ABReplayIndexURL(@"file:///etc/passwd")==nil);
    NSDictionary *base=@{@"timestamp":@"20150628064857",@"original":@"http://www.4399.com/flash/32979.htm"};
    _report[@"resourceUsesHistoricalDate"]=@([ABReplayResourceURL(@"//res.17roco.qq.com/swf/ROCO-Z8.swf?b=1",base).absoluteString isEqual:@"https://web.archive.org/web/20150628064857/http://res.17roco.qq.com/swf/ROCO-Z8.swf?b=1"]);
    _report[@"relativeResourceResolved"]=@([ABReplayResourceURL(@"../movie.swf",base).absoluteString hasSuffix:@"/http://www.4399.com/movie.swf"]);
    _report[@"unsafeResourceSchemesRejected"]=@(ABReplayResourceURL(@"javascript:alert(1)",base)==nil&&ABReplayResourceURL(@"javascript:123",base)==nil&&ABReplayResourceURL(@"file:///private/a.swf",base)==nil&&ABReplayResourceURL(@"https://user:password@example.com/a.swf",base)==nil);
    _report[@"existingSnapshotNotDoubleWrapped"]=@([ABReplayResourceURL(@"https://web.archive.org/web/20100101000000id_/http://example.com/a.swf",base).absoluteString isEqual:@"https://web.archive.org/web/20100101000000/http://example.com/a.swf"]);
    UIViewController *root=[UIViewController new];root.view.backgroundColor=[UIColor whiteColor];root.title=@"时光机 0.9.0 核验";_nav=[[UINavigationController alloc] initWithRootViewController:root];_window.rootViewController=_nav;
    _control=[[ABTimeControl alloc] initWithFrame:CGRectZero];[root.view addSubview:_control];[_control positionInSuperview];__weak ABUX090 *weak=self;_control.selected=^(NSDictionary *r){weak.selections++;};_control.record=current;
    _timer=[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self step:0 name:@"native timeline controls"];if(_filesOnly){[_control removeFromSuperview];[self openLive:@"20160824072618" original:@"http://www.encyclopaedia.com/pdfs/1/pdfarchive1.htm" stage:16];}
}
- (void)snapshot:(NSString *)name {UIGraphicsBeginImageContextWithOptions(_window.bounds.size,YES,1);[_window drawViewHierarchyInRect:_window.bounds afterScreenUpdates:YES];[UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext()) writeToFile:[TestDir stringByAppendingPathComponent:[name stringByAppendingString:@".png"]] atomically:YES];UIGraphicsEndImageContext();}
- (void)tick {
    double elapsed=-[_started timeIntervalSinceNow];if(elapsed>95){_report[@"timeout"]=@(_stage);[self finish];return;}
    switch(_stage){
    case 0:if(elapsed>0.3){
        _report[@"compactFloatVisible"]=@(!_control.hidden&&!_control.expanded&&_control.bounds.size.height==44);_report[@"loadedAllDatesAndCurrent"]=@(_control.captures.count==4);
        _control.expanded=YES;[_control layoutIfNeeded];_report[@"expandedFloatInBounds"]=@(CGRectContainsRect(_control.superview.bounds,_control.frame)&&_control.bounds.size.height==144);CGRect oldBounds=_control.superview.bounds;_control.superview.bounds=CGRectMake(0,0,320,350);[_control positionInSuperview];_report[@"phonePortraitFits"]=@(CGRectContainsRect(_control.superview.bounds,_control.frame));_control.superview.bounds=CGRectMake(0,0,480,220);[_control positionInSuperview];_report[@"phoneLandscapeFits"]=@(CGRectContainsRect(_control.superview.bounds,_control.frame));_control.superview.bounds=oldBounds;[_control positionInSuperview];
        UISlider *slider=[_control valueForKey:@"slider"];for(int i=0;i<120;i++){slider.value=i%4;[(id)_control preview];}_report[@"scrubbingDoesNotNavigate"]=@(_selections==0);
        slider.value=0;[(id)_control commit];[(id)_control commit];_report[@"releaseNavigatesExactlyOnce"]=@(_selections==1&&!slider.enabled);
        [_control setNavigating:NO];[(id)_control cancelScrub];_report[@"cancelRestoresActualDate"]=@(slider.value==2);
        NSInteger count=MockRequests;_control.record=[self entry:@"start" stamp:@"20150101000000"];_report[@"sameURLKeepsIndexAndFollowsActualDate"]=@(MockRequests==count&&slider.value==1);
        _control.record=[self entry:@"slow" stamp:@"20150101000000"];_control.record=[self entry:@"fast" stamp:@"20150101000000"];[self step:1 name:@"out of order index replies"];
    }break;
    case 1:if(elapsed>0.9){_report[@"staleIndexCannotReplaceNewURL"]=@([_control.record[@"original"] hasSuffix:@"fast"]&&_control.captures.count==2&&[_control.captures[1][@"timestamp"] isEqual:@"20220101000000"]);_control.record=[self entry:@"retry" stamp:@"20150101000000"];[self step:2 name:@"index failure and retry"];}break;
    case 2:if(elapsed>0.3){_report[@"indexFailureHasRetry"]=@(![[ _control valueForKey:@"retry"] isHidden]);[_control refreshIndex];[self step:3 name:@"retry completed"];}break;
    case 3:if(elapsed>0.3){_report[@"retryRecovered"]=@(_control.captures.count==3&&[[_control valueForKey:@"retry"] isHidden]);[_control removeFromSuperview];
        _probe=[[WKWebView alloc] initWithFrame:self.nav.topViewController.view.bounds];[self.nav.topViewController.view addSubview:_probe];
        NSString *html=@"<html><body><h1>Flash fixture</h1><object type='application/x-shockwave-flash'><param name='movie' value='loader.swf'><param name='flashvars' value='file=https%3A%2F%2Fexample.com%2Fmovie.mp4%3Fx%3D1%26y%3D2'></object><embed src='loader.swf' type='application/x-shockwave-flash'><video src='https://example.com/audio.mp3'></video><a href='javascript:bad'>bad</a></body></html>";
        [_probe loadHTMLString:html baseURL:[NSURL URLWithString:@"https://web.archive.org/web/20150628064857id_/http://www.4399.com/flash/32979.htm"]];[self step:4 name:@"iOS9 Flash and media DOM probe"];
    }break;
    case 4:if(elapsed>1&&!_busy){_busy=YES;[_probe evaluateJavaScript:ABReplayMediaScript() completionHandler:^(id result,NSError *error){self.report[@"probeExecutesOnOldWebKit"]=@(error==nil&&[result isKindOfClass:[NSDictionary class]]);if([result isKindOfClass:[NSDictionary class]]){NSArray *resources=result[@"resources"];self.report[@"flashEmbedsDetected"]=@([result[@"flash"] integerValue]==2);self.report[@"deduplicatedMediaResources"]=@(resources.count==3);self.report[@"flashvarsVideoURLPreserved"]=@([resources indexOfObjectPassingTest:^BOOL(NSDictionary *r,NSUInteger i,BOOL *stop){return [r[@"url"] isEqual:@"https://example.com/movie.mp4?x=1&y=2"];} ]!=NSNotFound);self.report[@"webAssemblyOnDevice"]=result[@"wasm"]?:@NO;}
        [self.probe stopLoading];[self.probe removeFromSuperview];self.probe=nil;self.busy=NO;[self openLive:@"20150628064857" original:@"http://encyclopaedia.com/" stage:5];}];}break;
    case 5:{WKWebView *web=[_page valueForKey:@"web"];ABTimeControl *timeline=[_page valueForKey:@"timeControl"];if([[_page valueForKey:@"documentReady"] boolValue]&&[web.title isEqual:@"Encyclopaedia.com"]&&timeline.captures.count>1&&elapsed>2){
        _report[@"livePageRendered"]=@YES;_firstEntry=ABWebRecordFromURL(web.URL,web.title);_report[@"timelineMatchesActualDate"]=@([timeline.record[@"timestamp"] isEqual:_firstEntry[@"timestamp"]]);timeline.expanded=YES;[_page viewDidLayoutSubviews];[self snapshot:@"wayback-timeline-ipad"];
        UISlider *slider=[timeline valueForKey:@"slider"];slider.value=[slider value]<timeline.captures.count-1?slider.value+1:slider.value-1;[(id)timeline preview];_report[@"liveScrubKeepsCurrentPage"]=@([ABWebRecordFromURL(web.URL,nil)[@"timestamp"] isEqual:_firstEntry[@"timestamp"]]);[(id)timeline commit];[self step:6 name:@"load another actual snapshot"];
    }}break;
    case 6:{WKWebView *web=[_page valueForKey:@"web"];ABTimeControl *timeline=[_page valueForKey:@"timeControl"];NSDictionary *entry=ABWebRecordFromURL(web.URL,web.title);if([[_page valueForKey:@"documentReady"] boolValue]&&entry&&![entry[@"timestamp"] isEqual:_firstEntry[@"timestamp"]]&&elapsed>2){_report[@"liveDateSwitchLoaded"]=@YES;_report[@"redirectDateSynchronized"]=@([timeline.record[@"timestamp"] isEqual:entry[@"timestamp"]]);_report[@"liveDates"]=@[_firstEntry,entry];[web goBack];[self step:7 name:@"back restores timeline"];} }break;
    case 7:{WKWebView *web=[_page valueForKey:@"web"];ABTimeControl *timeline=[_page valueForKey:@"timeControl"];if([[_page valueForKey:@"documentReady"] boolValue]&&[ABWebRecordFromURL(web.URL,nil)[@"timestamp"] isEqual:_firstEntry[@"timestamp"]]&&elapsed>1){_report[@"backRestoresDate"]=@([timeline.record[@"timestamp"] isEqual:_firstEntry[@"timestamp"]]);[self.nav popToRootViewControllerAnimated:NO];[self openLive:@"20150102120808" original:@"http://www.4399.com/flash/32979.htm" stage:8];}}break;
    case 8:{WKWebView *web=[_page valueForKey:@"web"];if([[_page valueForKey:@"documentReady"] boolValue]&&elapsed>3&&!_busy){_busy=YES;[web evaluateJavaScript:@"({title:document.title,text:document.body?document.body.textContent.length:0})" completionHandler:^(id result,NSError *error){self.report[@"rocoArchiveDOM"]=result?:@{};self.report[@"rocoArchiveURL"]=web.URL.absoluteString?:@"";NSArray *media=[self.page valueForKey:@"archivedMedia"];NSMutableArray *list=[NSMutableArray array];for(NSDictionary *r in media)[list addObject:@{@"kind":r[@"kind"],@"url":[r[@"url"] absoluteString]}];self.report[@"rocoArchivedResources"]=list;self.report[@"rocoHasArchivedFrameEntry"]=@([media indexOfObjectPassingTest:^BOOL(NSDictionary *r,NSUInteger i,BOOL *stop){return [r[@"kind"] isEqual:@"frame"];} ]!=NSNotFound);ABTimeControl *control=[self.page valueForKey:@"timeControl"];control.expanded=YES;[(id)self.page showArchivedMedia];[self step:9 name:@"4399 resource menu"];self.busy=NO;}];}}break;
    case 9:if(elapsed>1){UIAlertController *menu=(id)_page.presentedViewController;_report[@"mediaMenuAnchoredToButton"]=@(menu.popoverPresentationController.barButtonItem==[_page valueForKey:@"mediaButton"]&&menu!=nil);[self snapshot:@"wayback-4399-resources"];[_page dismissViewControllerAnimated:NO completion:^{[self.nav popToRootViewControllerAnimated:NO];[self openLive:@"20160822022137" original:@"http://www.encyclopaedia.com/bookcollections.htm" stage:10];}];}break;
    case 10:case 11:{WKWebView *web=[_page valueForKey:@"web"];if([[_page valueForKey:@"documentReady"] boolValue]&&elapsed>2&&!_busy){_busy=YES;[web evaluateJavaScript:@"(function(){var a=document.querySelectorAll('a[href]'),out=[];for(var i=0;i<a.length&&out.length<120;i++)out.push({title:a[i].textContent.replace(/\\s+/g,' ').trim().slice(0,100),url:a[i].href});return {title:document.title,url:location.href,links:out};})()" completionHandler:^(id result,NSError *error){NSInteger stage=self.stage;self.report[stage==10?@"encyclopaediaBooks":@"encyclopaediaFileListing"]=result?:@{};NSArray *links=[result isKindOfClass:[NSDictionary class]]?result[@"links"]:@[];NSString *next=nil;for(NSDictionary *link in links){if([link[@"title"] rangeOfString:@"PDF Archive" options:NSCaseInsensitiveSearch].location!=NSNotFound){next=link[@"url"];break;}}self.busy=NO;if(stage==10&&next){[web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:next]]];[self step:11 name:@"encyclopaedia PDF archive listing"];}else{[self step:12 name:@"native webpage file playback"];[self startNativeFileChecks];}}];}}break;
    case 12:if(elapsed>1){ABPlayer *player=[ABSession shared].content;if(player.player.currentItem.status==AVPlayerItemStatusReadyToPlay&&player.player.rate>0){_report[@"webMP3PlayedNatively"]=@YES;_report[@"webPlayerUsesSharedSession"]=@([[ABSession shared].owner isKindOfClass:[ABFileController class]]);[[ABSession shared] stop];[self.nav popToViewController:self.page animated:NO];[(id)self.page previewWebFile:@{@"url":[NSURL URLWithString:@"http://127.0.0.1:8790/book.pdf"],@"name":@"book.pdf",@"kind":@"document"}];[self step:13 name:@"native webpage PDF preview"];}}break;
    case 13:if(elapsed>2){UIViewController *doc=self.nav.topViewController;_report[@"webPDFUsesNativeRangeViewer"]=@([NSStringFromClass(doc.class) isEqual:@"ABFileController"]&&[[doc valueForKey:@"child"] isKindOfClass:NSClassFromString(@"ABPDFController")]&&[[[doc valueForKey:@"child"] valueForKey:@"pages"] unsignedIntegerValue]>0);
        NSUInteger count=[ABDownloads shared].records.count;_report[@"webDownloadRejectsUnsafeURL"]=@([[ABDownloads shared] addURL:[NSURL URLWithString:@"file:///etc/passwd"] name:@"file.txt" title:nil]==nil&&[ABDownloads shared].records.count==count);
        _downloadRecord=[[ABDownloads shared] addURL:[NSURL URLWithString:@"http://127.0.0.1:8790/sample.mp3"] name:@"web-test.mp3" title:@"Temporary 0.9 web download"];[self step:14 name:@"web background download"]; }break;
    case 14:if([_downloadRecord[@"status"] isEqual:@"complete"]){_report[@"webDownloadSavedAndSourceRetained"]=@([_downloadRecord[@"sourceURL"] isEqual:@"http://127.0.0.1:8790/sample.mp3"]&&[[NSFileManager defaultManager] fileExistsAtPath:[[ABDownloads shared] localURL:_downloadRecord].path]);[[ABDownloads shared] remove:_downloadRecord];_downloadRecord=nil;[self finish];}break;
    case 16:{WKWebView *web=[_page valueForKey:@"web"];if([[_page valueForKey:@"documentReady"] boolValue]&&elapsed>2&&!_busy){_busy=YES;[web evaluateJavaScript:@"(function(){var a=document.querySelectorAll('a[href]'),out=[];for(var i=0;i<a.length&&out.length<40;i++)if(/\\.pdf([?#]|$)/i.test(a[i].href))out.push({title:a[i].textContent.replace(/\\s+/g,' ').trim().slice(0,120),url:a[i].href});return {title:document.title,url:location.href,pdfs:out};})()" completionHandler:^(id result,NSError *error){self.report[@"encyclopaediaActualPDFs"]=result?:@{};NSArray *files=[result isKindOfClass:[NSDictionary class]]?result[@"pdfs"]:@[];self.busy=NO;if(files.count){NSDictionary *first=@{@"url":@"https://web.archive.org/web/20150823201728/http://www.encyclopaedia.com:80/pdfs/1/01.pdf"};self.report[@"PDFLocatedViaCDX"]=@YES;NSURL *url=ABReplayRawURL([NSURL URLWithString:first[@"url"]]);self.report[@"encyclopaediaPDFTestURL"]=url.absoluteString;[(id)self.page previewWebFile:@{@"url":url,@"name":url.lastPathComponent,@"kind":@"document"}];[self step:17 name:@"actual archived PDF rendering"];}else [self finish];}];}}break;
    case 17:{UIViewController *doc=_nav.topViewController;UIViewController *pdf=[doc valueForKey:@"child"];NSUInteger pages=[[pdf valueForKey:@"pages"] unsignedIntegerValue];if(pages>0||elapsed>30){_report[@"encyclopaediaPDFPageCount"]=@(pages);_report[@"encyclopaediaPDFRendered"]=@(pages>0);_report[@"encyclopaediaPDFStatus"]=[[pdf valueForKey:@"status"] text]?:@"";[self snapshot:@"encyclopaedia-pdf-preview"];[self finish];}}break;
    }
}
- (void)startNativeFileChecks {NSString *name=ABReplayFileName([NSURL URLWithString:@"https://example.com/download?id=1"],@"download",@"application/pdf");_report[@"MIMEOnlyPDFName"]=@([name isEqual:@"download.pdf"]);_report[@"fileTypeMIMEsAndExtensions"]=@([ABReplayFileKind(@"video",@"video/mp4") isEqual:@"media"]&&[ABReplayFileKind(@"book.epub",nil) isEqual:@"document"]&&[ABReplayFileKind(@"music.flac",nil) isEqual:@"download"]);_report[@"rawBinaryURLKeepsTimestamp"]=@([ABReplayRawURL([NSURL URLWithString:@"https://web.archive.org/web/20150628064857/http://example.com/book.pdf"]).absoluteString isEqual:@"https://web.archive.org/web/20150628064857id_/http://example.com/book.pdf"]);[(id)_page previewWebFile:@{@"url":[NSURL URLWithString:@"http://127.0.0.1:8790/sample.mp3"],@"name":@"web-test.mp3",@"kind":@"media"}];}
- (void)openLive:(NSString *)stamp original:(NSString *)original stage:(NSInteger)stage {UIViewController *page=[NSClassFromString(@"ABArchivedPage") new];[page setValue:ABWaybackSnapshotURL(stamp,original) forKey:@"url"];_page=page;[_nav pushViewController:page animated:NO];[self step:stage name:@"live archive page and index"] ;}
- (void)finish {
    if(_done)return;_done=YES;if(_downloadRecord){[[ABDownloads shared] remove:_downloadRecord];_downloadRecord=nil;}if(_page){WKWebView *web=[_page valueForKey:@"web"];_report[@"lastWebURL"]=web.URL.absoluteString?:@"";_report[@"lastWebTitle"]=web.title?:@"";_report[@"lastHTTPStatus"]=[_page valueForKey:@"responseStatus"]?:@0;_report[@"lastPageStatus"]=[[_page valueForKey:@"status"] text]?:@"";}[_timer invalidate];[_probe stopLoading];[[_page valueForKey:@"web"] stopLoading];_window.rootViewController=_savedRoot;ABUseTestWebLibrary(nil);
    [[ABSession shared] stop];[_nav popToRootViewControllerAnimated:NO];_page=nil;_nav=nil;_probe=nil;
    id oldPositions=_before[@"playback.plist"];NSString *positionPath=[ABDocuments() stringByAppendingPathComponent:@"playback.plist"];
    NSMutableDictionary *positionData=oldPositions==[NSNull null]?[NSMutableDictionary dictionary]:[[NSPropertyListSerialization propertyListWithData:oldPositions options:NSPropertyListMutableContainers format:nil error:nil] mutableCopy];
    [[ABPositions shared] setValue:positionData?:[NSMutableDictionary dictionary] forKey:@"positions"];
    if(oldPositions==[NSNull null])[[NSFileManager defaultManager] removeItemAtPath:positionPath error:nil];else [oldPositions writeToFile:positionPath atomically:YES];
    for(NSString *name in _before){id old=_before[name];NSData *data=[NSData dataWithContentsOfFile:[ABDocuments() stringByAppendingPathComponent:name]];_report[[name stringByAppendingString:@"Untouched"]]=@((old==[NSNull null]&&!data)||[data isEqual:old]);}
    _report[@"downloadsUntouched"]=@(_downloads==[ABDownloads shared].records.count&&[_originalDownloads isEqualToArray:[ABDownloads shared].records]);if([_page.presentedViewController isKindOfClass:[ABPlayer class]])[((ABPlayer *)_page.presentedViewController).player pause];_report[@"complete"]=@YES;[self save];[UIApplication sharedApplication].idleTimerDisabled=NO;
}
@end
void ABStartUX090(UIWindow *window){Run=[ABUX090 new];Run.window=window;Run.filesOnly=[[NSFileManager defaultManager] fileExistsAtPath:[TestDir stringByAppendingPathComponent:@"files090"]];[Run begin];}
