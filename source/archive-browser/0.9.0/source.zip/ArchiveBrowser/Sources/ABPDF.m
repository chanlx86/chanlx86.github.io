#import "ABPDF.h"
#import "ABVault.h"
static NSError *PDFError(NSString *text){return [NSError errorWithDomain:@"ArchivePDF" code:1 userInfo:@{NSLocalizedDescriptionKey:text}];}
// A bounded range transaction. Never accept an unbounded 200 response for a large PDF.
@interface ABPDFRange : NSObject <NSURLSessionDataDelegate>
@property(nonatomic,strong) NSMutableData *bytes;
@property(nonatomic,strong) NSHTTPURLResponse *response;
@property(nonatomic,strong) NSError *error;
@property(nonatomic) uint64_t start;
@property(nonatomic) NSUInteger limit;
@property(nonatomic,strong) dispatch_semaphore_t done;
@end
@implementation ABPDFRange
- (void)URLSession:(NSURLSession *)s dataTask:(NSURLSessionDataTask *)t didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completion {
 _response=(id)response;if(_response.statusCode>=400){_error=PDFError([NSString stringWithFormat:_response.statusCode==404?@"存档没有返回这个 PDF（HTTP %ld），网页中的链接不代表文件也已保存。":@"PDF 服务器返回 HTTP %ld，请稍后重试或下载后预览。",(long)_response.statusCode]);completion(NSURLSessionResponseCancel);return;}NSString *range=_response.allHeaderFields[@"Content-Range"]?:_response.allHeaderFields[@"content-range"];unsigned long long a=0,b=0,total=0;
 BOOL valid=_response.statusCode==206&&sscanf(range.UTF8String,"bytes %llu-%llu/%llu",&a,&b,&total)==3&&a==_start&&b>=a&&b-a+1<=_limit&&total>b;
 BOOL small=_response.statusCode==200&&_start==0&&response.expectedContentLength>0&&(uint64_t)response.expectedContentLength<=_limit;
 if(!valid&&!small){_error=PDFError(@"服务器未提供有效的 PDF 分段数据，请下载后预览。");completion(NSURLSessionResponseCancel);}else completion(NSURLSessionResponseAllow);
}
- (void)URLSession:(NSURLSession *)s dataTask:(NSURLSessionDataTask *)t didReceiveData:(NSData *)d {if(_bytes.length+d.length>_limit){_error=PDFError(@"PDF 分段响应过大。");[t cancel];}else [_bytes appendData:d];}
- (void)URLSession:(NSURLSession *)s task:(NSURLSessionTask *)t didCompleteWithError:(NSError *)e {if(!_error)_error=e;dispatch_semaphore_signal(_done);}
@end
@interface ABPDFSource ()
@property(nonatomic,strong) NSURL *url;
@property(nonatomic,strong) NSURL *directory;
@property(nonatomic,strong) NSMutableArray *chunks;
@property(atomic) uint64_t fetchedBytes;
@property(atomic) uint64_t totalBytes;
@property(atomic,strong) NSError *error;
@property(nonatomic,copy) NSString *validator;
@property(nonatomic) uint64_t allowance;
@end
@implementation ABPDFSource
- (instancetype)initWithURL:(NSURL *)url {if((self=[super init])){_url=url;_chunks=[NSMutableArray array];_allowance=8*1024*1024;_directory=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"ABPDF-" stringByAppendingString:[NSUUID UUID].UUIDString]]];[[NSFileManager defaultManager] createDirectoryAtURL:_directory withIntermediateDirectories:YES attributes:@{NSFileProtectionKey:NSFileProtectionComplete} error:nil];}return self;}
- (NSData *)chunk:(uint64_t)index {
 if(_cancelled||_error)return nil;NSURL *path=[_directory URLByAppendingPathComponent:[NSString stringWithFormat:@"%llu",index]];
 if([_chunks containsObject:@(index)]){[_chunks removeObject:@(index)];[_chunks addObject:@(index)];return [NSData dataWithContentsOfURL:path];}
 // Keep at most 16 MB of chunks on disk. A single parsing/render operation may fetch 8 MB.
 if(_fetchedBytes>=_allowance){_error=PDFError(@"此页或 PDF 索引需要超过 8 MB 的新增预览数据，请下载原文件阅读。");return nil;}
 if(_chunks.count>=64){NSNumber *old=_chunks.firstObject;[[NSFileManager defaultManager] removeItemAtURL:[_directory URLByAppendingPathComponent:old.stringValue] error:nil];[_chunks removeObjectAtIndex:0];}
 ABPDFRange *range=[ABPDFRange new];range.start=index*262144;range.limit=262144;range.bytes=[NSMutableData data];range.done=dispatch_semaphore_create(0);
 NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:_url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:25];[request setValue:[NSString stringWithFormat:@"bytes=%llu-%llu",range.start,range.start+range.limit-1] forHTTPHeaderField:@"Range"];[request setValue:@"identity" forHTTPHeaderField:@"Accept-Encoding"];if(_validator)[request setValue:_validator forHTTPHeaderField:@"If-Range"];
 NSURLSessionConfiguration *config=[NSURLSessionConfiguration ephemeralSessionConfiguration];config.timeoutIntervalForResource=45;NSOperationQueue *queue=[NSOperationQueue new];queue.maxConcurrentOperationCount=1;
 NSURLSession *session=[NSURLSession sessionWithConfiguration:config delegate:range delegateQueue:queue];NSURLSessionDataTask *task=[session dataTaskWithRequest:request];[task resume];
 // Only a dedicated PDF worker waits; cancellation is checked while a range is in flight.
 while(dispatch_semaphore_wait(range.done,dispatch_time(DISPATCH_TIME_NOW,100*NSEC_PER_MSEC))){if(_cancelled){[task cancel];break;}}
 [session invalidateAndCancel];if(_cancelled)return nil;if(range.error){NSMutableDictionary *info=[range.error.userInfo mutableCopy];info[@"receivedBytes"]=@(range.bytes.length);info[@"HTTPStatus"]=@(range.response.statusCode);_error=[NSError errorWithDomain:range.error.domain code:range.error.code userInfo:info];return nil;}
 NSString *cr=range.response.allHeaderFields[@"Content-Range"]?:range.response.allHeaderFields[@"content-range"];unsigned long long a=0,b=0,total=0;BOOL partial=sscanf(cr.UTF8String,"bytes %llu-%llu/%llu",&a,&b,&total)==3;
 if(partial&&range.bytes.length!=b-a+1){_error=PDFError(@"PDF 分段数据不完整。");return nil;}
 if(!_totalBytes){_totalBytes=partial?total:range.bytes.length;_validator=range.response.allHeaderFields[@"ETag"]?:range.response.allHeaderFields[@"Last-Modified"];}else if(!partial||total!=_totalBytes){_error=PDFError(@"远程 PDF 在阅读时发生变化，请重新打开。");return nil;}
 _fetchedBytes+=range.bytes.length;NSError *write=nil;if(![range.bytes writeToURL:path options:NSDataWritingAtomic error:&write]){_error=write;return nil;}[_chunks addObject:@(index)];return range.bytes;
}
- (size_t)read:(void *)buffer position:(off_t)position count:(size_t)count {
 if(position<0||_cancelled||_error||(uint64_t)position>=_totalBytes)return 0;size_t copied=0;count=(size_t)MIN((uint64_t)count,_totalBytes-(uint64_t)position);
 while(copied<count){uint64_t at=(uint64_t)position+copied;NSData *d=[self chunk:at/262144];NSUInteger offset=(NSUInteger)(at%262144);if(!d||offset>=d.length)break;size_t n=MIN(count-copied,d.length-offset);memcpy((uint8_t *)buffer+copied,(const uint8_t *)d.bytes+offset,n);copied+=n;}return copied;
}
static size_t PDFRead(void *info,void *buffer,off_t position,size_t count){@autoreleasepool{return [(__bridge ABPDFSource *)info read:buffer position:position count:count];}}
static void PDFFree(void *info){CFBridgingRelease(info);}
- (void)beginPage {_allowance=_fetchedBytes+8*1024*1024;}
- (CGPDFDocumentRef)createDocument {
 if(_url.isFileURL){_totalBytes=[[[NSFileManager defaultManager] attributesOfItemAtPath:_url.path error:nil][NSFileSize] unsignedLongLongValue];return CGPDFDocumentCreateWithURL((__bridge CFURLRef)_url);}
 if(![self chunk:0]||!_totalBytes||_totalBytes>INT64_MAX)return NULL;
 CGDataProviderDirectCallbacks callbacks={0,NULL,NULL,PDFRead,PDFFree};CGDataProviderRef provider=CGDataProviderCreateDirect((__bridge_retained void *)self,(off_t)_totalBytes,&callbacks);if(!provider)return NULL;CGPDFDocumentRef document=CGPDFDocumentCreateWithProvider(provider);CGDataProviderRelease(provider);return document;
}
- (void)dealloc {[[NSFileManager defaultManager] removeItemAtURL:_directory error:nil];}
@end
@interface ABPDFCell : UITableViewCell
@property(nonatomic,strong) UIImageView *page;
@property(nonatomic,strong) UILabel *message;
@property(nonatomic) NSInteger index;
@end
@implementation ABPDFCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse {if((self=[super initWithStyle:style reuseIdentifier:reuse])){self.selectionStyle=UITableViewCellSelectionStyleNone;self.backgroundColor=[UIColor colorWithWhite:0.88 alpha:1];_page=[UIImageView new];_page.contentMode=UIViewContentModeScaleAspectFit;[self.contentView addSubview:_page];_message=[UILabel new];_message.numberOfLines=3;_message.textAlignment=NSTextAlignmentCenter;_message.font=[UIFont systemFontOfSize:14];[self.contentView addSubview:_message];}return self;}
- (void)layoutSubviews {[super layoutSubviews];_page.frame=CGRectInset(self.contentView.bounds,8,8);_message.frame=CGRectInset(self.contentView.bounds,20,20);}
@end
@interface ABPDFController () {
 CGPDFDocumentRef _document;
}
@property(nonatomic,strong) ABPDFSource *source;
@property(nonatomic,strong) NSOperationQueue *worker;
@property(nonatomic,strong) NSCache *images;
@property(nonatomic,strong) NSMutableSet *pending;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic) NSUInteger pages;
@property(nonatomic) CGFloat ratio;
@property(nonatomic) BOOL privateMode;
@end
@implementation ABPDFController
- (instancetype)initWithURL:(NSURL *)url privateMode:(BOOL)privateMode {if((self=[super initWithStyle:UITableViewStylePlain])){_source=[[ABPDFSource alloc] initWithURL:url];_privateMode=privateMode;_worker=[NSOperationQueue new];_worker.maxConcurrentOperationCount=1;_images=[NSCache new];_images.totalCostLimit=8*1024*1024;_images.countLimit=3;_pending=[NSMutableSet set];_ratio=1.414;}return self;}
- (void)viewDidLoad {[super viewDidLoad];self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;_status=[[UILabel alloc] initWithFrame:CGRectMake(0,0,320,54)];_status.numberOfLines=3;_status.textAlignment=NSTextAlignmentCenter;_status.font=[UIFont systemFontOfSize:13];_status.text=@"正在读取 PDF 索引与首页…";self.tableView.tableHeaderView=_status;[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(locked) name:ABVaultChanged object:nil];[self open];}
- (void)open {ABPDFSource *source=_source;__weak ABPDFController *weak=self;[_worker addOperationWithBlock:^{CGPDFDocumentRef doc=[source createDocument];NSUInteger pages=doc?CGPDFDocumentGetNumberOfPages(doc):0;BOOL encrypted=doc&&CGPDFDocumentIsEncrypted(doc)&&!CGPDFDocumentIsUnlocked(doc);CGFloat ratio=1.414;if(pages&&!encrypted){CGRect box=CGPDFPageGetBoxRect(CGPDFDocumentGetPage(doc,1),kCGPDFCropBox);if(box.size.width>0){ratio=box.size.height/box.size.width;if(CGPDFPageGetRotationAngle(CGPDFDocumentGetPage(doc,1))%180&&ratio>0)ratio=1/ratio;}}if(!isfinite(ratio)||ratio<=0)ratio=1.414;dispatch_async(dispatch_get_main_queue(),^{ABPDFController *s=weak;if(!s||source.cancelled){if(doc)CGPDFDocumentRelease(doc);return;}s->_document=doc;s.pages=MIN(pages,(NSUInteger)10000);s.ratio=MAX(0.3,MIN(4,ratio));s.status.text=source.error.localizedDescription?:encrypted?@"此 PDF 需要密码，请下载后在其他阅读器打开。":pages?[NSString stringWithFormat:@"%lu 页 · 按需读取 · 已读取 %@ / %@",(unsigned long)pages,ABSize(source.fetchedBytes),ABSize(source.totalBytes)]:@"无法解析 PDF，请下载后阅读。";if(encrypted)s.pages=0;[s.tableView reloadData];});}];}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)section{return _pages;}
- (CGFloat)tableView:(UITableView *)t heightForRowAtIndexPath:(NSIndexPath *)p{return (t.bounds.size.width-16)*_ratio+16;}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p {ABPDFCell *cell=(id)[t dequeueReusableCellWithIdentifier:@"pdf"]?:[[ABPDFCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"pdf"];cell.index=p.row;cell.page.image=[_images objectForKey:@(p.row)];cell.message.text=cell.page.image?nil:[NSString stringWithFormat:@"第 %ld 页 · 正在载入…",(long)p.row+1];return cell;}
- (void)tableView:(UITableView *)t willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)p {[self render:p.row];}
- (void)render:(NSInteger)index {if([_images objectForKey:@(index)]||[_pending containsObject:@(index)]||!_document)return;[_pending addObject:@(index)];ABPDFSource *source=_source;CGPDFDocumentRef doc=CGPDFDocumentRetain(_document);CGFloat width=MIN(768,MAX(320,self.view.bounds.size.width-16));__weak ABPDFController *weak=self;
 [_worker addOperationWithBlock:^{@autoreleasepool{UIImage *image=nil;[source beginPage];if(!source.cancelled){CGPDFPageRef page=CGPDFDocumentGetPage(doc,index+1);CGRect box=page?CGPDFPageGetBoxRect(page,kCGPDFCropBox):CGRectZero;CGFloat ratio=box.size.width>0?box.size.height/box.size.width:0;NSInteger rotation=page?CGPDFPageGetRotationAngle(page):0;if(rotation%180&&ratio>0)ratio=1/ratio;if(ratio>0&&isfinite(ratio)){CGSize size=CGSizeMake(width,MIN(2048,width*ratio));UIGraphicsBeginImageContextWithOptions(size,YES,1);CGContextRef context=UIGraphicsGetCurrentContext();[[UIColor whiteColor] setFill];UIRectFill((CGRect){CGPointZero,size});CGContextTranslateCTM(context,0,size.height);CGContextScaleCTM(context,1,-1);CGContextConcatCTM(context,CGPDFPageGetDrawingTransform(page,kCGPDFCropBox,(CGRect){CGPointZero,size},0,YES));CGContextDrawPDFPage(context,page);if(!source.error)image=UIGraphicsGetImageFromCurrentImageContext();UIGraphicsEndImageContext();}}CGPDFDocumentRelease(doc);
 dispatch_async(dispatch_get_main_queue(),^{ABPDFController *s=weak;if(!s||source.cancelled)return;[s.pending removeObject:@(index)];if(image)[s.images setObject:image forKey:@(index) cost:CGImageGetBytesPerRow(image.CGImage)*CGImageGetHeight(image.CGImage)];s.status.text=source.error.localizedDescription?:[NSString stringWithFormat:@"%lu 页 · 按需读取 · 已读取 %@ / %@",(unsigned long)s.pages,ABSize(source.fetchedBytes),ABSize(source.totalBytes)];ABPDFCell *cell=(id)[s.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];if(cell&&cell.index==index){cell.page.image=image;cell.message.text=image?nil:source.error.localizedDescription?:@"此页无法显示，请下载原文件。";}});
 }}];}
- (void)locked {if(_privateMode&&!ABPrivateActive()){_source.cancelled=YES;[_images removeAllObjects];_pages=0;[self.tableView reloadData];}}
- (void)didReceiveMemoryWarning {[super didReceiveMemoryWarning];[_images removeAllObjects];}
- (void)dealloc {[[NSNotificationCenter defaultCenter] removeObserver:self];_source.cancelled=YES;[_worker cancelAllOperations];if(_document)CGPDFDocumentRelease(_document);}
@end
