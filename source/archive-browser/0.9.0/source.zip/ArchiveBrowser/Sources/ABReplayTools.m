#import "ABReplayTools.h"
#import "ABWebLibrary.h"
#import "ABWayback.h"
#import <math.h>

NSURL *ABReplayIndexURL(NSString *original) {
    if(![@[@"http",@"https"] containsObject:[NSURL URLWithString:original].scheme.lowercaseString]||!ABWebAddress(original))return nil;
    return [NSURL URLWithString:[NSString stringWithFormat:@"https://web.archive.org/cdx/search/cdx?url=%@&matchType=exact&output=json&fl=timestamp,original&filter=statuscode:200&collapse=timestamp:6&limit=512",ABEncode(original)]];
}

NSArray *ABReplayCaptures(id json, NSDictionary *current) {
    NSMutableDictionary *byDate=[NSMutableDictionary dictionary];
    if([json isKindOfClass:[NSArray class]]) {
        for(id row in json) {
            if(![row isKindOfClass:[NSArray class]]||[row count]<2)continue;
            NSDictionary *entry=ABWebRecord(@{@"timestamp":ABString(row[0]),@"original":ABString(row[1])});
            if(entry&&byDate.count<512)byDate[entry[@"timestamp"]]=entry;
        }
    }
    NSDictionary *entry=ABWebRecord(current);
    if(entry)byDate[entry[@"timestamp"]]=entry;
    NSArray *keys=[[byDate allKeys] sortedArrayUsingSelector:@selector(compare:)];
    NSMutableArray *rows=[NSMutableArray array];
    for(NSString *key in keys)[rows addObject:byDate[key]];
    return rows;
}

NSURL *ABReplayResourceURL(NSString *address, NSDictionary *page) {
    NSDictionary *record=ABWebRecord(page);if(!record||!address.length||address.length>8192)return nil;
    NSURL *base=[NSURL URLWithString:record[@"original"]];
    NSURL *url=[[NSURL URLWithString:address relativeToURL:base] absoluteURL];
    if(![@[@"http",@"https"] containsObject:url.scheme.lowercaseString]||!ABWebAddress(url.absoluteString))return nil;
    if([url.host.lowercaseString isEqual:@"web.archive.org"]){
        NSDictionary *archived=ABWebRecordFromURL(url,nil);
        return archived?ABWaybackSnapshotURL(archived[@"timestamp"],archived[@"original"]):nil;
    }
    return ABWaybackSnapshotURL(record[@"timestamp"],url.absoluteString);
}

NSString *ABReplayMediaScript(void) {
    // ES5 only: this executes in the iOS 9 WebKit process. No plugin spoofing.
    return @"(function(){var out=[],seen={},flash=0,frames=0;"
    "function add(raw,kind){if(!raw||typeof raw!=='string'||raw.length>8192||out.length>=40)return;"
    "raw=raw.replace(/&amp;/g,'&');if(/^(javascript|data|blob|file):/i.test(raw))return;"
    "var a=document.createElement('a');a.href=raw;var url=a.href;if(kind==='frame'&&/^https?:\\/\\/archive\\.org\\/(includes\\/donate\\.php|donate)/i.test(url))return;"
    "if(!/^https?:/i.test(url)||seen[url])return;seen[url]=1;out.push({url:url,kind:kind});}"
    "function media(raw){if(!raw)return;var v=raw;try{v=decodeURIComponent(raw);}catch(e){}"
    "if(/\\.(mp4|m4v|mov|m3u8|mp3)([?#]|$)/i.test(v))add(v,'media');"
    "else if(/\\.(pdf|epub|txt|png|jpe?g|gif)([?#]|$)/i.test(v))add(v,'document');"
    "else if(/\\.(zip|7z|rar|flac|m4a|avi|wmv|mpg|mpeg)([?#]|$)/i.test(v))add(v,'download');}"
    "var nodes=document.querySelectorAll('object,embed,video,source,a[href],iframe');"
    "for(var i=0;i<Math.min(nodes.length,800);i++){var n=nodes[i],tag=n.tagName.toLowerCase();"
    "var src=n.getAttribute('data')||n.getAttribute('src')||n.getAttribute('href')||'',type=n.getAttribute('type')||'';"
    "if(tag==='object'||tag==='embed'){var p=n.querySelectorAll('param');"
    "for(var j=0;j<p.length;j++){var k=(p[j].getAttribute('name')||'').toLowerCase(),v=p[j].getAttribute('value')||'';"
    "if(k==='movie'&&!src)src=v;"
    "if(k==='flashvars'){var vars=v.split('&');for(var z=0;z<Math.min(vars.length,80);z++){var pair=vars[z].split('=');media(pair.slice(1).join('='));}}}"
    "if(/shockwave-flash/i.test(type)||/\\.swf([?#]|$)/i.test(src)){flash++;add(src,'flash');}"
    "var vars=(n.getAttribute('flashvars')||'').split('&');for(var z=0;z<Math.min(vars.length,80);z++)media(vars[z].split('=').slice(1).join('='));}"
    "if(tag==='iframe'&&src&&frames<8){frames++;add(src,'frame');}else media(src);}"
    "return {flash:flash,resources:out,wasm:typeof WebAssembly!=='undefined'};})()";
}

NSURL *ABReplayRawURL(NSURL *url) {
    NSDictionary *record=ABWebRecordFromURL(url,nil);
    return record?[NSURL URLWithString:[NSString stringWithFormat:@"https://web.archive.org/web/%@id_/%@",record[@"timestamp"],record[@"original"]]]:url;
}
NSString *ABReplayFileKind(NSString *name,NSString *mime) {
    NSString *ext=name.pathExtension.lowercaseString;mime=[[[ABString(mime) componentsSeparatedByString:@";"] firstObject] lowercaseString];
    if([ext isEqual:@"swf"]||[mime isEqual:@"application/x-shockwave-flash"])return @"flash";
    if([@[@"mp4",@"m4v",@"mov",@"m3u8",@"mp3"] containsObject:ext]||[@[@"video/mp4",@"video/quicktime",@"audio/mpeg",@"application/vnd.apple.mpegurl",@"application/x-mpegurl"] containsObject:mime])return @"media";
    if([@[@"pdf",@"epub",@"txt",@"png",@"jpg",@"jpeg",@"gif"] containsObject:ext]||[@[@"application/pdf",@"application/epub+zip",@"text/plain",@"image/png",@"image/jpeg",@"image/gif"] containsObject:mime])return @"document";
    if([@[@"zip",@"rar",@"7z",@"flac",@"m4a",@"alac",@"aac",@"wav",@"avi",@"wmv",@"mpg",@"mpeg",@"vob",@"ts"] containsObject:ext])return @"download";
    return nil;
}
NSString *ABReplayFileName(NSURL *url,NSString *suggested,NSString *mime) {
    mime=ABString(mime);
    NSString *name=suggested.lastPathComponent;if(!name.length)name=url.lastPathComponent;if(!name.length)name=@"file";
    if(name.length>180)name=[name substringFromIndex:name.length-180];
    NSDictionary *suffixes=@{@"application/pdf":@"pdf",@"application/epub+zip":@"epub",@"audio/mpeg":@"mp3",@"video/mp4":@"mp4",@"video/quicktime":@"mov",@"application/vnd.apple.mpegurl":@"m3u8",@"application/x-mpegurl":@"m3u8",@"image/jpeg":@"jpg",@"image/png":@"png",@"image/gif":@"gif",@"text/plain":@"txt",@"application/x-shockwave-flash":@"swf"};
    NSString *ext=suffixes[mime.lowercaseString];
    if(ext.length&&![name.pathExtension.lowercaseString isEqual:ext])name=[name stringByAppendingPathExtension:ext];
    return name;
}

@interface ABTimeControl ()
@property(nonatomic,strong) UIButton *heading;
@property(nonatomic,strong) UILabel *dateLabel;
@property(nonatomic,strong) UILabel *detail;
@property(nonatomic,strong) UISlider *slider;
@property(nonatomic,strong) UIButton *older;
@property(nonatomic,strong) UIButton *newer;
@property(nonatomic,strong) UIButton *retry;
@property(nonatomic,strong) NSArray *captures;
@property(nonatomic,strong) NSURLSessionDataTask *task;
@property(nonatomic,strong) NSMutableDictionary *indexCache;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSInteger currentIndex;
@property(nonatomic) NSInteger previewIndex;
@property(nonatomic) BOOL navigating;
@property(nonatomic) BOOL dragging;
@property(nonatomic) CGPoint relativePosition;
@property(nonatomic,copy) NSString *indexMessage;
@end

@implementation ABTimeControl
- (instancetype)initWithFrame:(CGRect)frame {
    if((self=[super initWithFrame:frame])) {
        self.backgroundColor=[UIColor colorWithWhite:0.12 alpha:0.87];self.layer.cornerRadius=14;
        self.layer.shadowColor=[UIColor blackColor].CGColor;self.layer.shadowOpacity=0.18;self.layer.shadowRadius=4;self.layer.shadowOffset=CGSizeMake(0,2);
        _indexCache=[NSMutableDictionary dictionary];_captures=@[];_relativePosition=CGPointMake(1,1);
        _heading=[UIButton buttonWithType:UIButtonTypeSystem];_heading.tintColor=[UIColor whiteColor];_heading.titleLabel.font=[UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
        [_heading addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];
        UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(move:)];[_heading addGestureRecognizer:pan];[self addSubview:_heading];
        _dateLabel=[UILabel new];_dateLabel.textAlignment=NSTextAlignmentCenter;_dateLabel.font=[UIFont systemFontOfSize:16];_dateLabel.textColor=[UIColor whiteColor];[self addSubview:_dateLabel];
        _detail=[UILabel new];_detail.textAlignment=NSTextAlignmentCenter;_detail.font=[UIFont systemFontOfSize:11];_detail.textColor=[UIColor colorWithWhite:0.88 alpha:1];[self addSubview:_detail];
        _slider=[UISlider new];_slider.minimumValue=0;_slider.continuous=YES;_slider.tintColor=[UIColor colorWithRed:0.3 green:0.67 blue:1 alpha:1];_slider.accessibilityLabel=@"历史快照时间轴";
        [_slider addTarget:self action:@selector(preview) forControlEvents:UIControlEventValueChanged];
        [_slider addTarget:self action:@selector(beginScrub) forControlEvents:UIControlEventTouchDown];
        [_slider addTarget:self action:@selector(commit) forControlEvents:UIControlEventTouchUpInside|UIControlEventTouchUpOutside];
        [_slider addTarget:self action:@selector(cancelScrub) forControlEvents:UIControlEventTouchCancel];[self addSubview:_slider];
        _older=[UIButton buttonWithType:UIButtonTypeSystem];[_older setTitle:@"‹" forState:UIControlStateNormal];_older.accessibilityLabel=@"上一个快照";[_older addTarget:self action:@selector(previous) forControlEvents:UIControlEventTouchUpInside];
        _newer=[UIButton buttonWithType:UIButtonTypeSystem];[_newer setTitle:@"›" forState:UIControlStateNormal];_newer.accessibilityLabel=@"下一个快照";[_newer addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
        for(UIButton *b in @[_older,_newer]){b.titleLabel.font=[UIFont systemFontOfSize:30];b.tintColor=[UIColor whiteColor];[self addSubview:b];}
        _retry=[UIButton buttonWithType:UIButtonTypeSystem];[_retry setTitle:@"重试索引" forState:UIControlStateNormal];_retry.titleLabel.font=[UIFont systemFontOfSize:12];[_retry addTarget:self action:@selector(refreshIndex) forControlEvents:UIControlEventTouchUpInside];[self addSubview:_retry];self.hidden=YES;
    }return self;
}
- (void)setRecord:(NSDictionary *)record {
    NSDictionary *entry=ABWebRecord(record);BOOL same=[_record[@"original"] isEqual:entry[@"original"]];
    _record=entry;self.hidden=entry==nil;if(!entry){[_task cancel];_task=nil;_generation++;return;}
    _navigating=NO;_dragging=NO;
    if(same){_captures=ABReplayCaptures([self rawRows],entry);[self synchronize];return;}
    [_task cancel];_task=nil;_generation++;_captures=ABReplayCaptures(nil,entry);_indexMessage=@"正在读取可用日期…";
    [self synchronize];NSDictionary *cache=_indexCache[entry[@"original"]];
    if(cache&&-[cache[@"date"] timeIntervalSinceNow]<300){_captures=ABReplayCaptures(cache[@"rows"],entry);_indexMessage=nil;[self synchronize];}
    else [self refreshIndex];
}
- (NSArray *)rawRows {NSMutableArray *rows=[NSMutableArray array];for(NSDictionary *r in _captures)[rows addObject:@[r[@"timestamp"],r[@"original"]]];return rows;}
- (void)synchronize {
    _currentIndex=0;for(NSUInteger i=0;i<_captures.count;i++)if([_captures[i][@"timestamp"] isEqual:_record[@"timestamp"]]){_currentIndex=i;break;}
    _previewIndex=_currentIndex;_slider.maximumValue=MAX(1,(NSInteger)_captures.count-1);_slider.value=_currentIndex;[self updateLabels];
}
- (void)refreshIndex {
    if(!_record)return;[_task cancel];NSUInteger generation=++_generation;NSString *original=_record[@"original"];
    _indexMessage=@"正在读取可用日期…";_retry.hidden=YES;[self updateLabels];__weak ABTimeControl *weak=self;
    _task=[[ABHTTP shared] get:ABReplayIndexURL(original) limit:512*1024 completion:^(NSData *data,NSError *error){
        ABTimeControl *s=weak;if(!s||generation!=s.generation||![s.record[@"original"] isEqual:original])return;s.task=nil;
        id json=data?[NSJSONSerialization JSONObjectWithData:data options:0 error:nil]:nil;
        BOOL valid=[json isKindOfClass:[NSArray class]];
        if(!error&&valid){
            if(s.indexCache.count>=4)[s.indexCache removeAllObjects];
            s.indexCache[original]=@{@"date":[NSDate date],@"rows":json};s.captures=ABReplayCaptures(json,s.record);s.indexMessage=nil;s.retry.hidden=YES;
        }else{s.indexMessage=@"日期索引暂不可用";s.retry.hidden=NO;}
        s.dragging=NO;[s synchronize];
    }];
}
- (void)updateLabels {
    if(!_record)return;NSInteger index=MIN(MAX(0,_previewIndex),(NSInteger)_captures.count-1);NSDictionary *entry=_captures.count?_captures[index]:_record;
    NSString *ts=entry[@"timestamp"],*date=ABWebDate(entry);
    [_heading setTitle:_expanded?@"◷ 时光机 · 收起":[NSString stringWithFormat:@"◷ %@-%@",[ts substringToIndex:4],[ts substringWithRange:NSMakeRange(4,2)]] forState:UIControlStateNormal];
    _heading.accessibilityLabel=_expanded?@"收起时间轴，可拖动浮标":@"展开时间轴，可拖动浮标";
    _dateLabel.text=[NSString stringWithFormat:@"%@  %@:%@",date,[ts substringWithRange:NSMakeRange(8,2)],[ts substringWithRange:NSMakeRange(10,2)]];
    _detail.text=_indexMessage?:(_navigating?@"正在切换快照…":_captures.count<2?@"未找到其他月份的快照":_dragging?@"松手查看这个日期":[NSString stringWithFormat:@"%ld / %lu · 每月一项 · UTC",(long)index+1,(unsigned long)_captures.count]);
    _slider.enabled=!_navigating&&_captures.count>1;_slider.accessibilityValue=_dateLabel.text;
    _older.enabled=!_navigating&&index>0;_newer.enabled=!_navigating&&index<(NSInteger)_captures.count-1;
    for(UIView *v in @[_dateLabel,_detail,_slider,_older,_newer])v.hidden=!_expanded;
    _retry.hidden=!_expanded||![_indexMessage isEqual:@"日期索引暂不可用"];
    _detail.hidden=_retry.hidden?!_expanded:YES;
    [self setNeedsLayout];
}
- (void)setNavigating:(BOOL)navigating {_navigating=navigating;[self updateLabels];}
- (void)beginScrub {_dragging=YES;}
- (void)preview {if(!_captures.count||_navigating)return;_dragging=YES;_previewIndex=MIN(MAX(0,(NSInteger)lroundf(_slider.value)),(NSInteger)_captures.count-1);[self updateLabels];}
- (void)commit {if(!_captures.count||_navigating)return;[self preview];_slider.value=_previewIndex;_dragging=NO;NSDictionary *entry=_captures[_previewIndex];[self updateLabels];if([entry[@"timestamp"] isEqual:_record[@"timestamp"]])return;[self setNavigating:YES];if(_selected)_selected(entry);}
- (void)cancelScrub {_dragging=NO;_previewIndex=_currentIndex;_slider.value=_currentIndex;[self updateLabels];}
- (void)previous {_slider.value=MAX(0,_previewIndex-1);[self commit];}
- (void)next {_slider.value=MIN((NSInteger)_captures.count-1,_previewIndex+1);[self commit];}
- (void)toggle {self.expanded=!_expanded;}
- (void)setExpanded:(BOOL)expanded {_expanded=expanded;[self updateLabels];[self positionInSuperview];}
- (void)positionInSuperview {
    if(!self.superview)return;CGRect area=CGRectInset(self.superview.bounds,12,12);area.origin.y+=32;area.size.height=MAX(44,area.size.height-32);
    CGSize size=CGSizeMake(MIN(_expanded?316:110,area.size.width),MIN(_expanded?144:44,area.size.height));
    CGFloat dx=MAX(0,area.size.width-size.width),dy=MAX(0,area.size.height-size.height);
    self.frame=CGRectMake(area.origin.x+dx*_relativePosition.x,area.origin.y+dy*_relativePosition.y,size.width,size.height);[self setNeedsLayout];
}
- (void)move:(UIPanGestureRecognizer *)pan {
    CGPoint change=[pan translationInView:self.superview];CGRect bounds=self.superview.bounds;
    CGRect f=self.frame;f.origin.x=MAX(12,MIN(bounds.size.width-12-f.size.width,f.origin.x+change.x));f.origin.y=MAX(44,MIN(bounds.size.height-12-f.size.height,f.origin.y+change.y));self.frame=f;
    _relativePosition=CGPointMake((f.origin.x-12)/MAX(1,bounds.size.width-24-f.size.width),(f.origin.y-44)/MAX(1,bounds.size.height-56-f.size.height));
    [pan setTranslation:CGPointZero inView:self.superview];
}
- (void)layoutSubviews {
    [super layoutSubviews];CGFloat w=self.bounds.size.width;
    _heading.frame=CGRectMake(0,0,w,44);_dateLabel.frame=CGRectMake(8,42,w-16,24);
    _older.frame=CGRectMake(0,64,44,44);_newer.frame=CGRectMake(w-44,64,44,44);_slider.frame=CGRectMake(44,67,w-88,40);
    _detail.frame=CGRectMake(8,112,w-16,24);_retry.frame=_detail.frame;
}
- (void)dealloc {[_task cancel];}
@end
