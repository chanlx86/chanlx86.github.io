#import "ABCore.h"

NSArray *ABReplayCaptures(id json, NSDictionary *current);
NSURL *ABReplayIndexURL(NSString *original);
NSURL *ABReplayResourceURL(NSString *address, NSDictionary *page);
NSString *ABReplayMediaScript(void);
NSString *ABReplayFileKind(NSString *name, NSString *mime);
NSString *ABReplayFileName(NSURL *url, NSString *suggested, NSString *mime);
NSURL *ABReplayRawURL(NSURL *url);

// Native controls live outside the webpage and cannot be hidden by a Flash splash screen.
@interface ABTimeControl : UIView
@property(nonatomic,copy) void (^selected)(NSDictionary *record);
@property(nonatomic,copy) NSDictionary *record;
@property(nonatomic,readonly) NSArray *captures;
@property(nonatomic,getter=isExpanded) BOOL expanded;
- (void)positionInSuperview;
- (void)setNavigating:(BOOL)navigating;
- (void)refreshIndex;
@end
