#import "ABWayback.h"
#import "ABSession.h"
#import "ABWebLibrary.h"
#import "ABVisual.h"
#import "ABReplayTools.h"
#import "ABExtras.h"
#import "ABMedia.h"
#import <WebKit/WebKit.h>
#import <AVFoundation/AVFoundation.h>
NSURL *ABWebAddress(NSString *input){NSString *s=[input stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];if(!s.length)return nil;if([s rangeOfString:@"://"].location==NSNotFound)s=[@"https://" stringByAppendingString:s];NSURL *url=[NSURL URLWithString:s];if(![@[@"http",@"https"] containsObject:url.scheme.lowercaseString]||!url.host.length||url.user.length||url.password.length)return nil;return url;}
NSURL *ABWaybackSnapshotURL(NSString *timestamp,NSString *original){if(timestamp.length!=14||[timestamp rangeOfCharacterFromSet:[[NSCharacterSet decimalDigitCharacterSet] invertedSet]].location!=NSNotFound||![@[@"http",@"https"] containsObject:[NSURL URLWithString:original].scheme.lowercaseString]||!ABWebAddress(original))return nil;return [NSURL URLWithString:[NSString stringWithFormat:@"https://web.archive.org/web/%@/%@",timestamp,original]];}
@class ABArchivedPage;
@interface ABReplayReadyProxy : NSObject <WKScriptMessageHandler>
@property(nonatomic,weak) ABArchivedPage *owner;
@end
@interface ABArchivedPage : UIViewController <WKNavigationDelegate>
@property(nonatomic,strong) NSURL *url;
@property(nonatomic,strong) WKWebView *web;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic) NSInteger responseStatus;
@property(nonatomic,strong) UIBarButtonItem *favoriteButton;
@property(nonatomic) NSUInteger previewGeneration;
@property(nonatomic) BOOL documentReady;
@property(nonatomic,strong) ABTimeControl *timeControl;
@property(nonatomic,strong) UIBarButtonItem *mediaButton;
@property(nonatomic,strong) NSArray *archivedMedia;
@property(nonatomic,strong) NSDictionary *lastWebFile;
@property(nonatomic,strong) NSURLSessionDataTask *flashTask;
@end
@interface ABArchivedPage (Ready)
- (void)completeDocument;
@end
@implementation ABReplayReadyProxy
- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {ABArchivedPage *page=_owner;if(page&&message.frameInfo.isMainFrame&&[ABString(message.body) isEqual:page.web.URL.absoluteString])[page completeDocument];}
@end
@implementation ABArchivedPage
- (void)viewDidLoad {[super viewDidLoad];self.title=@"网页快照";self.edgesForExtendedLayout=UIRectEdgeNone;WKWebViewConfiguration *c=[WKWebViewConfiguration new];c.websiteDataStore=[WKWebsiteDataStore nonPersistentDataStore];ABReplayReadyProxy *ready=[ABReplayReadyProxy new];ready.owner=self;[c.userContentController addScriptMessageHandler:ready name:@"abReplayReady"];[c.userContentController addUserScript:[[WKUserScript alloc] initWithSource:@"(function(){function ready(){window.webkit.messageHandlers.abReplayReady.postMessage(location.href);}window.addEventListener('pageshow',ready,false);ready();})()" injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES]];_web=[[WKWebView alloc] initWithFrame:self.view.bounds configuration:c];_web.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;_web.navigationDelegate=self;[self.view addSubview:_web];_status=[[UILabel alloc] initWithFrame:CGRectMake(8,0,self.view.bounds.size.width-16,32)];_status.autoresizingMask=UIViewAutoresizingFlexibleWidth;_status.font=[UIFont systemFontOfSize:12];_status.backgroundColor=[UIColor colorWithWhite:1 alpha:0.94];_status.numberOfLines=2;_status.text=@"正在载入历史网页…";[self.view addSubview:_status];UIBarButtonItem *safari=[[UIBarButtonItem alloc] initWithTitle:@"Safari" style:UIBarButtonItemStylePlain target:self action:@selector(safari)];_favoriteButton=[[UIBarButtonItem alloc] initWithTitle:@"☆" style:UIBarButtonItemStylePlain target:self action:@selector(toggleFavorite)];_favoriteButton.enabled=NO;self.navigationItem.rightBarButtonItems=@[safari,_favoriteButton];self.toolbarItems=@[[[UIBarButtonItem alloc] initWithTitle:@"后退" style:UIBarButtonItemStylePlain target:self action:@selector(back)],[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],[[UIBarButtonItem alloc] initWithTitle:@"前进" style:UIBarButtonItemStylePlain target:self action:@selector(forward)],[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(reload)]];[self installReplayTools];[self loadSnapshot];}
- (void)viewWillAppear:(BOOL)a{[super viewWillAppear:a];[self.navigationController setToolbarHidden:NO animated:NO];[[ABSession shared] refresh];}
- (void)viewWillDisappear:(BOOL)a{[super viewWillDisappear:a];[self cachePreview];[self.navigationController setToolbarHidden:YES animated:NO];[[ABSession shared] refresh];}
- (NSURL *)normalURL {NSString *address=(_web.URL?:_url).absoluteString;NSRegularExpression *r=[NSRegularExpression regularExpressionWithPattern:@"/web/([0-9]{14})(?:id_|if_)/" options:0 error:nil];return [NSURL URLWithString:[r stringByReplacingMatchesInString:address options:0 range:NSMakeRange(0,address.length) withTemplate:@"/web/$1/"]];}
- (void)loadSnapshot {_status.hidden=NO;_status.text=@"正在载入历史网页…";[_web loadRequest:[NSURLRequest requestWithURL:_url]];}
- (void)back{[_web goBack];}- (void)forward{[_web goForward];}- (void)reload{[_web reload];}- (void)safari{[[UIApplication sharedApplication] openURL:[self normalURL]];}
- (void)webView:(WKWebView *)v decidePolicyForNavigationResponse:(WKNavigationResponse *)response decisionHandler:(void (^)(WKNavigationResponsePolicy))done {NSHTTPURLResponse *http=[response.response isKindOfClass:[NSHTTPURLResponse class]]?(id)response.response:nil;if(response.isForMainFrame)_responseStatus=http.statusCode;
if(response.isForMainFrame&&http.statusCode>=200&&http.statusCode<300){NSString *name=ABReplayFileName(response.response.URL,response.response.suggestedFilename,response.response.MIMEType);NSString *kind=ABReplayFileKind(name,response.response.MIMEType);if(kind){[_timeControl setNavigating:NO];_status.hidden=YES;done(WKNavigationResponsePolicyCancel);dispatch_async(dispatch_get_main_queue(),^{[self offerWebFile:response.response.URL name:name mime:response.response.MIMEType];});return;}}

if(response.isForMainFrame&&http.statusCode>=400){[_timeControl setNavigating:NO];_status.hidden=NO;_status.text=[NSString stringWithFormat:@"快照服务器返回 HTTP %ld，可点 Safari 重试。",(long)http.statusCode];done(WKNavigationResponsePolicyCancel);}else done(WKNavigationResponsePolicyAllow);}
- (void)webView:(WKWebView *)v didStartProvisionalNavigation:(WKNavigation *)n{_status.hidden=NO;_status.text=@"正在载入历史网页…";self.navigationItem.titleView=nil;_favoriteButton.enabled=NO;_previewGeneration++;_documentReady=NO;[_timeControl setNavigating:YES];_archivedMedia=@[];_mediaButton.enabled=NO;_mediaButton.title=@"文件";NSUInteger generation=_previewGeneration;__weak ABArchivedPage *weak=self;dispatch_after(dispatch_time(DISPATCH_TIME_NOW,600*NSEC_PER_MSEC),dispatch_get_main_queue(),^{if(weak.previewGeneration==generation)[weak checkReadyDocument];});}
- (void)updateReplayTitle {NSString *address=_web.URL.absoluteString?:@"";NSRegularExpression *r=[NSRegularExpression regularExpressionWithPattern:@"/web/([0-9]{14})(?:[a-z]+_)?/(https?://.+)" options:0 error:nil];NSTextCheckingResult *m=[r firstMatchInString:address options:0 range:NSMakeRange(0,address.length)];if(!m)return;NSString *ts=[address substringWithRange:[m rangeAtIndex:1]];NSURL *original=[NSURL URLWithString:[address substringWithRange:[m rangeAtIndex:2]]];UILabel *label=[[UILabel alloc] initWithFrame:CGRectMake(0,0,200,40)];label.numberOfLines=2;label.textAlignment=NSTextAlignmentCenter;label.font=[UIFont systemFontOfSize:13];label.text=[NSString stringWithFormat:@"%@-%@-%@ · 快照\n%@",[ts substringToIndex:4],[ts substringWithRange:NSMakeRange(4,2)],[ts substringWithRange:NSMakeRange(6,2)],original.host?:@""];self.navigationItem.titleView=label;}
- (void)checkReadyDocument {NSUInteger generation=_previewGeneration;__weak ABArchivedPage *weak=self;[_web evaluateJavaScript:@"({url:location.href,ready:document.readyState,body:!!document.body})" completionHandler:^(id result,NSError *error){ABArchivedPage *page=weak;if(!page||page.documentReady||generation!=page.previewGeneration||error||![result isKindOfClass:[NSDictionary class]])return;if([result[@"url"] isEqual:page.web.URL.absoluteString]&&[result[@"body"] boolValue]&&[@[@"interactive",@"complete"] containsObject:result[@"ready"]])[page completeDocument];}];}
- (void)webView:(WKWebView *)v didCommitNavigation:(WKNavigation *)navigation {_timeControl.record=[self currentEntry];[self updateReplayTitle];[self checkReadyDocument];}
- (void)webView:(WKWebView *)v didFinishNavigation:(WKNavigation *)n{if(_documentReady){[self probeArchivedMedia];[self cachePreview];return;}[self completeDocument];}
- (void)completeDocument {if(_documentReady)return;_documentReady=YES;WKWebView *v=_web;[self updateReplayTitle];_timeControl.record=[self currentEntry];[_timeControl setNavigating:NO];_status.hidden=YES;[self updateFavorite];NSDictionary *entry=[self currentEntry];if(entry&&_responseStatus>=200&&_responseStatus<300)[[ABWebLibrary shared] visit:entry];NSUInteger generation=++_previewGeneration;[self probeArchivedMedia];__weak ABArchivedPage *owner=self;dispatch_after(dispatch_time(DISPATCH_TIME_NOW,1500*NSEC_PER_MSEC),dispatch_get_main_queue(),^{if(owner.previewGeneration==generation)[owner probeArchivedMedia];});dispatch_after(dispatch_time(DISPATCH_TIME_NOW,700*NSEC_PER_MSEC),dispatch_get_main_queue(),^{if(owner.previewGeneration==generation)[owner cachePreview];});__weak ABArchivedPage *weak=self;[v evaluateJavaScript:@"document.body ? (document.body.textContent.trim().length + document.body.querySelectorAll('img,svg,canvas,video,iframe').length) : 0" completionHandler:^(id result,NSError *error){ABArchivedPage *s=weak;if(s&&!error&&[result integerValue]==0){s.status.hidden=NO;s.status.text=@"页面为空，可能缺少存档资源；可点 Safari 重试。";}}];}
- (void)webView:(WKWebView *)v didFailProvisionalNavigation:(WKNavigation *)n withError:(NSError *)e{if(e.code==NSURLErrorCancelled)return;[_timeControl setNavigating:NO];_status.hidden=NO;_status.text=@"历史网页暂时无法载入，可点 Safari 重试。";}
- (void)webView:(WKWebView *)v decidePolicyForNavigationAction:(WKNavigationAction *)a decisionHandler:(void (^)(WKNavigationActionPolicy))done{NSURL *u=a.request.URL;
if((a.targetFrame.isMainFrame||!a.targetFrame)&&[@[@"http",@"https"] containsObject:u.scheme.lowercaseString]&&ABReplayFileKind(u.lastPathComponent,nil)){
 NSURL *file=[u.host.lowercaseString isEqual:@"web.archive.org"]?u:ABReplayResourceURL(u.absoluteString,[self currentEntry]);
 if(file){done(WKNavigationActionPolicyCancel);dispatch_async(dispatch_get_main_queue(),^{[self offerWebFile:file name:ABReplayFileName(file,nil,nil) mime:nil];});return;}
}
if([@[@"http",@"https"] containsObject:u.scheme.lowercaseString]){if([u.host.lowercaseString isEqual:@"web.archive.org"]){if([u.scheme isEqual:@"http"]){NSURLComponents *c=[NSURLComponents componentsWithURL:u resolvingAgainstBaseURL:NO];c.scheme=@"https";[v loadRequest:[NSURLRequest requestWithURL:c.URL]];done(WKNavigationActionPolicyCancel);}else if(!a.targetFrame){[v loadRequest:a.request];done(WKNavigationActionPolicyCancel);}else done(WKNavigationActionPolicyAllow);}else if(a.targetFrame.isMainFrame||!a.targetFrame){done(WKNavigationActionPolicyCancel);UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"离开历史快照？" message:@"这个链接指向现有网站。可查找它在同年代的快照，或交给 Safari。" preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];NSString *stamp=[self currentEntry][@"timestamp"]?:@"";if(stamp.length>=14){stamp=[stamp substringToIndex:14];NSURL *capture=ABWaybackSnapshotURL(stamp,u.absoluteString);if(capture)[alert addAction:[UIAlertAction actionWithTitle:@"查找同年代快照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){self.url=capture;[self loadSnapshot];}]];}[alert addAction:[UIAlertAction actionWithTitle:@"在 Safari 打开现有网站" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[[UIApplication sharedApplication] openURL:u];}]];[self presentViewController:alert animated:YES completion:nil];}else done(WKNavigationActionPolicyAllow);}else done(WKNavigationActionPolicyCancel);}
- (NSDictionary *)currentEntry{return ABWebRecordFromURL(_web.URL,_web.title);}
- (void)updateFavorite{NSDictionary *entry=[self currentEntry];_favoriteButton.enabled=entry!=nil&&_responseStatus>=200&&_responseStatus<300;_favoriteButton.title=[[ABWebLibrary shared] isFavorite:entry]?@"★":@"☆";_favoriteButton.accessibilityLabel=[[ABWebLibrary shared] isFavorite:entry]?@"取消收藏此快照":@"收藏此快照";}
- (void)toggleFavorite{NSDictionary *entry=[self currentEntry];if(!entry)return;ABWebLibrary *library=[ABWebLibrary shared];BOOL ok=[library setFavorite:entry present:![library isFavorite:entry]];if(!ok)ABAlert(self,@"无法保存收藏",library.error?:@"请稍后重试。");[self updateFavorite];[self cachePreview];}
- (void)cachePreview{if(!_status.hidden||_web.loading||!_web.window||_web.bounds.size.width<1||_web.bounds.size.height<1||_responseStatus<200||_responseStatus>=300)return;NSDictionary *entry=[self currentEntry];if(!entry)return;CGSize size=CGSizeMake(256,172);UIGraphicsBeginImageContextWithOptions(size,YES,1);[[UIColor whiteColor] setFill];UIRectFill((CGRect){CGPointZero,size});CGFloat scale=size.width/_web.bounds.size.width;BOOL rendered=[_web drawViewHierarchyInRect:CGRectMake(0,0,size.width,_web.bounds.size.height*scale) afterScreenUpdates:NO];UIImage *image=rendered?UIGraphicsGetImageFromCurrentImageContext():nil;UIGraphicsEndImageContext();if(!image)return;[[ABImages shared] cacheImage:image key:ABWebThumbnailKey(entry) completion:^{[[NSNotificationCenter defaultCenter] postNotificationName:ABWebLibraryChanged object:nil];}];}
- (void)webView:(WKWebView *)web didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {[self webView:web didFailProvisionalNavigation:navigation withError:error];}
- (void)installReplayTools {
    _timeControl=[[ABTimeControl alloc] initWithFrame:CGRectZero];__weak ABArchivedPage *weak=self;
    _timeControl.selected=^(NSDictionary *record){ABArchivedPage *page=weak;if(!page)return;page.url=ABWaybackSnapshotURL(record[@"timestamp"],record[@"original"]);[page loadSnapshot];};
    [self.view addSubview:_timeControl];_timeControl.record=ABWebRecordFromURL(_url,nil);[_timeControl positionInSuperview];
    _mediaButton=[[UIBarButtonItem alloc] initWithTitle:@"文件" style:UIBarButtonItemStylePlain target:self action:@selector(showArchivedMedia)];_mediaButton.enabled=NO;
    NSMutableArray *items=[self.toolbarItems mutableCopy];[items insertObject:_mediaButton atIndex:4];[items insertObject:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil] atIndex:5];self.toolbarItems=items;
}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];[_timeControl positionInSuperview];}
- (void)probeArchivedMedia {
    NSUInteger generation=_previewGeneration;__weak ABArchivedPage *weak=self;
    [_web evaluateJavaScript:ABReplayMediaScript() completionHandler:^(id result,NSError *error){
        ABArchivedPage *page=weak;if(!page||generation!=page.previewGeneration||error||![result isKindOfClass:[NSDictionary class]])return;
        NSDictionary *entry=[page currentEntry];NSMutableArray *resources=[NSMutableArray array];NSMutableSet *seen=[NSMutableSet set];
        id list=result[@"resources"];if([list isKindOfClass:[NSArray class]])for(id raw in list){
            if(![raw isKindOfClass:[NSDictionary class]])continue;NSString *kind=ABString(raw[@"kind"]);
            if(![@[@"flash",@"media",@"frame",@"document",@"download"] containsObject:kind])continue;
            NSURL *url=ABReplayResourceURL(ABString(raw[@"url"]),entry);if(!url||[seen containsObject:url.absoluteString])continue;
            [seen addObject:url.absoluteString];[resources addObject:@{@"url":url,@"kind":kind}];if(resources.count>=40)break;
        }
        page.archivedMedia=resources;page.mediaButton.enabled=resources.count>0;
        page.mediaButton.title=resources.count?[NSString stringWithFormat:@"文件(%lu)",(unsigned long)resources.count]:@"文件";
    }];
}
- (void)showArchivedMedia {
    if(!_archivedMedia.count)return;
    UIAlertController *menu=[UIAlertController alertControllerWithTitle:@"网页文件与框架" message:@"文档可预览，音视频可尝试系统播放，也可下载到本地。Flash 仍需独立运行环境；框架页可进入同年代快照。资源缺档时可能无法载入。" preferredStyle:UIAlertControllerStyleActionSheet];
    // UIAlertController scrolls long action lists; extraction is bounded to 40 resources.
    for(NSDictionary *resource in _archivedMedia){
        NSURL *url=resource[@"url"];NSString *name=url.lastPathComponent;NSString *kind=resource[@"kind"];
        NSString *label=[NSString stringWithFormat:@"%@ · %@",[kind isEqual:@"flash"]?@"Flash":[kind isEqual:@"frame"]?@"框架页":[kind isEqual:@"document"]?@"文档":[kind isEqual:@"download"]?@"下载":@"音视频",name.length?name:url.host];
        if(label.length>90)label=[label substringToIndex:90];
        [menu addAction:[UIAlertAction actionWithTitle:label style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self openArchivedResource:resource];}]];
    }
    [menu addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];ABPresentBarSheet(self,menu,_mediaButton);
}
- (void)openArchivedResource:(NSDictionary *)resource {
    NSURL *url=resource[@"url"];NSString *kind=resource[@"kind"];
    if([kind isEqual:@"frame"]){_url=url;[self loadSnapshot];return;}
    if(![kind isEqual:@"flash"]){[self offerWebFile:url name:ABReplayFileName(url,nil,nil) mime:nil];return;}
    UIAlertController *menu=[UIAlertController alertControllerWithTitle:@"Flash 资源" message:@"iOS 9 无法直接运行 SWF。可保存此文件到本地，再交给兼容的 Flash 播放器；这不会恢复游戏服务器或缺失的素材。" preferredStyle:UIAlertControllerStyleActionSheet];
    [menu addAction:[UIAlertAction actionWithTitle:@"保存 SWF（最多 20 MB）" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self saveFlashResource:ABReplayRawURL(url)];}]];
    [menu addAction:[UIAlertAction actionWithTitle:@"复制存档链接" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[UIPasteboard generalPasteboard].URL=url;}]];
    [menu addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];ABPresentBarSheet(self,menu,_mediaButton);
}
- (void)offerWebFile:(NSURL *)url name:(NSString *)name mime:(NSString *)mime {
    NSString *kind=ABReplayFileKind(name,mime);if(!kind)return;
    url=ABReplayRawURL(url);
    if([kind isEqual:@"flash"]){[self openArchivedResource:@{@"url":url,@"kind":@"flash"}];return;}
    _lastWebFile=@{@"url":url,@"name":name,@"kind":kind};NSDictionary *file=_lastWebFile;
    UIAlertController *menu=[UIAlertController alertControllerWithTitle:name message:@"在应用内查看，或下载到“本地”。资源未存档或系统不支持其编码时可能无法打开。" preferredStyle:UIAlertControllerStyleActionSheet];
    if(![kind isEqual:@"download"])[menu addAction:[UIAlertAction actionWithTitle:[kind isEqual:@"media"]?@"应用内播放":@"应用内预览" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self previewWebFile:file];}]];
    if(![name.pathExtension.lowercaseString isEqual:@"m3u8"])[menu addAction:[UIAlertAction actionWithTitle:@"下载到本地" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){NSDictionary *record=[[ABDownloads shared] addURL:url name:name title:self.web.title?:name];ABAlert(self,record?@"已加入下载":@"无法加入下载",record?@"可在“本地 → 下载”查看进度、打开或分享。":@"文件名或网址无效。");}]];
    [menu addAction:[UIAlertAction actionWithTitle:@"复制文件链接" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[UIPasteboard generalPasteboard].URL=url;}]];
    [menu addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];ABPresentBarSheet(self,menu,_mediaButton);
}
- (void)previewWebFile:(NSDictionary *)file {ABOpenFileFrom(self,file[@"url"],file[@"name"],nil,NO);}

- (void)saveFlashResource:(NSURL *)url {
    if(_flashTask){ABAlert(self,@"正在保存",@"请等待当前 Flash 文件保存完成。");return;}
    __weak ABArchivedPage *weak=self;_mediaButton.enabled=NO;
    _flashTask=[[ABHTTP shared] get:url limit:20*1024*1024 completion:^(NSData *data,NSError *error){
        ABArchivedPage *page=weak;if(!page)return;page.flashTask=nil;page.mediaButton.enabled=page.archivedMedia.count>0;
        BOOL swf=data.length>=8&&(!memcmp(data.bytes,"FWS",3)||!memcmp(data.bytes,"CWS",3)||!memcmp(data.bytes,"ZWS",3));
        if(error||!swf){ABAlert(page,@"保存失败",error.localizedDescription?:@"存档没有返回有效的 SWF 文件，可能未保存该资源。");return;}
        NSString *name=url.lastPathComponent;if(![name.pathExtension.lowercaseString isEqual:@"swf"])name=@"archive.swf";
        NSURL *temp=[NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:[@"ABPreview-" stringByAppendingString:[NSUUID UUID].UUIDString]]];
        BOOL written=[data writeToURL:temp options:NSDataWritingAtomic error:nil];NSDictionary *saved=written?[[ABDownloads shared] importURL:temp identifier:@"wayback-flash" name:name title:@"网页存档 Flash"]:nil;
        [[NSFileManager defaultManager] removeItemAtURL:temp error:nil];ABAlert(page,saved?@"已保存到本地下载":@"保存失败",saved?@"SWF 已保存；本 App 尚不能播放 Flash 动画／游戏。":@"无法写入本地，请检查可用空间。");
    }];
}

- (void)dealloc{[_web stopLoading];[_flashTask cancel];}
@end
static UIImage *ABWebPlaceholder(void){static UIImage *image;static dispatch_once_t once;dispatch_once(&once,^{UIGraphicsBeginImageContextWithOptions(CGSizeMake(124,84),YES,1);[[UIColor colorWithWhite:0.95 alpha:1] setFill];UIRectFill(CGRectMake(0,0,124,84));[ABWebTabIcon() drawInRect:CGRectMake(50,30,24,24) blendMode:kCGBlendModeNormal alpha:0.4];image=UIGraphicsGetImageFromCurrentImageContext();UIGraphicsEndImageContext();});return image;}
@interface ABWebTile : UICollectionViewCell
@property(nonatomic,strong) UIImageView *preview;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *date;
@property(nonatomic,copy) NSString *key;
- (void)show:(NSDictionary *)entry;
@end
@implementation ABWebTile
- (instancetype)initWithFrame:(CGRect)frame{if((self=[super initWithFrame:frame])){_preview=[UIImageView new];_preview.contentMode=UIViewContentModeScaleAspectFill;_preview.clipsToBounds=YES;_preview.layer.cornerRadius=6;_preview.backgroundColor=[UIColor colorWithWhite:0.94 alpha:1];[self.contentView addSubview:_preview];_heading=[UILabel new];_heading.font=[UIFont systemFontOfSize:13];_heading.numberOfLines=2;[self.contentView addSubview:_heading];_date=[UILabel new];_date.font=[UIFont systemFontOfSize:11];_date.textColor=[UIColor grayColor];[self.contentView addSubview:_date];}return self;}
- (void)show:(NSDictionary *)entry{entry=ABWebRecord(entry);_heading.text=entry[@"title"];_date.text=ABWebDate(entry);_key=ABWebThumbnailKey(entry);_preview.image=ABWebPlaceholder();__weak ABWebTile *weak=self;NSString *key=_key;[[ABImages shared] cachedImageForKey:key completion:^(UIImage *image){ABWebTile *cell=weak;if(image&&[cell.key isEqual:key])cell.preview.image=image;}];}
- (void)layoutSubviews{[super layoutSubviews];_preview.frame=CGRectMake(0,0,124,84);_heading.frame=CGRectMake(0,89,124,34);_date.frame=CGRectMake(0,127,124,16);}
- (void)prepareForReuse{[super prepareForReuse];_key=nil;_preview.image=nil;}
@end
@interface ABWebRow : UITableViewCell
@property(nonatomic,strong) UIImageView *preview;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *details;
@property(nonatomic,copy) NSString *key;
- (void)show:(NSDictionary *)entry;
@end
@implementation ABWebRow
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse{if((self=[super initWithStyle:style reuseIdentifier:reuse])){_preview=[UIImageView new];_preview.contentMode=UIViewContentModeScaleAspectFill;_preview.clipsToBounds=YES;_preview.layer.cornerRadius=5;_preview.backgroundColor=[UIColor colorWithWhite:0.94 alpha:1];[self.contentView addSubview:_preview];_heading=[UILabel new];_heading.font=[UIFont systemFontOfSize:15];_heading.lineBreakMode=NSLineBreakByTruncatingTail;[self.contentView addSubview:_heading];_details=[UILabel new];_details.numberOfLines=2;_details.font=[UIFont systemFontOfSize:12];_details.textColor=[UIColor grayColor];[self.contentView addSubview:_details];self.accessoryType=UITableViewCellAccessoryDisclosureIndicator;}return self;}
- (void)show:(NSDictionary *)entry{entry=ABWebRecord(entry);_heading.text=entry[@"title"];_details.text=[NSString stringWithFormat:@"%@\n%@",ABWebDate(entry),entry[@"original"]];_key=ABWebThumbnailKey(entry);_preview.image=ABWebPlaceholder();__weak ABWebRow *weak=self;NSString *key=_key;[[ABImages shared] cachedImageForKey:key completion:^(UIImage *image){ABWebRow *cell=weak;if(image&&[cell.key isEqual:key])cell.preview.image=image;}];}
- (void)layoutSubviews{[super layoutSubviews];CGFloat w=self.contentView.bounds.size.width;_preview.frame=CGRectMake(16,12,88,60);_heading.frame=CGRectMake(116,10,MAX(20,w-126),22);_details.frame=CGRectMake(116,35,MAX(20,w-126),38);}
- (void)prepareForReuse{[super prepareForReuse];_key=nil;_preview.image=nil;}
@end
@interface ABWaybackController () <UITextFieldDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UIGestureRecognizerDelegate>
@property(nonatomic,strong) UITextField *address;
@property(nonatomic,strong) UITextField *year;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) NSArray *captures;
@property(nonatomic,strong) NSArray *recent;
@property(nonatomic,strong) NSMutableArray *tasks;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) BOOL showingRecent;
@property(nonatomic,strong) UICollectionView *favoritesRail;
@property(nonatomic,strong) UILabel *favoritesHeading;
@property(nonatomic,strong) NSArray *favorites;
@end
@implementation ABWaybackController
- (NSString *)historyPath{return [ABDocuments() stringByAppendingPathComponent:@"web-history.plist"];}
- (void)viewDidLoad{[super viewDidLoad];self.title=@"时光机";self.navigationController.tabBarItem.title=@"时光机";self.tableView.rowHeight=84;_tasks=[NSMutableArray array];_recent=[ABWebLibrary shared].history;_favorites=[ABWebLibrary shared].favorites;_captures=_recent;_showingRecent=YES;[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(libraryChanged) name:ABWebLibraryChanged object:nil];UILongPressGestureRecognizer *longPress=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(historyMenu:)];longPress.delegate=self;[self.tableView addGestureRecognizer:longPress];self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"说明" style:UIBarButtonItemStylePlain target:self action:@selector(help)];UIView *head=[[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,212)];head.autoresizingMask=UIViewAutoresizingFlexibleWidth;CGFloat w=head.bounds.size.width;
 _address=[[UITextField alloc] initWithFrame:CGRectMake(16,16,w-32,50)];_address.autoresizingMask=UIViewAutoresizingFlexibleWidth;_address.borderStyle=UITextBorderStyleRoundedRect;_address.placeholder=@"输入网址，例如 apple.com";_address.font=[UIFont systemFontOfSize:19];_address.keyboardType=UIKeyboardTypeURL;_address.autocapitalizationType=UITextAutocapitalizationTypeNone;_address.autocorrectionType=UITextAutocorrectionTypeNo;_address.returnKeyType=UIReturnKeySearch;_address.delegate=self;[head addSubview:_address];
 _year=[[UITextField alloc] initWithFrame:CGRectMake(16,80,w-148,40)];_year.autoresizingMask=UIViewAutoresizingFlexibleWidth;_year.borderStyle=UITextBorderStyleRoundedRect;_year.placeholder=@"年份（可选，如 2010）";_year.keyboardType=UIKeyboardTypeNumberPad;[head addSubview:_year];UIButton *search=[UIButton buttonWithType:UIButtonTypeSystem];search.frame=CGRectMake(w-120,80,104,40);search.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;[search setTitle:@"查找快照" forState:UIControlStateNormal];[search addTarget:self action:@selector(search) forControlEvents:UIControlEventTouchUpInside];[head addSubview:search];_status=[[UILabel alloc] initWithFrame:CGRectMake(16,132,w-32,64)];_status.autoresizingMask=UIViewAutoresizingFlexibleWidth;_status.numberOfLines=3;_status.font=[UIFont systemFontOfSize:14];_status.textColor=[UIColor grayColor];_status.text=@"输入网址，查看过去的网页。可指定年份；下方保留最近打开的快照。";[head addSubview:_status];_favoritesHeading=[[UILabel alloc] initWithFrame:CGRectMake(16,212,w-32,32)];_favoritesHeading.font=[UIFont boldSystemFontOfSize:18];_favoritesHeading.text=@"收藏";_favoritesHeading.autoresizingMask=UIViewAutoresizingFlexibleWidth;[head addSubview:_favoritesHeading];UICollectionViewFlowLayout *layout=[UICollectionViewFlowLayout new];layout.scrollDirection=UICollectionViewScrollDirectionHorizontal;layout.itemSize=CGSizeMake(124,146);layout.minimumLineSpacing=12;layout.sectionInset=UIEdgeInsetsMake(4,16,4,16);_favoritesRail=[[UICollectionView alloc] initWithFrame:CGRectMake(0,248,w,154) collectionViewLayout:layout];_favoritesRail.autoresizingMask=UIViewAutoresizingFlexibleWidth;_favoritesRail.backgroundColor=[UIColor whiteColor];_favoritesRail.dataSource=self;_favoritesRail.delegate=self;[_favoritesRail registerClass:[ABWebTile class] forCellWithReuseIdentifier:@"web-favorite"];UILongPressGestureRecognizer *favoritePress=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(favoriteMenu:)];[_favoritesRail addGestureRecognizer:favoritePress];[head addSubview:_favoritesRail];head.frame=CGRectMake(0,0,w,410);self.tableView.tableHeaderView=head;[self libraryChanged];
}
- (BOOL)textFieldShouldReturn:(UITextField *)f{[self search];return YES;}
- (void)search{NSURL *url=ABWebAddress(_address.text);NSString *year=[_year.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];if(!url||(year.length&&(year.length!=4||year.integerValue<1996||year.integerValue>[[NSCalendar currentCalendar] component:NSCalendarUnitYear fromDate:[NSDate date]]))){ABAlert(self,@"检查输入",@"请输入有效 HTTP / HTTPS 网址，年份从 1996 年至今，也可留空。");return;}[self.view endEditing:YES];for(NSURLSessionTask *t in _tasks)[t cancel];[_tasks removeAllObjects];NSUInteger generation=++_generation;_captures=@[];_showingRecent=NO;[self layoutHomeHeader];self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"最近" style:UIBarButtonItemStylePlain target:self action:@selector(showRecent)];_status.text=@"正在查询 Wayback 快照…";[self.tableView reloadData];NSString *timestamp=year.length?[year stringByAppendingString:@"0701"]:@"";NSString *path=[NSString stringWithFormat:@"/wayback/available?url=%@%@",ABEncode(url.absoluteString),timestamp.length?[@"&timestamp=" stringByAppendingString:timestamp]:@""];__weak ABWaybackController *weak=self;
 [_tasks addObject:[[ABHTTP shared] json:path completion:^(id json,NSError *error){ABWaybackController *s=weak;if(!s||generation!=s.generation)return;id snapshots=[json isKindOfClass:[NSDictionary class]]?json[@"archived_snapshots"]:nil;id candidate=[snapshots isKindOfClass:[NSDictionary class]]?snapshots[@"closest"]:nil;NSDictionary *nearest=[candidate isKindOfClass:[NSDictionary class]]?candidate:nil;NSString *ts=ABString(nearest[@"timestamp"]);NSString *original=url.absoluteString;NSString *snapshot=ABString(nearest[@"url"]);NSRange marker=[snapshot rangeOfString:[NSString stringWithFormat:@"/web/%@/",ts]];if(marker.location!=NSNotFound){NSString *candidate=[snapshot substringFromIndex:NSMaxRange(marker)];if(ABWebAddress(candidate))original=candidate;}if([nearest[@"available"] boolValue]&&ABWaybackSnapshotURL(ts,original))s.captures=@[@{@"timestamp":ts,@"original":original}];s.status.text=error?@"最近快照查询失败，正在尝试历史索引。":s.captures.count?@"已找到接近指定日期的快照；继续读取历史版本…":@"未找到最近快照，继续查询历史索引…";[s.tableView reloadData];[s loadIndex:url year:year generation:generation];}]];
}
- (void)loadIndex:(NSURL *)url year:(NSString *)year generation:(NSUInteger)generation{NSString *address=[NSString stringWithFormat:@"https://web.archive.org/cdx/search/cdx?url=%@&output=json&fl=timestamp,original&filter=statuscode:200&collapse=timestamp:6&limit=-100%@",ABEncode(url.absoluteString),year.length?[NSString stringWithFormat:@"&from=%@&to=%@",year,year]:@""];__weak ABWaybackController *weak=self;[_tasks addObject:[[ABHTTP shared] get:[NSURL URLWithString:address] limit:1024*1024 completion:^(NSData *d,NSError *error){ABWaybackController *s=weak;if(!s||s.generation!=generation)return;id json=d?[NSJSONSerialization JSONObjectWithData:d options:0 error:nil]:nil;NSMutableArray *rows=[s.captures mutableCopy];NSMutableSet *seen=[NSMutableSet set];for(NSDictionary *r in rows)[seen addObject:r[@"timestamp"]];if([json isKindOfClass:[NSArray class]])for(id row in [json reverseObjectEnumerator])if([row isKindOfClass:[NSArray class]]&&[row count]>=2&&ABWaybackSnapshotURL(ABString(row[0]),ABString(row[1]))&&![seen containsObject:row[0]]){[seen addObject:row[0]];[rows addObject:@{@"timestamp":row[0],@"original":row[1]}];}s.captures=rows;s.status.text=rows.count?[NSString stringWithFormat:@"%lu 个快照 · 首项为接近目标日期的版本，其余按日期从新到旧（每月最多一个，最近 100 项）%@",(unsigned long)rows.count,error?@"\n历史索引暂不可用，仅显示最近快照。":@""]:error?@"查询暂不可用，请稍后重试。":@"此网址未找到可用快照，可换一个年份或网址。";[s.tableView reloadData];}]];}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)s{return _captures.count;}
- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s{return _showingRecent?@"最近浏览的网页快照":@"历史快照";}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p{ABWebRow *c=(id)[t dequeueReusableCellWithIdentifier:@"capture"]?:[[ABWebRow alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"capture"];[c show:_captures[p.row]];return c;}
- (void)openRecord:(NSDictionary *)record{NSDictionary *entry=ABWebRecord(record);if(!entry)return;ABArchivedPage *page=[ABArchivedPage new];page.url=ABWaybackSnapshotURL(entry[@"timestamp"],entry[@"original"]);[[ABWebLibrary shared] visit:entry];[self.navigationController pushViewController:page animated:YES];}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)p{[t deselectRowAtIndexPath:p animated:YES];[self openRecord:_captures[p.row]];}
- (void)viewWillAppear:(BOOL)a{[super viewWillAppear:a];[self libraryChanged];[_favoritesRail reloadData];[self.tableView reloadData];}
- (void)layoutHomeHeader{UIView *head=self.tableView.tableHeaderView;CGRect frame=head.frame;frame.size.height=_showingRecent?410:212;head.frame=frame;_favoritesHeading.hidden=_favoritesRail.hidden=!_showingRecent;self.tableView.tableHeaderView=head;}
- (void)libraryChanged{_recent=[ABWebLibrary shared].history;_favorites=[ABWebLibrary shared].favorites;if(_showingRecent)_captures=_recent;if(!self.isViewLoaded)return;UILabel *empty=[UILabel new];empty.text=@"长按记录或在浏览中点 ☆ 收藏快照";empty.textAlignment=NSTextAlignmentCenter;empty.textColor=[UIColor grayColor];empty.font=[UIFont systemFontOfSize:13];_favoritesRail.backgroundView=_favorites.count?nil:empty;[_favoritesRail reloadData];[self.tableView reloadData];}
- (void)showRecent{_generation++;for(NSURLSessionTask *t in _tasks)[t cancel];[_tasks removeAllObjects];_showingRecent=YES;_captures=[ABWebLibrary shared].history;self.navigationItem.leftBarButtonItem=nil;_status.text=@"输入网址，查看过去的网页。最近记录可左滑删除或收藏。";[self layoutHomeHeader];[self libraryChanged];[self.tableView reloadData];}
- (BOOL)tableView:(UITableView *)t canEditRowAtIndexPath:(NSIndexPath *)p{return _showingRecent;}
- (void)removeRecord:(NSDictionary *)entry{if(![[ABWebLibrary shared] removeHistory:entry])ABAlert(self,@"无法删除记录",[ABWebLibrary shared].error);}
- (void)toggleRecordFavorite:(NSDictionary *)entry{ABWebLibrary *library=[ABWebLibrary shared];if(![library setFavorite:entry present:![library isFavorite:entry]])ABAlert(self,@"无法保存收藏",library.error);}
- (void)tableView:(UITableView *)t commitEditingStyle:(UITableViewCellEditingStyle)style forRowAtIndexPath:(NSIndexPath *)p{if(_showingRecent&&style==UITableViewCellEditingStyleDelete)[self removeRecord:_captures[p.row]];}
- (NSArray *)tableView:(UITableView *)t editActionsForRowAtIndexPath:(NSIndexPath *)p{if(!_showingRecent)return @[];NSDictionary *entry=_captures[p.row];UITableViewRowAction *remove=[UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"删除" handler:^(UITableViewRowAction *a,NSIndexPath *index){[t setEditing:NO animated:YES];[self removeRecord:entry];}];UITableViewRowAction *favorite=[UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleNormal title:[[ABWebLibrary shared] isFavorite:entry]?@"取消收藏":@"收藏" handler:^(UITableViewRowAction *a,NSIndexPath *index){[t setEditing:NO animated:YES];[self toggleRecordFavorite:entry];}];favorite.backgroundColor=ABTint();return @[remove,favorite];}
- (void)recordMenu:(NSDictionary *)entry anchor:(UIView *)anchor{entry=ABWebRecord(entry);BOOL favorite=[[ABWebLibrary shared] isFavorite:entry];UIAlertController *a=[UIAlertController alertControllerWithTitle:entry[@"title"] message:ABWebDate(entry) preferredStyle:UIAlertControllerStyleActionSheet];[a addAction:[UIAlertAction actionWithTitle:favorite?@"取消收藏":@"收藏此快照" style:favorite?UIAlertActionStyleDestructive:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self toggleRecordFavorite:entry];}]];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];ABPresentSheet(self,a,anchor);}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)g shouldReceiveTouch:(UITouch *)touch{return g.view!=self.tableView||[touch locationInView:self.tableView].y>=CGRectGetMaxY(self.tableView.tableHeaderView.frame);}
- (void)historyMenu:(UILongPressGestureRecognizer *)g{if(g.state!=UIGestureRecognizerStateBegan||[g locationInView:self.tableView].y<CGRectGetMaxY(self.tableView.tableHeaderView.frame))return;NSIndexPath *p=[self.tableView indexPathForRowAtPoint:[g locationInView:self.tableView]];if(p)[self recordMenu:_captures[p.row] anchor:[self.tableView cellForRowAtIndexPath:p]];}
- (NSInteger)collectionView:(UICollectionView *)c numberOfItemsInSection:(NSInteger)section{return _favorites.count;}
- (UICollectionViewCell *)collectionView:(UICollectionView *)c cellForItemAtIndexPath:(NSIndexPath *)p{ABWebTile *tile=(id)[c dequeueReusableCellWithReuseIdentifier:@"web-favorite" forIndexPath:p];[tile show:_favorites[p.item]];return tile;}
- (void)collectionView:(UICollectionView *)c didSelectItemAtIndexPath:(NSIndexPath *)p{[self openRecord:_favorites[p.item]];}
- (void)favoriteMenu:(UILongPressGestureRecognizer *)g{if(g.state!=UIGestureRecognizerStateBegan)return;NSIndexPath *p=[_favoritesRail indexPathForItemAtPoint:[g locationInView:_favoritesRail]];if(p)[self recordMenu:_favorites[p.item] anchor:[_favoritesRail cellForItemAtIndexPath:p]];}
- (void)help{ABAlert(self,@"时光机",@"输入网址可查询 Internet Archive 保存的历史网页；指定年份可查找接近该年中旬的版本。历史列表每月取一个成功快照，最多 100 项。\n\n浏览快照时点右下方的日期浮标，可展开时间轴，左右滑动选择可用日期，松手后载入；浮标标题可拖动移动位置。时间轴每月取一项成功快照，并保留当前实际日期。\n\n查询只读取已有快照，不会提交网站保存请求。页面可能缺少图片、脚本或视频，iOS 9 的 WebKit 也不能显示所有网页。载入失败可点 Safari 重试。\n\n这是网页存档；软件、图书和音视频仍在“浏览”页搜索。网页访问历史最多 30 项，可左滑删除或收藏。浏览中点 ☆ / ★ 可加入或取消收藏；首页收藏横向排列，长按可取消。收藏最多 200 项，和历史独立保存。预览缩略图仅在实际浏览后生成，和其他缩略图共用不到 10 MB 的缓存，可能被系统或缓存淘汰。" );}
- (void)dealloc{[[NSNotificationCenter defaultCenter] removeObserver:self];for(NSURLSessionTask *t in _tasks)[t cancel];}
@end
