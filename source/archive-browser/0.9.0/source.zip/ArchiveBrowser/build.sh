#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
AB_DEV="${AB_DEVELOPER_DIR:-/Volumes/OS X/Applications/Xcode.app/Contents/Developer}"
AB_SDK="$AB_DEV/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk"
AB_CC="$AB_DEV/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
mkdir -p build/ArchiveBrowser.app
AB_EXTRA=(-DAB_BUILD=1)
if [[ "${1:-}" == "--testing" ]]; then AB_EXTRA=(-DAB_TESTING=1 tests/Integration.m tests/UX081.m tests/UX090.m); fi
AB_ARCH_ARGS=()
AB_TARGET_ARCHS="${AB_ARCHS:-armv7 arm64}"
for AB_TARGET_ARCH in $AB_TARGET_ARCHS; do AB_ARCH_ARGS+=(-arch "$AB_TARGET_ARCH"); done
"$AB_CC" "${AB_ARCH_ARGS[@]}" -isysroot "$AB_SDK" -miphoneos-version-min=9.0 -O2 -fobjc-arc -fblocks -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -ISources Sources/App.m Sources/ABCore.m Sources/ABUI.m Sources/ABSearch.m Sources/ABPanels.m Sources/ABLibrary.m Sources/ABMedia.m Sources/ABVisual.m Sources/ABPlayback.m Sources/ABVault.m Sources/ABExtras.m Sources/ABZIP.m Sources/ABSession.m Sources/ABPDF.m Sources/ABWayback.m Sources/ABWebLibrary.m Sources/ABReplayTools.m "${AB_EXTRA[@]}" -framework UIKit -framework Foundation -framework AVKit -framework AVFoundation -framework ImageIO -framework MobileCoreServices -framework QuartzCore -framework CoreGraphics -framework CoreMedia -framework QuickLook -framework Security -framework WebKit -framework MediaPlayer -lz -o build/ArchiveBrowser.app/ArchiveBrowser
cp Info.plist build/ArchiveBrowser.app/
cp Resources/*.png build/ArchiveBrowser.app/
if [[ "${1:-}" == "--testing" ]]; then /usr/libexec/PlistBuddy -c 'Add :NSAppTransportSecurity dict' -c 'Add :NSAppTransportSecurity:NSAllowsArbitraryLoads bool true' build/ArchiveBrowser.app/Info.plist; fi
/usr/bin/plutil -convert binary1 build/ArchiveBrowser.app/Info.plist
echo "Built: $PWD/build/ArchiveBrowser.app"
