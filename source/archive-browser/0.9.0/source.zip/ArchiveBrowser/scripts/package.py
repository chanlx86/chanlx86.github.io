#!/usr/bin/env python3
"""Create a jailbreak DEB and IPA from the release build signed on the device."""
import io,tarfile,zipfile,time,shutil,hashlib,json,os,plistlib
from pathlib import Path
root=Path(__file__).resolve().parent.parent
signed=root/'build/signed';app=root/'build/ArchiveBrowser.app'
version=plistlib.loads((app/'Info.plist').read_bytes())['CFBundleShortVersionString']
if not (signed/'ArchiveBrowser').exists():raise SystemExit('Run scripts/deploy.py with a release build first.')
stage=root/'build/package';shutil.rmtree(stage,ignore_errors=True)
target=stage/'Applications/ArchiveBrowser.app';target.parent.mkdir(parents=True)
shutil.copytree(app,target);shutil.copy2(signed/'ArchiveBrowser',target/'ArchiveBrowser')
# Refuse to package diagnostic code as the release.
if b'ArchiveBrowser-Test/run' in (target/'ArchiveBrowser').read_bytes():raise SystemExit('Diagnostic binary detected; build and deploy Release first.')
helper=stage/'usr/libexec/archive-browser-register';helper.parent.mkdir(parents=True);shutil.copy2(signed/'register',helper)
control=root/'build/control';shutil.rmtree(control,ignore_errors=True);control.mkdir()
(control/'control').write_text(f'Package: local.archive.browser\nName: 存档浏览器\nVersion: {version}\nArchitecture: iphoneos-arm\nSection: Utilities\nPriority: optional\nMaintainer: ArchiveBrowser\nDepends: firmware (>= 9.0)\nDescription: Native public Internet Archive search, files, downloads and media player for iOS 9.\n')
(control/'postinst').write_text('''#!/bin/sh
set -e
if command -v uicache >/dev/null 2>&1; then uicache -p /Applications/ArchiveBrowser.app || true; fi
cd /var/mobile
su mobile -c '/usr/libexec/archive-browser-register --register-only' || true
exit 0
''')
(control/'prerm').write_text('''#!/bin/sh
killall ArchiveBrowser 2>/dev/null || true
case "$1" in
remove|deconfigure)
cd /var/mobile
su mobile -c '/usr/libexec/archive-browser-register --unregister' || true
;;
esac
exit 0
''')
def tgz(base):
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w:gz',format=tarfile.USTAR_FORMAT) as t:
  for p in sorted(base.rglob('*')):
   m=t.gettarinfo(str(p),'./'+p.relative_to(base).as_posix());m.uid=m.gid=0;m.uname='root';m.gname='wheel';m.mode=0o755 if p.is_dir() or p.name in ['ArchiveBrowser','archive-browser-register','postinst','prerm'] else 0o644
   with p.open('rb') if p.is_file() else io.BytesIO() as f:t.addfile(m,f if p.is_file() else None)
 return b.getvalue()
dist=root/'dist';dist.mkdir(exist_ok=True);deb=dist/('存档浏览器_'+version+'_iphoneos-arm.deb')
with deb.open('wb') as f:
 f.write(b'!<arch>\n')
 for n,d in [('debian-binary',b'2.0\n'),('control.tar.gz',tgz(control)),('data.tar.gz',tgz(stage))]:
  f.write(f'{n+"/":<16}{int(time.time()):<12}{0:<6}{0:<6}{100644:<8}{len(d):<10}`\n'.encode());f.write(d)
  if len(d)%2:f.write(b'\n')
ipa=dist/('存档浏览器_'+version+'_越狱版.ipa')
with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(target.rglob('*')):
  if not p.is_file():continue
  n='Payload/ArchiveBrowser.app/'+p.relative_to(target).as_posix();i=zipfile.ZipInfo(n);i.create_system=3;i.external_attr=(0o100755 if p.name=='ArchiveBrowser' else 0o100644)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,p.read_bytes())
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [deb,ipa]}
(dist/'SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for p in [deb,ipa]:print(p)
