# Flash 与旧 iPad 的适配结论

检查日期：2026-10-26。目标：iPad 3（A5X、ARMv7）、iOS 9.3.6、存档浏览器 0.9.0。

## 4399 洛克王国的实际情况

检查公开网页，没有登录账号或尝试连接游戏角色：

1. `https://www.4399.com/flash/32979.htm` 是 HTML 页面，嵌入腾讯 `17roco.qq.com/default.html` 框架。
2. 腾讯页面通过脚本插入 `//res.17roco.qq.com/swf/ROCO-Z8.swf?...`。
3. 检查当前公开加载器文件头，签名 CWS，SWF 版本 10，声明解压大小 110,808 字节，实际取得压缩文件 92,627 字节。FileAttributes 的 ActionScript 3 标志已设置。这不是一个换成 `<video>` 就能播放的视频播放器。
4. CDX 精确网址查询取得 179 个按月合并的成功快照，跨度 2010-09-22 至 2026-10-02。单次 Availability 查询 2015 年却未给出最近快照，因此不能仅凭 Availability 的空结果认定没有存档。

这些是当前加载器和页面结构的检查结果，并未证明每一年的游戏加载器、全部素材及服务器协议均已保存。网页快照也不是游戏后台的备份。

## 为什么不能直接注入 Ruffle

[Ruffle 网页版](https://github.com/ruffle-rs/ruffle/blob/master/web/README.md)将运行库编译为 WebAssembly。[WebKit 的 Safari 11 发布说明](https://webkit.org/blog/7956/new-webkit-features-in-safari-11/)才引入 WebAssembly，并说明实现支持 ARM64 / x86-64。iPad 3 的 iOS 9 网页视图不具备这项能力；真机脚本检查也得到 `typeof WebAssembly === 'undefined'`。

越狱、伪签名或允许生成机器码，不会自动在旧 WebKit 中补出 WebAssembly、完整 AVM2 虚拟机及 Flash 渲染／音频接口。因此“解除 JIT 限制”不等于网页已经能运行 Flash。

可继续研究的本地路线是移植原生 Flash 运行库，至少满足 ARMv7 / iOS 9、ActionScript 3（AVM2）、适配 A5X 的绘图后端、音频、网络和输入。它是独立的运行库移植工作，不能将只支持早期简单 SWF 的播放器当成洛克王国可用的证明；也不能承诺资源缺失或游戏服务器不兼容时仍可登录。

## Puffin 的方式为什么不能直接移植

[Puffin 官方 Flash 说明](https://www.puffin.com/flash-browser)明确表示 Flash 在云端执行，再串流到设备；[官方技术说明](https://support.puffin.com/topic/5)也说明网页在服务器处理，再以其远程图形格式发送到客户端。这不是 iOS 9 上可复制的本地 Flash 插件。若另做远程渲染，需要可用的服务器端播放器及客户端协议，不能通过移动 Puffin 的 IPA 文件就把 Flash 引擎嵌入本 App。

本次未接入 Puffin 云服务，未实现本地 Flash 图形界面的渲染。4399 的 HTML 页面与框架入口可以浏览；Flash 内容仍受运行库和资源完整性限制。

## 0.9.0 实际提供的能力

- 网页统一使用标准回放，移除简洁／标准切换。二进制文件使用 `id_` 取得原始文件字节，这不是另一种网页回放模式。
- 原生时光机浮标，独立于网页 DOM；展开时间轴后滑动选择日期，松手才切换。当前网址按月取成功快照，并保留实际浏览日期。前进、后退、重定向及更换网址后同步。
- DOM 检查识别 object / embed / movie 参数、常见 FlashVars 音视频地址以及 iframe。仅做两次有上限的扫描，不注入假的 Flash 插件信息，也不持续轮询。
- “文件”菜单可进入框架页的同年代快照，或尝试用系统播放器打开已独立保存的 MP4 / M4V / MP3 / HLS。文件缺档、编码不支持或 HLS 分片缺失时仍可能失败。
- 网页 PDF / EPUB / 文本和图片可进入已有原生预览器；MP3 和常见视频可进入系统播放器；也能将普通文件加入后台下载列表，保存来源 URL。SWF 提供保存和复制存档链接。保存限制 20 MB，检查 SWF 签名，存到已有本地下载栏目；**没有加入 SWF 播放引擎，也未实现洛克王国登录或游戏运行**。
- 相对资源地址转换为当前日期的 Wayback 地址；不为了探测资源而主动打开现有游戏登录页。

网页正文和它的嵌入子资源可能来自不同快照日期。浮标显示的是当前主文档的实际日期，不代表每项依赖资源都存在于同一时间点。

## 实际文件验证

在 iPad 3 / iOS 9.3.6 上，用标准回放进入 Encyclopaedia 的 Book Collections、9000 Downloads 和 PDF 子目录。目录首个 `1000.pdf` 返回 HTTP 404；CDX 精确定位到有保存记录的 `http://www.encyclopaedia.com/pdfs/1/01.pdf`，快照时间 2015-08-23 20:17:28。原生 PDF 阅读器解析 421 页，首屏文字已经绘制，原文件大小 732,685 字节；HTTP 分段探测返回 206 和有效 Content-Range。其他链接仍取决于实际存档是否完整。

网页 MP3 通过既有 ABFileController / ABSession 流式播放，不需要先下载整个文件；同一播放会话提供全屏和现有跨页播放能力。网页文件后台下载复用本地下载系统，记录来源 URL；未重新开放 FLAC / ALAC 音频预览。
