#import "ABUI.h"
#import <QuickLook/QuickLook.h>

static UILabel *ABLabel(CGRect f,CGFloat size,BOOL bold) { UILabel *l=[[UILabel alloc] initWithFrame:f]; l.font=bold?[UIFont boldSystemFontOfSize:size]:[UIFont systemFontOfSize:size]; l.textColor=[UIColor colorWithWhite:0.18 alpha:1]; return l; }
static NSString *ABType(id s) { NSDictionary *d=@{@"software":@"软件",@"movies":@"视频",@"audio":@"音频",@"texts":@"书籍",@"image":@"图片",@"collection":@"合集"}; return d[ABString(s)]?:ABString(s); }
static BOOL ABSoftware(NSString *n) { return [@[@"ipa",@"zip",@"7z",@"rar",@"tar",@"gz",@"bz2",@"xz",@"deb",@"jar",@"exe",@"dmg",@"iso",@"apk",@"sit"] containsObject:n.pathExtension.lowercaseString]; }
static BOOL ABMediaFile(NSString *n) { return ABPlayable(n) || [@[@"webm",@"mkv",@"avi",@"ogv",@"ogg",@"flac",@"opus",@"mpg",@"mpeg",@"wmv",@"wma",@"mid"] containsObject:n.pathExtension.lowercaseString]; }
static NSString *ABPlain(id value) { NSString *s=ABString(value); if(s.length>3000)s=[s substringToIndex:3000]; s=[s stringByReplacingOccurrencesOfString:@"<[^>]+>" withString:@" " options:NSRegularExpressionSearch range:NSMakeRange(0,s.length)]; return [[[s stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"] stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; }

@interface ABResultCell : UITableViewCell
@property(nonatomic,strong) UIImageView *thumb;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *subheading;
@property(nonatomic,copy) NSString *representedID;
@end
@implementation ABResultCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse { if((self=[super initWithStyle:style reuseIdentifier:reuse])) { _thumb=[[UIImageView alloc] initWithFrame:CGRectZero]; _thumb.backgroundColor=[UIColor colorWithWhite:0.93 alpha:1]; _thumb.contentMode=UIViewContentModeScaleAspectFit; _thumb.layer.cornerRadius=5; _thumb.clipsToBounds=YES; [self.contentView addSubview:_thumb]; _heading=ABLabel(CGRectZero,17,YES); _heading.numberOfLines=2; [self.contentView addSubview:_heading]; _subheading=ABLabel(CGRectZero,12,NO); _subheading.textColor=[UIColor grayColor]; [self.contentView addSubview:_subheading]; self.accessoryType=UITableViewCellAccessoryDisclosureIndicator; } return self; }
- (void)layoutSubviews { [super layoutSubviews]; CGFloat w=self.contentView.bounds.size.width; _thumb.frame=CGRectMake(16,10,64,64); _heading.frame=CGRectMake(94,10,MAX(50,w-106),44); _subheading.frame=CGRectMake(94,57,MAX(50,w-106),17); }
- (void)prepareForReuse { [super prepareForReuse]; _representedID=nil; _thumb.image=nil; }
@end

@interface ABBrowseController () <UISearchBarDelegate>
@property(nonatomic,strong) UISearchBar *search;
@property(nonatomic,strong) UISegmentedControl *types;
@property(nonatomic,strong) NSMutableArray *items;
@property(nonatomic,strong) NSURLSessionTask *task;
@property(nonatomic) NSInteger page;
@property(nonatomic) NSInteger found;
@property(nonatomic) NSInteger generation;
@property(nonatomic) BOOL loading;
@property(nonatomic) BOOL hasSearch;
@property(nonatomic,copy) NSString *query;
@property(nonatomic,copy) NSString *message;
@end
@implementation ABBrowseController
- (void)viewDidLoad { [super viewDidLoad]; self.navigationItem.title=@"存档浏览器"; self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"打开条目" style:UIBarButtonItemStylePlain target:self action:@selector(promptIdentifier)]; self.tableView.rowHeight=84; self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag; self.tableView.tableFooterView=[UIView new];
    UIView *h=[[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,154)]; h.backgroundColor=[UIColor colorWithWhite:0.97 alpha:1];
    _search=[[UISearchBar alloc] initWithFrame:CGRectMake(0,0,h.bounds.size.width,50)]; _search.autoresizingMask=UIViewAutoresizingFlexibleWidth; _search.placeholder=@"搜索名称、作者或关键词"; _search.delegate=self; [h addSubview:_search];
    _types=[[UISegmentedControl alloc] initWithItems:@[@"全部",@"软件",@"视频",@"音频",@"书籍"]]; _types.frame=CGRectMake(16,58,h.bounds.size.width-32,30); _types.autoresizingMask=UIViewAutoresizingFlexibleWidth; _types.selectedSegmentIndex=0; [_types addTarget:self action:@selector(typeChanged) forControlEvents:UIControlEventValueChanged]; [h addSubview:_types];
    UILabel *hint=ABLabel(CGRectMake(18,98,h.bounds.size.width-36,46),12,NO); hint.autoresizingMask=UIViewAutoresizingFlexibleWidth; hint.numberOfLines=2; hint.textColor=[UIColor grayColor]; hint.text=@"浏览 Internet Archive 的公开存档\n也可直接粘贴 archive.org 条目链接或编号"; [h addSubview:hint]; self.tableView.tableHeaderView=h;
    self.refreshControl=[UIRefreshControl new]; [self.refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
    _items=[NSMutableArray arrayWithArray:@[@{@"identifier":@"BigBuckBunny_328",@"title":@"Big Buck Bunny · 播放示例",@"mediatype":@"movies",@"creator":@"Blender Foundation"},@{@"identifier":@"testmp3testfile",@"title":@"音频测试存档",@"mediatype":@"audio"}]]; _message=@"可先用示例熟悉文件浏览与播放";
}
- (void)promptIdentifier { UIAlertController *a=[UIAlertController alertControllerWithTitle:@"打开存档条目" message:@"粘贴 archive.org/details/… 链接或条目编号" preferredStyle:UIAlertControllerStyleAlert]; [a addTextFieldWithConfigurationHandler:^(UITextField *t){t.placeholder=@"BigBuckBunny_328"; t.autocapitalizationType=UITextAutocapitalizationTypeNone; t.autocorrectionType=UITextAutocorrectionTypeNo;}]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; [a addAction:[UIAlertAction actionWithTitle:@"打开" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){NSString *s=ABIdentifier(a.textFields.firstObject.text); if(s)[self openIdentifier:s]; else dispatch_async(dispatch_get_main_queue(),^{ABAlert(self,@"链接无效",@"请输入 Archive 条目链接或编号。文件链接请先打开对应条目。");});}]]; [self presentViewController:a animated:YES completion:nil]; }
- (void)openIdentifier:(NSString *)identifier { [self.view endEditing:YES]; [self.navigationController pushViewController:[[ABItemController alloc] initWithIdentifier:identifier] animated:YES]; }
- (void)searchBarSearchButtonClicked:(UISearchBar *)bar { [bar resignFirstResponder]; NSString *s=[bar.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; if([s rangeOfString:@"archive.org/"].location!=NSNotFound) { NSString *i=ABIdentifier(s); if(i) { [self openIdentifier:i]; return; } } _query=s; [self begin]; }
- (void)typeChanged { _query=[_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; [self.view endEditing:YES]; [self begin]; }
- (void)refresh { if(!_hasSearch) { [self.refreshControl endRefreshing]; return; } [self begin]; }
- (void)begin { [_task cancel]; _generation++; _page=0; _found=0; _hasSearch=YES; [_items removeAllObjects]; _loading=NO; [self loadNext]; }
- (void)loadNext { if(_loading)return; _loading=YES; _message=@"正在查询…"; [self.tableView reloadData]; NSInteger gen=_generation; NSString *q=_query.length?_query:@"*:*"; NSArray *types=@[@"",@"software",@"movies",@"audio",@"texts"]; NSString *type=types[_types.selectedSegmentIndex]; if(type.length)q=[NSString stringWithFormat:@"(%@) AND mediatype:%@",q,type]; NSString *path=[NSString stringWithFormat:@"/advancedsearch.php?q=%@&output=json&rows=25&page=%ld&fl%%5B%%5D=identifier&fl%%5B%%5D=title&fl%%5B%%5D=creator&fl%%5B%%5D=mediatype",ABEncode(q),(long)(_page+1)]; __weak ABBrowseController *weak=self;
    _task=[[ABHTTP shared] json:path completion:^(id json,NSError *error){ ABBrowseController *s=weak; if(!s||gen!=s.generation)return; s.loading=NO; [s.refreshControl endRefreshing]; NSDictionary *response=[json isKindOfClass:[NSDictionary class]]?json[@"response"]:nil; NSArray *docs=[response isKindOfClass:[NSDictionary class]]?response[@"docs"]:nil; if(error || ![docs isKindOfClass:[NSArray class]]) { s.message=error.localizedDescription?:@"服务返回了无法识别的数据。下拉可重试。"; } else { for(id doc in docs) if([doc isKindOfClass:[NSDictionary class]] && ABIdentifier(ABString(doc[@"identifier"]))) [s.items addObject:doc]; s.page++; s.found=[response[@"numFound"] integerValue]; s.message=[NSString stringWithFormat:@"共 %ld 个结果 · 已显示 %lu 个",(long)s.found,(unsigned long)s.items.count]; if(docs.count==0)s.found=s.items.count; } [s.tableView reloadData]; }];
}
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return _items.count+1; }
- (CGFloat)tableView:(UITableView *)table heightForRowAtIndexPath:(NSIndexPath *)path { return path.row<(NSInteger)_items.count?84:62; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path { if(path.row==(NSInteger)_items.count) { UITableViewCell *c=[table dequeueReusableCellWithIdentifier:@"footer"]?:[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"footer"]; c.textLabel.font=[UIFont systemFontOfSize:14]; c.textLabel.text=_loading?@"正在加载…":(_hasSearch&&(NSInteger)_items.count<_found?@"加载更多":_message); c.detailTextLabel.text=_hasSearch&&(NSInteger)_items.count<_found?_message:@""; c.textLabel.numberOfLines=2; c.textLabel.textColor=ABTint(); c.accessoryType=UITableViewCellAccessoryNone; return c; }
    NSDictionary *d=_items[path.row]; ABResultCell *c=(ABResultCell *)[table dequeueReusableCellWithIdentifier:@"result"]?:[[ABResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"result"]; NSString *key=ABString(d[@"identifier"]); c.representedID=key; c.heading.text=ABString(d[@"title"]).length?ABString(d[@"title"]):key; c.subheading.text=[NSString stringWithFormat:@"%@   %@",ABType(d[@"mediatype"]),ABString(d[@"creator"])]; c.thumb.image=nil; __weak ABResultCell *cell=c; [[ABImages shared] image:key completion:^(UIImage *im){ if([cell.representedID isEqual:key])cell.thumb.image=im; }]; return c;
}
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path { [table deselectRowAtIndexPath:path animated:YES]; if(path.row<(NSInteger)_items.count)[self openIdentifier:ABString(_items[path.row][@"identifier"])]; else if(_hasSearch&&!_loading) { if((NSInteger)_items.count<_found)[self loadNext]; else if(!_items.count)[self begin]; } }
- (void)didReceiveMemoryWarning { [super didReceiveMemoryWarning]; [[ABImages shared] clearMemory]; }
- (void)dealloc { [_task cancel]; }
@end

@interface ABItemController () <UISearchBarDelegate>
@property(nonatomic,copy) NSString *identifier;
@property(nonatomic,strong) NSDictionary *metadata;
@property(nonatomic,strong) NSMutableArray *files;
@property(nonatomic,strong) NSArray *shown;
@property(nonatomic,strong) NSMutableArray *requests;
@property(nonatomic,strong) UISegmentedControl *filter;
@property(nonatomic,strong) UISearchBar *search;
@property(nonatomic,strong) UILabel *info;
@property(nonatomic,strong) UIImageView *thumb;
@property(nonatomic,strong) UIButton *playButton;
@property(nonatomic) BOOL loading;
@property(nonatomic) BOOL more;
@property(nonatomic) NSInteger offset;
@property(nonatomic) NSInteger fileCount;
@property(nonatomic,copy) NSString *failure;
@end
@implementation ABItemController
- (instancetype)initWithIdentifier:(NSString *)identifier { if((self=[super initWithStyle:UITableViewStylePlain])) { _identifier=identifier; _files=[NSMutableArray array]; _shown=@[]; _requests=[NSMutableArray array]; _more=YES; _fileCount=-1; } return self; }
- (void)viewDidLoad { [super viewDidLoad]; self.title=@"条目文件"; self.tableView.rowHeight=68; self.tableView.tableFooterView=[UIView new]; self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag; self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"更多" style:UIBarButtonItemStylePlain target:self action:@selector(moreActions)];
    UIView *h=[[UIView alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,278)]; h.backgroundColor=[UIColor colorWithWhite:0.97 alpha:1];
    _thumb=[[UIImageView alloc] initWithFrame:CGRectMake(16,16,82,82)]; _thumb.contentMode=UIViewContentModeScaleAspectFit; _thumb.backgroundColor=[UIColor colorWithWhite:0.91 alpha:1]; _thumb.layer.cornerRadius=6; _thumb.clipsToBounds=YES; [h addSubview:_thumb];
    _info=ABLabel(CGRectMake(112,14,h.bounds.size.width-128,88),15,YES); _info.autoresizingMask=UIViewAutoresizingFlexibleWidth; _info.numberOfLines=4; _info.text=_identifier; [h addSubview:_info];
    _playButton=[UIButton buttonWithType:UIButtonTypeSystem]; _playButton.frame=CGRectMake(16,112,h.bounds.size.width-32,42); _playButton.autoresizingMask=UIViewAutoresizingFlexibleWidth; _playButton.layer.cornerRadius=7; _playButton.backgroundColor=ABTint(); [_playButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal]; [_playButton setTitle:@"正在查找可播放版本…" forState:UIControlStateNormal]; _playButton.enabled=NO; [_playButton addTarget:self action:@selector(playRecommended) forControlEvents:UIControlEventTouchUpInside]; [h addSubview:_playButton];
    _filter=[[UISegmentedControl alloc] initWithItems:@[@"全部文件",@"音视频",@"软件 / 压缩包"]]; _filter.frame=CGRectMake(16,166,h.bounds.size.width-32,30); _filter.autoresizingMask=UIViewAutoresizingFlexibleWidth; _filter.selectedSegmentIndex=0; [_filter addTarget:self action:@selector(applyFilter) forControlEvents:UIControlEventValueChanged]; [h addSubview:_filter];
    _search=[[UISearchBar alloc] initWithFrame:CGRectMake(0,202,h.bounds.size.width,50)]; _search.autoresizingMask=UIViewAutoresizingFlexibleWidth; _search.placeholder=@"在已加载文件中筛选"; _search.delegate=self; [h addSubview:_search]; UILabel *hint=ABLabel(CGRectMake(16,250,h.bounds.size.width-32,24),11,NO); hint.text=@"点文件可播放、下载或复制链接；大条目分批加载"; hint.textColor=[UIColor grayColor]; [h addSubview:hint]; self.tableView.tableHeaderView=h;
    __weak ABItemController *weak=self; [[ABImages shared] image:_identifier completion:^(UIImage *im){weak.thumb.image=im;}];
    [_requests addObject:[[ABHTTP shared] json:[@"/metadata/" stringByAppendingFormat:@"%@/metadata",ABEncode(_identifier)] completion:^(id j,NSError *e){ ABItemController *s=weak; if(!s)return; NSDictionary *m=[j isKindOfClass:[NSDictionary class]]?j[@"result"]:nil; if(!e&&[m isKindOfClass:[NSDictionary class]]) { s.metadata=m; s.info.text=[NSString stringWithFormat:@"%@\n%@\n%@",ABString(m[@"title"]).length?ABString(m[@"title"]):s.identifier,ABString(m[@"creator"]),ABType(m[@"mediatype"])]; } else { s.info.text=e.localizedDescription?:@"条目不存在或暂时不可用"; } }]];
    [_requests addObject:[[ABHTTP shared] json:[@"/metadata/" stringByAppendingFormat:@"%@/files_count",ABEncode(_identifier)] completion:^(id j,NSError *e){ABItemController *s=weak; if(s && !e && [j isKindOfClass:[NSDictionary class]] && [j[@"result"] respondsToSelector:@selector(integerValue)]) { s.fileCount=[j[@"result"] integerValue]; [s.tableView reloadData]; }}]];
    [self loadFiles];
}
- (void)moreActions { UIAlertController *a=[UIAlertController alertControllerWithTitle:ABString(_metadata[@"title"]).length?ABString(_metadata[@"title"]):_identifier message:nil preferredStyle:UIAlertControllerStyleActionSheet]; [a addAction:[UIAlertAction actionWithTitle:@"条目简介" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){dispatch_async(dispatch_get_main_queue(),^{ABAlert(self,@"条目简介",ABPlain(self.metadata[@"description"]).length?ABPlain(self.metadata[@"description"]):@"此条目没有简介。");});}]]; [a addAction:[UIAlertAction actionWithTitle:@"在 Safari 打开文件页面" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"https://archive.org/download/" stringByAppendingString:ABEncode(self.identifier)]]];}]]; [a addAction:[UIAlertAction actionWithTitle:@"复制条目链接" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=[@"https://archive.org/details/" stringByAppendingString:ABEncode(self.identifier)];}]]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; ABPresentSheet(self,a,nil); }
- (void)loadFiles { if(_loading)return; _loading=YES; _failure=nil; [self.tableView reloadData]; __weak ABItemController *weak=self; NSString *p=[NSString stringWithFormat:@"/metadata/%@/files?start=%ld&count=200",ABEncode(_identifier),(long)_offset];
    [_requests addObject:[[ABHTTP shared] json:p completion:^(id j,NSError *e){ ABItemController *s=weak; if(!s)return; s.loading=NO; NSArray *a=[j isKindOfClass:[NSDictionary class]]?j[@"result"]:nil; if(e||![a isKindOfClass:[NSArray class]]) s.failure=e.localizedDescription?:@"没有找到文件。点击重试。"; else { for(id f in a) if([f isKindOfClass:[NSDictionary class]]&&ABString(f[@"name"]).length)[s.files addObject:f]; s.offset+=a.count; s.more=a.count==200; } [s applyFilter]; }]];
}
- (void)applyFilter { NSMutableArray *a=[NSMutableArray array]; NSString *q=_search.text.lowercaseString; for(NSDictionary *f in _files) { NSString *n=ABString(f[@"name"]); if(q.length&&[n.lowercaseString rangeOfString:q].location==NSNotFound)continue; if(_filter.selectedSegmentIndex==1&&!ABMediaFile(n))continue; if(_filter.selectedSegmentIndex==2&&!ABSoftware(n))continue; [a addObject:f]; } _shown=a; BOOL playable=[self recommended]!=nil; _playButton.enabled=playable; [_playButton setTitle:playable?@"▶  播放推荐版本":(_loading?@"正在查找可播放版本…":@"当前文件中无原生可播放版本") forState:UIControlStateNormal]; [self.tableView reloadData]; }
- (NSDictionary *)recommended { NSDictionary *best=nil; NSInteger score=NSIntegerMin; for(NSDictionary *f in _files) { NSString *n=ABString(f[@"name"]).lowercaseString; if(!ABPlayable(n)||ABPrivate(f))continue; NSInteger s=0; if([n.pathExtension isEqual:@"mp4"])s=100; if([n.pathExtension isEqual:@"mp3"])s=90; if([n.pathExtension isEqual:@"m4a"])s=85; if([n rangeOfString:@"512kb"].location!=NSNotFound)s+=50; if([n rangeOfString:@"h264"].location!=NSNotFound)s+=20; if([n rangeOfString:@"1080"].location!=NSNotFound||[n rangeOfString:@"4k"].location!=NSNotFound||[n rangeOfString:@"av1"].location!=NSNotFound||[n rangeOfString:@"hevc"].location!=NSNotFound)s-=150; long long size=[ABString(f[@"size"]) longLongValue]; if(size>800*1024*1024)s-=40; if(s>score) { score=s; best=f; } } return best; }
- (void)play:(NSDictionary *)f { ABPlayer *p=[[ABPlayer alloc] initWithURL:ABFileURL(_identifier,ABString(f[@"name"])) title:ABString(f[@"name"])]; [self presentViewController:p animated:YES completion:nil]; }
- (void)playRecommended { NSDictionary *f=[self recommended]; if(f)[self play:f]; }
- (void)searchBar:(UISearchBar *)bar textDidChange:(NSString *)text { [self applyFilter]; }
- (void)searchBarSearchButtonClicked:(UISearchBar *)bar { [bar resignFirstResponder]; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return _shown.count+1; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path { UITableViewCell *c=[table dequeueReusableCellWithIdentifier:@"file"]?:[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"file"]; c.textLabel.font=[UIFont systemFontOfSize:15]; c.textLabel.numberOfLines=2; c.detailTextLabel.font=[UIFont systemFontOfSize:11]; c.detailTextLabel.textColor=[UIColor grayColor]; c.accessoryType=UITableViewCellAccessoryNone;
    if(path.row==(NSInteger)_shown.count) { c.textLabel.text=_loading?@"正在加载文件…":(_failure?:(_more?@"加载下一批文件":@"已加载全部文件")); c.textLabel.textColor=ABTint(); c.detailTextLabel.text=[NSString stringWithFormat:@"已加载 %lu%@ · 当前显示 %lu",(unsigned long)_files.count,_fileCount>=0?[NSString stringWithFormat:@" / %ld",(long)_fileCount]:@"",(unsigned long)_shown.count]; }
    else { NSDictionary *f=_shown[path.row]; NSString *n=ABString(f[@"name"]); c.textLabel.text=n; c.textLabel.textColor=ABPrivate(f)?[UIColor lightGrayColor]:[UIColor darkTextColor]; c.detailTextLabel.text=[NSString stringWithFormat:@"%@ · %@%@",ABString(f[@"format"]),ABSize([ABString(f[@"size"]) longLongValue]),ABPrivate(f)?@" · 受限":(ABPlayable(n)?@" · 可尝试播放":@"")]; c.accessoryType=UITableViewCellAccessoryDisclosureIndicator; } return c;
}
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path { [table deselectRowAtIndexPath:path animated:YES]; [self.view endEditing:YES]; if(path.row==(NSInteger)_shown.count) { if(_more||_failure)[self loadFiles]; return; } NSDictionary *f=_shown[path.row]; if(ABPrivate(f)) { ABAlert(self,@"受限文件",@"此文件需要在官方网站取得访问权限，本 App 只下载公开文件。"); return; }
    NSString *name=ABString(f[@"name"]); UIAlertController *a=[UIAlertController alertControllerWithTitle:name message:[NSString stringWithFormat:@"%@ · %@",ABString(f[@"format"]),ABSize([ABString(f[@"size"]) longLongValue])] preferredStyle:UIAlertControllerStyleActionSheet];
    if(ABPlayable(name)) [a addAction:[UIAlertAction actionWithTitle:@"在线播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self play:f];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"下载到本机" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){NSDictionary *r=[[ABDownloads shared] add:self.identifier file:f title:ABString(self.metadata[@"title"]).length?ABString(self.metadata[@"title"]):self.identifier]; if(r) { self.tabBarController.selectedIndex=1; } }]];
    [a addAction:[UIAlertAction actionWithTitle:@"复制文件直链" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=ABFileURL(self.identifier,name).absoluteString;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; ABPresentSheet(self,a,[table cellForRowAtIndexPath:path]);
}
- (void)dealloc { for(NSURLSessionTask *r in _requests)[r cancel]; }
@end

@interface ABDownloadController () <QLPreviewControllerDataSource>
@property(nonatomic,strong) NSURL *previewURL;
@property(nonatomic,strong) UILabel *empty;
@end
@implementation ABDownloadController
- (void)viewDidLoad { [super viewDidLoad]; self.navigationItem.title=@"下载"; self.tableView.rowHeight=82; self.tableView.tableFooterView=[UIView new]; self.navigationItem.rightBarButtonItem=self.editButtonItem; self.editButtonItem.title=@"编辑"; [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changed:) name:ABDownloadsChanged object:nil]; _empty=ABLabel(CGRectMake(20,0,self.view.bounds.size.width-40,160),16,NO); _empty.numberOfLines=3; _empty.textAlignment=NSTextAlignmentCenter; _empty.textColor=[UIColor grayColor]; _empty.text=@"还没有下载\n在条目文件中选择“下载到本机”\n完成后可播放、预览或分享文件"; [self changed:nil]; }
- (void)setEditing:(BOOL)editing animated:(BOOL)animated { [super setEditing:editing animated:animated]; self.editButtonItem.title=editing?@"完成":@"编辑"; }
- (void)changed:(NSNotification *)note { self.tableView.backgroundView=[ABDownloads shared].records.count?nil:_empty; [self.tableView reloadData]; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return [ABDownloads shared].records.count; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path { UITableViewCell *c=[table dequeueReusableCellWithIdentifier:@"download"]?:[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"download"]; NSDictionary *r=[ABDownloads shared].records[path.row]; c.textLabel.text=ABString(r[@"name"]); c.textLabel.font=[UIFont systemFontOfSize:15]; c.textLabel.numberOfLines=2; c.detailTextLabel.font=[UIFont systemFontOfSize:11]; NSString *status=r[@"status"]; NSString *state=@{@"complete":@"已完成",@"downloading":@"下载中",@"waiting":@"等待中",@"paused":@"已暂停",@"failed":@"失败，点击重试"}[status]?:status; long long total=[r[@"total"] longLongValue], bytes=[r[@"bytes"] longLongValue]; c.detailTextLabel.text=[NSString stringWithFormat:@"%@ · %@ / %@\n%@",state,ABSize(bytes),ABSize(total),[status isEqual:@"failed"]?ABString(r[@"error"]):ABString(r[@"title"])]; c.detailTextLabel.numberOfLines=2; c.accessoryType=UITableViewCellAccessoryDisclosureIndicator; return c; }
- (void)tableView:(UITableView *)table commitEditingStyle:(UITableViewCellEditingStyle)style forRowAtIndexPath:(NSIndexPath *)path { NSDictionary *r=[ABDownloads shared].records[path.row]; UIAlertController *a=[UIAlertController alertControllerWithTitle:@"删除下载？" message:ABString(r[@"name"]) preferredStyle:UIAlertControllerStyleAlert]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; [a addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){[[ABDownloads shared] remove:r];}]]; [self presentViewController:a animated:YES completion:nil]; }
- (void)share:(NSURL *)url anchor:(UIView *)view { UIActivityViewController *a=[[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil]; a.popoverPresentationController.sourceView=view; a.popoverPresentationController.sourceRect=view.bounds; [self presentViewController:a animated:YES completion:nil]; }
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path { [table deselectRowAtIndexPath:path animated:YES]; NSDictionary *r=[ABDownloads shared].records[path.row]; BOOL complete=[r[@"status"] isEqual:@"complete"]; UIAlertController *a=[UIAlertController alertControllerWithTitle:ABString(r[@"name"]) message:ABString(r[@"title"]) preferredStyle:UIAlertControllerStyleActionSheet]; NSURL *url=[[ABDownloads shared] localURL:r]; UIView *anchor=[table cellForRowAtIndexPath:path];
    if(complete) { if(ABPlayable(ABString(r[@"name"]))) [a addAction:[UIAlertAction actionWithTitle:@"离线播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self presentViewController:[[ABPlayer alloc] initWithURL:url title:ABString(r[@"name"])] animated:YES completion:nil];}]]; [a addAction:[UIAlertAction actionWithTitle:@"预览文件" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){self.previewURL=url; QLPreviewController *p=[QLPreviewController new]; p.dataSource=self; [self.navigationController pushViewController:p animated:YES];}]]; [a addAction:[UIAlertAction actionWithTitle:@"分享 / 在其他应用打开" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self share:url anchor:anchor];}]]; }
    else [a addAction:[UIAlertAction actionWithTitle:[r[@"status"] isEqual:@"downloading"]?@"暂停下载":([r[@"status"] isEqual:@"paused"]?@"继续下载":@"重新下载") style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[[ABDownloads shared] toggle:r];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"查看来源条目" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self.navigationController pushViewController:[[ABItemController alloc] initWithIdentifier:r[@"identifier"]] animated:YES];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"删除文件及任务" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){[[ABDownloads shared] remove:r];}]]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; ABPresentSheet(self,a,anchor);
}
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller { return _previewURL?1:0; }
- (id<QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index { return _previewURL; }
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
@end

@implementation ABAboutController
- (instancetype)init { return [super initWithStyle:UITableViewStyleGrouped]; }
- (void)viewDidLoad { [super viewDidLoad]; self.navigationItem.title=@"使用说明"; self.tableView.estimatedRowHeight=90; self.tableView.rowHeight=UITableViewAutomaticDimension; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return 6; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path { UITableViewCell *c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil]; NSArray *titles=@[@"存档浏览器 0.1.0",@"搜索与文件浏览",@"音视频播放",@"下载与分享",@"文件位置",@"存档与兼容性"]; NSArray *text=@[@"专为旧 iPhone / iPad 设计的非官方 Internet Archive 客户端。原生 Objective-C 界面，iOS 9 起适用。",@"输入关键词后选择分类。软件条目不一定包含适合本设备的安装包；请在文件列表确认扩展名与系统要求。打开条目支持粘贴编号或官方链接。",@"优先使用较小的 MP4 / MP3 / M4A 版本，支持在线缓冲、拖动进度和下载后离线播放。原生解码是否可用取决于文件编码与设备能力。",@"下载采用系统后台任务，可暂停或取消。强制退出 App 可能使系统取消下载，重新打开后可重试。完成的文件可用分享菜单交给 Filza 等应用。不会自动安装 IPA，也不会绕过受限条目的访问权限。",[NSString stringWithFormat:@"%@/Downloads\n普通安装时也可使用 iTunes 文件共享读取。缩略图磁盘缓存限制约 12 MB，系统可自动清理。",ABDocuments()],@"数据直接来自 archive.org 的公开接口。服务器、网络或原始文件异常均可能影响速度。当前版本不提供登录、转码、解压及软件安装。"];
    c.textLabel.text=titles[path.row]; c.textLabel.font=[UIFont boldSystemFontOfSize:16]; c.detailTextLabel.text=text[path.row]; c.detailTextLabel.font=[UIFont systemFontOfSize:14]; c.detailTextLabel.numberOfLines=0; c.selectionStyle=UITableViewCellSelectionStyleNone; return c; }
@end
