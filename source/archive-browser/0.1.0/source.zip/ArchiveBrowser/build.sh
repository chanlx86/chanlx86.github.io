#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
AB_DEV="${AB_DEVELOPER_DIR:-/Volumes/OS X/Applications/Xcode.app/Contents/Developer}"
AB_SDK="$AB_DEV/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk"
AB_CC="$AB_DEV/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
mkdir -p build/ArchiveBrowser.app
AB_EXTRA=(-DAB_BUILD=1)
if [[ "${1:-}" == "--testing" ]]; then AB_EXTRA=(-DAB_TESTING=1 tests/Integration.m); fi
"$AB_CC" -arch armv7 -arch arm64 -isysroot "$AB_SDK" -miphoneos-version-min=9.0 -O2 -fobjc-arc -fblocks -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -ISources Sources/App.m Sources/ABCore.m Sources/ABUI.m "${AB_EXTRA[@]}" -framework UIKit -framework Foundation -framework AVKit -framework AVFoundation -framework ImageIO -framework MobileCoreServices -framework QuartzCore -framework CoreGraphics -framework CoreMedia -framework QuickLook -o build/ArchiveBrowser.app/ArchiveBrowser
cp Info.plist build/ArchiveBrowser.app/
cp Resources/*.png build/ArchiveBrowser.app/
/usr/bin/plutil -convert binary1 build/ArchiveBrowser.app/Info.plist
echo "Built: $PWD/build/ArchiveBrowser.app"
