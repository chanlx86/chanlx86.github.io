// Device-only integration runner, omitted from release builds.
#import "ABUI.h"
#import <AVFoundation/AVFoundation.h>
#import <mach/mach.h>
@interface ABBrowseController (Testing)
- (void)searchBarSearchButtonClicked:(UISearchBar *)bar;
@end
@interface ABIntegration : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@property(nonatomic,strong) NSMutableDictionary *report;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic) NSInteger stage;
@property(nonatomic,strong) NSDate *started;
@property(nonatomic,strong) ABPlayer *player;
@property(nonatomic,strong) NSDictionary *zipRecord;
@property(nonatomic,strong) NSDictionary *audioRecord;
@property(nonatomic,strong) NSDictionary *cancelRecord;
@property(nonatomic,strong) NSDictionary *pauseRecord;
@end
static ABIntegration *test;
@implementation ABIntegration
- (void)save { NSMutableDictionary *r=_report; struct mach_task_basic_info info; mach_msg_type_number_t n=MACH_TASK_BASIC_INFO_COUNT; if(task_info(mach_task_self(),MACH_TASK_BASIC_INFO,(task_info_t)&info,&n)==KERN_SUCCESS)r[@"residentMB"]=@(info.resident_size/1048576.0); [r setObject:ABDocuments() forKey:@"documents"]; NSData *d=[NSJSONSerialization dataWithJSONObject:r options:NSJSONWritingPrettyPrinted error:nil]; [d writeToFile:@"/var/mobile/Media/ArchiveBrowser-Test/report.json" atomically:YES]; [d writeToFile:[ABDocuments() stringByAppendingPathComponent:@"integration-report.json"] atomically:YES]; }
- (void)snapshot:(NSString *)name { UIGraphicsBeginImageContextWithOptions(_window.bounds.size,YES,1); [_window drawViewHierarchyInRect:_window.bounds afterScreenUpdates:YES]; NSData *d=UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext()); UIGraphicsEndImageContext(); [d writeToFile:[@"/var/mobile/Media/ArchiveBrowser-Test/" stringByAppendingString:[name stringByAppendingString:@".png"]] atomically:YES]; }
- (void)next:(NSInteger)stage { _stage=stage; _started=[NSDate date]; _report[@"stage"]=@(stage); [self save]; }
- (void)begin {
    [UIApplication sharedApplication].idleTimerDisabled=YES; _report=[NSMutableDictionary dictionary];
    _report[@"validation"]=@{ @"rejectTraversal":@(!ABIdentifier(@"../bad")),@"rejectOtherHost":@(!ABIdentifier(@"https://example.org/details/test")),@"parseOfficialURL":@([ABIdentifier(@"https://archive.org/details/BigBuckBunny_328") isEqual:@"BigBuckBunny_328"]),@"escapedFilename":ABFileURL(@"test",@"folder/a #?.zip").absoluteString?:@""};
    [[ABImages shared] image:@"BigBuckBunny_328" completion:^(UIImage *i){self.report[@"thumbnail"]=@{@"width":@(i.size.width),@"height":@(i.size.height),@"pass":@(i!=nil&&i.size.width<=192&&i.size.height<=192)};[self save];}];
    UISearchBar *bar=[_browse valueForKey:@"search"]; bar.text=@"title:(Big Buck Bunny)"; [_browse searchBarSearchButtonClicked:bar];
    _timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES]; [self next:1];
}
- (void)startPlayer:(NSURL *)url title:(NSString *)title stage:(NSInteger)stage { _player=[[ABPlayer alloc] initWithURL:url title:title]; UIViewController *presenter=_browse.navigationController.topViewController; [presenter presentViewController:_player animated:NO completion:nil]; [self next:stage]; }
- (NSDictionary *)playerResult { AVPlayerItem *item=_player.player.currentItem; NSMutableDictionary *d=[@{@"status":@(item.status),@"time":@(isfinite(CMTimeGetSeconds(item.currentTime))?CMTimeGetSeconds(item.currentTime):0),@"rate":@(_player.player.rate),@"width":@(item.presentationSize.width),@"height":@(item.presentationSize.height),@"bufferEmpty":@(item.playbackBufferEmpty),@"error":item.error.localizedDescription?:@""} mutableCopy]; NSArray *events=item.accessLog.events; if(events.count) { AVPlayerItemAccessLogEvent *e=events.lastObject; d[@"droppedVideoFrames"]=@(e.numberOfDroppedVideoFrames); d[@"stalls"]=@(e.numberOfStalls); d[@"observedBitrate"]=@(e.observedBitrate); d[@"watchedSeconds"]=@(e.durationWatched); } return d; }
- (void)tick {
    NSTimeInterval elapsed=-[_started timeIntervalSinceNow];
    if(elapsed>100) { _report[@"failure"]=[NSString stringWithFormat:@"stage %ld timeout",(long)_stage]; [_timer invalidate]; [self save]; return; }
    if(_stage==1 && elapsed>6 && ![[_browse valueForKey:@"loading"] boolValue]) {
        NSArray *a=[_browse valueForKey:@"items"]; _report[@"search"]=@{@"count":@(a.count),@"found":[_browse valueForKey:@"found"],@"message":[_browse valueForKey:@"message"]?:@""}; [self snapshot:@"search"]; [_browse openIdentifier:@"BigBuckBunny_328"]; [self next:2];
    } else if(_stage==2) {
        ABItemController *item=(id)_browse.navigationController.topViewController; NSArray *files=[item valueForKey:@"files"];
        if(files.count&&elapsed>4&&![[item valueForKey:@"loading"] boolValue]) { _report[@"files"]=@{@"count":@(files.count),@"fileCount":[item valueForKey:@"fileCount"]}; [self snapshot:@"files"];
            _zipRecord=[[ABDownloads shared] add:@"testmp3testfile" file:@{@"name":@"testmp3testfile_64kb_mp3.zip",@"size":@198820} title:@"下载验证 · ZIP"];
            _audioRecord=[[ABDownloads shared] add:@"testmp3testfile" file:@{@"name":@"mpthreetest.mp3",@"size":@198658} title:@"离线播放验证"];
            _cancelRecord=[[ABDownloads shared] add:@"BigBuckBunny_328" file:@{@"name":@"BigBuckBunny.avi",@"size":@400455228} title:@"取消测试"];
            [[ABDownloads shared] remove:_cancelRecord];
            _pauseRecord=[[ABDownloads shared] add:@"BigBuckBunny_328" file:@{@"name":@"BigBuckBunny_512kb.mp4",@"size":@43315070} title:@"暂停测试"];
            [[ABDownloads shared] toggle:_pauseRecord]; _report[@"pause"]=@([_pauseRecord[@"status"] isEqual:@"paused"]); [[ABDownloads shared] remove:_pauseRecord];
            [self startPlayer:ABFileURL(@"BigBuckBunny_328",@"BigBuckBunny_512kb.mp4") title:@"视频硬件解码测试" stage:3];
        }
    } else if(_stage==3 && elapsed>18) { _report[@"video"]= [self playerResult]; [_player.player seekToTime:CMTimeMake(60,1)]; [self next:4];
    } else if(_stage==4 && elapsed>10) { _report[@"videoAfterSeek"]=[self playerResult]; [_player dismissViewControllerAnimated:NO completion:^{ [self startPlayer:ABFileURL(@"testmp3testfile",@"mpthreetest.mp3") title:@"在线音频测试" stage:5]; }];
    } else if(_stage==5 && elapsed>12) { _report[@"audio"]=[self playerResult]; [_player dismissViewControllerAnimated:NO completion:^{ [self next:6]; }];
    } else if(_stage==6) {
        BOOL z=[_zipRecord[@"status"] isEqual:@"complete"], a=[_audioRecord[@"status"] isEqual:@"complete"]; if((z&&a)||elapsed>40) {
            NSData *zip=[NSData dataWithContentsOfURL:[[ABDownloads shared] localURL:_zipRecord]]; _report[@"zip"]=@{@"status":_zipRecord[@"status"]?:@"",@"error":_zipRecord[@"error"]?:@"",@"bytes":@(zip.length),@"validMagic":@(zip.length>4&&memcmp(zip.bytes,"PK\003\004",4)==0)};
            _report[@"cancelRemoved"]=@(![[ABDownloads shared].records containsObject:_cancelRecord]);
            if(a) [self startPlayer:[[ABDownloads shared] localURL:_audioRecord] title:@"离线音频测试" stage:7]; else { _report[@"offlineError"]=_audioRecord[@"error"]?:@"下载失败"; [self finish]; }
        }
    } else if(_stage==7 && elapsed>6) { _report[@"offlineAudio"]=[self playerResult]; [_player dismissViewControllerAnimated:NO completion:^{[self finish];}]; }
}
- (void)finish { [_timer invalidate]; _timer=nil; UITabBarController *tab=(id)_window.rootViewController; tab.selectedIndex=1; dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{[self snapshot:@"downloads"];}); _report[@"complete"]=@YES; [self save]; [UIApplication sharedApplication].idleTimerDisabled=NO; }
@end
void ABStartIntegration(UIWindow *window,ABBrowseController *browse) { test=[ABIntegration new]; test.window=window; test.browse=browse; [test begin]; }
