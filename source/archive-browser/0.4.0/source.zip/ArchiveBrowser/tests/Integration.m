// Diagnostic only. Bulk/corruption/eviction tests use separate data paths.
#import "ABUI.h"
#import "ABLibrary.h"
#import "ABMedia.h"
#import "ABPlayback.h"
#import "ABVisual.h"
#import <mach/mach.h>
@interface ABItemController (Test)
- (void)playRecommended;
- (void)play:(NSDictionary *)file;
- (void)enterFullscreen;
- (void)closePlayer;
- (void)floatPlayer;
- (void)playSettings;
@end
@interface UITableViewController (LocalTest)
- (void)toggleSelection;
- (void)selectAll;
@end
@interface ABImages (Test)
- (void)trimFor:(NSUInteger)incoming;
@end
@interface ABIntegration : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@property(nonatomic,strong) ABItemController *item;
@property(nonatomic,strong) NSMutableDictionary *report;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) NSDate *started;
@property(nonatomic,strong) NSString *folder;
@property(nonatomic,strong) NSString *other;
@property(nonatomic,strong) ABMediaCache *testCache;
@property(nonatomic) BOOL addedCollection;
@property(nonatomic) NSInteger stage;
@property(nonatomic) double previous;
@end
static NSString *Dir=@"/var/mobile/Media/ArchiveBrowser-Test";static ABIntegration *test;
static NSDictionary *Movie(void){return @{@"identifier":@"BigBuckBunny_328",@"title":@"Big Buck Bunny",@"collection":@NO,@"mediatype":@"movies"};}
static NSDictionary *Audio(void){return @{@"identifier":@"IbertEscales",@"title":@"IBERT: Escales",@"collection":@NO,@"mediatype":@"audio"};}
@implementation ABIntegration
- (void)save {struct mach_task_basic_info m;mach_msg_type_number_t count=MACH_TASK_BASIC_INFO_COUNT;if(task_info(mach_task_self(),MACH_TASK_BASIC_INFO,(task_info_t)&m,&count)==KERN_SUCCESS)_report[@"residentMB"]=@(m.resident_size/1048576.0);_report[@"stage"]=@(_stage);[[NSJSONSerialization dataWithJSONObject:_report options:NSJSONWritingPrettyPrinted error:nil] writeToFile:[Dir stringByAppendingPathComponent:@"report.json"] atomically:YES];}
- (void)snapshot:(NSString *)name {UIGraphicsBeginImageContextWithOptions(_window.bounds.size,YES,1);[_window drawViewHierarchyInRect:_window.bounds afterScreenUpdates:YES];NSData *d=UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext());UIGraphicsEndImageContext();[d writeToFile:[Dir stringByAppendingPathComponent:[name stringByAppendingString:@".png"]] atomically:YES];}
- (void)next:(NSInteger)s {_stage=s;_started=[NSDate date];[self save];}
- (unsigned long long)size:(NSString *)path {unsigned long long n=0;NSFileManager *f=[NSFileManager defaultManager];for(NSString *name in [f contentsOfDirectoryAtPath:path error:nil])n+=[[f attributesOfItemAtPath:[path stringByAppendingPathComponent:name] error:nil] fileSize];return n;}
- (void)modelTests {
 NSString *path=[Dir stringByAppendingPathComponent:@"library-test.json"];[[NSFileManager defaultManager] removeItemAtPath:path error:nil];ABLibrary *l=[[ABLibrary alloc] initWithPath:path];NSString *a=[l createFolder:@"源"],*b=[l createFolder:@"目标"];[l setEntry:Movie() folder:a present:YES];[l setEntry:Audio() folder:a present:YES];[l setEntry:Audio() folder:b present:YES];BOOL moved=[l entries:@[Movie(),Audio()] from:a to:b];ABLibrary *read=[[ABLibrary alloc] initWithPath:path];NSArray *folders=read.data[@"folders"];NSDictionary *before=[read.data copy];BOOL invalid=![read entries:@[Movie()] from:b to:@"missing"]&&[read.data isEqual:before];[read entries:@[Movie(),Audio()] from:b to:nil];
 _report[@"bulk"]=@{@"moved":@(moved),@"sourceEmpty":@([folders[1][@"items"] count]==0),@"destinationDeduplicated":@([folders[2][@"items"] count]==2),@"invalidTargetAtomic":@(invalid),@"removedBoth":@([read.data[@"folders"][2][@"items"] count]==0)};
 for(int i=0;i<35;i++)[l visit:ABEntry([NSString stringWithFormat:@"test-%d",i],nil,NO)];_report[@"historyLimit"]=@([l.data[@"history"] count]);
 NSString *bad=[Dir stringByAppendingPathComponent:@"corrupt.json"];[@"bad" writeToFile:bad atomically:YES encoding:NSUTF8StringEncoding error:nil];ABLibrary *invalidStore=[[ABLibrary alloc] initWithPath:bad];_report[@"corruptProtected"]=@(![invalidStore clearHistory]);
 NSString *images=[Dir stringByAppendingPathComponent:@"thumb-budget"];[[NSFileManager defaultManager] createDirectoryAtPath:images withIntermediateDirectories:YES attributes:nil error:nil];for(int i=0;i<10;i++){NSString *f=[images stringByAppendingPathComponent:[NSString stringWithFormat:@"%d.jpg",i]];[[NSFileManager defaultManager] createFileAtPath:f contents:nil attributes:nil];NSFileHandle *h=[NSFileHandle fileHandleForWritingAtPath:f];[h truncateFileAtOffset:1024*1024];[h closeFile];}ABImages *im=[ABImages new];[im setValue:images forKey:@"folder"];[im trimFor:0];_report[@"thumbnailDiskAfterEviction"]=@([self size:images]);
 NSString *media=[Dir stringByAppendingPathComponent:@"media-budget"];[[NSFileManager defaultManager] createDirectoryAtPath:media withIntermediateDirectories:YES attributes:nil error:nil];for(int i=0;i<66;i++){NSString *f=[media stringByAppendingPathComponent:[NSString stringWithFormat:@"%d.chunk",i]];[[NSFileManager defaultManager] createFileAtPath:f contents:nil attributes:nil];NSFileHandle *h=[NSFileHandle fileHandleForWritingAtPath:f];[h truncateFileAtOffset:1024*1024];[h closeFile];}_testCache=[ABMediaCache new];[_testCache setValue:media forKey:@"folder"];[_testCache trim];
 _folder=[[ABLibrary shared] createFolder:@"界面测试 · 临时"];_other=[[ABLibrary shared] createFolder:@"移动目标 · 临时"];[[ABLibrary shared] setEntry:Movie() folder:_folder present:YES];[[ABLibrary shared] setEntry:Audio() folder:_folder present:YES];BOOL exists=NO;for(NSDictionary *e in [ABLibrary shared].data[@"collections"])if([e[@"identifier"] isEqual:@"more_animation"])exists=YES;_addedCollection=!exists;if(_addedCollection)[[ABLibrary shared] setCollection:ABEntry(@"more_animation",@"Animation Shorts",YES) present:YES];
 _report[@"downloadsBefore"]=@([ABDownloads shared].records.count);
}
- (void)begin {[UIApplication sharedApplication].idleTimerDisabled=YES;_report=[NSMutableDictionary dictionary];_report[@"version"]=@"0.4.0";if([[NSFileManager defaultManager] fileExistsAtPath:[Dir stringByAppendingPathComponent:@"audio-only"]]){[[NSFileManager defaultManager] removeItemAtPath:[Dir stringByAppendingPathComponent:@"audio-only"] error:nil];_timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self openItem:@"IbertEscales"];[self next:26];return;}if([[NSFileManager defaultManager] fileExistsAtPath:[Dir stringByAppendingPathComponent:@"focused"]]){[[NSFileManager defaultManager] removeItemAtPath:[Dir stringByAppendingPathComponent:@"focused"] error:nil];_timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self openItem:@"BigBuckBunny_328"];[self next:20];return;}[self modelTests];UITabBarController *tabs=(id)_window.rootViewController;tabs.selectedIndex=1;_timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self next:1];}
- (UITableViewController *)localTop {UITabBarController *t=(id)_window.rootViewController;return (id)[(UINavigationController *)t.viewControllers[1] topViewController];}
- (NSDictionary *)playback {ABPlayer *p=[_item valueForKey:@"inlinePlayer"];AVPlayerItem *i=p.player.currentItem;double t=CMTimeGetSeconds(i.currentTime);return @{@"status":@(i.status),@"time":@(isfinite(t)?t:0),@"rate":@(p.player.rate),@"cachedStream":@([p valueForKey:@"stream"]!=nil),@"cacheHits":@([ABMediaCache shared].hits),@"cacheMisses":@([ABMediaCache shared].misses),@"cacheFailure":p.cacheFailure?:@"",@"readyForDisplay":@(p.readyForDisplay),@"error":i.error.localizedDescription?:@""};}
- (void)openItem:(NSString *)identifier {UITabBarController *t=(id)_window.rootViewController;t.selectedIndex=0;[_browse.navigationController popToRootViewControllerAnimated:NO];_item=[[ABItemController alloc] initWithIdentifier:identifier];[_browse.navigationController pushViewController:_item animated:NO];}
- (void)tick {double elapsed=-[_started timeIntervalSinceNow];if(elapsed>85){_report[@"timeout"]=@(_stage);[self finish];return;}switch(_stage){
 case 1:if(elapsed>3){_report[@"mediaAfterEviction"]=@([self size:[_testCache valueForKey:@"folder"]]);[self snapshot:@"local-home"];UITableViewController *local=[self localTop];_report[@"localSections"]=@([local numberOfSectionsInTableView:local.tableView]);[local tableView:local.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];[self next:2];}break;
 case 2:if(elapsed>3){UITableViewController *f=[self localTop];[self snapshot:@"favorites"];NSUInteger n=[[ABLibrary shared].data[@"collections"] count];if(n){[f tableView:f.tableView accessoryButtonTappedForRowWithIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];_report[@"collectionCountBeforeInfo"]=@(n);}[self next:3];}break;
 case 3:if(elapsed>3){[self snapshot:@"collection-info"];UITableViewController *f=[self localTop];_report[@"infoPreservedCollection"]=@([[ABLibrary shared].data[@"collections"] count]==[_report[@"collectionCountBeforeInfo"] unsignedIntegerValue]);[f dismissViewControllerAnimated:NO completion:nil];NSArray *folders=[ABLibrary shared].data[@"folders"];NSUInteger idx=[folders indexOfObjectPassingTest:^BOOL(NSDictionary *e,NSUInteger i,BOOL *stop){return [e[@"id"] isEqual:self.folder];}];[f tableView:f.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:idx inSection:0]];[self next:4];}break;
 case 4:if(elapsed>2){UITableViewController *f=[self localTop];[f toggleSelection];[f selectAll];_report[@"selectedCount"]=@([[f valueForKey:@"selection"] count]);[self snapshot:@"selection"];[self openItem:@"IbertEscales"];[self next:5];}break;
 case 5:if([[_item valueForKey:@"playlist"] count]==3){[_item playRecommended];[self next:6];}break;
 case 6:if(elapsed>13){_report[@"audio"]=self.playback;ABPlayer *p=[_item valueForKey:@"inlinePlayer"];[p.player seekToTime:CMTimeMake(100,1)];[self next:7];}break;
 case 7:if(elapsed>5){[self snapshot:@"wave-progress"];ABAudioBar *bar=[_item valueForKey:@"audioBar"];id wave=[bar valueForKey:@"wave"];_report[@"waveProgress"]= [wave valueForKey:@"progress"]?:@0;ABPlayer *p=[_item valueForKey:@"inlinePlayer"];[p.player pause];[p savePosition];_report[@"savedAudioPosition"]=@([[ABPositions shared] position:ABFileURL(@"IbertEscales",@"01.I.Palermo.mp3")]);[_item closePlayer];[self openItem:@"BigBuckBunny_328"];[self next:8];}break;
 case 8:if([[_item valueForKey:@"playlist"] count]){[_item setValue:@3 forKey:@"aspect"];[_item playRecommended];[self next:9];}break;
 case 9:if(elapsed>13){_report[@"video"]=self.playback;UIView *host=[_item valueForKey:@"playerHost"];ABPlayer *p=[_item valueForKey:@"inlinePlayer"];_report[@"ratio4by3"]=@(p.view.bounds.size.width/p.view.bounds.size.height);_report[@"videoHost"]=NSStringFromCGRect(host.frame);[self snapshot:@"video-4x3"];[_item enterFullscreen];[self next:10];}break;
 case 10:if(elapsed>4){ABVideoStage *stage=(id)_item.presentedViewController;_report[@"fullscreenRatio"]=@(stage.content.view.bounds.size.width/stage.content.view.bounds.size.height);_previous=[self.playback[@"time"] doubleValue];[stage dismissViewControllerAnimated:NO completion:nil];[self next:11];}break;
 case 11:if(elapsed>2){_report[@"fullscreenReturned"]=self.playback;[_item floatPlayer];UITabBarController *t=(id)_window.rootViewController;t.selectedIndex=1;[self next:12];}break;
 case 12:if(elapsed>4){_report[@"floatingAcrossTabs"]=@([ABFloating shared].content!=nil&&[self.playback[@"time"] doubleValue]>_previous);[self snapshot:@"floating-local"];[[ABFloating shared] restore];[self next:13];}break;
 case 13:if(elapsed>2){_report[@"floatingRestored"]=@([[_item valueForKey:@"inlinePlayer"] parentViewController]==_item);ABPlayer *p=[_item valueForKey:@"inlinePlayer"];[p.player seekToTime:CMTimeMake(120,1)];[self next:14];}break;
 case 14:if(elapsed>5){ABPlayer *p=[_item valueForKey:@"inlinePlayer"];[p.player pause];[p savePosition];_report[@"savedVideoPosition"]=@([[ABPositions shared] position:ABFileURL(@"BigBuckBunny_328",@"BigBuckBunny_512kb.mp4")]);[_item closePlayer];[_item playRecommended];[self next:15];}break;
 case 26:if([[_item valueForKey:@"playlist"] count]==3){[_item play:[_item valueForKey:@"playlist"][0]];[self next:27];}break;
 case 27:if((elapsed>8&&[self.playback[@"status"] intValue]==1&&[self.playback[@"time"] doubleValue]>1)||elapsed>45){_report[@"firstTrack"]=self.playback;ABPlayer *p=[_item valueForKey:@"inlinePlayer"];double d=CMTimeGetSeconds(p.player.currentItem.duration);[p.player seekToTime:CMTimeMakeWithSeconds(d-1,600) toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];[self next:28];}break;
 case 28:if((elapsed>5&&[ABString([_item valueForKey:@"currentFile"][@"name"]) hasPrefix:@"02."]&&[self.playback[@"status"] intValue]==1&&[self.playback[@"time"] doubleValue]>1)||elapsed>45){_report[@"autoNextFinal"]=self.playback;_report[@"autoNextFile"]=ABString([_item valueForKey:@"currentFile"][@"name"]);[self finish];}break;
 case 20:if([[_item valueForKey:@"playlist"] count]){[_item playRecommended];[self next:21];}break;
 case 21:if(elapsed>10){ABPlayer *p=[_item valueForKey:@"inlinePlayer"];NSMutableArray *ratios=[NSMutableArray array];for(int mode=0;mode<4;mode++){[_item setValue:@(mode) forKey:@"aspect"];[_item.view setNeedsLayout];[_item.view layoutIfNeeded];[ratios addObject:@{@"mode":@(mode),@"ratio":@(p.view.bounds.size.width/p.view.bounds.size.height),@"gravity":p.videoGravity}];}_report[@"allVideoModes"]=ratios;_report[@"videoFinal"]=self.playback;_report[@"systemPiPSupported"]=@([AVPictureInPictureController isPictureInPictureSupported]);[_item floatPlayer];((UITabBarController *)_window.rootViewController).selectedIndex=1;UINavigationController *nav=((UITabBarController *)_window.rootViewController).viewControllers[1];[nav popToRootViewControllerAnimated:NO];[self next:22];}break;
 case 22:if(elapsed>15&&![[NSFileManager defaultManager] fileExistsAtPath:[Dir stringByAppendingPathComponent:@"capture-hold"]]){[self snapshot:@"local-final"];_report[@"floatingFinal"]=self.playback;[[ABFloating shared] restore];[_item closePlayer];[self openItem:@"IbertEscales"];[self next:23];}break;
 case 23:if([[_item valueForKey:@"playlist"] count]==3){[_item playRecommended];[self next:24];}break;
 case 24:if(elapsed>9){_report[@"audioResumeFinal"]=self.playback;[self snapshot:@"audio-final"];ABPlayer *p=[_item valueForKey:@"inlinePlayer"];double d=CMTimeGetSeconds(p.player.currentItem.duration);[p.player seekToTime:CMTimeMakeWithSeconds(d-1,600) toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];[self next:25];}break;
 case 25:if((elapsed>4&&[self.playback[@"status"] intValue]==1&&[self.playback[@"time"] doubleValue]>1)||elapsed>50){_report[@"autoNextFinal"]=self.playback;_report[@"autoNextFile"]=ABString([_item valueForKey:@"currentFile"][@"name"]);[self finish];}break;
 case 15:if(elapsed>10){_report[@"videoResumed"]=self.playback;[self snapshot:@"video-resumed"];[self finish];}break;
}}
- (void)finish {[_timer invalidate];_timer=nil;[[ABFloating shared] close];[_item closePlayer];ABLibrary *l=[ABLibrary shared];if(_folder)[l deleteFolder:_folder];if(_other)[l deleteFolder:_other];if(_addedCollection)[l setCollection:ABEntry(@"more_animation",nil,YES) present:NO];_report[@"downloadsAfter"]=@([ABDownloads shared].records.count);NSString *cache=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"ArchiveBrowser"];_report[@"thumbnailDiskBytes"]=@([self size:[cache stringByAppendingPathComponent:@"Thumbnails"]]);_report[@"mediaDiskBytes"]=@([self size:[cache stringByAppendingPathComponent:@"Media"]]);_report[@"thumbnailMemoryBytes"]=[[ABImages shared] valueForKey:@"imageCost"];_report[@"complete"]=@YES;[self save];[_browse.navigationController popToRootViewControllerAnimated:NO];[UIApplication sharedApplication].idleTimerDisabled=NO;}
@end
void ABStartIntegration(UIWindow *window,ABBrowseController *browse){test=[ABIntegration new];test.window=window;test.browse=browse;[test begin];}
