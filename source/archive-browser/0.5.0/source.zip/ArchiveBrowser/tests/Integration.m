// Test-only: the vault is redirected to an isolated test path. No user PIN is read or set.
#import "ABUI.h"
#import "ABLibrary.h"
#import "ABVisual.h"
#import "ABVault.h"
#import "ABPlayback.h"
#import <mach/mach.h>
@interface ABItemController (Test)
- (void)playRecommended;
- (void)closePlayer;
- (void)togglePlaylist;
- (void)playManualNext;
- (void)playPrevious;
@end
@interface UITableViewController (LocalTest)
- (void)loadMore;
- (void)submit;
@end
@interface ABIntegration : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@property(nonatomic,strong) ABItemController *item;
@property(nonatomic,strong) NSMutableDictionary *report;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) NSDate *started;
@property(nonatomic,strong) ABVault *vault;
@property(nonatomic,copy) NSString *folder;
@property(nonatomic,copy) NSString *vaultPath;
@property(nonatomic,strong) NSData *originalVaultData;
@property(nonatomic,strong) NSArray *historyIDs;
@property(nonatomic) NSInteger stage;
@property(nonatomic) NSInteger guesses;
@property(nonatomic) BOOL waiting;
@property(nonatomic) BOOL completedAuth;
@end
static NSString *Dir=@"/var/mobile/Media/ArchiveBrowser-Test";
static ABIntegration *test;
static NSDictionary *Movie(void){return @{@"identifier":@"BigBuckBunny_328",@"title":@"Big Buck Bunny",@"collection":@NO,@"mediatype":@"movies"};}
static NSDictionary *Audio(void){return @{@"identifier":@"IbertEscales",@"title":@"IBERT: Escales",@"collection":@NO,@"mediatype":@"audio"};}
@implementation ABIntegration
- (void)save{struct mach_task_basic_info m;mach_msg_type_number_t n=MACH_TASK_BASIC_INFO_COUNT;if(task_info(mach_task_self(),MACH_TASK_BASIC_INFO,(task_info_t)&m,&n)==KERN_SUCCESS)_report[@"residentMB"]=@(m.resident_size/1048576.0);_report[@"stage"]=@(_stage);[[NSJSONSerialization dataWithJSONObject:_report options:NSJSONWritingPrettyPrinted error:nil] writeToFile:[Dir stringByAppendingPathComponent:@"report.json"] atomically:YES];}
- (void)snapshot:(NSString *)name{UIGraphicsBeginImageContextWithOptions(_window.bounds.size,YES,1);[_window drawViewHierarchyInRect:_window.bounds afterScreenUpdates:YES];NSData *data=UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext());UIGraphicsEndImageContext();[data writeToFile:[Dir stringByAppendingPathComponent:[name stringByAppendingString:@".png"]] atomically:YES];}
- (void)next:(NSInteger)s{_stage=s;_started=[NSDate date];[self save];}
- (UITableViewController *)localTop{UITabBarController *tab=(id)_window.rootViewController;return (id)[(UINavigationController *)tab.viewControllers[1] topViewController];}
- (void)begin{[UIApplication sharedApplication].idleTimerDisabled=YES;_report=[NSMutableDictionary dictionaryWithDictionary:@{@"version":@"0.5.0",@"downloadsBefore":@([ABDownloads shared].records.count)}];_vaultPath=[Dir stringByAppendingPathComponent:@"private-test.plist"];[[NSFileManager defaultManager] removeItemAtPath:_vaultPath error:nil];_vault=[[ABVault alloc] initWithPath:_vaultPath];ABUseTestVault(_vault);for(NSDictionary *f in [[ABLibrary shared].data[@"folders"] copy])if([f[@"name"] isEqual:@"文件夹封面验证 · 临时"])[[ABLibrary shared] deleteFolder:f[@"id"]];_folder=[[ABLibrary shared] createFolder:@"文件夹封面验证 · 临时"];[[ABLibrary shared] setEntry:Movie() folder:_folder present:YES];[[ABLibrary shared] setEntry:Audio() folder:_folder present:YES];ABEqualizer *eq=[[ABEqualizer alloc] initWithFrame:CGRectMake(0,0,24,24)];eq.playing=YES;[eq layoutIfNeeded];NSMutableArray *anchors=[NSMutableArray array];for(CALayer *bar in eq.layer.sublayers)[anchors addObject:@{@"anchorY":@(bar.anchorPoint.y),@"bottomY":@(bar.position.y)}];_report[@"equalizerAnchors"]=anchors;UITabBarController *tab=(id)_window.rootViewController;tab.selectedIndex=1;_timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self next:1];}
- (void)runWrongPIN{if(_waiting)return;_waiting=YES;[_vault unlockPIN:@"0000" recovery:NO completion:^(BOOL ok){self.waiting=NO;self.guesses++;if(self.guesses==4){self.report[@"fourthWarningState"]=@(self.vault.failures==4);[self save];}if(self.guesses<5)[self runWrongPIN];else{self.report[@"fiveFailures"]=@(self.vault.failures==5);self.vault=[[ABVault alloc] initWithPath:self.vaultPath];ABUseTestVault(self.vault);[self.vault unlockPIN:@"4716" recovery:NO completion:^(BOOL allowed){self.report[@"restartStillBlocked"]=@(!allowed&&self.vault.failures==5);[self.vault unlockPIN:@"000000" recovery:YES completion:^(BOOL good){self.report[@"wrongRecoveryRejected"]=@(!good&&self.vault.failures==5);self.completedAuth=YES;[self next:10];}];}];}}];}
- (void)openItem:(NSString *)identifier private:(BOOL)private{UITabBarController *tab=(id)_window.rootViewController;tab.selectedIndex=0;[_browse.navigationController popToRootViewControllerAnimated:NO];_item=[[ABItemController alloc] initWithIdentifier:identifier];_item.privateMode=private;[_browse.navigationController pushViewController:_item animated:NO];}
- (void)tick{double elapsed=-[_started timeIntervalSinceNow];if(elapsed>75){_report[@"timeout"]=@(_stage);[self finish];return;}switch(_stage){
 case 1:if(elapsed>3){[self snapshot:@"local"];UITableViewController *local=[self localTop];_report[@"localHeaderRows"]=@([local tableView:local.tableView numberOfRowsInSection:2]);UITableViewCell *head=[local tableView:local.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];_report[@"minimalHeader"]=@(head.imageView.image==nil&&head.detailTextLabel.text.length==0);UITableViewCell *rail=[local tableView:local.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];NSMutableArray *synthetic=[NSMutableArray array];for(int i=0;i<30;i++)[synthetic addObject:@{@"identifier":[NSString stringWithFormat:@"history-%d",i],@"title":@"历史分页验证",@"name":@"test.zip"}];[rail setValue:synthetic forKey:@"entries"];NSUInteger first=[[rail valueForKey:@"loaded"] unsignedIntegerValue];[(id)rail loadMore];NSUInteger second=[[rail valueForKey:@"loaded"] unsignedIntegerValue];[(id)rail loadMore];_report[@"railPaging"]=@[@(first),@(second),[rail valueForKey:@"loaded"]];[local.tableView reloadData];ABUnlockPrivate(local,^{self.report[@"setupOpened"]=@YES;});[self next:2];}break;
 case 2:if(elapsed>2){[self snapshot:@"private-setup"];UINavigationController *nav=(id)[self localTop].presentedViewController;UIViewController *gate=nav.topViewController;[(UITextField *)[gate valueForKey:@"pin"] setText:@"4716"];[(UITextField *)[gate valueForKey:@"confirmPIN"] setText:@"4716"];[(UITextField *)[gate valueForKey:@"recovery"] setText:@"582914"];[(UITextField *)[gate valueForKey:@"confirmRecovery"] setText:@"582914"];[(id)gate submit];[self next:3];}break;
 case 3:if(_vault.unlocked&&elapsed>2){NSMutableDictionary *entry=[Movie() mutableCopy];entry[@"title"]=@"private-marker-secret-title";[_vault setEntry:entry present:YES];NSData *cipher=[NSData dataWithContentsOfFile:_vaultPath];_report[@"encryptedAtRest"]=@([cipher rangeOfData:[@"private-marker-secret-title" dataUsingEncoding:NSUTF8StringEncoding] options:0 range:NSMakeRange(0,cipher.length)].location==NSNotFound&&[cipher rangeOfData:[@"BigBuckBunny_328" dataUsingEncoding:NSUTF8StringEncoding] options:0 range:NSMakeRange(0,cipher.length)].location==NSNotFound);[_vault lock];UITableViewController *local=[self localTop];[local tableView:local.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1]];[self next:4];}break;
 case 4:if(elapsed>2){[self snapshot:@"folders"];UITableViewController *f=[self localTop];UITableViewCell *private=[f tableView:f.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];_report[@"privateCountHidden"]=@(private.detailTextLabel.text.length==0);[f tableView:f.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];[self next:5];}break;
 case 5:if(elapsed>1){UINavigationController *nav=(id)[self localTop].presentedViewController;UIViewController *g=nav.topViewController;[(UITextField *)[g valueForKey:@"pin"] setText:@"4716"];[(id)g submit];[self next:6];}break;
 case 6:if(_vault.unlocked&&elapsed>2){[self snapshot:@"private-list"];self.historyIDs=[[ABLibrary shared].data[@"history"] valueForKey:@"identifier"];UITableViewController *v=[self localTop];[v tableView:v.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];[self next:7];}break;
 case 7:if(elapsed>7){ABItemController *item=(id)[self localTop];_report[@"privateItemMode"]=@(item.privateMode);_report[@"privateHistoryUnchanged"]=@([[[ABLibrary shared].data[@"history"] valueForKey:@"identifier"] isEqual:self.historyIDs]);[self snapshot:@"private-item"];ABPlayer *privatePlayer=[[ABPlayer alloc] initWithURL:ABFileURL(@"BigBuckBunny_328",@"BigBuckBunny_512kb.mp4") title:@"私密媒体测试" privateMode:YES];_report[@"privateSharedCacheDisabled"]=@(privatePlayer.privateMode&&[privatePlayer valueForKey:@"stream"]==nil);ABAlert(item,@"private-detail-marker",@"私密详情遮挡验证");[[UIApplication sharedApplication].delegate applicationWillResignActive:[UIApplication sharedApplication]];[self next:8];}break;
 case 8:if(elapsed>2){_report[@"lockedBranchRemoved"]=@([self localTop].navigationController.viewControllers.count==1);_report[@"privacyCoverPresent"]=@([(id)[UIApplication sharedApplication].delegate valueForKey:@"privacyCover"]!=nil);[self snapshot:@"privacy-cover"];[[UIApplication sharedApplication].delegate applicationDidBecomeActive:[UIApplication sharedApplication]];_guesses=0;[self runWrongPIN];[self next:9];}break;
 case 9:break;
 case 10:if(elapsed>1){ABUnlockPrivate([self localTop],^{});[self next:11];}break;
 case 11:if(elapsed>2){[self snapshot:@"private-blocked"];UINavigationController *nav=(id)[self localTop].presentedViewController;UIViewController *gate=nav.topViewController;[(UITextField *)[gate valueForKey:@"recovery"] setText:@"582914"];[(id)gate submit];[self next:12];}break;
 case 12:if(_vault.unlocked&&elapsed>2){_report[@"recoverySucceeded"]=@(_vault.entries.count==1&&_vault.failures==0);_originalVaultData=[NSData dataWithContentsOfFile:_vaultPath];NSMutableDictionary *doc=[[NSPropertyListSerialization propertyListWithData:_originalVaultData options:NSPropertyListMutableContainers format:NULL error:nil] mutableCopy];NSMutableDictionary *box=[doc[@"payload"] mutableCopy];NSMutableData *bytes=[box[@"cipher"] mutableCopy];((unsigned char *)bytes.mutableBytes)[0]^=1;box[@"cipher"]=bytes;doc[@"payload"]=box;[[NSPropertyListSerialization dataWithPropertyList:doc format:NSPropertyListBinaryFormat_v1_0 options:0 error:nil] writeToFile:_vaultPath atomically:YES];[_vault lock];_vault=[[ABVault alloc] initWithPath:_vaultPath];ABUseTestVault(_vault);[_vault unlockPIN:@"4716" recovery:NO completion:^(BOOL ok){self.report[@"tamperRejected"]=@(!ok);[self.originalVaultData writeToFile:self.vaultPath atomically:YES];self.vault=[[ABVault alloc] initWithPath:self.vaultPath];ABUseTestVault(self.vault);self.report[@"destroySucceeded"]=@([self.vault destroy]&&!self.vault.configured);[self openItem:@"IbertEscales" private:NO];[self next:14];}];[self next:13];}break;
 case 13:break;
 case 14:if([[_item valueForKey:@"playlist"] count]==3){[_item playRecommended];[self next:15];}break;
 case 15:if(elapsed>9){NSInteger rows=[_item tableView:_item.tableView numberOfRowsInSection:0];NSArray *full=[_item valueForKey:@"playlist"];[_item setValue:[full subarrayWithRange:NSMakeRange(0,2)] forKey:@"playlist"];[_item.view setNeedsLayout];[_item.view layoutIfNeeded];_report[@"transportHiddenForTwo"]=@([(UIButton *)[_item valueForKey:@"nextButton"] isHidden]);[_item setValue:full forKey:@"playlist"];[_item.view setNeedsLayout];[_item.view layoutIfNeeded];[_item togglePlaylist];_report[@"playlistFolded"]=@([_item tableView:_item.tableView numberOfRowsInSection:0]==0);_report[@"transportVisible"]=@(![(UIButton *)[_item valueForKey:@"nextButton"] isHidden]);[self snapshot:@"playlist-folded"];[_item playManualNext];_report[@"nextFile"]=ABString([_item valueForKey:@"currentFile"][@"name"]);[_item togglePlaylist];_report[@"playlistExpanded"]=@([_item tableView:_item.tableView numberOfRowsInSection:0]==rows);[self next:16];}break;
 case 16:if(elapsed>6){[_item playPrevious];_report[@"previousFile"]=ABString([_item valueForKey:@"currentFile"][@"name"]);[self snapshot:@"playlist-expanded"];[self finish];}break;
}}
- (void)finish{[_timer invalidate];_timer=nil;[_item closePlayer];[_vault lock];ABUseTestVault(nil);if(_folder)[[ABLibrary shared] deleteFolder:_folder];_report[@"downloadsAfter"]=@([ABDownloads shared].records.count);_report[@"realVaultUntouched"]=@(![[NSFileManager defaultManager] fileExistsAtPath:[ABDocuments() stringByAppendingPathComponent:@"private-vault.plist"]]);_report[@"complete"]=@YES;[self save];[_browse.navigationController popToRootViewControllerAnimated:NO];[UIApplication sharedApplication].idleTimerDisabled=NO;}
@end
void ABStartIntegration(UIWindow *w,ABBrowseController *b){test=[ABIntegration new];test.window=w;test.browse=b;[test begin];}
