#import "ABUI.h"
#import "ABSearch.h"
#import "ABPanels.h"
#import "ABLibrary.h"
#import "ABMedia.h"
#import "ABVisual.h"
#import "ABPlayback.h"
#import "ABVault.h"
#import <QuickLook/QuickLook.h>
#import <AVFoundation/AVFoundation.h>

static UILabel *ABLabel(CGRect f,CGFloat size,BOOL bold) { UILabel *l=[[UILabel alloc] initWithFrame:f]; l.font=bold?[UIFont boldSystemFontOfSize:size]:[UIFont systemFontOfSize:size]; l.textColor=[UIColor colorWithWhite:0.18 alpha:1]; return l; }
static NSString *ABType(id s) { NSDictionary *d=@{@"software":@"软件",@"movies":@"视频",@"audio":@"音频",@"texts":@"书籍",@"image":@"图片",@"collection":@"合集"}; return d[ABString(s)]?:ABString(s); }
static BOOL ABSoftware(NSString *n) { return [@[@"ipa",@"zip",@"7z",@"rar",@"tar",@"gz",@"bz2",@"xz",@"deb",@"jar",@"exe",@"dmg",@"iso",@"apk",@"sit"] containsObject:n.pathExtension.lowercaseString]; }
static NSString *ABDuration(id value) {NSString *raw=ABString(value);if(!raw.length)return @"";double seconds=0;for(NSString *p in [raw componentsSeparatedByString:@":"])seconds=seconds*60+[p doubleValue];if(!isfinite(seconds)||seconds<0||seconds>31536000)return raw;long t=(long)seconds;return t>=3600?[NSString stringWithFormat:@"%ld:%02ld:%02ld",t/3600,(t/60)%60,t%60]:[NSString stringWithFormat:@"%ld:%02ld",t/60,t%60];}
static NSString *ABPlain(id value) { NSString *s=ABString(value); if(s.length>3000)s=[s substringToIndex:3000]; s=[s stringByReplacingOccurrencesOfString:@"<[^>]+>" withString:@" " options:NSRegularExpressionSearch range:NSMakeRange(0,s.length)]; return [[[s stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"] stringByReplacingOccurrencesOfString:@"&nbsp;" withString:@" "] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; }

@interface ABResultCell : UITableViewCell
@property(nonatomic,strong) UIImageView *thumb;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *subheading;
@property(nonatomic,copy) NSString *representedID;
@property(nonatomic,strong) ABEqualizer *equalizer;
@end
@implementation ABResultCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse { if((self=[super initWithStyle:style reuseIdentifier:reuse])) { _thumb=[[UIImageView alloc] initWithFrame:CGRectZero]; _thumb.backgroundColor=[UIColor colorWithWhite:0.93 alpha:1]; _thumb.contentMode=UIViewContentModeScaleAspectFit; _thumb.layer.cornerRadius=5; _thumb.clipsToBounds=YES; [self.contentView addSubview:_thumb]; _heading=ABLabel(CGRectZero,17,YES); _heading.numberOfLines=2; [self.contentView addSubview:_heading]; _subheading=ABLabel(CGRectZero,12,NO); _subheading.textColor=[UIColor grayColor]; [self.contentView addSubview:_subheading]; self.accessoryType=UITableViewCellAccessoryDisclosureIndicator; } return self; }
- (void)layoutSubviews { [super layoutSubviews]; CGFloat w=self.contentView.bounds.size.width; _thumb.frame=CGRectMake(16,10,64,64); _heading.frame=CGRectMake(94,10,MAX(50,w-106),44); _subheading.frame=CGRectMake(94,57,MAX(50,w-106),17); }
- (void)prepareForReuse { [super prepareForReuse];[_equalizer removeFromSuperview];_equalizer=nil; _representedID=nil; _thumb.image=nil; }
@end

@interface ABBrowseController () <UITextFieldDelegate>
@property(nonatomic,strong) UITextField *search;
@property(nonatomic,strong) UISegmentedControl *types;
@property(nonatomic,strong) UIButton *advancedButton;
@property(nonatomic,strong) NSMutableArray *items;
@property(nonatomic,strong) NSURLSessionTask *task;
@property(nonatomic) NSInteger page;
@property(nonatomic) NSInteger found;
@property(nonatomic) NSInteger generation;
@property(nonatomic) NSInteger sort;
@property(nonatomic) BOOL titleOnly;
@property(nonatomic) BOOL loading;
@property(nonatomic) BOOL hasSearch;
@property(nonatomic) BOOL hasMore;
@property(nonatomic) BOOL requestFailed;
@property(nonatomic,copy) NSString *query;
@property(nonatomic,copy) NSString *collection;
@property(nonatomic,copy) NSString *collectionTitle;
@property(nonatomic,copy) NSString *message;
@end
@implementation ABBrowseController
- (instancetype)initWithCollection:(NSString *)identifier title:(NSString *)title {
    if((self=[super initWithStyle:UITableViewStylePlain])) { _collection=[identifier copy]; _collectionTitle=[title copy]; }
    return self;
}
- (void)privateLocked {if(!_privateMode||ABPrivateActive())return;_search.text=@"";[_task cancel];[_items removeAllObjects];[self.tableView reloadData];ABClosePrivateBranch(self,nil);}
- (void)viewDidLoad {
    [super viewDidLoad]; if(_privateMode)[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(privateLocked) name:ABVaultChanged object:nil];
    self.navigationItem.title=_collection.length?(_collectionTitle?:_collection):@"存档浏览器";
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"使用说明" style:UIBarButtonItemStylePlain target:self action:@selector(help)];
    self.tableView.rowHeight=84; self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag; self.tableView.tableFooterView=[UIView new];
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults]; _sort=[defaults integerForKey:@"searchSort"]; if(_sort<0||_sort>3)_sort=0;
    _titleOnly=[defaults boolForKey:@"searchTitleOnly"]; [defaults removeObjectForKey:@"searchExtension"]; if(_collection.length)_sort=1;
    CGFloat w=self.view.bounds.size.width;
    UIView *header=[[UIView alloc] initWithFrame:CGRectMake(0,0,w,250)]; header.backgroundColor=[UIColor colorWithRed:0.95 green:0.98 blue:0.99 alpha:1];
    UILabel *heading=ABLabel(CGRectMake(20,16,w-40,34),25,YES); heading.autoresizingMask=UIViewAutoresizingFlexibleWidth; heading.text=_collection.length?@"发现合集中的内容":@"寻找你想要的存档"; [header addSubview:heading];
    UILabel *hint=ABLabel(CGRectMake(20,54,w-40,22),13,NO); hint.autoresizingMask=UIViewAutoresizingFlexibleWidth; hint.textColor=[UIColor grayColor]; hint.text=_collection.length?(_collectionTitle?:_collection):@"软件、影像、声音与书籍，从这里开始"; [header addSubview:hint];
    UIView *box=[[UIView alloc] initWithFrame:CGRectMake(20,86,w-40,60)]; box.autoresizingMask=UIViewAutoresizingFlexibleWidth; box.backgroundColor=[UIColor whiteColor]; box.layer.cornerRadius=10; box.layer.borderWidth=1.5; box.layer.borderColor=[ABTint() colorWithAlphaComponent:0.45].CGColor; [header addSubview:box];
    _search=[[UITextField alloc] initWithFrame:CGRectMake(14,7,w-142,46)]; _search.autoresizingMask=UIViewAutoresizingFlexibleWidth; _search.placeholder=@"搜索名称、作者或关键词"; _search.font=[UIFont systemFontOfSize:19]; _search.adjustsFontSizeToFitWidth=YES; _search.minimumFontSize=14; _search.clearButtonMode=UITextFieldViewModeWhileEditing; _search.returnKeyType=UIReturnKeySearch; _search.autocorrectionType=UITextAutocorrectionTypeNo; _search.autocapitalizationType=UITextAutocapitalizationTypeNone; _search.delegate=self; [box addSubview:_search];
    UIButton *go=[UIButton buttonWithType:UIButtonTypeSystem]; go.frame=CGRectMake(box.bounds.size.width-76,7,68,46); go.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin; go.backgroundColor=ABTint(); go.layer.cornerRadius=7; go.titleLabel.font=[UIFont boldSystemFontOfSize:17]; [go setTitle:@"搜索" forState:UIControlStateNormal]; [go setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal]; [go addTarget:self action:@selector(submitSearch) forControlEvents:UIControlEventTouchUpInside]; [box addSubview:go];
    _types=[[UISegmentedControl alloc] initWithItems:@[@"全部",@"软件",@"视频",@"音频",@"书籍"]]; _types.frame=CGRectMake(20,162,w-40,32); _types.autoresizingMask=UIViewAutoresizingFlexibleWidth; _types.selectedSegmentIndex=0; [_types addTarget:self action:@selector(typeChanged) forControlEvents:UIControlEventValueChanged]; [header addSubview:_types];
    _advancedButton=[UIButton buttonWithType:UIButtonTypeSystem]; _advancedButton.frame=CGRectMake(20,204,w-40,36); _advancedButton.autoresizingMask=UIViewAutoresizingFlexibleWidth; _advancedButton.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft; _advancedButton.titleLabel.font=[UIFont systemFontOfSize:13]; _advancedButton.titleLabel.adjustsFontSizeToFitWidth=YES; [_advancedButton addTarget:self action:@selector(showAdvanced) forControlEvents:UIControlEventTouchUpInside]; [header addSubview:_advancedButton]; [self updateAdvancedTitle];
    self.tableView.tableHeaderView=header;
    self.refreshControl=[UIRefreshControl new]; [self.refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
    _items=[NSMutableArray arrayWithArray:@[@{@"identifier":@"BigBuckBunny_328",@"title":@"Big Buck Bunny · 播放示例",@"mediatype":@"movies",@"creator":@"Blender Foundation"},@{@"identifier":@"testmp3testfile",@"title":@"音频测试存档",@"mediatype":@"audio"}]];
    _message=@"输入关键词开始，也可点选示例浏览";
    if(_collection.length) { self.navigationItem.rightBarButtonItems=@[[[UIBarButtonItem alloc] initWithTitle:@"收藏合集" style:UIBarButtonItemStylePlain target:self action:@selector(favoriteCollection)],self.navigationItem.rightBarButtonItem]; if(!_privateMode)[[ABLibrary shared] visit:ABEntry(_collection,_collectionTitle,YES)]; _query=@""; [self begin]; }
}
- (void)favoriteCollection {if(_privateMode){[[ABVault shared] setEntry:ABEntry(_collection,_collectionTitle,YES) present:YES];ABAlert(self,@"已保存在私密收藏",@"");}else ABFavorite(self,ABEntry(_collection,_collectionTitle,YES));}
- (void)help { [self.view endEditing:YES]; ABShowHelp(self); }
- (void)updateAdvancedTitle {
    NSString *sort=@[@"相关性最高",@"最新收录",@"作品日期↓",@"作品日期↑"][_sort];
    [_advancedButton setTitle:[NSString stringWithFormat:@"高级搜索  ›  %@ · %@",sort,_titleOnly?@"仅标题":@"名称优先"] forState:UIControlStateNormal];
}
- (void)showAdvanced {
    [self.view endEditing:YES]; ABAdvancedController *a=[ABAdvancedController new]; a.sort=_sort; a.titleOnly=_titleOnly;
    __weak ABBrowseController *weak=self;
    a.applied=^(NSInteger sort,BOOL title){ABBrowseController *c=weak;if(!c)return;c.sort=sort;c.titleOnly=title;NSUserDefaults *d=[NSUserDefaults standardUserDefaults];if(!c.collection.length)[d setInteger:sort forKey:@"searchSort"];[d setBool:title forKey:@"searchTitleOnly"];[c updateAdvancedTitle];[c submitSearch];};
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:a]; nav.modalPresentationStyle=UIModalPresentationFormSheet; nav.preferredContentSize=CGSizeMake(540,650); [self presentViewController:nav animated:YES completion:nil];
}
- (void)openIdentifier:(NSString *)identifier { [self.view endEditing:YES]; ABItemController *c=[[ABItemController alloc] initWithIdentifier:identifier]; c.privateMode=_privateMode; [self.navigationController pushViewController:c animated:YES]; }
- (BOOL)textFieldShouldReturn:(UITextField *)field { [self submitSearch]; return YES; }
- (void)submitSearch {
    [self.view endEditing:YES]; NSString *s=[_search.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if([s rangeOfString:@"archive.org/"].location!=NSNotFound) { NSString *identifier=ABIdentifier(s); if(identifier) { [self openIdentifier:identifier]; return; } }
    _query=s?:@""; [self begin];
}
- (void)typeChanged { [self submitSearch]; }
- (void)refresh { if(!_hasSearch) { [self.refreshControl endRefreshing]; return; } [self begin]; }
- (void)begin { [_task cancel]; _generation++; _page=0; _found=0; _hasSearch=YES; _hasMore=YES; [_items removeAllObjects]; _loading=NO; [self loadNext]; }
- (void)updateMessage {
    _message=[NSString stringWithFormat:@"共 %ld 个结果 · 已显示 %lu 个",(long)_found,(unsigned long)_items.count];
}
- (void)loadNext {
    if(_loading)return; _loading=YES; _requestFailed=NO; _message=@"正在查询…"; [self.tableView reloadData];
    NSInteger gen=_generation; NSArray *types=@[@"",@"software",@"movies",@"audio",@"texts"];
    NSString *q=ABSearchQuery(_query?:@"",_titleOnly,_collection,types[_types.selectedSegmentIndex]);
    __weak ABBrowseController *weak=self;
    _task=[[ABHTTP shared] json:ABSearchPath(q,_page+1,_sort) completion:^(id json,NSError *error){
        ABBrowseController *s=weak; if(!s||gen!=s.generation||(s.privateMode&&!ABPrivateActive()))return; [s.refreshControl endRefreshing];
        NSDictionary *response=[json isKindOfClass:[NSDictionary class]]?json[@"response"]:nil;
        NSArray *docs=[response isKindOfClass:[NSDictionary class]]?response[@"docs"]:nil;
        if(error||![docs isKindOfClass:[NSArray class]]) { s.loading=NO; s.requestFailed=YES; s.message=error.localizedDescription?:@"搜索暂时不可用，点击重试。"; [s.tableView reloadData]; return; }
        NSMutableArray *valid=[NSMutableArray array]; for(id d in docs)if([d isKindOfClass:[NSDictionary class]]&&ABIdentifier(ABString(d[@"identifier"])))[valid addObject:d];
        s.page++; s.found=[response[@"numFound"] integerValue]; s.hasMore=docs.count==25 && s.page*25<s.found;
        [s appendUnique:valid];s.loading=NO;[s updateMessage];[s.tableView reloadData];
    }];
}
- (void)appendUnique:(NSArray *)docs { NSMutableSet *ids=[NSMutableSet set]; for(NSDictionary *d in _items)[ids addObject:ABString(d[@"identifier"])]; for(NSDictionary *d in docs)if(![ids containsObject:ABString(d[@"identifier"])]) { [_items addObject:d]; [ids addObject:ABString(d[@"identifier"])]; } }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return _items.count+1; }
- (CGFloat)tableView:(UITableView *)table heightForRowAtIndexPath:(NSIndexPath *)path { return path.row<(NSInteger)_items.count?84:78; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path {
    if(path.row==(NSInteger)_items.count) { UITableViewCell *c=[table dequeueReusableCellWithIdentifier:@"footer"]?:[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"footer"]; c.textLabel.font=[UIFont systemFontOfSize:14]; c.textLabel.text=_loading?@"正在查询…":(_requestFailed?@"搜索失败，点此重试":(_hasSearch&&_hasMore?@"加载下一批":(_items.count?@"已显示全部结果":@"暂未找到匹配项"))); if(!_hasSearch)c.textLabel.text=@"浏览公开存档"; c.detailTextLabel.text=_message; c.detailTextLabel.numberOfLines=2; c.textLabel.numberOfLines=2; c.textLabel.textColor=ABTint(); return c; }
    NSDictionary *d=_items[path.row]; ABResultCell *c=(ABResultCell *)[table dequeueReusableCellWithIdentifier:@"result"]?:[[ABResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"result"]; NSString *key=ABString(d[@"identifier"]); c.representedID=key; c.heading.text=ABString(d[@"title"]).length?ABString(d[@"title"]):key;
    NSString *date=ABString(d[_sort==1?@"addeddate":@"date"]); if(date.length>10)date=[date substringToIndex:10];
    c.subheading.text=[NSString stringWithFormat:@"%@   %@%@",ABType(d[@"mediatype"]),ABString(d[@"creator"]),date.length?[@" · " stringByAppendingString:date]:@""]; c.thumb.image=nil; __weak ABResultCell *cell=c; [[ABImages shared] image:key completion:^(UIImage *im){if([cell.representedID isEqual:key])cell.thumb.image=im;}]; return c;
}
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path {
    [table deselectRowAtIndexPath:path animated:YES];
    if(path.row<(NSInteger)_items.count) { NSDictionary *d=_items[path.row]; if([ABString(d[@"mediatype"]) isEqual:@"collection"]) { ABBrowseController *c=[[ABBrowseController alloc] initWithCollection:ABString(d[@"identifier"]) title:ABString(d[@"title"])];c.privateMode=self.privateMode;[self.navigationController pushViewController:c animated:YES]; } else [self openIdentifier:ABString(d[@"identifier"])]; }
    else if(_hasSearch&&!_loading&&(_hasMore||_requestFailed))[self loadNext];
}
- (void)didReceiveMemoryWarning { [super didReceiveMemoryWarning]; [[ABImages shared] clearMemory]; }
- (void)dealloc {[[NSNotificationCenter defaultCenter] removeObserver:self]; [_task cancel]; }
@end

@interface ABItemController () <UISearchBarDelegate>
@property(nonatomic,copy) NSString *identifier;
@property(nonatomic,strong) NSDictionary *metadata;
@property(nonatomic,strong) NSMutableArray *files;
@property(nonatomic,strong) NSArray *shown;
@property(nonatomic,strong) NSMutableArray *requests;
@property(nonatomic,strong) UISegmentedControl *filter;
@property(nonatomic,strong) UISearchBar *search;
@property(nonatomic,strong) UILabel *info;
@property(nonatomic,strong) UIImageView *thumb;
@property(nonatomic,strong) UIButton *playButton;
@property(nonatomic) BOOL loading;
@property(nonatomic) BOOL more;
@property(nonatomic) NSInteger offset;
@property(nonatomic) NSInteger fileCount;
@property(nonatomic,copy) NSString *failure;
@property(nonatomic,strong) NSArray *collections;
@property(nonatomic,strong) NSMutableDictionary *collectionTitles;
@property(nonatomic,strong) UIView *header;
@property(nonatomic,strong) UIView *filterHeader;
@property(nonatomic,strong) UIView *playerHost;
@property(nonatomic,strong) UILabel *fileHint;
@property(nonatomic,strong) NSArray *playlist;
@property(nonatomic,strong) NSDictionary *currentFile;
@property(nonatomic) BOOL awaitingNext;
@property(nonatomic,strong) ABAudioBar *audioBar;
@property(nonatomic,strong) UILabel *nowPlaying;
@property(nonatomic,strong) UIButton *fullButton;
@property(nonatomic,strong) UIButton *closePlayerButton;
@property(nonatomic,strong) ABPlayer *inlinePlayer;
@property(nonatomic,strong) UIButton *settingsButton;
@property(nonatomic,strong) UIButton *pipButton;
@property(nonatomic) NSInteger aspect;
@property(nonatomic) BOOL floating;
@property(nonatomic,weak) ABVideoStage *fullStage;
@property(nonatomic,strong) id rateObserver;
@property(nonatomic) BOOL playlistCollapsed;
@property(nonatomic,strong) UIView *playlistHeader;
@property(nonatomic,strong) UIButton *playlistToggle;
@property(nonatomic,strong) UIButton *previousButton;
@property(nonatomic,strong) UIButton *nextButton;
@end
@implementation ABItemController
- (instancetype)initWithIdentifier:(NSString *)identifier { if((self=[super initWithStyle:UITableViewStylePlain])) { _identifier=identifier; _files=[NSMutableArray array]; _shown=@[]; _requests=[NSMutableArray array]; _more=YES; _fileCount=-1; } return self; }
- (void)privateLocked {if(!_privateMode||ABPrivateActive())return;[self closePlayer];for(NSURLSessionTask *task in _requests)[task cancel];[_files removeAllObjects];_shown=_playlist=_collections=@[];_metadata=nil;_thumb.image=nil;_info.text=@"私密收藏已锁定";[self.tableView reloadData];ABClosePrivateBranch(self,nil);}
- (void)viewDidLoad {
    [super viewDidLoad]; if(_privateMode)[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(privateLocked) name:ABVaultChanged object:nil]; self.title=@"条目文件"; self.tableView.rowHeight=68; self.tableView.tableFooterView=[UIView new]; self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag;
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"更多" style:UIBarButtonItemStylePlain target:self action:@selector(moreActions)];
    _playlistHeader=[UIView new];_playlistHeader.backgroundColor=[UIColor colorWithWhite:0.97 alpha:1];_playlistToggle=[UIButton buttonWithType:UIButtonTypeSystem];_playlistToggle.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;_playlistToggle.titleLabel.font=[UIFont boldSystemFontOfSize:14];[_playlistToggle addTarget:self action:@selector(togglePlaylist) forControlEvents:UIControlEventTouchUpInside];[_playlistHeader addSubview:_playlistToggle];
    _previousButton=[UIButton buttonWithType:UIButtonTypeSystem];[_previousButton setImage:ABTransportIcon(NO) forState:UIControlStateNormal];_previousButton.accessibilityLabel=@"上一项";[_previousButton addTarget:self action:@selector(playPrevious) forControlEvents:UIControlEventTouchUpInside];[_playlistHeader addSubview:_previousButton];
    _nextButton=[UIButton buttonWithType:UIButtonTypeSystem];[_nextButton setImage:ABTransportIcon(YES) forState:UIControlStateNormal];_nextButton.accessibilityLabel=@"下一项";[_nextButton addTarget:self action:@selector(playManualNext) forControlEvents:UIControlEventTouchUpInside];[_playlistHeader addSubview:_nextButton];
    _playlist=@[]; _collections=@[]; _collectionTitles=[NSMutableDictionary dictionary];
    CGFloat w=self.tableView.bounds.size.width;
    _header=[[UIView alloc] initWithFrame:CGRectMake(0,0,w,164)]; _header.backgroundColor=[UIColor colorWithWhite:0.97 alpha:1];
    _thumb=[[UIImageView alloc] initWithFrame:CGRectMake(16,16,82,82)]; _thumb.contentMode=UIViewContentModeScaleAspectFit; _thumb.backgroundColor=[UIColor colorWithWhite:0.91 alpha:1]; _thumb.layer.cornerRadius=6; _thumb.clipsToBounds=YES; [_header addSubview:_thumb];
    _info=ABLabel(CGRectMake(112,14,w-128,88),15,YES); _info.autoresizingMask=UIViewAutoresizingFlexibleWidth; _info.numberOfLines=4; _info.text=_identifier; [_header addSubview:_info];
    _playButton=[UIButton buttonWithType:UIButtonTypeSystem]; _playButton.frame=CGRectMake(16,112,w-32,42); _playButton.autoresizingMask=UIViewAutoresizingFlexibleWidth; _playButton.layer.cornerRadius=7; _playButton.backgroundColor=ABTint(); [_playButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal]; [_playButton setTitle:@"正在查找可播放版本…" forState:UIControlStateNormal]; _playButton.enabled=NO; [_playButton addTarget:self action:@selector(playRecommended) forControlEvents:UIControlEventTouchUpInside]; [_header addSubview:_playButton];
    _playerHost=[UIView new]; _playerHost.backgroundColor=[UIColor blackColor]; _playerHost.hidden=YES; [_header addSubview:_playerHost];
    _fullButton=[UIButton buttonWithType:UIButtonTypeSystem]; [_fullButton setTitle:@"全屏播放" forState:UIControlStateNormal]; [_fullButton addTarget:self action:@selector(enterFullscreen) forControlEvents:UIControlEventTouchUpInside]; _fullButton.hidden=YES; [_header addSubview:_fullButton];
    _closePlayerButton=[UIButton buttonWithType:UIButtonTypeSystem]; [_closePlayerButton setTitle:@"关闭播放器" forState:UIControlStateNormal]; [_closePlayerButton addTarget:self action:@selector(closePlayer) forControlEvents:UIControlEventTouchUpInside]; _closePlayerButton.hidden=YES; [_header addSubview:_closePlayerButton];
    _nowPlaying=ABLabel(CGRectZero,13,YES);_nowPlaying.numberOfLines=2;_nowPlaying.hidden=YES;[_header addSubview:_nowPlaying];
    _aspect=[[NSUserDefaults standardUserDefaults] integerForKey:@"videoAspect"];if(_aspect<0||_aspect>3)_aspect=0;
    _settingsButton=[UIButton buttonWithType:UIButtonTypeSystem];[_settingsButton setTitle:@"播放设置" forState:UIControlStateNormal];[_settingsButton addTarget:self action:@selector(playSettings) forControlEvents:UIControlEventTouchUpInside];[_header addSubview:_settingsButton];_settingsButton.hidden=YES;
    _pipButton=[UIButton buttonWithType:UIButtonTypeSystem];[_pipButton setTitle:@"小窗播放" forState:UIControlStateNormal];[_pipButton addTarget:self action:@selector(floatPlayer) forControlEvents:UIControlEventTouchUpInside];[_header addSubview:_pipButton];_pipButton.hidden=YES;
    self.tableView.tableHeaderView=_header;
    _filterHeader=[[UIView alloc] initWithFrame:CGRectMake(0,0,w,139)]; _filterHeader.backgroundColor=[UIColor colorWithWhite:0.97 alpha:1];
    UILabel *heading=ABLabel(CGRectMake(16,3,w-32,24),13,YES); heading.text=@"文件列表"; [_filterHeader addSubview:heading];
    _filter=[[UISegmentedControl alloc] initWithItems:@[@"全部",@"音视频",@"图片",@"软件包"]]; _filter.frame=CGRectMake(16,31,w-32,30); _filter.autoresizingMask=UIViewAutoresizingFlexibleWidth; _filter.selectedSegmentIndex=0; [_filter addTarget:self action:@selector(applyFilter) forControlEvents:UIControlEventValueChanged]; [_filterHeader addSubview:_filter];
    _search=[[UISearchBar alloc] initWithFrame:CGRectMake(0,65,w,46)]; _search.autoresizingMask=UIViewAutoresizingFlexibleWidth; _search.placeholder=@"在已加载文件中筛选"; _search.delegate=self; [_filterHeader addSubview:_search];
    _fileHint=ABLabel(CGRectMake(16,111,w-32,25),11,NO);_fileHint.autoresizingMask=UIViewAutoresizingFlexibleWidth;_fileHint.text=@"点文件可查看、播放或下载；大条目分批加载";[_filterHeader addSubview:_fileHint];
    __weak ABItemController *weak=self; [[ABImages shared] image:_identifier completion:^(UIImage *im){weak.thumb.image=im;}];
    [_requests addObject:[[ABHTTP shared] json:[@"/metadata/" stringByAppendingFormat:@"%@/metadata",ABEncode(_identifier)] completion:^(id j,NSError *e){
        ABItemController *s=weak; if(!s||(s.privateMode&&!ABPrivateActive()))return; NSDictionary *m=[j isKindOfClass:[NSDictionary class]]?j[@"result"]:nil;
        if(!e&&[m isKindOfClass:[NSDictionary class]]) {
            s.metadata=m; if(!s.privateMode)[[ABLibrary shared] visit:[s libraryEntry]]; s.info.text=[NSString stringWithFormat:@"%@\n%@\n%@",ABString(m[@"title"]).length?ABString(m[@"title"]):s.identifier,ABString(m[@"creator"]),ABType(m[@"mediatype"])];
            id value=m[@"collection"]; NSArray *a=[value isKindOfClass:[NSArray class]]?value:([value isKindOfClass:[NSString class]]?@[value]:@[]); NSMutableOrderedSet *valid=[NSMutableOrderedSet orderedSet]; for(id identifier in a)if(ABIdentifier(ABString(identifier)))[valid addObject:ABString(identifier)]; s.collections=valid.array; [s.tableView reloadData]; [s loadCollectionTitles];
        } else s.info.text=e.localizedDescription?:@"条目不存在或暂时不可用";
    }]];
    [_requests addObject:[[ABHTTP shared] json:[@"/metadata/" stringByAppendingFormat:@"%@/files_count",ABEncode(_identifier)] completion:^(id j,NSError *e){ ABItemController *s=weak; if(s&&(!s.privateMode||ABPrivateActive())&&!e&&[j isKindOfClass:[NSDictionary class]]&&[j[@"result"] respondsToSelector:@selector(integerValue)]) {s.fileCount=[j[@"result"] integerValue];[s.tableView reloadData];} }]];
    [self loadFiles];
}
- (NSDictionary *)libraryEntry {NSMutableDictionary *e=[ABEntry(_identifier,ABString(_metadata[@"title"]),[ABString(_metadata[@"mediatype"]) isEqual:@"collection"]) mutableCopy];e[@"mediatype"]=ABString(_metadata[@"mediatype"]);if(![@[@"movies",@"audio",@"image"] containsObject:e[@"mediatype"]])for(NSDictionary *f in _files)if(ABSoftware(ABString(f[@"name"]))){e[@"name"]=f[@"name"];break;}return e;}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];CGFloat w=self.tableView.bounds.size.width;BOOL audio=ABAudioFile(ABString(_currentFile[@"name"]));CGFloat ph=audio?140:MIN(300,(w-32)*9.0/16.0);CGFloat height=_inlinePlayer?258+ph:164;
    _nowPlaying.frame=CGRectMake(16,162,w-32,42);_playerHost.frame=CGRectMake(16,206,w-32,ph);_audioBar.frame=_playerHost.bounds;
    if(_inlinePlayer.parentViewController==self){_inlinePlayer.view.frame=[self videoFrame:_playerHost.bounds];_inlinePlayer.view.hidden=audio;_inlinePlayer.videoGravity=_aspect==0?AVLayerVideoGravityResizeAspect:AVLayerVideoGravityResize;}
    NSArray *buttons=@[_closePlayerButton,_fullButton,_settingsButton,_pipButton];for(NSUInteger i=0;i<buttons.count;i++){UIButton *b=buttons[i];b.frame=CGRectMake(16+i*(w-32)/4,206+ph,(w-32)/4,44);b.titleLabel.font=[UIFont systemFontOfSize:12];}_pipButton.enabled=!audio&&!_privateMode;
    if(_floating)_playerHost.hidden=YES;
    BOOL controls=_playlist.count>=3;_previousButton.hidden=_nextButton.hidden=!controls;_playlistToggle.frame=CGRectMake(16,0,w-(controls?124:32),44);_previousButton.frame=CGRectMake(w-104,0,44,44);_nextButton.frame=CGRectMake(w-56,0,44,44);[_playlistToggle setTitle:[NSString stringWithFormat:@"%@ 播放列表（%lu）",_playlistCollapsed?@"▸":@"▾",(unsigned long)_playlist.count] forState:UIControlStateNormal];NSUInteger index=[self playingIndex];_previousButton.enabled=index!=NSNotFound&&index>0;_nextButton.enabled=_playlist.count>=3&&(index==NSNotFound||index+1<_playlist.count||_more);
    if(fabs(_header.bounds.size.width-w)>0.5||fabs(_header.bounds.size.height-height)>0.5){_header.frame=CGRectMake(0,0,w,height);self.tableView.tableHeaderView=_header;}
    if(fabs(_filterHeader.bounds.size.width-w)>0.5)_filterHeader.frame=CGRectMake(0,0,w,139);
}
- (void)loadCollectionTitles {
    if(!_collections.count)return; NSMutableArray *ids=[NSMutableArray array]; for(NSString *s in _collections) { [ids addObject:[NSString stringWithFormat:@"identifier:\"%@\"",s]]; if(ids.count==30)break; }
    NSString *path=[NSString stringWithFormat:@"/advancedsearch.php?q=%@&output=json&rows=30&fl%%5B%%5D=identifier&fl%%5B%%5D=title",ABEncode([ids componentsJoinedByString:@" OR "])]; __weak ABItemController *weak=self;
    [_requests addObject:[[ABHTTP shared] json:path completion:^(id j,NSError *e){ABItemController *s=weak; if(!s||e||![j isKindOfClass:[NSDictionary class]])return; id r=j[@"response"]; NSArray *a=[r isKindOfClass:[NSDictionary class]]?r[@"docs"]:nil; if([a isKindOfClass:[NSArray class]])for(id d in a)if([d isKindOfClass:[NSDictionary class]]&&ABString(d[@"identifier"]).length&&ABString(d[@"title"]).length)s.collectionTitles[ABString(d[@"identifier"])]=ABString(d[@"title"]); [s.tableView reloadData];}]];
}
- (void)moreActions { UIAlertController *a=[UIAlertController alertControllerWithTitle:ABString(_metadata[@"title"]).length?ABString(_metadata[@"title"]):_identifier message:nil preferredStyle:UIAlertControllerStyleActionSheet]; [a addAction:[UIAlertAction actionWithTitle:@"收藏 / 管理收藏" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){dispatch_async(dispatch_get_main_queue(),^{if(self.privateMode){[[ABVault shared] setEntry:[self libraryEntry] present:YES];ABAlert(self,@"已保存在私密收藏",@"离开后会自动锁定。");}else ABFavorite(self,[self libraryEntry]);});}]]; [a addAction:[UIAlertAction actionWithTitle:@"条目简介" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){dispatch_async(dispatch_get_main_queue(),^{ABAlert(self,@"条目简介",ABPlain(self.metadata[@"description"]).length?ABPlain(self.metadata[@"description"]):@"此条目没有简介。");});}]]; [a addAction:[UIAlertAction actionWithTitle:@"在 Safari 打开文件页面" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[[UIApplication sharedApplication] openURL:[NSURL URLWithString:[@"https://archive.org/download/" stringByAppendingString:ABEncode(self.identifier)]]];}]]; [a addAction:[UIAlertAction actionWithTitle:@"复制条目链接" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=[@"https://archive.org/details/" stringByAppendingString:ABEncode(self.identifier)];}]]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; ABPresentSheet(self,a,nil); }
- (void)loadFiles { if(_loading)return; _loading=YES; _failure=nil; [self.tableView reloadData]; __weak ABItemController *weak=self; NSString *p=[NSString stringWithFormat:@"/metadata/%@/files?start=%ld&count=200",ABEncode(_identifier),(long)_offset];
    [_requests addObject:[[ABHTTP shared] json:p completion:^(id j,NSError *e){ ABItemController *s=weak; if(!s||(s.privateMode&&!ABPrivateActive()))return; s.loading=NO; NSArray *a=[j isKindOfClass:[NSDictionary class]]?j[@"result"]:nil; if(e||![a isKindOfClass:[NSArray class]]) s.failure=e.localizedDescription?:@"没有找到文件。点击重试。"; else { for(id f in a) if([f isKindOfClass:[NSDictionary class]]&&ABString(f[@"name"]).length)[s.files addObject:f]; s.offset+=a.count; s.more=a.count==200; } [s applyFilter];if(s.metadata&&!s.privateMode)[[ABLibrary shared] updateDetails:[s libraryEntry]]; if(s.awaitingNext&&!s.failure){s.awaitingNext=NO;[s playNext];} }]];
}
- (void)applyFilter { NSMutableArray *a=[NSMutableArray array]; NSString *q=_search.text.lowercaseString; for(NSDictionary *f in _files) { NSString *n=ABString(f[@"name"]); if(q.length&&[n.lowercaseString rangeOfString:q].location==NSNotFound)continue; if(_filter.selectedSegmentIndex==1&&!ABMediaFile(n))continue; if(_filter.selectedSegmentIndex==2&&!ABImageFile(n))continue; if(_filter.selectedSegmentIndex==3&&!ABSoftware(n))continue; [a addObject:f]; } _shown=a; _playlist=ABPlaylist(_files); BOOL playable=[self recommended]!=nil; _playButton.enabled=playable; [_playButton setTitle:playable?@"▶  播放推荐版本":(_loading?@"正在查找可播放版本…":@"当前文件中无原生可播放版本") forState:UIControlStateNormal]; [self.tableView reloadData];[self.view setNeedsLayout]; }
- (NSDictionary *)recommended {for(NSDictionary *f in _playlist)if(ABPlayable(ABString(f[@"name"])))return f;return nil;}
- (void)attachPlayer {
    if(!_inlinePlayer)return; _inlinePlayer.embeddedMode=YES; _inlinePlayer.returnedFromFullscreen=nil;
    [self addChildViewController:_inlinePlayer]; [_playerHost addSubview:_inlinePlayer.view]; _inlinePlayer.view.frame=_playerHost.bounds; _inlinePlayer.view.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; [_inlinePlayer didMoveToParentViewController:self];
}
- (void)play:(NSDictionary *)file {
    if([ABFloating shared].content&&[ABFloating shared].content!=_inlinePlayer)[[ABFloating shared] close];
    [self.view endEditing:YES];NSDictionary *resolved=ABCompatibleFile(file,_files);BOOL converted=resolved&&![ABString(resolved[@"name"]) isEqual:ABString(file[@"name"])];NSDictionary *chosen=resolved?:file;
    for(NSDictionary *f in _playlist)if([ABString(f[@"name"]) isEqual:ABString(chosen[@"name"])]){chosen=f;break;}
    _awaitingNext=NO; _currentFile=chosen;NSString *name=ABString(chosen[@"name"]),*title=ABString(chosen[@"title"]);if(!title.length)title=name;
    _nowPlaying.text=[NSString stringWithFormat:@"%@%@",converted?@"兼容衍生版 · ":@"正在播放 · ",title];_nowPlaying.hidden=NO;
    if(_inlinePlayer){if(_rateObserver){[_inlinePlayer.player removeTimeObserver:_rateObserver];_rateObserver=nil;}[_inlinePlayer loadURL:ABFileURL(_identifier,name) title:title];}else{_inlinePlayer=[[ABPlayer alloc] initWithURL:ABFileURL(_identifier,name) title:title privateMode:_privateMode];[self attachPlayer];}
    __weak ABItemController *owner=self;_rateObserver=[_inlinePlayer.player addPeriodicTimeObserverForInterval:CMTimeMakeWithSeconds(0.5,600) queue:dispatch_get_main_queue() usingBlock:^(CMTime t){[owner updateEqualizers];}];
    __weak ABItemController *weak=self;_inlinePlayer.finished=^{[weak playNext];};[_audioBar stop];[_audioBar removeFromSuperview];_audioBar=nil;
    if(ABAudioFile(name)){_audioBar=[[ABAudioBar alloc] initWithPlayer:_inlinePlayer.player];NSString *wave=ABString(chosen[@"_wave"]);[_audioBar setArtwork:wave.length?ABFileURL(_identifier,wave):nil];[_playerHost addSubview:_audioBar];}
    _playerHost.hidden=NO;_fullButton.hidden=NO;_closePlayerButton.hidden=NO;_settingsButton.hidden=NO;_pipButton.hidden=NO;[self.view setNeedsLayout];[self.view layoutIfNeeded];[self.tableView reloadData];
    if(!_inlinePlayer.presentingViewController&&!_floating&&!_fullStage)[self.tableView setContentOffset:CGPointMake(0,-self.tableView.contentInset.top) animated:YES];
}
- (void)choosePlayback:(NSDictionary *)file {if(ABPlayable(ABString(file[@"name"]))||ABCompatibleFile(file,_files)){[self play:file];return;}UIAlertController *a=[UIAlertController alertControllerWithTitle:@"此文件可能需要其他解码器" message:@"未在已加载文件中找到同内容的 MP4 / MP3 衍生版本。MPG、VOB 的 MPEG-1/2 视频与 TS 容器并不保证被 iOS 9 解码。可先加载更多文件、尝试系统播放，或下载后通过分享交给其他播放器。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[a addAction:[UIAlertAction actionWithTitle:@"尝试系统播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self play:file];}]];if(_more)[a addAction:[UIAlertAction actionWithTitle:@"加载更多文件" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self loadFiles];}]];[self presentViewController:a animated:YES completion:nil];}
- (NSUInteger)playingIndex {for(NSUInteger i=0;i<_playlist.count;i++)if([_playlist[i][@"name"] isEqual:_currentFile[@"name"]])return i;return NSNotFound;}
- (void)togglePlaylist {_playlistCollapsed=!_playlistCollapsed;[_playlistToggle setTitle:[NSString stringWithFormat:@"%@ 播放列表（%lu）",_playlistCollapsed?@"▸":@"▾",(unsigned long)_playlist.count] forState:UIControlStateNormal];[self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];[self.view setNeedsLayout];}
- (void)playPrevious {if(_playlist.count<3)return;NSUInteger i=[self playingIndex];if(i!=NSNotFound&&i>0)[self choosePlayback:_playlist[i-1]];}
- (void)playManualNext {if(_playlist.count<3)return;NSUInteger i=[self playingIndex];if(i==NSNotFound){[self playRecommended];return;}if(i+1<_playlist.count)[self choosePlayback:_playlist[i+1]];else if(_more){_awaitingNext=YES;[self loadFiles];}}
- (void)playNext {NSUInteger idx=NSNotFound;for(NSUInteger i=0;i<_playlist.count;i++)if([_playlist[i][@"name"] isEqual:_currentFile[@"name"]]){idx=i;break;}if(idx!=NSNotFound&&idx+1<_playlist.count){NSDictionary *f=_playlist[idx+1];if(ABPlayable(ABString(f[@"name"])))[self play:f];}else if(idx!=NSNotFound&&_more){_awaitingNext=YES;[self loadFiles];}}
- (CGRect)videoFrame:(CGRect)b {if(_aspect<2)return b;CGFloat ratio=_aspect==2?16.0/9.0:4.0/3.0;CGFloat w=b.size.width,h=w/ratio;if(h>b.size.height){h=b.size.height;w=h*ratio;}return CGRectMake((b.size.width-w)/2,(b.size.height-h)/2,w,h);}
- (void)playSettings {NSArray *names=@[@"适应（保持原比例）",@"拉伸（铺满窗口）",@"强制 16:9",@"强制 4:3"];UIAlertController *a=[UIAlertController alertControllerWithTitle:@"播放设置" message:@"画面尺寸在窗口、全屏及小窗中生效。小窗可在本 App 内跨页面播放；系统级画中画取决于设备支持。媒体缓存上限 64 MB，播放位置另外保存。" preferredStyle:UIAlertControllerStyleActionSheet];for(NSInteger i=0;i<4;i++)[a addAction:[UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@%@",i==_aspect?@"✓ ":@"",names[i]] style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){self.aspect=i;[[NSUserDefaults standardUserDefaults] setInteger:i forKey:@"videoAspect"];[self.view setNeedsLayout];}]];[a addAction:[UIAlertAction actionWithTitle:@"从头播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self.inlinePlayer restart];}]];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];ABPresentSheet(self,a,_settingsButton);}
- (void)detachPlayer {ABPlayer *p=_inlinePlayer;[p willMoveToParentViewController:nil];[p.view removeFromSuperview];[p removeFromParentViewController];}
- (void)enterFullscreen {if(!_inlinePlayer||_inlinePlayer.parentViewController!=self)return;[self detachPlayer];ABVideoStage *stage=[ABVideoStage new];stage.content=_inlinePlayer;stage.aspect=_aspect;_fullStage=stage;__weak ABItemController *weak=self;stage.returned=^{ABItemController *s=weak;if(s&&s.inlinePlayer){s.fullStage=nil;[s attachPlayer];[s.view setNeedsLayout];}};[self presentViewController:stage animated:YES completion:nil];}
- (void)floatPlayer {if(_privateMode||!_inlinePlayer||_inlinePlayer.parentViewController!=self||ABAudioFile(ABString(_currentFile[@"name"])))return;[self detachPlayer];_floating=YES;_playerHost.hidden=YES;[[ABFloating shared] show:_inlinePlayer owner:self aspect:_aspect restore:^{self.floating=NO;UINavigationController *nav=self.navigationController;if(nav){UITabBarController *tab=(id)[UIApplication sharedApplication].keyWindow.rootViewController;tab.selectedViewController=nav;[nav popToViewController:self animated:NO];}else{UITabBarController *tab=(id)[UIApplication sharedApplication].keyWindow.rootViewController;tab.selectedIndex=0;nav=tab.viewControllers[0];[nav pushViewController:self animated:NO];}self.playerHost.hidden=NO;[self attachPlayer];[self.view setNeedsLayout];} close:^{self.floating=NO;[self closePlayer];}];}
- (void)updateEqualizers {BOOL playing=_inlinePlayer.player.rate>0;for(UITableViewCell *cell in self.tableView.visibleCells)if([cell isKindOfClass:[ABResultCell class]]){ABResultCell *c=(id)cell;if(c.equalizer)c.equalizer.playing=playing&&self.view.window!=nil;}}
- (void)closePlayer {
    [_audioBar stop];[_audioBar removeFromSuperview];_audioBar=nil;_nowPlaying.hidden=YES;_awaitingNext=NO;_currentFile=nil;_inlinePlayer.finished=nil;
    if(_floating){_floating=NO;[[ABFloating shared] close];} [_inlinePlayer savePosition];if(_rateObserver){[_inlinePlayer.player removeTimeObserver:_rateObserver];_rateObserver=nil;}
    [_inlinePlayer.player pause]; if(_inlinePlayer.parentViewController==self) { [_inlinePlayer willMoveToParentViewController:nil]; [_inlinePlayer.view removeFromSuperview]; [_inlinePlayer removeFromParentViewController]; }
    _inlinePlayer.returnedFromFullscreen=nil; _inlinePlayer=nil; _playerHost.hidden=YES; _fullButton.hidden=YES; _closePlayerButton.hidden=YES;_settingsButton.hidden=YES;_pipButton.hidden=YES; [self.view setNeedsLayout];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if(!_inlinePlayer.presentingViewController && _inlinePlayer.parentViewController==self){[_inlinePlayer savePosition];[_inlinePlayer.player pause];}
}
- (void)playRecommended { NSDictionary *f=[self recommended]; if(f)[self play:f]; }
- (void)searchBar:(UISearchBar *)bar textDidChange:(NSString *)text { [self applyFilter]; }
- (void)searchBarSearchButtonClicked:(UISearchBar *)bar { [bar resignFirstResponder]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)table { return 3; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return section==0?(_playlistCollapsed?0:MAX((NSUInteger)1,_playlist.count)+(NSUInteger)(_playlist.count&&(_more||_failure!=nil))):section==1?MAX((NSUInteger)1,_collections.count):_shown.count+1; }
- (NSString *)tableView:(UITableView *)table titleForHeaderInSection:(NSInteger)section { return section==0?nil:section==1?@"IN COLLECTIONS · 所属合集":nil; }
- (CGFloat)tableView:(UITableView *)table heightForHeaderInSection:(NSInteger)section { return section==0?44:section==1?34:139; }
- (UIView *)tableView:(UITableView *)table viewForHeaderInSection:(NSInteger)section { return section==0?_playlistHeader:section==2?_filterHeader:nil; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path {
    if(path.section==0){ABResultCell *c=(id)[table dequeueReusableCellWithIdentifier:@"track"]?:[[ABResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"track"];c.thumb.image=nil;c.representedID=nil;c.accessoryType=UITableViewCellAccessoryNone;[c.equalizer removeFromSuperview];c.equalizer=nil;c.accessoryView=nil;
        if(!_playlist.count||path.row>=(NSInteger)_playlist.count){c.heading.text=_loading?@"正在读取播放列表…":(_failure?:(_more?@"加载更多曲目 / 分集":@"此条目没有音视频文件"));c.subheading.text=@"根据公开文件元数据生成 · 不重复列出不同编码版本";return c;}
        NSDictionary *f=_playlist[path.row];NSString *name=ABString(f[@"name"]),*key=[_identifier stringByAppendingString:name];c.representedID=key;c.heading.text=[NSString stringWithFormat:@"%@%@",@"",ABString(f[@"title"]).length?ABString(f[@"title"]):name];c.subheading.text=[NSString stringWithFormat:@"%@%@ · %@%@",ABString(f[@"track"]).length?[@"第 " stringByAppendingString:ABString(f[@"track"])]:@"",ABString(f[@"length"]).length?[@"  时长 " stringByAppendingString:ABDuration(f[@"length"])]:@"",ABString(f[@"format"]),ABPlayable(name)?@"":@" · 需兼容解码器"];
        if([_currentFile[@"name"] isEqual:name]){ABEqualizer *eq=[[ABEqualizer alloc] initWithFrame:CGRectMake(0,0,22,24)];eq.playing=_inlinePlayer.player.rate>0;c.equalizer=eq;c.accessoryView=eq;}
        __weak ABResultCell *cell=c;void(^show)(UIImage *)=^(UIImage *im){if([cell.representedID isEqual:key])cell.thumb.image=im;};NSString *art=ABString(f[@"_art"]);if(!art.length)art=ABString(f[@"_wave"]);if(art.length)[[ABImages shared] imageURL:ABFileURL(_identifier,art) completion:show];else [[ABImages shared] image:_identifier completion:show];return c;}
    if(path.section==1) {
        ABResultCell *c=(id)[table dequeueReusableCellWithIdentifier:@"collection"]?:[[ABResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"collection"];
        if(!_collections.count) { c.heading.text=_metadata?@"此条目没有合集资料":@"正在读取合集…"; c.subheading.text=@""; c.representedID=nil; c.thumb.image=nil; c.accessoryType=UITableViewCellAccessoryNone; return c; }
        NSString *identifier=_collections[path.row]; c.representedID=identifier; c.heading.text=_collectionTitles[identifier]?:identifier; c.subheading.text=@"浏览此合集的更多内容"; c.accessoryType=UITableViewCellAccessoryDisclosureIndicator; c.thumb.image=nil; __weak ABResultCell *cell=c; [[ABImages shared] image:identifier completion:^(UIImage *im){if([cell.representedID isEqual:identifier])cell.thumb.image=im;}]; return c;
    }
    UITableViewCell *c=[table dequeueReusableCellWithIdentifier:@"file"]?:[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"file"]; c.textLabel.font=[UIFont systemFontOfSize:15]; c.textLabel.numberOfLines=2; c.detailTextLabel.font=[UIFont systemFontOfSize:11]; c.detailTextLabel.textColor=[UIColor grayColor]; c.accessoryType=UITableViewCellAccessoryNone;
    if(path.row==(NSInteger)_shown.count) { c.textLabel.text=_loading?@"正在加载文件…":(_failure?:(_more?@"加载下一批文件":@"已加载全部文件")); c.textLabel.textColor=ABTint(); c.detailTextLabel.text=[NSString stringWithFormat:@"已加载 %lu%@ · 当前显示 %lu",(unsigned long)_files.count,_fileCount>=0?[NSString stringWithFormat:@" / %ld",(long)_fileCount]:@"",(unsigned long)_shown.count]; }
    else { NSDictionary *f=_shown[path.row]; NSString *n=ABString(f[@"name"]); c.textLabel.text=n; c.textLabel.textColor=ABPrivate(f)?[UIColor lightGrayColor]:[UIColor darkTextColor]; c.detailTextLabel.text=[NSString stringWithFormat:@"%@ · %@%@",ABString(f[@"format"]),ABSize([ABString(f[@"size"]) longLongValue]),ABPrivate(f)?@" · 受限":(ABPlayable(n)?@" · 可尝试播放":@"")]; c.accessoryType=UITableViewCellAccessoryDisclosureIndicator; } return c;
}
- (CGFloat)tableView:(UITableView *)table heightForRowAtIndexPath:(NSIndexPath *)path { return path.section<2?84:68; }
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path {
    [table deselectRowAtIndexPath:path animated:YES]; [self.view endEditing:YES];
    if(path.section==0){if(!_playlist.count||path.row>=(NSInteger)_playlist.count){if(!_loading&&(_more||_failure))[self loadFiles];return;}NSDictionary *f=_playlist[path.row];[self choosePlayback:f];return;}
    if(path.section==1) { if(_collections.count) { NSString *identifier=_collections[path.row]; ABBrowseController *c=[[ABBrowseController alloc] initWithCollection:identifier title:_collectionTitles[identifier]?:identifier];c.privateMode=self.privateMode;[self.navigationController pushViewController:c animated:YES]; } return; }
    if(path.row==(NSInteger)_shown.count) { if(_more||_failure)[self loadFiles]; return; }
    NSDictionary *f=_shown[path.row]; if(ABPrivate(f)) { ABAlert(self,@"受限文件",@"此文件需要在官方网站取得访问权限，本 App 只下载公开文件。"); return; }
    NSString *name=ABString(f[@"name"]); UIAlertController *a=[UIAlertController alertControllerWithTitle:name message:[NSString stringWithFormat:@"%@ · %@",ABString(f[@"format"]),ABSize([ABString(f[@"size"]) longLongValue])] preferredStyle:UIAlertControllerStyleActionSheet];
    if(ABMediaFile(name))[a addAction:[UIAlertAction actionWithTitle:@"在内置窗口播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){dispatch_async(dispatch_get_main_queue(),^{[self choosePlayback:f];});}]];
    if(ABImageFile(name))[a addAction:[UIAlertAction actionWithTitle:@"查看图片 / 动图" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self.navigationController pushViewController:[[ABImageController alloc] initWithURL:ABFileURL(self.identifier,name) title:name] animated:YES];}]];
    if(!_privateMode)[a addAction:[UIAlertAction actionWithTitle:@"下载到本机" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){NSDictionary *r=[[ABDownloads shared] add:self.identifier file:f title:ABString(self.metadata[@"title"]).length?ABString(self.metadata[@"title"]):self.identifier]; if(r){self.tabBarController.selectedIndex=1;UINavigationController *nav=self.tabBarController.viewControllers[1];[nav popToRootViewControllerAnimated:NO];[nav pushViewController:[ABDownloadController new] animated:YES];}}]];
    [a addAction:[UIAlertAction actionWithTitle:@"复制文件直链" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[UIPasteboard generalPasteboard].string=ABFileURL(self.identifier,name).absoluteString;}]];
    [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; ABPresentSheet(self,a,[table cellForRowAtIndexPath:path]);
}
- (void)dealloc {[[NSNotificationCenter defaultCenter] removeObserver:self];if(_rateObserver)[_inlinePlayer.player removeTimeObserver:_rateObserver];[_audioBar stop]; [_inlinePlayer savePosition];[_inlinePlayer.player pause]; for(NSURLSessionTask *r in _requests)[r cancel]; }
@end

@interface ABDownloadController () <QLPreviewControllerDataSource>
@property(nonatomic,strong) NSURL *previewURL;
@property(nonatomic,strong) UILabel *empty;
@end
@implementation ABDownloadController
- (void)viewDidLoad { [super viewDidLoad]; self.navigationItem.title=@"下载"; self.tableView.rowHeight=82; self.tableView.tableFooterView=[UIView new]; self.navigationItem.rightBarButtonItem=self.editButtonItem; self.editButtonItem.title=@"编辑"; [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changed:) name:ABDownloadsChanged object:nil]; _empty=ABLabel(CGRectMake(20,0,self.view.bounds.size.width-40,160),16,NO); _empty.numberOfLines=3; _empty.textAlignment=NSTextAlignmentCenter; _empty.textColor=[UIColor grayColor]; _empty.text=@"还没有下载\n在条目文件中选择“下载到本机”\n完成后可播放、预览或分享文件"; [self changed:nil]; }
- (void)setEditing:(BOOL)editing animated:(BOOL)animated { [super setEditing:editing animated:animated]; self.editButtonItem.title=editing?@"完成":@"编辑"; }
- (void)changed:(NSNotification *)note { self.tableView.backgroundView=[ABDownloads shared].records.count?nil:_empty; [self.tableView reloadData]; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return [ABDownloads shared].records.count; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path { ABThumbCell *c=(id)[table dequeueReusableCellWithIdentifier:@"download"]?:[[ABThumbCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"download"]; NSDictionary *r=[ABDownloads shared].records[path.row]; c.entry=r; c.textLabel.text=ABString(r[@"name"]); c.textLabel.font=[UIFont systemFontOfSize:15]; c.textLabel.numberOfLines=2; c.detailTextLabel.font=[UIFont systemFontOfSize:11]; NSString *status=r[@"status"]; NSString *state=@{@"complete":@"已完成",@"downloading":@"下载中",@"waiting":@"等待中",@"paused":@"已暂停",@"failed":@"失败，点击重试"}[status]?:status; long long total=[r[@"total"] longLongValue], bytes=[r[@"bytes"] longLongValue]; c.detailTextLabel.text=[NSString stringWithFormat:@"%@ · %@ / %@\n%@",state,ABSize(bytes),ABSize(total),[status isEqual:@"failed"]?ABString(r[@"error"]):ABString(r[@"title"])]; c.detailTextLabel.numberOfLines=2; c.accessoryType=UITableViewCellAccessoryDisclosureIndicator; return c; }
- (void)tableView:(UITableView *)table commitEditingStyle:(UITableViewCellEditingStyle)style forRowAtIndexPath:(NSIndexPath *)path { NSDictionary *r=[ABDownloads shared].records[path.row]; UIAlertController *a=[UIAlertController alertControllerWithTitle:@"删除下载？" message:ABString(r[@"name"]) preferredStyle:UIAlertControllerStyleAlert]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; [a addAction:[UIAlertAction actionWithTitle:@"删除" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){[[ABDownloads shared] remove:r];}]]; [self presentViewController:a animated:YES completion:nil]; }
- (void)share:(NSURL *)url anchor:(UIView *)view { UIActivityViewController *a=[[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil]; a.popoverPresentationController.sourceView=view; a.popoverPresentationController.sourceRect=view.bounds; [self presentViewController:a animated:YES completion:nil]; }
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)path { [table deselectRowAtIndexPath:path animated:YES]; NSDictionary *r=[ABDownloads shared].records[path.row]; BOOL complete=[r[@"status"] isEqual:@"complete"]; UIAlertController *a=[UIAlertController alertControllerWithTitle:ABString(r[@"name"]) message:ABString(r[@"title"]) preferredStyle:UIAlertControllerStyleActionSheet]; NSURL *url=[[ABDownloads shared] localURL:r]; UIView *anchor=[table cellForRowAtIndexPath:path];
    if(complete) { if(ABPlayable(ABString(r[@"name"]))) [a addAction:[UIAlertAction actionWithTitle:@"离线播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self presentViewController:[[ABPlayer alloc] initWithURL:url title:ABString(r[@"name"])] animated:YES completion:nil];}]]; [a addAction:[UIAlertAction actionWithTitle:@"预览文件" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){if(ABImageFile(ABString(r[@"name"]))){[self.navigationController pushViewController:[[ABImageController alloc] initWithURL:url title:ABString(r[@"name"])] animated:YES];return;} self.previewURL=url; QLPreviewController *p=[QLPreviewController new]; p.dataSource=self; [self.navigationController pushViewController:p animated:YES];}]]; [a addAction:[UIAlertAction actionWithTitle:@"分享 / 在其他应用打开" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self share:url anchor:anchor];}]]; }
    else [a addAction:[UIAlertAction actionWithTitle:[r[@"status"] isEqual:@"downloading"]?@"暂停下载":([r[@"status"] isEqual:@"paused"]?@"继续下载":@"重新下载") style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[[ABDownloads shared] toggle:r];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"查看来源条目" style:UIAlertActionStyleDefault handler:^(UIAlertAction *x){[self.navigationController pushViewController:[[ABItemController alloc] initWithIdentifier:r[@"identifier"]] animated:YES];}]];
    [a addAction:[UIAlertAction actionWithTitle:@"删除文件及任务" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){[[ABDownloads shared] remove:r];}]]; [a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]]; ABPresentSheet(self,a,anchor);
}
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller { return _previewURL?1:0; }
- (id<QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index { return _previewURL; }
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
@end

static NSAttributedString *ABHelpBody(NSString *text) {
    NSMutableParagraphStyle *style=[NSMutableParagraphStyle new]; style.lineSpacing=4;
    return [[NSAttributedString alloc] initWithString:text attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15],NSForegroundColorAttributeName:[UIColor colorWithWhite:0.35 alpha:1],NSParagraphStyleAttributeName:style}];
}
@interface ABHelpCell : UITableViewCell
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) UILabel *body;
@end
@implementation ABHelpCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuse {
    if((self=[super initWithStyle:style reuseIdentifier:reuse])) { _heading=ABLabel(CGRectZero,17,YES); _heading.numberOfLines=0; _body=ABLabel(CGRectZero,15,NO); _body.numberOfLines=0; [self.contentView addSubview:_heading]; [self.contentView addSubview:_body]; self.selectionStyle=UITableViewCellSelectionStyleNone; } return self;
}
- (void)layoutSubviews { [super layoutSubviews]; CGFloat w=self.contentView.bounds.size.width-40; CGFloat h=[_heading sizeThatFits:CGSizeMake(w,CGFLOAT_MAX)].height; _heading.frame=CGRectMake(20,16,w,h); _body.frame=CGRectMake(20,24+h,w,[_body sizeThatFits:CGSizeMake(w,CGFLOAT_MAX)].height); }
@end

@implementation ABAboutController { CGFloat _lastWidth; }
- (instancetype)init { return [super initWithStyle:UITableViewStyleGrouped]; }
- (void)viewDidLoad { [super viewDidLoad]; self.title=@"使用说明"; self.tableView.estimatedRowHeight=110; self.tableView.rowHeight=UITableViewAutomaticDimension; self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStyleDone target:self action:@selector(close)]; }
- (void)close { [self dismissViewControllerAnimated:YES completion:nil]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)table { return 6; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return 1; }
- (NSArray *)titles {
    return @[@"Archive Browser · 存档浏览器 0.5.0",@"搜索得更准确",@"发现相似内容",@"窗口播放与全屏",@"下载与分享",@"文件位置与兼容性"];
}
- (NSArray *)descriptions {
    NSArray *text=@[@"面向旧 iPhone / iPad 的非官方 Internet Archive 客户端。浏览公开存档，适用 iOS 9 及以上。",@"默认优先匹配标题，并要求包含所有关键词。高级搜索可以选择相关性、收录时间或作品日期排序，以及仅搜标题。后缀筛选已移除，结果直接来自站点索引。下拉可重新搜索。",@"条目中的 IN COLLECTIONS 展示所属合集。点击后即可浏览更多内容，并在该合集内继续搜索。合集可单独收藏，默认最新收录优先，下拉刷新。个人收藏夹可新建、命名、编辑，位于“本地 → 收藏”；历史最多保留 30 项。",@"点击播放后先在条目内显示播放器，可以拖动进度或切换全屏。窗口和全屏共用播放进度。下方播放列表按曲目排序，合并同源编码版本，可自动续播下一项。音频用条状控件，有附带频谱图则显示静态图。PNG/JPEG/GIF 可查看与缩放。优先选较小的 MP4、MP3 或 M4A；是否能播放仍取决于文件内部编码和网络。",@"文件支持系统后台下载、暂停、继续和删除。下载完成后可离线播放、预览，或分享到 Filza 等应用。强制划掉 App 可能导致任务被系统取消，重新打开后可重试。不会自动安装软件或绕过受限条目。",[NSString stringWithFormat:@"%@/Downloads\n\n普通安装时支持 iTunes 文件共享。缩略图磁盘缓存最多 8 MB、内存最多 1.5 MB。媒体分段缓存另有 64 MB 上限；播放进度单独保存。小窗可在 App 内跨页面播放。MPG/VOB/TS 等原件优先匹配同内容的兼容衍生版；没有衍生版时可尝试系统播放或下载给其他播放器。未内置 MPEG-1/2、HEVC、AV1 软件解码器。图片预览上限 20 MB，最大解码边长 1280；GIF 按原帧延时逐帧解码。当前不提供登录、解压或转码。",ABDocuments()]];
    return text;
}
- (CGFloat)tableView:(UITableView *)table heightForHeaderInSection:(NSInteger)section { return section?12:20; }
- (CGFloat)tableView:(UITableView *)table heightForFooterInSection:(NSInteger)section { return 8; }
- (CGFloat)tableView:(UITableView *)table heightForRowAtIndexPath:(NSIndexPath *)p {
    CGFloat w=table.bounds.size.width-40;
    CGFloat heading=[self.titles[p.section] boundingRectWithSize:CGSizeMake(w,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:17]} context:nil].size.height;
    CGFloat body=[ABHelpBody(self.descriptions[p.section]) boundingRectWithSize:CGSizeMake(w,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading context:nil].size.height;
    return ceil(heading)+ceil(body)+44;
}
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)path {
    ABHelpCell *c=(id)[table dequeueReusableCellWithIdentifier:@"help"]?:[[ABHelpCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"help"];
    c.heading.text=self.titles[path.section]; c.body.attributedText=ABHelpBody(self.descriptions[path.section]); return c;
}
- (void)viewDidLayoutSubviews { [super viewDidLayoutSubviews]; if(_lastWidth!=self.tableView.bounds.size.width) { _lastWidth=self.tableView.bounds.size.width; [self.tableView reloadData]; } }
@end
