#import "ABVault.h"
#import <Security/Security.h>
#import <objc/runtime.h>
#import <CommonCrypto/CommonCrypto.h>
NSString * const ABVaultChanged=@"ABVaultChanged";
NSString * const ABPrivateFolderID=@"__private__";
static BOOL ABDigits(NSString *s,NSUInteger count){return s.length==count&&[s rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet]].location==NSNotFound;}
static NSData *ABRandom(NSUInteger length){NSMutableData *d=[NSMutableData dataWithLength:length];return SecRandomCopyBytes(kSecRandomDefault,length,d.mutableBytes)==errSecSuccess?d:nil;}
static NSData *ABDerive(NSString *pin,NSData *salt){if(![salt isKindOfClass:[NSData class]]||salt.length!=16)return nil;NSData *password=[pin dataUsingEncoding:NSUTF8StringEncoding];NSMutableData *key=[NSMutableData dataWithLength:64];int r=CCKeyDerivationPBKDF(kCCPBKDF2,password.bytes,password.length,salt.bytes,salt.length,kCCPRFHmacAlgSHA256,50000,key.mutableBytes,key.length);return r==kCCSuccess?key:nil;}
static NSData *ABMAC(NSData *key,NSData *iv,NSData *cipher){if(key.length!=64)return nil;NSMutableData *data=[iv mutableCopy];[data appendData:cipher];unsigned char mac[CC_SHA256_DIGEST_LENGTH];CCHmac(kCCHmacAlgSHA256,(const char *)key.bytes+32,32,data.bytes,data.length,mac);return [NSData dataWithBytes:mac length:sizeof mac];}
static BOOL ABEqual(NSData *a,NSData *b){if(a.length!=b.length||!a.length)return NO;const unsigned char *x=a.bytes,*y=b.bytes;unsigned char difference=0;for(NSUInteger i=0;i<a.length;i++)difference|=x[i]^y[i];return difference==0;}
static NSDictionary *ABEncrypt(NSData *plain,NSData *key){if(!plain||key.length!=64)return nil;NSData *iv=ABRandom(16);if(!iv)return nil;NSMutableData *out=[NSMutableData dataWithLength:plain.length+kCCBlockSizeAES128];size_t used=0;CCCryptorStatus s=CCCrypt(kCCEncrypt,kCCAlgorithmAES,kCCOptionPKCS7Padding,key.bytes,32,iv.bytes,plain.bytes,plain.length,out.mutableBytes,out.length,&used);if(s!=kCCSuccess)return nil;out.length=used;return @{@"iv":iv,@"cipher":out,@"mac":ABMAC(key,iv,out)};}
static NSData *ABDecrypt(NSDictionary *box,NSData *key){if(![box isKindOfClass:[NSDictionary class]]||key.length!=64)return nil;NSData *iv=box[@"iv"],*cipher=box[@"cipher"],*mac=box[@"mac"];if(![iv isKindOfClass:[NSData class]]||iv.length!=16||![cipher isKindOfClass:[NSData class]]||!cipher.length||![mac isKindOfClass:[NSData class]]||!ABEqual(mac,ABMAC(key,iv,cipher)))return nil;NSMutableData *out=[NSMutableData dataWithLength:cipher.length];size_t used=0;CCCryptorStatus s=CCCrypt(kCCDecrypt,kCCAlgorithmAES,kCCOptionPKCS7Padding,key.bytes,32,iv.bytes,cipher.bytes,cipher.length,out.mutableBytes,out.length,&used);if(s!=kCCSuccess)return nil;out.length=used;return out;}
static NSArray *ABVaultEntries(id value){if(![value isKindOfClass:[NSArray class]])return nil;NSMutableArray *out=[NSMutableArray array];NSMutableSet *have=[NSMutableSet set];for(id e in value){if(![e isKindOfClass:[NSDictionary class]]||!ABIdentifier(ABString(e[@"identifier"])))return nil;NSString *i=e[@"identifier"];if([have containsObject:i])continue;NSMutableDictionary *copy=[NSMutableDictionary dictionary];for(NSString *k in @[@"identifier",@"title",@"mediatype",@"name"])copy[k]=ABString(e[k]);copy[@"collection"]=@([e[@"collection"] respondsToSelector:@selector(boolValue)]&&[e[@"collection"] boolValue]);[out addObject:copy];[have addObject:i];}return out;}
@interface ABVault ()
@property(nonatomic,copy) NSString *path;
@property(nonatomic,strong) NSDictionary *document;
@property(nonatomic,strong) NSMutableData *master;
@property(nonatomic,strong) NSArray *entries;
@property(nonatomic,copy) NSString *error;
@property(nonatomic) BOOL busy;
@property(nonatomic) BOOL corrupt;
@property(nonatomic) BOOL unlocked;
@property(nonatomic) NSUInteger generation;
@end
#ifdef AB_TESTING
static ABVault *ABTestingVault;
void ABUseTestVault(ABVault *vault){ABTestingVault=vault;}
#endif
@implementation ABVault
+ (instancetype)shared{
#ifdef AB_TESTING
if(ABTestingVault)return ABTestingVault;
#endif
static ABVault *s;static dispatch_once_t once;dispatch_once(&once,^{s=[[self alloc] initWithPath:[ABDocuments() stringByAppendingPathComponent:@"private-vault.plist"]];});return s;}
- (instancetype)initWithPath:(NSString *)path{if((self=[super init])){_path=path;_entries=@[];NSData *d=[NSData dataWithContentsOfFile:path];id value=d?[NSPropertyListSerialization propertyListWithData:d options:NSPropertyListImmutable format:NULL error:nil]:nil;_document=[value isKindOfClass:[NSDictionary class]]?value:@{};if(d&&(![value isKindOfClass:[NSDictionary class]]||![_document[@"version"] isKindOfClass:[NSNumber class]]||[_document[@"version"] integerValue]!=1)){_corrupt=YES;_error=@"私密收藏文件损坏，无法解锁；可以选择销毁重建。";}}return self;}
- (BOOL)configured{return _document[@"payload"]!=nil||_corrupt;}
- (NSInteger)failures{if(_corrupt)return 5;id count=_document[@"failures"];if(count&&![count isKindOfClass:[NSNumber class]])return 5;return MAX(0,MIN(5,[count integerValue]));}
- (BOOL)write:(NSDictionary *)document{NSError *error=nil;NSData *d=[NSPropertyListSerialization dataWithPropertyList:document format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];if(!d||![d writeToFile:_path options:NSDataWritingAtomic error:&error]){_error=error.localizedDescription?:@"无法保存私密收藏";return NO;}[[NSFileManager defaultManager] setAttributes:@{NSFilePosixPermissions:@0600,NSFileProtectionKey:NSFileProtectionComplete} ofItemAtPath:_path error:nil];_document=document;return YES;}
- (void)publish{[[NSNotificationCenter defaultCenter] postNotificationName:ABVaultChanged object:self];}
- (void)createPIN:(NSString *)pin recovery:(NSString *)recovery completion:(void (^)(BOOL))completion{
 if(_busy||self.configured||!ABDigits(pin,4)||!ABDigits(recovery,6)){_error=@"请输入四位密码和六位恢复密码。";completion(NO);return;}_busy=YES;NSUInteger generation=_generation;dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{NSData *master=ABRandom(64),*s4=ABRandom(16),*s6=ABRandom(16);NSDictionary *wrap4=ABEncrypt(master,ABDerive(pin,s4)),*wrap6=ABEncrypt(master,ABDerive(recovery,s6));NSData *plain=[NSJSONSerialization dataWithJSONObject:@[] options:0 error:nil];NSDictionary *payload=ABEncrypt(plain,master);dispatch_async(dispatch_get_main_queue(),^{self.busy=NO;if(generation!=self.generation){completion(NO);return;}if(!master||!wrap4||!wrap6||!payload){self.error=@"无法建立加密收藏，请稍后再试。";completion(NO);return;}NSDictionary *d=@{@"version":@1,@"failures":@0,@"salt4":s4,@"salt6":s6,@"wrap4":wrap4,@"wrap6":wrap6,@"payload":payload};if([self write:d]){self.master=[master mutableCopy];self.entries=@[];self.unlocked=YES;self.error=nil;[self publish];completion(YES);}else completion(NO);});});
}
- (void)unlockPIN:(NSString *)pin recovery:(BOOL)recovery completion:(void (^)(BOOL))completion{
 if(_busy||!self.configured||!ABDigits(pin,recovery?6:4)||(!recovery&&self.failures>=5)){_error=(!recovery&&self.failures>=5)?@"四位密码已停用，请输入六位恢复密码或销毁重建。":@"密码格式不正确。";completion(NO);return;}
 if(!recovery){NSMutableDictionary *count=[_document mutableCopy];count[@"failures"]=@(MIN(5,self.failures+1));if(![self write:count]){completion(NO);return;}}
 _busy=YES;NSUInteger generation=_generation;NSDictionary *d=_document;dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0),^{NSData *key=ABDerive(pin,d[recovery?@"salt6":@"salt4"]),*master=ABDecrypt(d[recovery?@"wrap6":@"wrap4"],key);NSData *plain=ABDecrypt(d[@"payload"],master);id array=plain?[NSJSONSerialization JSONObjectWithData:plain options:0 error:nil]:nil;NSArray *entries=ABVaultEntries(array);dispatch_async(dispatch_get_main_queue(),^{self.busy=NO;if(generation!=self.generation){completion(NO);return;}if(!master||!entries){self.error=recovery?@"恢复密码不正确，或私密收藏文件损坏。":self.failures>=5?@"已连续出错 5 次，四位密码已停用。":self.failures==4?@"已连续出错 4 次；再错一次将停用四位密码。":@"密码不正确，请重试。";[self publish];completion(NO);return;}NSMutableDictionary *state=[self.document mutableCopy];state[@"failures"]=@0;if(![self write:state]){completion(NO);return;}self.master=[master mutableCopy];self.entries=entries;self.unlocked=YES;self.error=nil;[self publish];completion(YES);});});
}
- (void)lock{BOOL notify=_unlocked||_master.length>0;_generation++;if(_master.length)memset(_master.mutableBytes,0,_master.length);_master=nil;_entries=@[];_unlocked=NO;if(notify)[self publish];}
- (BOOL)replaceEntries:(NSArray *)entries{if(!_unlocked||_master.length!=64)return NO;NSArray *valid=ABVaultEntries(entries);if(!valid)return NO;NSData *data=[NSJSONSerialization dataWithJSONObject:valid options:0 error:nil];NSDictionary *payload=ABEncrypt(data,_master);if(!payload)return NO;NSMutableDictionary *d=[_document mutableCopy];d[@"payload"]=payload;if(![self write:d])return NO;_entries=valid;[self publish];return YES;}
- (BOOL)setEntry:(NSDictionary *)entry present:(BOOL)present{if(!_unlocked||!ABIdentifier(ABString(entry[@"identifier"])))return NO;NSMutableArray *a=[_entries mutableCopy];NSIndexSet *i=[a indexesOfObjectsPassingTest:^BOOL(NSDictionary *e,NSUInteger index,BOOL *stop){return [e[@"identifier"] isEqual:entry[@"identifier"]];}];[a removeObjectsAtIndexes:i];if(present)[a addObject:entry];return [self replaceEntries:a];}
- (BOOL)destroy{if(_busy)return NO;NSDictionary *empty=@{@"version":@1,@"failures":@0};if(![self write:empty])return NO;_error=nil;_corrupt=NO;[self lock];return YES;}
@end
BOOL ABPrivateActive(void){return [ABVault shared].unlocked;}

static char ABClosingKey;
void ABClosePrivateBranch(UIViewController *controller,void(^closed)(void)) {
    UINavigationController *nav=[controller isKindOfClass:[UINavigationController class]]?(id)controller:controller.navigationController;
    if(!nav){if(closed)closed();return;}
    NSMutableArray *callbacks=objc_getAssociatedObject(nav,&ABClosingKey);if(callbacks){if(closed)[callbacks addObject:[closed copy]];return;}
    callbacks=[NSMutableArray array];if(closed)[callbacks addObject:[closed copy]];objc_setAssociatedObject(nav,&ABClosingKey,callbacks,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    void(^finish)(void)=^{if(!ABPrivateActive())[nav popToRootViewControllerAnimated:NO];NSArray *blocks=[objc_getAssociatedObject(nav,&ABClosingKey) copy];objc_setAssociatedObject(nav,&ABClosingKey,nil,OBJC_ASSOCIATION_RETAIN_NONATOMIC);for(void(^block)(void) in blocks)block();};
    dispatch_async(dispatch_get_main_queue(),^{UIViewController *top=nav.topViewController;UIViewController *popup=top.presentedViewController;void(^dismiss)(void)=^{if(top.presentedViewController)[top dismissViewControllerAnimated:NO completion:finish];else finish();};id<UIViewControllerTransitionCoordinator> coordinator=popup.transitionCoordinator;if(popup.isBeingPresented&&coordinator){[coordinator animateAlongsideTransition:nil completion:^(id<UIViewControllerTransitionCoordinatorContext> context){dispatch_async(dispatch_get_main_queue(),dismiss);}];}else dismiss();});
}
@interface ABVaultGate : UITableViewController <UITextFieldDelegate>
@property(nonatomic,copy) void (^opened)(void);
@property(nonatomic,strong) UITextField *pin;
@property(nonatomic,strong) UITextField *confirmPIN;
@property(nonatomic,strong) UITextField *recovery;
@property(nonatomic,strong) UITextField *confirmRecovery;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic) BOOL recovering;
@end
@implementation ABVaultGate
- (UITextField *)field:(NSString *)placeholder{UITextField *f=[UITextField new];f.secureTextEntry=YES;f.keyboardType=UIKeyboardTypeNumberPad;f.placeholder=placeholder;f.font=[UIFont systemFontOfSize:18];f.delegate=self;f.autocorrectionType=UITextAutocorrectionTypeNo;return f;}
- (void)viewDidLoad{[super viewDidLoad];self.title=@"私密收藏";self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(cancel)];self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"确定" style:UIBarButtonItemStyleDone target:self action:@selector(submit)];_pin=[self field:@"四位密码"];_confirmPIN=[self field:@"再次输入四位密码"];_recovery=[self field:@"六位恢复密码"];_confirmRecovery=[self field:@"再次输入六位恢复密码"];self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag;}
- (BOOL)textField:(UITextField *)f shouldChangeCharactersInRange:(NSRange)r replacementString:(NSString *)s{NSString *text=[f.text stringByReplacingCharactersInRange:r withString:s];NSUInteger max=f==_pin||f==_confirmPIN?4:6;return text.length<=max&&[text rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet]].location==NSNotFound;}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)t{return 2;}
- (NSInteger)tableView:(UITableView *)t numberOfRowsInSection:(NSInteger)section{if(section==1)return [ABVault shared].configured?2:0;return ![ABVault shared].configured?4:1;}
- (CGFloat)tableView:(UITableView *)t heightForRowAtIndexPath:(NSIndexPath *)p{return 54;}
- (NSString *)tableView:(UITableView *)t titleForHeaderInSection:(NSInteger)s{return s?nil:![ABVault shared].configured?@"首次设置":_recovering||[ABVault shared].failures>=5?@"六位恢复密码":@"四位密码";}
- (NSString *)tableView:(UITableView *)t titleForFooterInSection:(NSInteger)s{if(s)return nil;ABVault *v=[ABVault shared];if(!v.configured)return @"四位密码用于日常进入；六位恢复密码用于解锁被停用的四位密码。两者均由你在此独立设置，应用无法读取或验证设备锁屏密码。请记住恢复密码，丢失后只能销毁私密收藏并重建。";return v.failures>=5?@"四位密码已停用，重启应用也不会恢复尝试次数。输入六位恢复密码，或选择销毁重建。":v.failures==4?@"已出错 4 次；下一次再错，四位密码将被停用。":@"连续输错 5 次会停用四位密码。离开私密收藏或切到后台会自动锁定。";}
- (UITableViewCell *)tableView:(UITableView *)t cellForRowAtIndexPath:(NSIndexPath *)p{UITableViewCell *c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];if(p.section==1){c.textLabel.text=p.row==0?@"使用六位恢复密码":@"销毁私密收藏并重建";c.textLabel.textColor=p.row==1?[UIColor redColor]:ABTint();return c;}UITextField *f=![ABVault shared].configured?@[_pin,_confirmPIN,_recovery,_confirmRecovery][p.row]:(_recovering||[ABVault shared].failures>=5?_recovery:_pin);f.translatesAutoresizingMaskIntoConstraints=NO;[c.contentView addSubview:f];[c.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-16-[field]-16-|" options:0 metrics:nil views:@{@"field":f}]];[c.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[field]|" options:0 metrics:nil views:@{@"field":f}]];return c;}
- (void)tableView:(UITableView *)t didSelectRowAtIndexPath:(NSIndexPath *)p{[t deselectRowAtIndexPath:p animated:YES];if(p.section!=1||[ABVault shared].busy)return;if(p.row==0){_recovering=YES;_pin.text=@"";[t reloadData];return;}UIAlertController *a=[UIAlertController alertControllerWithTitle:@"销毁私密收藏并重建？" message:@"将永久丢弃私密收藏的密码和全部收藏记录。普通收藏、历史和下载文件不受影响。此操作无法撤销。" preferredStyle:UIAlertControllerStyleAlert];[a addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];[a addAction:[UIAlertAction actionWithTitle:@"销毁并重新设置" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *x){if([[ABVault shared] destroy]){self.recovering=NO;self.pin.text=self.recovery.text=self.confirmPIN.text=self.confirmRecovery.text=@"";[self.tableView reloadData];}else ABAlert(self,@"无法销毁",[ABVault shared].error);}]];[self presentViewController:a animated:YES completion:nil];}
- (void)submit{ABVault *v=[ABVault shared];if(v.busy)return;BOOL create=!v.configured,recover=_recovering||v.failures>=5;if(create&&(![_pin.text isEqual:_confirmPIN.text]||![_recovery.text isEqual:_confirmRecovery.text])){ABAlert(self,@"两次输入不一致",@"请分别确认四位密码与六位恢复密码。");return;}NSString *pin=create?_pin.text:(recover?_recovery.text:_pin.text),*recovery=_recovery.text;if(!ABDigits(pin,recover&&!create?6:4)||(create&&!ABDigits(recovery,6))){ABAlert(self,@"密码位数",@"请输入四位数字密码；恢复密码需要六位数字。");return;}[self.view endEditing:YES];self.navigationItem.rightBarButtonItem.enabled=NO;self.navigationItem.leftBarButtonItem.enabled=NO;__weak ABVaultGate *weak=self;void(^done)(BOOL)=^(BOOL ok){ABVaultGate *s=weak;if(!s)return;s.navigationItem.rightBarButtonItem.enabled=s.navigationItem.leftBarButtonItem.enabled=YES;s.pin.text=s.recovery.text=s.confirmPIN.text=s.confirmRecovery.text=@"";if(ok){void(^opened)(void)=s.opened;[s dismissViewControllerAnimated:YES completion:^{if(opened&&ABPrivateActive())opened();}];}else{[s.tableView reloadData];ABAlert(s,@"未能解锁",v.error?:@"操作已取消，请重新尝试。");}};if(create)[v createPIN:pin recovery:recovery completion:done];else [v unlockPIN:pin recovery:recover completion:done];}
- (void)cancel{[self dismissViewControllerAnimated:YES completion:nil];}
@end
void ABUnlockPrivate(UIViewController *presenter,void(^opened)(void)){if([ABVault shared].unlocked){if(opened)opened();return;}ABVaultGate *g=[[ABVaultGate alloc] initWithStyle:UITableViewStyleGrouped];g.opened=opened;UINavigationController *n=[[UINavigationController alloc] initWithRootViewController:g];n.modalPresentationStyle=UIModalPresentationFormSheet;n.preferredContentSize=CGSizeMake(540,600);[presenter presentViewController:n animated:YES completion:nil];}
