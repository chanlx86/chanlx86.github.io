#import "ABCore.h"
extern NSString * const ABVaultChanged;
extern NSString * const ABPrivateFolderID;
@interface ABVault : NSObject
+ (instancetype)shared;
- (instancetype)initWithPath:(NSString *)path;
@property(nonatomic,readonly) BOOL configured;
@property(nonatomic,readonly) BOOL unlocked;
@property(nonatomic,readonly) BOOL busy;
@property(nonatomic,readonly) NSInteger failures;
@property(nonatomic,readonly) NSArray *entries;
@property(nonatomic,readonly) NSString *error;
- (void)createPIN:(NSString *)pin recovery:(NSString *)recovery completion:(void (^)(BOOL))completion;
- (void)unlockPIN:(NSString *)pin recovery:(BOOL)recovery completion:(void (^)(BOOL))completion;
- (void)lock;
- (BOOL)setEntry:(NSDictionary *)entry present:(BOOL)present;
- (BOOL)replaceEntries:(NSArray *)entries;
- (BOOL)destroy;
@end
void ABUnlockPrivate(UIViewController *presenter, void (^opened)(void));
BOOL ABPrivateActive(void);
void ABClosePrivateBranch(UIViewController *controller, void (^closed)(void));

#ifdef AB_TESTING
void ABUseTestVault(ABVault *vault);
#endif
