// Diagnostic helper only. Uses the same system media-command transport as Control Center.
#import <Foundation/Foundation.h>
#import <dlfcn.h>
int main(int argc,char **argv){@autoreleasepool{
 if(argc!=3)return 2;int expected=atoi(argv[1]),command=atoi(argv[2]);if(command!=4&&command!=5)return 2;
 void *lib=dlopen("/System/Library/PrivateFrameworks/MediaRemote.framework/MediaRemote",RTLD_NOW);
 void(*getPID)(dispatch_queue_t,void(^)(int))=dlsym(lib,"MRMediaRemoteGetNowPlayingApplicationPID");
 Boolean(*send)(int,NSDictionary *)=dlsym(lib,"MRMediaRemoteSendCommand");if(!getPID||!send)return 3;
 dispatch_semaphore_t sem=dispatch_semaphore_create(0);__block int pid=0;getPID(dispatch_get_global_queue(0,0),^(int p){pid=p;dispatch_semaphore_signal(sem);});
 if(dispatch_semaphore_wait(sem,dispatch_time(DISPATCH_TIME_NOW,3*NSEC_PER_SEC))||pid!=expected){printf("refused: nowPlayingPID=%d expected=%d\n",pid,expected);return 4;}
 BOOL result=send(command,nil);CFRunLoopRunInMode(kCFRunLoopDefaultMode,1,NO);printf("targetPID=%d command=%d sent=%d\n",pid,command,result);return result?0:5;
}}
