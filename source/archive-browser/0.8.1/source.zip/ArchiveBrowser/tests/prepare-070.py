#!/usr/bin/env python3
from pathlib import Path
import shutil,urllib.request,tarfile,subprocess,sys
root=Path(__file__).resolve().parent.parent
p=root/'build/test-fixtures-070';p.mkdir(exist_ok=True,parents=True)
if not (root/'build/test-fixtures-060/book.pdf').exists():subprocess.run([sys.executable,str(root/'tests/prepare-060.py')],check=True)
for n in ['book.pdf','book.txt']:shutil.copy2(root/'build/test-fixtures-060'/n,p/n)
u='https://archive.org/download/testmp3testfile/mpthreetest.mp3'
with urllib.request.urlopen(u,timeout=30) as r:data=r.read(1024*1024+1)
assert 0<len(data)<=1024*1024
(p/'sample.mp3').write_bytes(data)
with tarfile.open(p/'fixtures.tgz','w:gz') as t:
 for f in sorted(p.iterdir()):
  if f.suffix!='.tgz':t.add(f,arcname=f.name)
print(p/'fixtures.tgz')
