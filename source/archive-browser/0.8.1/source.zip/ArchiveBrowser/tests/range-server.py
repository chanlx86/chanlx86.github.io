from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
import re,json
root=Path('build/test-fixtures-080').resolve()
class Handler(BaseHTTPRequestHandler):
 protocol_version="HTTP/1.1"
 def do_GET(self):
  path=root/self.path.lstrip('/')
  if path.parent!=root or not path.is_file():self.send_error(404);return
  size=path.stat().st_size;match=re.fullmatch(r'bytes=(\d+)-(\d+)',self.headers.get('Range',''))
  if match:
   a,b=map(int,match.groups());b=min(b,size-1)
   if a>b:self.send_error(416);return
   self.send_response(206);self.send_header('Content-Range',f'bytes {a}-{b}/{size}')
  else:a,b=0,size-1;self.send_response(200)
  self.send_header('Content-Type','application/pdf');self.send_header('Content-Length',str(b-a+1));self.send_header('ETag','"080-range-fixture"');self.end_headers()
  with path.open('rb') as f:f.seek(a);self.wfile.write(f.read(b-a+1))
  print(json.dumps({'path':self.path,'start':a,'end':b,'bytes':b-a+1}),flush=True)
ThreadingHTTPServer(('0.0.0.0',8768),Handler).serve_forever()
