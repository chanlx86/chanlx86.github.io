from pathlib import Path
import zipfile,shutil,json,subprocess,sys,urllib.request
if not Path('build/test-fixtures-070/sample.mp3').exists():subprocess.run([sys.executable,'tests/prepare-070.py'],check=True)
if not Path('build/archive-view.html').exists():
 with urllib.request.urlopen('https://archive.org/download/testmp3testfile/testmp3testfile_64kb_mp3.zip/',timeout=30) as r:Path('build/archive-view.html').write_bytes(r.read(2*1024*1024))
p=Path('build/test-fixtures-080');p.mkdir(exist_ok=True)
for name in ['book.txt','book.pdf','sample.mp3']:shutil.copy2(Path('build/test-fixtures-070')/name,p/name)
shutil.copy2('build/test-fixtures-060/files.zip',p/'nested.zip')
shutil.copy2('build/archive-view.html',p/'archive-view.html')
with zipfile.ZipFile('build/test-fixtures-060/book.epub') as original,zipfile.ZipFile(p/'paged.epub','w') as z:
 for name in original.namelist():
  data=original.read(name)
  if name.endswith('.xhtml'):
   body=''.join(f'<p>Page flow paragraph {i}: Archive Browser EPUB 分页阅读测试。'+'可左右滑动翻页，上一页、下一页跨章节。 '*12+'</p>' for i in range(70))
   data=data.replace(b'</body>',body.encode()+b'</body>')
  z.writestr(name,data,compress_type=8)
# A real 50 MB PDF, with valid xref at EOF and independent pages spread across the file.
# Tests must prove first-page rendering does not read the unneeded intervening objects.
file=p/'large.pdf';offsets={};pages=20
with file.open('wb') as f:
 f.write(b'%PDF-1.4\n')
 def obj(n,b):
  offsets[n]=f.tell();f.write(f'{n} 0 obj\n'.encode()+b+b'\nendobj\n')
 kids=' '.join(f'{4+i*2} 0 R' for i in range(pages))
 obj(1,b'<< /Type /Catalog /Pages 2 0 R >>');obj(2,f'<< /Type /Pages /Kids [{kids}] /Count {pages} >>'.encode());obj(3,b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>')
 for i in range(pages):
  num=4+i*2;obj(num,f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 800] /Resources << /Font << /F1 3 0 R >> >> /Contents {num+1} 0 R >>'.encode())
 for i in range(pages):
  if i:f.write(b'%' + b' '*(i*2*1024*1024-f.tell()-2)+b'\n')
  num=4+i*2
  stream=f'BT /F1 26 Tf 60 680 Td (Range PDF page {i+1}) Tj ET'.encode();obj(num+1,b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream')
 f.write(b'%'+b' '*(50*1024*1024-f.tell()-1025)+b'\n');xref=f.tell();count=max(offsets)+1;f.write(f'xref\n0 {count}\n0000000000 65535 f \n'.encode())
 for n in range(1,count):f.write(f'{offsets[n]:010d} 00000 n \n'.encode())
 f.write(f'trailer\n<< /Size {count} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
(p/'configuration.json').write_text(json.dumps({'pdf':'http://192.168.1.10:8768/large.pdf'}))
print(file.stat().st_size)
