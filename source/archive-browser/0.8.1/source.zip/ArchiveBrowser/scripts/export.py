#!/usr/bin/env python3
"""Export built packages, sources and notes to the user's Downloads directory."""
import pathlib,plistlib,zipfile,hashlib,json,shutil
root=pathlib.Path(__file__).resolve().parent.parent
version=plistlib.loads((root/'Info.plist').read_bytes())['CFBundleShortVersionString']
prefix='存档浏览器_'+version;dist=root/'dist';out=pathlib.Path.home()/'Downloads'
source=dist/(prefix+'_源码.zip')
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for name in ['Sources','Resources','scripts','tests','ArchiveBrowser.xcodeproj','Info.plist','README.md','build.sh']:
  p=root/name
  for f in sorted(p.rglob('*')) if p.is_dir() else [p]:
   if f.is_file() and '.DS_Store' not in f.name and '__pycache__' not in f.parts:z.write(f,'ArchiveBrowser/'+str(f.relative_to(root)))
files=[dist/(prefix+'_iphoneos-arm.deb'),dist/(prefix+'_越狱版.ipa'),source]
notes=dist/(prefix+'_使用与测试说明.md');shutil.copyfile(root/'README.md',notes);files.append(notes)
manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
hashes=dist/(prefix+'_SHA256.json');hashes.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');files.append(hashes)
for file in files:shutil.copy2(file,out/file.name);print(out/file.name)
