#import "ABCore.h"
// Random-access PDF provider. Network and Core Graphics parsing stay off the main thread.
@interface ABPDFSource : NSObject
@property(atomic,readonly) uint64_t fetchedBytes;
@property(atomic,readonly) uint64_t totalBytes;
@property(atomic,readonly) NSError *error;
@property(atomic) BOOL cancelled;
- (instancetype)initWithURL:(NSURL *)url;
- (CGPDFDocumentRef)createDocument CF_RETURNS_RETAINED;
- (void)beginPage;
@end
@interface ABPDFController : UITableViewController
- (instancetype)initWithURL:(NSURL *)url privateMode:(BOOL)privateMode;
@end
