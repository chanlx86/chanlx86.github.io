#import "ABCore.h"
#import <AVFoundation/AVFoundation.h>
@interface ABMediaCache : NSObject
+ (instancetype)shared;
- (void)chunk:(NSURL *)url offset:(long long)offset completion:(void (^)(NSData *,NSDictionary *,NSError *))block;
- (void)trim;
@property(nonatomic,readonly) NSUInteger hits;
@property(nonatomic,readonly) NSUInteger misses;
@end
@interface ABStream : NSObject <AVAssetResourceLoaderDelegate>
@property(nonatomic,readonly) AVURLAsset *asset;
- (instancetype)initWithURL:(NSURL *)url;
- (void)cancel;
@end
@interface ABPositions : NSObject
+ (instancetype)shared;
- (double)position:(NSURL *)url;
- (void)store:(NSURL *)url seconds:(double)seconds duration:(double)duration;
@end
// Hosts one existing AVPlayer controller. No duplicate decoder.
@interface ABVideoStage : UIViewController
@property(nonatomic,strong) ABPlayer *content;
@property(nonatomic) NSInteger aspect;
@property(nonatomic,copy) void (^returned)(void);
@end
@interface ABFloating : NSObject
+ (instancetype)shared;
@property(nonatomic,strong,readonly) ABPlayer *content;
- (void)show:(ABPlayer *)player owner:(UIViewController *)owner aspect:(NSInteger)aspect restore:(void (^)(void))restore close:(void (^)(void))close;
- (void)detachPreservingPlayback;
- (void)restore;
- (void)close;
@end
