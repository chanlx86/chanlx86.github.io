#import "ABCore.h"
NSURL *ABWebAddress(NSString *input);
NSURL *ABWaybackSnapshotURL(NSString *timestamp,NSString *original);
@interface ABWaybackController : UITableViewController
@end
