#import "ABMedia.h"
#import <ImageIO/ImageIO.h>
BOOL ABImageFile(NSString *n) {return [@[@"png",@"jpg",@"jpeg",@"gif",@"bmp",@"tif",@"tiff"] containsObject:n.pathExtension.lowercaseString];}
BOOL ABAudioFile(NSString *n) {return [@[@"mp3",@"m4b",@"alac",@"m4a",@"aac",@"wav",@"aiff",@"aif",@"caf",@"flac",@"ogg",@"opus",@"wma",@"ac3",@"mp2",@"au"] containsObject:n.pathExtension.lowercaseString];}
BOOL ABMediaFile(NSString *n) {return ABPlayable(n)||ABAudioFile(n)||[@[@"webm",@"mkv",@"avi",@"ogv",@"mpg",@"mpeg",@"mpe",@"mpeg1",@"mpeg2",@"vob",@"ts",@"m2ts",@"wmv",@"m2v"] containsObject:n.pathExtension.lowercaseString];}
BOOL ABPreviewMedia(NSString *name){return ABMediaFile(name)&&(!ABAudioFile(name)||ABPlayable(name));}
static NSString *ABRoot(NSDictionary *f,NSDictionary *index) {NSString *n=ABString(f[@"name"]);NSMutableSet *seen=[NSMutableSet set];while(n.length&&![seen containsObject:n]){[seen addObject:n];NSDictionary *parent=index[n];NSString *o=ABString(parent[@"original"]);if(!o.length)return n;n=o;}return ABString(f[@"name"]);}
static NSInteger ABMediaScore(NSDictionary *f) {NSString *n=ABString(f[@"name"]).lowercaseString; if(!ABPlayable(n))return -1000;NSInteger s=10;NSString *e=n.pathExtension;if([e isEqual:@"mp4"])s=100;if([e isEqual:@"mp3"])s=100;if([e isEqual:@"flac"])s=60;if([e isEqual:@"m4a"])s=90;if([n rangeOfString:@"512kb"].location!=NSNotFound)s+=40;if([n rangeOfString:@"h264"].location!=NSNotFound)s+=10;if([n rangeOfString:@"1080"].location!=NSNotFound||[n rangeOfString:@"4k"].location!=NSNotFound||[n rangeOfString:@"hevc"].location!=NSNotFound||[n rangeOfString:@"av1"].location!=NSNotFound)s-=160;NSInteger width=[ABString(f[@"width"]) integerValue];if(width>1280)s-=120;return s;}
NSArray *ABPlaylist(NSArray *files) {
    NSMutableDictionary *index=[NSMutableDictionary dictionary],*groups=[NSMutableDictionary dictionary];for(NSDictionary *f in files)if(ABString(f[@"name"]).length)index[ABString(f[@"name"])]=f;
    for(NSDictionary *f in files)if(!ABPrivate(f)&&ABPreviewMedia(ABString(f[@"name"]))) {NSString *root=ABRoot(f,index);NSDictionary *old=groups[root];if(!old||ABMediaScore(f)>ABMediaScore(old))groups[root]=f;}
    NSMutableDictionary *art=[NSMutableDictionary dictionary],*artCandidates=[NSMutableDictionary dictionary],*wave=[NSMutableDictionary dictionary];
    for(NSDictionary *f in files)if(!ABPrivate(f)&&ABImageFile(ABString(f[@"name"]))) {NSString *root=ABRoot(f,index),*name=ABString(f[@"name"]);if([root isEqual:name])continue;BOOL audio=ABAudioFile(root)||ABAudioFile(ABString(groups[root][@"name"]));if(audio&&[name.pathExtension.lowercaseString isEqual:@"png"]) {if(!wave[root])wave[root]=name;}else {NSMutableArray *a=artCandidates[root];if(!a){a=[NSMutableArray array];artCandidates[root]=a;}[a addObject:name];}}
    for(NSString *root in artCandidates){NSArray *a=artCandidates[root];NSMutableArray *stills=[NSMutableArray array];for(NSString *n in a)if(![n.pathExtension.lowercaseString isEqual:@"gif"])[stills addObject:n];if(stills.count)a=stills;a=[a sortedArrayUsingSelector:@selector(localizedStandardCompare:)];art[root]=a[a.count/2];}
    NSMutableArray *list=[NSMutableArray array];for(NSString *root in groups) {NSMutableDictionary *f=[groups[root] mutableCopy];NSDictionary *original=index[root];for(NSString *k in @[@"title",@"track",@"disc",@"album",@"creator",@"length"])if(!ABString(f[k]).length&&ABString(original[k]).length)f[k]=original[k];f[@"_root"]=root;if(art[root])f[@"_art"]=art[root];if(wave[root])f[@"_wave"]=wave[root];[list addObject:f];}
    [list sortUsingComparator:^NSComparisonResult(NSDictionary *a,NSDictionary *b){NSInteger ad=[ABString(a[@"disc"]) integerValue],bd=[ABString(b[@"disc"]) integerValue];if(ad!=bd)return ad<bd?NSOrderedAscending:NSOrderedDescending;NSInteger at=[ABString(a[@"track"]) integerValue],bt=[ABString(b[@"track"]) integerValue];if(at&&bt&&at!=bt)return at<bt?NSOrderedAscending:NSOrderedDescending;return [ABString(a[@"_root"]) localizedStandardCompare:ABString(b[@"_root"])];}];return list;
}
NSDictionary *ABCompatibleFile(NSDictionary *file,NSArray *files) {if(ABPlayable(ABString(file[@"name"])))return file;NSMutableDictionary *index=[NSMutableDictionary dictionary];for(NSDictionary *f in files)index[ABString(f[@"name"])]=f;NSString *root=ABRoot(file,index);for(NSDictionary *f in ABPlaylist(files))if([f[@"_root"] isEqual:root]&&ABPlayable(ABString(f[@"name"])))return f;return nil;}

@interface ABImageController () <UIScrollViewDelegate>
@property(nonatomic,strong) NSURL *url;
@property(nonatomic,strong) NSURLSessionTask *task;
@property(nonatomic,strong) UIScrollView *scroll;
@property(nonatomic,strong) UIImageView *image;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic) BOOL active;
@property(nonatomic) NSUInteger frame;
@property(nonatomic) NSUInteger count;
@property(nonatomic) CGImageSourceRef source;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic) dispatch_queue_t decoder;
@end
@implementation ABImageController
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title {if((self=[super init])){_url=url;self.title=title;_decoder=dispatch_queue_create("local.archive.gif",DISPATCH_QUEUE_SERIAL);}return self;}
- (void)viewDidLoad {[super viewDidLoad];self.view.backgroundColor=[UIColor blackColor];_scroll=[[UIScrollView alloc] initWithFrame:self.view.bounds];_scroll.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;_scroll.minimumZoomScale=1;_scroll.maximumZoomScale=5;_scroll.delegate=self;[self.view addSubview:_scroll];_image=[[UIImageView alloc] initWithFrame:_scroll.bounds];_image.contentMode=UIViewContentModeScaleAspectFit;[_scroll addSubview:_image];_status=[[UILabel alloc] initWithFrame:CGRectMake(16,80,self.view.bounds.size.width-32,80)];_status.autoresizingMask=UIViewAutoresizingFlexibleWidth;_status.textColor=[UIColor whiteColor];_status.numberOfLines=3;_status.textAlignment=NSTextAlignmentCenter;_status.text=@"正在读取图片…";[self.view addSubview:_status];__weak ABImageController *weak=self;
    void(^loaded)(NSData *,NSError *)=^(NSData *d,NSError *err){ABImageController *s=weak;if(!s)return;if(err||!d.length){s.status.text=err.localizedDescription?:@"无法读取图片。";return;}dispatch_async(s.decoder,^{CGImageSourceRef src=CGImageSourceCreateWithData((__bridge CFDataRef)d,NULL);dispatch_async(dispatch_get_main_queue(),^{ABImageController *v=weak;if(!v){if(src)CFRelease(src);return;}if(!src){v.status.text=@"系统无法解码此图片，可下载后用其他应用打开。";return;}v.source=src;v.count=CGImageSourceGetCount(src);[v decodeFrame];});});};
    if(_url.isFileURL)dispatch_async(_decoder,^{NSDictionary *a=[[NSFileManager defaultManager] attributesOfItemAtPath:self.url.path error:nil];NSData *d=[a fileSize]<=20*1024*1024?[NSData dataWithContentsOfURL:self.url]:nil;dispatch_async(dispatch_get_main_queue(),^{loaded(d,nil);});});else _task=[[ABHTTP shared] get:_url limit:20*1024*1024 completion:loaded];
}
- (void)viewWillAppear:(BOOL)a {[super viewWillAppear:a];_active=YES;if(_source&&!_timer)[self decodeFrame];}
- (void)viewWillDisappear:(BOOL)a {[super viewWillDisappear:a];_active=NO;[_timer invalidate];_timer=nil;}
- (void)decodeFrame {if(!_source||!_active)return;CGImageSourceRef src=(CGImageSourceRef)CFRetain(_source);NSUInteger i=_frame;__weak ABImageController *weak=self;dispatch_async(_decoder,^{@autoreleasepool{NSDictionary *opts=@{(id)kCGImageSourceCreateThumbnailFromImageAlways:@YES,(id)kCGImageSourceThumbnailMaxPixelSize:@1280,(id)kCGImageSourceCreateThumbnailWithTransform:@YES,(id)kCGImageSourceShouldCache:@NO};CGImageRef cg=CGImageSourceCreateThumbnailAtIndex(src,i,(__bridge CFDictionaryRef)opts);UIImage *im=cg?[UIImage imageWithCGImage:cg]:nil;if(cg)CGImageRelease(cg);NSDictionary *props=CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(src,i,NULL));NSDictionary *gif=props[(id)kCGImagePropertyGIFDictionary];double delay=[gif[(id)kCGImagePropertyGIFUnclampedDelayTime] doubleValue];if(delay<=0)delay=[gif[(id)kCGImagePropertyGIFDelayTime] doubleValue];if(delay<0.02)delay=0.1;CFStringRef type=CGImageSourceGetType(src);BOOL animated=type&&CFEqual(type,CFSTR("com.compuserve.gif"))&&CGImageSourceGetCount(src)>1;CFRelease(src);dispatch_async(dispatch_get_main_queue(),^{ABImageController *s=weak;if(!s||!s.active)return;s.image.image=im;s.status.text=im?nil:@"图片解码失败，可下载后在其他应用打开。";if(animated&&im){s.frame=(i+1)%s.count;s.timer=[NSTimer scheduledTimerWithTimeInterval:delay target:s selector:@selector(nextFrame:) userInfo:nil repeats:NO];}});}});}
- (void)nextFrame:(NSTimer *)t {_timer=nil;[self decodeFrame];}
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)s {return _image;}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];if(_scroll.zoomScale==1){_image.frame=_scroll.bounds;_scroll.contentSize=_scroll.bounds.size;}}
- (void)dealloc {[_task cancel];[_timer invalidate];if(_source)CFRelease(_source);}
@end

@interface ABWaveform : UIView
@property(nonatomic,strong) UIImage *image;
@property(nonatomic) CGFloat progress;
@end
@implementation ABWaveform {UIImageView *_base;UIImageView *_played;CALayer *_mask;}
- (instancetype)init {if((self=[super init])){self.backgroundColor=[UIColor blackColor];_base=[UIImageView new];_base.contentMode=UIViewContentModeScaleToFill;_played=[UIImageView new];_played.contentMode=UIViewContentModeScaleToFill;_played.tintColor=[UIColor colorWithRed:0.12 green:0.62 blue:1 alpha:1];_mask=[CALayer layer];_mask.backgroundColor=[UIColor blackColor].CGColor;_played.layer.mask=_mask;[self addSubview:_base];[self addSubview:_played];}return self;}
- (void)setImage:(UIImage *)image {_image=image;_base.image=image;_played.image=[image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];}
- (void)setProgress:(CGFloat)progress {_progress=MAX(0,MIN(1,progress));[self setNeedsLayout];}
- (void)layoutSubviews {[super layoutSubviews];_base.frame=_played.frame=self.bounds;[CATransaction begin];[CATransaction setDisableActions:YES];_mask.frame=CGRectMake(0,0,self.bounds.size.width*_progress,self.bounds.size.height);[CATransaction commit];}
@end
static UIImage *ABWaveMask(UIImage *image){CGImageRef cg=image.CGImage;size_t w=CGImageGetWidth(cg),h=CGImageGetHeight(cg);if(!w||!h||w*h>1024*1024)return image;unsigned char *bytes=calloc(w*h,4);CGColorSpaceRef rgb=CGColorSpaceCreateDeviceRGB();CGContextRef c=CGBitmapContextCreate(bytes,w,h,8,w*4,rgb,kCGImageAlphaPremultipliedLast|kCGBitmapByteOrder32Big);CGColorSpaceRelease(rgb);if(!c){free(bytes);return image;}CGContextDrawImage(c,CGRectMake(0,0,w,h),cg);int background=(bytes[0]+bytes[1]+bytes[2])/3;for(size_t i=0;i<w*h;i++){int level=(bytes[4*i]+bytes[4*i+1]+bytes[4*i+2])/3;unsigned char a=background<128?level:255-level;bytes[i*4]=bytes[i*4+1]=bytes[i*4+2]=bytes[i*4+3]=a;}CGImageRef mask=CGBitmapContextCreateImage(c);UIImage *result=[UIImage imageWithCGImage:mask];CGImageRelease(mask);CGContextRelease(c);free(bytes);return result;}
@implementation ABAudioBar {
    AVPlayer *_player; id _observer; ABWaveform *_wave; UIButton *_toggle; UISlider *_progress; UILabel *_clock; UILabel *_hint; BOOL _dragging; NSString *_artKey;
}
- (instancetype)initWithPlayer:(AVPlayer *)player {if((self=[super initWithFrame:CGRectZero])){_player=player;self.backgroundColor=[UIColor colorWithWhite:0.95 alpha:1];_wave=[ABWaveform new];[self addSubview:_wave];_hint=[UILabel new];_hint.text=@"音频播放";_hint.font=[UIFont systemFontOfSize:12];_hint.textColor=[UIColor grayColor];[self addSubview:_hint];_toggle=[UIButton buttonWithType:UIButtonTypeSystem];[_toggle addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];[self addSubview:_toggle];_progress=[UISlider new];[_progress addTarget:self action:@selector(drag) forControlEvents:UIControlEventTouchDown];[_progress addTarget:self action:@selector(dragChanged) forControlEvents:UIControlEventValueChanged];[_progress addTarget:self action:@selector(seek) forControlEvents:UIControlEventTouchUpInside|UIControlEventTouchUpOutside];[_progress addTarget:self action:@selector(cancelDrag) forControlEvents:UIControlEventTouchCancel];[self addSubview:_progress];_clock=[UILabel new];_clock.font=[UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightRegular];_clock.textAlignment=NSTextAlignmentRight;[self addSubview:_clock];__weak ABAudioBar *weak=self;_observer=[player addPeriodicTimeObserverForInterval:CMTimeMakeWithSeconds(0.5,600) queue:dispatch_get_main_queue() usingBlock:^(CMTime t){[weak update];}];[self update];}return self;}
- (void)setArtwork:(NSURL *)url {_artKey=url.absoluteString;_wave.image=nil;_hint.text=url?@"曲目附图（静态频谱 / 波形）":@"音频播放 · 此曲目未提供频谱图";if(!url)return;NSString *key=_artKey;__weak ABAudioBar *weak=self;[[ABImages shared] imageURL:url completion:^(UIImage *im){ABAudioBar *bar=weak;if(!bar||![bar->_artKey isEqual:key])return;dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW,0),^{UIImage *mask=im?ABWaveMask(im):nil;dispatch_async(dispatch_get_main_queue(),^{ABAudioBar *v=weak;if(v&&[v->_artKey isEqual:key]){v->_wave.image=mask;v->_progress.minimumTrackTintColor=mask?[UIColor clearColor]:ABTint();v->_progress.maximumTrackTintColor=mask?[UIColor clearColor]:[UIColor lightGrayColor];}});});}];}
- (void)layoutSubviews {[super layoutSubviews];CGFloat w=self.bounds.size.width;_hint.frame=CGRectMake(12,4,w-24,18);_wave.frame=CGRectMake(12,25,w-24,60);_toggle.frame=CGRectMake(8,91,52,44);_progress.frame=CGRectMake(12,25,w-24,60);_clock.frame=CGRectMake(w-108,100,100,28);}
- (void)update {double t=CMTimeGetSeconds(_player.currentTime),d=CMTimeGetSeconds(_player.currentItem.duration);if(!isfinite(t))t=0;if(!isfinite(d))d=0;_progress.enabled=d>0;if(!_dragging)_progress.value=d>0?t/d:0;_wave.progress=_progress.value;[_toggle setTitle:_player.rate>0?@"暂停":@"播放" forState:UIControlStateNormal];_clock.text=[NSString stringWithFormat:@"%ld:%02ld / %ld:%02ld",(long)t/60,(long)t%60,(long)d/60,(long)d%60];}
- (void)toggle {if(_player.rate>0)[_player pause];else [_player play];[self update];}
- (void)drag {_dragging=YES;}
- (void)dragChanged {_wave.progress=_progress.value;}
- (void)cancelDrag {_dragging=NO;}
- (void)seek {double d=CMTimeGetSeconds(_player.currentItem.duration);if(isfinite(d)&&d>0)[_player seekToTime:CMTimeMakeWithSeconds(d*_progress.value,600)];_dragging=NO;}
- (void)stop {if(_observer){[_player removeTimeObserver:_observer];_observer=nil;}}
- (void)dealloc {[self stop];}
@end
