#import "ABCore.h"
extern NSString * const ABWebLibraryChanged;
NSDictionary *ABWebRecord(NSDictionary *record);
NSDictionary *ABWebRecordFromURL(NSURL *url,NSString *title);
NSString *ABWebRecordKey(NSDictionary *record);
NSString *ABWebThumbnailKey(NSDictionary *record);
NSString *ABWebDate(NSDictionary *record);
@interface ABWebLibrary : NSObject
@property(nonatomic,readonly) NSArray *history;
@property(nonatomic,readonly) NSArray *favorites;
@property(nonatomic,readonly) NSString *error;
+ (instancetype)shared;
- (instancetype)initWithDirectory:(NSString *)directory;
- (BOOL)visit:(NSDictionary *)record;
- (BOOL)removeHistory:(NSDictionary *)record;
- (BOOL)isFavorite:(NSDictionary *)record;
- (BOOL)setFavorite:(NSDictionary *)record present:(BOOL)present;
@end
#ifdef AB_TESTING
void ABUseTestWebLibrary(ABWebLibrary *library);
#endif
