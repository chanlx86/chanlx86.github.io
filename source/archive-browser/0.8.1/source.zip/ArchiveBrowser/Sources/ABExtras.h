#import "ABCore.h"
BOOL ABDocumentFile(NSString *name);
// Owns an ephemeral on-disk transfer. Cancelling/deallocating removes its directory.
@interface ABTransfer : NSObject <NSURLSessionDownloadDelegate>
@property(atomic) BOOL cancelled;
@property(nonatomic,strong,readonly) NSURL *directory;
@property(nonatomic,copy) void (^progress)(int64_t,int64_t);
- (void)start:(NSURLRequest *)request limit:(uint64_t)limit completion:(void (^)(NSURL *,NSHTTPURLResponse *,NSError *))completion;
- (void)cancel;
@end
@interface ABFileController : UIViewController
@property(nonatomic,copy) NSString *archiveIdentifier;
- (instancetype)initWithURL:(NSURL *)url name:(NSString *)name privateMode:(BOOL)privateMode;
@end

void ABOpenFileFrom(UIViewController *presenter,NSURL *url,NSString *name,NSString *identifier,BOOL privateMode);
