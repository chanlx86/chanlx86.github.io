#import "ABPlayback.h"
#import <CommonCrypto/CommonDigest.h>
#import <MobileCoreServices/MobileCoreServices.h>
static NSUInteger const ABChunk=256*1024;
static NSString *ABHash(NSString *s){NSData *d=[s dataUsingEncoding:NSUTF8StringEncoding];unsigned char bytes[CC_SHA256_DIGEST_LENGTH];CC_SHA256(d.bytes,(CC_LONG)d.length,bytes);NSMutableString *h=[NSMutableString string];for(int i=0;i<CC_SHA256_DIGEST_LENGTH;i++)[h appendFormat:@"%02x",bytes[i]];return h;}
static NSError *ABPlaybackError(NSString *s){return [NSError errorWithDomain:@"ArchivePlayback" code:1 userInfo:@{NSLocalizedDescriptionKey:s}];}
@interface ABMediaCache ()
@property(nonatomic,copy) NSString *folder;
@property(nonatomic) dispatch_queue_t io;
@property(nonatomic,strong) NSMutableDictionary *waiting;
@property(nonatomic) NSUInteger hits;
@property(nonatomic) NSUInteger misses;
@end
@implementation ABMediaCache
+ (instancetype)shared {static ABMediaCache *s;static dispatch_once_t t;dispatch_once(&t,^{s=[self new];});return s;}
- (instancetype)init {if((self=[super init])){_folder=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"ArchiveBrowser/Media"];[[NSFileManager defaultManager] createDirectoryAtPath:_folder withIntermediateDirectories:YES attributes:nil error:nil];_io=dispatch_queue_create("local.archive.media-cache",DISPATCH_QUEUE_SERIAL);_waiting=[NSMutableDictionary dictionary];[self trim];}return self;}
- (void)makeRoom:(NSUInteger)bytes {NSFileManager *fm=[NSFileManager defaultManager];unsigned long long total=0;NSMutableArray *files=[NSMutableArray array];for(NSString *name in [fm contentsOfDirectoryAtPath:_folder error:nil]){NSString *p=[_folder stringByAppendingPathComponent:name];NSDictionary *a=[fm attributesOfItemAtPath:p error:nil];total+=a.fileSize;[files addObject:@{@"path":p,@"size":@(a.fileSize),@"date":a[NSFileModificationDate]?:[NSDate distantPast]}];}[files sortUsingComparator:^NSComparisonResult(NSDictionary *a,NSDictionary *b){return [a[@"date"] compare:b[@"date"]];}];for(NSDictionary *f in files){if(total+bytes<=64*1024*1024)break;if([fm removeItemAtPath:f[@"path"] error:nil])total-=[f[@"size"] unsignedLongLongValue];}}
- (void)trim {dispatch_async(_io,^{[self makeRoom:0];});}
- (void)deliver:(NSString *)key data:(NSData *)data info:(NSDictionary *)info error:(NSError *)error {NSArray *callbacks=[_waiting[key] copy];[_waiting removeObjectForKey:key];for(void(^block)(NSData *,NSDictionary *,NSError *) in callbacks)block(data,info,error);}
- (void)chunk:(NSURL *)url offset:(long long)offset completion:(void (^)(NSData *,NSDictionary *,NSError *))block {
    NSString *prefix=ABHash(url.absoluteString),*key=[prefix stringByAppendingFormat:@".%lld",offset],*path=[_folder stringByAppendingPathComponent:key],*meta=[_folder stringByAppendingPathComponent:[prefix stringByAppendingString:@".info"]];
    if(_waiting[key]){[_waiting[key] addObject:[block copy]];return;}_waiting[key]=[NSMutableArray arrayWithObject:[block copy]];
    dispatch_async(_io,^{NSData *d=[NSData dataWithContentsOfFile:path];NSDictionary *info=[NSDictionary dictionaryWithContentsOfFile:meta];NSDate *date=[[NSFileManager defaultManager] attributesOfItemAtPath:meta error:nil][NSFileModificationDate];BOOL valid=d.length&&d.length==(NSUInteger)MIN((long long)ABChunk,MAX(0,[info[@"length"] longLongValue]-offset))&&[info[@"length"] longLongValue]>offset&&date&&-[date timeIntervalSinceNow]<86400; if(valid)[[NSFileManager defaultManager] setAttributes:@{NSFileModificationDate:[NSDate date]} ofItemAtPath:path error:nil];
      dispatch_async(dispatch_get_main_queue(),^{if(valid){self.hits++;[self deliver:key data:d info:info error:nil];return;}self.misses++;NSMutableURLRequest *r=[NSMutableURLRequest requestWithURL:url];[r setValue:[NSString stringWithFormat:@"bytes=%lld-%lld",offset,offset+ABChunk-1] forHTTPHeaderField:@"Range"];[r setValue:@"identity" forHTTPHeaderField:@"Accept-Encoding"];
        [[ABHTTP shared] request:r limit:ABChunk completion:^(NSData *bytes,NSHTTPURLResponse *response,NSError *error){
          NSDictionary *h=response.allHeaderFields;NSString *range=nil;for(NSString *k in h)if([k.lowercaseString isEqual:@"content-range"])range=ABString(h[k]);long long start=-1,end=-1,total=-1;if(range.length)sscanf(range.UTF8String,"bytes %lld-%lld/%lld",&start,&end,&total);
          if(response.statusCode==200&&offset==0&&bytes.length<=ABChunk){start=0;end=(long long)bytes.length-1;total=bytes.length;}
          if(error||start!=offset||end-start+1!=(long long)bytes.length||total<=0||!bytes.length){[self deliver:key data:nil info:nil error:error?:ABPlaybackError(@"服务器未提供可校验的分段响应")];return;}
          NSString *type=CFBridgingRelease(UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension,(__bridge CFStringRef)url.pathExtension,NULL))?:@"public.data";NSDictionary *newInfo=@{@"length":@(total),@"type":type};
          dispatch_async(self.io,^{NSData *m=[NSPropertyListSerialization dataWithPropertyList:newInfo format:NSPropertyListBinaryFormat_v1_0 options:0 error:nil];[self makeRoom:bytes.length+m.length];[bytes writeToFile:path atomically:YES];[m writeToFile:meta atomically:YES];dispatch_async(dispatch_get_main_queue(),^{[self deliver:key data:bytes info:newInfo error:nil];});});
        }];
      });
    });
}
@end
@interface ABStream ()
@property(nonatomic,strong) AVURLAsset *asset;
@property(nonatomic,strong) NSURL *url;
@property(nonatomic,strong) NSMutableSet *requests;
@property(nonatomic) BOOL cancelled;
@property(nonatomic) long long length;
@end
@implementation ABStream
- (instancetype)initWithURL:(NSURL *)url {if((self=[super init])){_url=url;_requests=[NSMutableSet set];NSURLComponents *c=[NSURLComponents componentsWithURL:url resolvingAgainstBaseURL:NO];c.scheme=@"abmedia";_asset=[AVURLAsset URLAssetWithURL:c.URL options:nil];[_asset.resourceLoader setDelegate:self queue:dispatch_get_main_queue()];}return self;}
- (BOOL)resourceLoader:(AVAssetResourceLoader *)loader shouldWaitForLoadingOfRequestedResource:(AVAssetResourceLoadingRequest *)request {if(_cancelled)return NO;[_requests addObject:request];[self pump:request];return YES;}
- (void)pump:(AVAssetResourceLoadingRequest *)r {if(_cancelled||![_requests containsObject:r])return;AVAssetResourceLoadingDataRequest *dr=r.dataRequest;long long current=dr?(dr.currentOffset?:dr.requestedOffset):0;if(_length>0&&current>=_length){[r finishLoading];[_requests removeObject:r];return;}long long aligned=current/ABChunk*ABChunk;__weak ABStream *weak=self;[[ABMediaCache shared] chunk:_url offset:aligned completion:^(NSData *d,NSDictionary *info,NSError *error){ABStream *s=weak;if(!s||s.cancelled||![s.requests containsObject:r])return;if(error){[r finishLoadingWithError:error];[s.requests removeObject:r];return;}long long total=[info[@"length"] longLongValue];s.length=total;r.contentInformationRequest.contentType=info[@"type"];r.contentInformationRequest.contentLength=total;r.contentInformationRequest.byteRangeAccessSupported=YES;if(!dr||(r.contentInformationRequest&&dr.requestedOffset==0&&dr.requestedLength<=2)){[r finishLoading];[s.requests removeObject:r];return;}long long pos=dr.currentOffset?:dr.requestedOffset;long long end=dr.requestsAllDataToEndOfResource?total:MIN(total,dr.requestedOffset+dr.requestedLength);NSUInteger available=pos>=aligned&&pos<aligned+(long long)d.length?(NSUInteger)(aligned+d.length-pos):0;NSUInteger n=(NSUInteger)MAX(0,MIN((long long)available,end-pos));if(n)[dr respondWithData:[d subdataWithRange:NSMakeRange((NSUInteger)(pos-aligned),n)]];pos=dr.currentOffset;if(pos>=end||!n){[r finishLoading];[s.requests removeObject:r];}else [s pump:r];}];}
- (void)resourceLoader:(AVAssetResourceLoader *)loader didCancelLoadingRequest:(AVAssetResourceLoadingRequest *)request {[_requests removeObject:request];}
- (void)cancel {_cancelled=YES;for(AVAssetResourceLoadingRequest *r in [_requests copy])if(!r.isFinished&&!r.isCancelled)[r finishLoadingWithError:[NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorCancelled userInfo:nil]];[_requests removeAllObjects];[_asset.resourceLoader setDelegate:nil queue:NULL];}
- (void)dealloc {[self cancel];}
@end
@implementation ABPositions {NSMutableDictionary *_positions;NSString *_path;}
+ (instancetype)shared {static ABPositions *s;static dispatch_once_t t;dispatch_once(&t,^{s=[self new];});return s;}
- (instancetype)init {if((self=[super init])){_path=[ABDocuments() stringByAppendingPathComponent:@"playback.plist"];_positions=[[NSDictionary dictionaryWithContentsOfFile:_path] mutableCopy]?:[NSMutableDictionary dictionary];}return self;}
- (double)position:(NSURL *)url {id d=_positions[ABHash(url.absoluteString)];return [d isKindOfClass:[NSDictionary class]]?[d[@"seconds"] doubleValue]:0;}
- (void)store:(NSURL *)url seconds:(double)t duration:(double)d {if(!url||!isfinite(t)||t<0)return;NSString *key=ABHash(url.absoluteString);if(isfinite(d)&&d>0&&t>=d-2)t=0;_positions[key]=@{@"seconds":@(t),@"date":@([NSDate timeIntervalSinceReferenceDate])};if(_positions.count>300){NSArray *sorted=[_positions keysSortedByValueUsingComparator:^NSComparisonResult(NSDictionary *a,NSDictionary *b){return [a[@"date"] compare:b[@"date"]];}];[_positions removeObjectsForKeys:[sorted subarrayWithRange:NSMakeRange(0,_positions.count-300)]];}[_positions writeToFile:_path atomically:YES];}
@end
static CGRect ABVideoRect(CGRect bounds,NSInteger aspect) {if(aspect<2)return bounds;CGFloat ratio=aspect==2?16.0/9.0:4.0/3.0;CGFloat w=bounds.size.width,h=w/ratio;if(h>bounds.size.height){h=bounds.size.height;w=h*ratio;}return CGRectMake(bounds.origin.x+(bounds.size.width-w)/2,bounds.origin.y+(bounds.size.height-h)/2,w,h);}
@implementation ABVideoStage
- (void)viewDidLoad {[super viewDidLoad];self.view.backgroundColor=[UIColor blackColor];[self addChildViewController:_content];[self.view addSubview:_content.view];_content.view.hidden=NO;[_content didMoveToParentViewController:self];UIButton *done=[UIButton buttonWithType:UIButtonTypeSystem];done.frame=CGRectMake(12,22,60,40);[done setTitle:@"返回" forState:UIControlStateNormal];[done addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:done];}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];CGRect b=self.view.bounds;b.origin.y=64;b.size.height-=64;_content.view.frame=ABVideoRect(b,_aspect);_content.videoGravity=_aspect==0?AVLayerVideoGravityResizeAspect:AVLayerVideoGravityResize;}
- (void)close {[self dismissViewControllerAnimated:YES completion:nil];}
- (void)viewDidDisappear:(BOOL)a {[super viewDidDisappear:a];if(self.isBeingDismissed||!self.presentingViewController){[_content willMoveToParentViewController:nil];[_content.view removeFromSuperview];[_content removeFromParentViewController];if(_returned)_returned();}}
@end
@interface ABFloating ()
@property(nonatomic,strong) ABPlayer *content;
@property(nonatomic,strong) UIView *panel;
@property(nonatomic,strong) UIView *host;
@property(nonatomic,strong) UIViewController *owner;
@property(nonatomic,copy) void (^restored)(void);
@property(nonatomic,copy) void (^closed)(void);
@property(nonatomic) NSInteger aspect;
@end
@implementation ABFloating
+ (instancetype)shared {static ABFloating *s;static dispatch_once_t t;dispatch_once(&t,^{s=[self new];});return s;}
- (void)show:(ABPlayer *)p owner:(UIViewController *)owner aspect:(NSInteger)aspect restore:(void (^)(void))restore close:(void (^)(void))close {if(_content)[self close];_owner=owner;_content=p;_aspect=aspect;_restored=restore;_closed=close;UIViewController *root=[UIApplication sharedApplication].keyWindow.rootViewController;_panel=[[UIView alloc] initWithFrame:CGRectMake(MAX(12,root.view.bounds.size.width-296),86,280,204)];_panel.backgroundColor=[UIColor colorWithWhite:0.12 alpha:1];_panel.layer.cornerRadius=8;_panel.clipsToBounds=YES;_panel.layer.borderColor=[UIColor grayColor].CGColor;_panel.layer.borderWidth=1;[root.view addSubview:_panel];UIView *bar=[[UIView alloc] initWithFrame:CGRectMake(0,0,280,44)];[_panel addSubview:bar];UIButton *back=[UIButton buttonWithType:UIButtonTypeSystem];back.frame=CGRectMake(8,0,188,44);[back setTitle:@"返回播放页 · 可拖动" forState:UIControlStateNormal];[back addTarget:self action:@selector(restore) forControlEvents:UIControlEventTouchUpInside];[bar addSubview:back];UIButton *x=[UIButton buttonWithType:UIButtonTypeSystem];x.frame=CGRectMake(232,0,44,44);[x setTitle:@"关闭" forState:UIControlStateNormal];[x addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];[bar addSubview:x];UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(drag:)];[bar addGestureRecognizer:pan];_host=[[UIView alloc] initWithFrame:CGRectMake(0,44,280,160)];_host.backgroundColor=[UIColor blackColor];[_panel addSubview:_host];[root addChildViewController:p];[_host addSubview:p.view];p.view.hidden=NO;p.view.frame=ABVideoRect(_host.bounds,aspect);p.videoGravity=aspect==0?AVLayerVideoGravityResizeAspect:AVLayerVideoGravityResize;[p didMoveToParentViewController:root];[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clamp) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];}
- (void)drag:(UIPanGestureRecognizer *)g {CGPoint t=[g translationInView:_panel.superview];_panel.center=CGPointMake(_panel.center.x+t.x,_panel.center.y+t.y);[g setTranslation:CGPointZero inView:_panel.superview];[self clamp];}
- (void)clamp {CGRect b=_panel.superview.bounds,f=_panel.frame;f.origin.x=MAX(4,MIN(f.origin.x,b.size.width-f.size.width-4));f.origin.y=MAX(22,MIN(f.origin.y,b.size.height-f.size.height-54));_panel.frame=f;}
- (void)detach {[[NSNotificationCenter defaultCenter] removeObserver:self];[_content willMoveToParentViewController:nil];[_content.view removeFromSuperview];[_content removeFromParentViewController];[_panel removeFromSuperview];_panel=nil;_host=nil;_content=nil;_owner=nil;}
- (void)detachPreservingPlayback {_restored=nil;_closed=nil;[self detach];}
- (void)restore {void(^b)(void)=[_restored copy];_restored=nil;_closed=nil;[self detach];if(b)b();}
- (void)close {[_content.player pause];void(^b)(void)=[_closed copy];_restored=nil;_closed=nil;[self detach];if(b)b();}
@end
