#import "ABWebLibrary.h"
#import "ABWayback.h"
NSString * const ABWebLibraryChanged=@"ABWebLibraryChanged";
NSDictionary *ABWebRecord(NSDictionary *record){if(![record isKindOfClass:[NSDictionary class]])return nil;NSString *ts=ABString(record[@"timestamp"]),*original=ABString(record[@"original"]);if(original.length>8192||!ABWaybackSnapshotURL(ts,original))return nil;NSURLComponents *c=[NSURLComponents componentsWithString:original];c.scheme=c.scheme.lowercaseString;c.host=c.host.lowercaseString;c.fragment=nil;if(([c.scheme isEqual:@"http"]&&c.port.integerValue==80)||([c.scheme isEqual:@"https"]&&c.port.integerValue==443))c.port=nil;if(!c.path.length)c.path=@"/";NSString *title=[ABString(record[@"title"]) stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];if(title.length>180)title=[title substringToIndex:180];if(!title.length)title=c.host;return @{@"timestamp":ts,@"original":c.URL.absoluteString,@"title":title?:@"网页快照"};}
NSDictionary *ABWebRecordFromURL(NSURL *url,NSString *title){if(![url.host.lowercaseString isEqual:@"web.archive.org"])return nil;NSString *s=url.absoluteString;NSRegularExpression *re=[NSRegularExpression regularExpressionWithPattern:@"^https?://web\\.archive\\.org/web/([0-9]{14})(?:[a-z]+_)?/(https?://.+)$" options:0 error:nil];NSTextCheckingResult *m=[re firstMatchInString:s options:0 range:NSMakeRange(0,s.length)];return m?ABWebRecord(@{@"timestamp":[s substringWithRange:[m rangeAtIndex:1]],@"original":[s substringWithRange:[m rangeAtIndex:2]],@"title":title?:@""}):nil;}
NSString *ABWebRecordKey(NSDictionary *record){NSDictionary *r=ABWebRecord(record);return r?[NSString stringWithFormat:@"%@|%@",r[@"timestamp"],r[@"original"]]:nil;}
NSString *ABWebThumbnailKey(NSDictionary *record){NSString *key=ABWebRecordKey(record);return key?[@"wayback-preview:" stringByAppendingString:key]:nil;}
NSString *ABWebDate(NSDictionary *record){NSString *ts=ABString(record[@"timestamp"]);return ts.length==14?[NSString stringWithFormat:@"%@-%@-%@",[ts substringToIndex:4],[ts substringWithRange:NSMakeRange(4,2)],[ts substringWithRange:NSMakeRange(6,2)]]:@"";}
@interface ABWebLibrary ()
@property(nonatomic,strong) NSArray *history;
@property(nonatomic,strong) NSArray *favorites;
@property(nonatomic,copy) NSString *directory;
@property(nonatomic,copy) NSString *error;
@property(nonatomic,strong) NSMutableSet *invalid;
@end
#ifdef AB_TESTING
static ABWebLibrary *TestLibrary;
void ABUseTestWebLibrary(ABWebLibrary *library){TestLibrary=library;[[NSNotificationCenter defaultCenter] postNotificationName:ABWebLibraryChanged object:nil];}
#endif
@implementation ABWebLibrary
+ (instancetype)shared {
#ifdef AB_TESTING
 if(TestLibrary)return TestLibrary;
#endif
 static ABWebLibrary *s;static dispatch_once_t once;dispatch_once(&once,^{s=[[self alloc] initWithDirectory:ABDocuments()];});return s;
}
- (instancetype)initWithDirectory:(NSString *)directory{if((self=[super init])){_directory=[directory copy];_invalid=[NSMutableSet set];[[NSFileManager defaultManager] createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:nil error:nil];_history=[self load:@"web-history.plist" limit:30];_favorites=[self load:@"web-favorites.plist" limit:200];}return self;}
- (NSArray *)load:(NSString *)name limit:(NSUInteger)limit{NSString *path=[_directory stringByAppendingPathComponent:name];NSData *d=[NSData dataWithContentsOfFile:path];if(!d)return @[];id raw=d.length<=2*1024*1024?[NSPropertyListSerialization propertyListWithData:d options:NSPropertyListImmutable format:nil error:nil]:nil;if(![raw isKindOfClass:[NSArray class]]){[_invalid addObject:name];_error=@"网页记录文件无法读取，已保留原文件。";return @[];}NSMutableArray *list=[NSMutableArray array];NSMutableSet *seen=[NSMutableSet set];for(id record in raw){NSDictionary *entry=ABWebRecord(record);NSString *key=ABWebRecordKey(entry);if(entry&&![seen containsObject:key]&&list.count<limit){[list addObject:entry];[seen addObject:key];}}return list;}
- (BOOL)save:(NSArray *)records name:(NSString *)name{if([_invalid containsObject:name]){_error=@"网页记录文件无法读取，已保留原文件。";return NO;}NSError *error=nil;NSData *data=[NSPropertyListSerialization dataWithPropertyList:records format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];BOOL ok=data&&[data writeToFile:[_directory stringByAppendingPathComponent:name] options:NSDataWritingAtomic error:&error];if(!ok)_error=error.localizedDescription?:@"无法保存网页记录。";else _error=nil;return ok;}
- (void)changed{[[NSNotificationCenter defaultCenter] postNotificationName:ABWebLibraryChanged object:self];}
- (BOOL)visit:(NSDictionary *)record{NSDictionary *entry=ABWebRecord(record);if(!entry)return NO;NSString *key=ABWebRecordKey(entry);NSMutableArray *next=[NSMutableArray arrayWithObject:entry];for(NSDictionary *r in _history)if(![ABWebRecordKey(r) isEqual:key]&&next.count<30)[next addObject:r];if(![self save:next name:@"web-history.plist"])return NO;_history=next;[self changed];return YES;}
- (BOOL)removeHistory:(NSDictionary *)record{NSString *key=ABWebRecordKey(record);NSMutableArray *next=[NSMutableArray array];for(NSDictionary *r in _history)if(![ABWebRecordKey(r) isEqual:key])[next addObject:r];if(![self save:next name:@"web-history.plist"])return NO;_history=next;[self changed];return YES;}
- (BOOL)isFavorite:(NSDictionary *)record{NSString *key=ABWebRecordKey(record);for(NSDictionary *r in _favorites)if([ABWebRecordKey(r) isEqual:key])return YES;return NO;}
- (BOOL)setFavorite:(NSDictionary *)record present:(BOOL)present{NSDictionary *entry=ABWebRecord(record);if(!entry)return NO;NSString *key=ABWebRecordKey(entry);NSMutableArray *next=[NSMutableArray array];if(present)[next addObject:entry];for(NSDictionary *r in _favorites)if(![ABWebRecordKey(r) isEqual:key])[next addObject:r];if(next.count>200){_error=@"网页收藏最多保存 200 项，请先整理已有收藏。";return NO;}if(![self save:next name:@"web-favorites.plist"])return NO;_favorites=next;[self changed];return YES;}
@end
