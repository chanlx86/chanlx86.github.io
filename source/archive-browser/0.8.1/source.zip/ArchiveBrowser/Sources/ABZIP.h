#import "ABCore.h"
@interface ABZIPReader : NSObject
@property(nonatomic,readonly) NSArray *entries;
@property(nonatomic,readonly) uint64_t totalSize;
- (instancetype)initWithURL:(NSURL *)url;
- (void)open:(void (^)(NSError *))completion;
- (void)extract:(NSDictionary *)entry completion:(void (^)(NSURL *,NSError *))completion;
- (void)cancel;
@end
BOOL ABArchiveFile(NSString *name);
NSURL *ABArchiveWebURL(NSURL *source);
NSArray *ABArchiveListing(NSData *html,NSURL *base);
BOOL ABZIPSafePath(NSString *name);
@interface ABZIPController : UITableViewController
- (instancetype)initWithURL:(NSURL *)url identifier:(NSString *)identifier name:(NSString *)name privateMode:(BOOL)privateMode;
@end
