#import "ABCore.h"
#import <MediaPlayer/MediaPlayer.h>
extern NSString * const ABSessionChanged;
@protocol ABSessionOwner <NSObject>
- (void)playbackClose;
- (void)playbackReturn;
- (BOOL)playbackCanNext;
- (BOOL)playbackCanPrevious;
- (void)playbackNext;
- (void)playbackPrevious;
@end
// The sole app-wide playback owner. Retains the source queue when its page is popped.
@interface ABSession : NSObject
+ (instancetype)shared;
@property(nonatomic,strong,readonly) ABPlayer *content;
@property(nonatomic,strong,readonly) UIViewController<ABSessionOwner> *owner;
@property(nonatomic,strong,readonly) UIImage *artwork;
@property(nonatomic,copy,readonly) NSString *title;
@property(nonatomic,readonly) BOOL audio;
- (void)bind:(ABPlayer *)player owner:(UIViewController<ABSessionOwner> *)owner audio:(BOOL)audio title:(NSString *)title artist:(NSString *)artist artwork:(UIImage *)image artworkURL:(NSURL *)url;
- (void)forget:(UIViewController *)owner;
- (void)stop;
- (void)sourceVisible:(BOOL)visible owner:(UIViewController *)owner;
- (void)returnToSource;
- (void)navigateToOwner;
- (void)presentAudioFrom:(UIViewController *)presenter;
- (void)refresh;
- (MPRemoteCommandHandlerStatus)remoteNext:(MPRemoteCommandEvent *)event;
- (MPRemoteCommandHandlerStatus)remotePrevious:(MPRemoteCommandEvent *)event;
@end
