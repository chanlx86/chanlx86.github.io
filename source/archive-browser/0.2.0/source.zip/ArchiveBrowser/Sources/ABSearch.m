#import "ABSearch.h"

static NSString *ABQuote(NSString *s) {
    s=[s stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"];
    s=[s stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    return [NSString stringWithFormat:@"\"%@\"",s];
}
NSString *ABNormalizeExtension(NSString *s) {
    s=[[s stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] lowercaseString];
    while([s hasPrefix:@"."] || [s hasPrefix:@"*"])s=[s substringFromIndex:1];
    if(s.length>16 || [s rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyz0123456789"] invertedSet]].location!=NSNotFound)return nil;
    return s;
}
NSString *ABSearchQuery(NSString *text,BOOL titleOnly,NSString *collection,NSString *type) {
    NSString *t=[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *q=@"*:*";
    if(t.length) {
        NSMutableArray *words=[NSMutableArray array];
        for(NSString *w in [t componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]])if(w.length)[words addObject:ABQuote(w)];
        NSString *all=[words componentsJoinedByString:@" AND "];
        q=titleOnly?[NSString stringWithFormat:@"title:(%@)",all]:[NSString stringWithFormat:@"(title:%@^12 OR title:(%@)^6 OR (%@))",ABQuote(t),all,all];
    }
    if(collection.length)q=[NSString stringWithFormat:@"(%@) AND collection:%@",q,ABQuote(collection)];
    if(type.length)q=[NSString stringWithFormat:@"(%@) AND mediatype:%@",q,ABQuote(type)];
    return q;
}
NSString *ABSearchPath(NSString *query,NSInteger page,NSInteger sort) {
    NSString *path=[NSString stringWithFormat:@"/advancedsearch.php?q=%@&output=json&rows=25&page=%ld&fl%%5B%%5D=identifier&fl%%5B%%5D=title&fl%%5B%%5D=creator&fl%%5B%%5D=mediatype&fl%%5B%%5D=date&fl%%5B%%5D=addeddate",ABEncode(query),(long)page];
    // The proxy accepts _score, not score; without it relevance boosts may be ignored.
    NSArray *sorts=@[@"_score desc",@"addeddate desc",@"date desc",@"date asc"];
    if(sort>=0&&sort<(NSInteger)sorts.count)path=[path stringByAppendingFormat:@"&sort%%5B%%5D=%@&sort%%5B%%5D=identifier%%20asc",ABEncode(sorts[sort])];
    return path;
}

@interface ABFileScan ()
@property(nonatomic,strong) NSArray *documents;
@property(nonatomic,copy) NSString *extension;
@property(nonatomic,strong) NSMutableDictionary *tasks;
@property(nonatomic,strong) NSMutableIndexSet *matches;
@property(nonatomic) NSInteger next;
@property(nonatomic) NSInteger active;
@property(nonatomic) NSInteger checked;
@property(nonatomic) NSInteger failed;
@property(nonatomic) BOOL canceled;
@end
@implementation ABFileScan
- (instancetype)initWithDocuments:(NSArray *)documents extension:(NSString *)ext { if((self=[super init])) { _documents=[documents copy]; _extension=[ext copy]; _tasks=[NSMutableDictionary dictionary]; _matches=[NSMutableIndexSet indexSet]; } return self; }
- (void)publish { if(_canceled)return; NSMutableArray *a=[NSMutableArray array]; [_matches enumerateIndexesUsingBlock:^(NSUInteger i,BOOL *stop){[a addObject:self.documents[i]];}]; if(_progress)_progress(a,_checked,_failed,_checked==(NSInteger)_documents.count); }
- (void)start { [self pump]; if(!_documents.count)[self publish]; }
- (void)pump { while(!_canceled && _active<2 && _next<(NSInteger)_documents.count) { NSInteger i=_next++; _active++; [self read:i offset:0]; } }
- (void)finish:(NSInteger)i match:(BOOL)match failed:(BOOL)failed { if(_canceled)return; if(match)[_matches addIndex:i]; _active--; _checked++; if(failed)_failed++; [self publish]; [self pump]; }
- (void)read:(NSInteger)i offset:(NSInteger)offset {
    NSString *identifier=ABString(_documents[i][@"identifier"]);
    NSString *path=[NSString stringWithFormat:@"/metadata/%@/files?start=%ld&count=200",ABEncode(identifier),(long)offset];
    __weak ABFileScan *weak=self;
    NSURLSessionDataTask *task=[[ABHTTP shared] json:path completion:^(id json,NSError *e){
        ABFileScan *s=weak; if(!s||s.canceled)return; [s.tasks removeObjectForKey:@(i)];
        NSArray *files=[json isKindOfClass:[NSDictionary class]]?json[@"result"]:nil;
        if(e || ![files isKindOfClass:[NSArray class]]) { [s finish:i match:NO failed:YES]; return; }
        for(id f in files)if([f isKindOfClass:[NSDictionary class]] && !ABPrivate(f) && [ABString(f[@"name"]).pathExtension.lowercaseString isEqual:s.extension]) { [s finish:i match:YES failed:NO]; return; }
        if(files.count==200)[s read:i offset:offset+200]; else [s finish:i match:NO failed:NO];
    }];
    _tasks[@(i)]=task;
}
- (void)cancel { _canceled=YES; _progress=nil; for(NSURLSessionTask *t in _tasks.allValues)[t cancel]; [_tasks removeAllObjects]; }
- (void)dealloc { [self cancel]; }
@end
