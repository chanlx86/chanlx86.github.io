#import "ABPanels.h"
#import "ABSearch.h"
#import "ABUI.h"

@implementation ABAdvancedController {
    UITextField *_suffix;
}
- (instancetype)init { return [super initWithStyle:UITableViewStyleGrouped]; }
- (void)viewDidLoad {
    [super viewDidLoad]; self.title=@"高级搜索";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(close)];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"应用" style:UIBarButtonItemStyleDone target:self action:@selector(apply)];
    _suffix=[[UITextField alloc] initWithFrame:CGRectZero]; _suffix.placeholder=@"不限，或输入 ipa / zip / mp4 …"; _suffix.text=_extension; _suffix.autocorrectionType=UITextAutocorrectionTypeNo; _suffix.autocapitalizationType=UITextAutocapitalizationTypeNone; _suffix.clearButtonMode=UITextFieldViewModeWhileEditing; _suffix.font=[UIFont systemFontOfSize:16]; _suffix.returnKeyType=UIReturnKeyDone;
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag;
}
- (void)close { [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)apply { NSString *ext=ABNormalizeExtension(_suffix.text); if(!ext) { ABAlert(self,@"后缀格式",@"请输入不超过 16 个英文字母或数字，例如 ipa、zip、mp4；留空表示不限。"); return; } [self.view endEditing:YES]; void (^callback)(NSInteger,BOOL,NSString *)=_applied; NSInteger sort=_sort; BOOL title=_titleOnly; [self dismissViewControllerAnimated:YES completion:^{if(callback)callback(sort,title,ext);}]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)table { return 3; }
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section { return section==0?4:2; }
- (NSString *)tableView:(UITableView *)table titleForHeaderInSection:(NSInteger)section { return @[@"结果排序",@"关键词匹配",@"文件后缀"][section]; }
- (NSString *)tableView:(UITableView *)table titleForFooterInSection:(NSInteger)section { return @[@"相关性由 Archive 搜索引擎计算；日期排序分别使用收录时间或作品日期。",@"默认优先匹配标题，并要求结果包含所有关键词。",@"后缀按实际文件名核对，首次筛选可能较慢。条目内会继续应用同一后缀；留空表示不限。"][section]; }
- (CGFloat)tableView:(UITableView *)table heightForRowAtIndexPath:(NSIndexPath *)p { return p.section==2&&p.row==1?52:44; }
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)p {
    UITableViewCell *c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil]; c.textLabel.font=[UIFont systemFontOfSize:16];
    if(p.section==0) { c.textLabel.text=@[@"相关性最高",@"最新收录优先",@"作品日期：由新到旧",@"作品日期：由旧到新"][p.row]; c.accessoryType=p.row==_sort?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone; }
    else if(p.section==1) { c.textLabel.text=@[@"名称优先，兼顾简介和作者",@"仅在标题中匹配"][p.row]; c.accessoryType=p.row==(_titleOnly?1:0)?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone; }
    else if(p.row==0) { _suffix.translatesAutoresizingMaskIntoConstraints=NO; [c.contentView addSubview:_suffix]; NSDictionary *v=@{@"input":_suffix}; [c.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-16-[input]-16-|" options:0 metrics:nil views:v]]; [c.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[input]|" options:0 metrics:nil views:v]]; c.selectionStyle=UITableViewCellSelectionStyleNone; }
    else { UISegmentedControl *presets=[[UISegmentedControl alloc] initWithItems:@[@"不限",@"ipa",@"zip",@"mp4",@"mp3"]]; presets.translatesAutoresizingMaskIntoConstraints=NO; NSArray *values=@[@"",@"ipa",@"zip",@"mp4",@"mp3"]; NSUInteger selected=[values indexOfObject:ABNormalizeExtension(_suffix.text)?:@""]; presets.selectedSegmentIndex=selected==NSNotFound?UISegmentedControlNoSegment:(NSInteger)selected; [presets addTarget:self action:@selector(preset:) forControlEvents:UIControlEventValueChanged]; [c.contentView addSubview:presets]; NSDictionary *v=@{@"presets":presets}; [c.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-16-[presets]-16-|" options:0 metrics:nil views:v]]; [c.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-8-[presets(34)]" options:0 metrics:nil views:v]]; c.selectionStyle=UITableViewCellSelectionStyleNone; }
    return c;
}
- (void)preset:(UISegmentedControl *)sender { _suffix.text=@[@"",@"ipa",@"zip",@"mp4",@"mp3"][sender.selectedSegmentIndex]; [self.view endEditing:YES]; }
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)p { [table deselectRowAtIndexPath:p animated:YES]; if(p.section==0)_sort=p.row; if(p.section==1)_titleOnly=p.row==1; if(p.section<2)[table reloadSections:[NSIndexSet indexSetWithIndex:p.section] withRowAnimation:UITableViewRowAnimationNone]; }
@end

void ABShowHelp(UIViewController *presenter) {
    ABAboutController *help=[ABAboutController new];
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:help];
    nav.modalPresentationStyle=UIModalPresentationFormSheet; nav.preferredContentSize=CGSizeMake(540,640);
    [presenter presentViewController:nav animated:YES completion:nil];
}
