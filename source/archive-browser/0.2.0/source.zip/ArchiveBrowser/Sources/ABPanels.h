#import "ABCore.h"
@interface ABAdvancedController : UITableViewController
@property(nonatomic) NSInteger sort;
@property(nonatomic) BOOL titleOnly;
@property(nonatomic,copy) NSString *extension;
@property(nonatomic,copy) void (^applied)(NSInteger sort,BOOL titleOnly,NSString *extension);
@end
void ABShowHelp(UIViewController *presenter);
