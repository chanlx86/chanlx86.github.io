#import "ABCore.h"

NSString *ABSearchQuery(NSString *text, BOOL titleOnly, NSString *collection, NSString *type);
NSString *ABSearchPath(NSString *query, NSInteger page, NSInteger sort);
NSString *ABNormalizeExtension(NSString *text);

// Checks real file names. Two requests at a time, paginating large file lists.
@interface ABFileScan : NSObject
@property(nonatomic,copy) void (^progress)(NSArray *matches, NSInteger checked, NSInteger failed, BOOL done);
- (instancetype)initWithDocuments:(NSArray *)documents extension:(NSString *)extension;
- (void)start;
- (void)cancel;
@end
