# 存档浏览器 0.2.0

独立的 Objective-C iOS App，用原生 UIKit 界面访问 Internet Archive 的公开 API，不依赖现代网站的 JavaScript。工程与录屏大师、J2ME 模拟器分开。

## 0.2.0 更新

- 搜索区域加大，增加独立搜索按钮；原“打开条目”按钮替换为“使用说明”弹窗，底部保留浏览与下载两栏。仍可在搜索框粘贴官方条目链接。
- 修正默认相关性排序：显式使用服务支持的 `_score desc`。不传排序时，服务会忽略部分权重，相关条目未必优先；`score desc` 会报不支持。新增标题/短语权重，同时要求包含所有关键词。
- 高级搜索弹窗支持相关性、最新收录、作品日期新/旧排序，以及仅标题匹配。
- 后缀筛选核对真实文件名，而非用简介里的 ZIP、IPA 关键词代替。并发限制为 2 个文件列表请求，长列表分批核对，保留服务排序；候选数量与实际匹配数量分别显示。网络失败数会显示出来，下拉重试。大条目或宽泛搜索可能较慢。
- 音视频先在条目内播放，提供全屏与关闭按钮；全屏返回复用同一个播放器和播放进度，不创建第二路解码。
- 条目新增 IN COLLECTIONS 区域，显示合集名称/缩略图，点击可浏览合集并在其中搜索。

真机 0.2.0 功能报告：`tests/results/ipad3-ios9-020.json`。日期排序、结果分页去重、后缀筛选、合集浏览、窗口/全屏往返均已验证。示例后缀检索核对 11 个候选、确认 2 个真实 ZIP 条目，失败 0；短片窗口播放时未报告 stalls，全屏往返保留了进度。切换动画期间记录少量 dropped frames，不能将此说成全程零丢帧。

## 功能

- 关键词搜索；全部、软件、视频、音频、书籍分类；25 条一页。
- 粘贴 archive.org/details、download、metadata 条目链接或直接输入条目编号。
- 异步显示缩略图，内存缓存约 3 MB，磁盘缓存约 12 MB；在后台缩小图片。
- 文件列表每批 200 项；按名称筛选，筛选音视频或软件压缩包；显示格式、大小与受限标记。
- 在线播放、拖动进度、原生全屏控制；推荐较小 MP4 / MP3 衍生版本，也能手动挑文件。
- 系统后台下载、进度、暂停/继续、取消、删除；保存任务记录，启动时恢复系统中的下载。
- 下载完成后可离线播放、Quick Look 预览、分享给 Filza 等应用。

支持 iOS 9.0 以上、ARMv7 / ARM64、iPhone / iPad、横竖屏。在 iPad 3（iPad3,3）、iOS 9.3.6 越狱环境实测；其他设备目前只有构建覆盖，未真机测试。当前发行包用 ldid 伪签名，适用于越狱设备；不需要 UDID。普通设备需用自己的开发证书重新构建和签名。

播放器使用 AVPlayer / AVPlayerViewController 的系统解码路径，不以网页或逐帧软件绘制播放。MP4 仅是容器，内部若采用 HEVC、AV1 等老系统不支持的编码仍会失败；AVI、MKV、WebM 等文件可下载，但本 App 未添加第三方解码器。网络速度、服务器及原文件编码都会影响实际播放。没有登录、解压、转码或 IPA 自动安装功能；不绕过受限条目。

## 安装与文件位置

建议在 Filza 打开 `dist/存档浏览器_0.2.0_iphoneos-arm.deb` 安装。安装脚本只注册本 App，不重启 SpringBoard、不装全局插件、不改系统证书。若用 IPA，设备还需具备接受伪签名安装包的安装环境；不能据此保证爱思或系统安装器都能安装。DEB 是推荐路径。

本次以系统 App 安装的 iPad：

```
/Applications/ArchiveBrowser.app
/var/mobile/Documents/ArchiveBrowser/downloads.json
/var/mobile/Documents/ArchiveBrowser/Downloads/<任务 UUID>/<文件名>
/var/mobile/Library/Caches/ArchiveBrowser/Thumbnails
```

每个下载单独放在 UUID 文件夹内，避免同名覆盖及远程文件路径越界。App 的“说明”页显示当前设备实际路径。普通沙盒安装会使用自身容器中的 `Documents/ArchiveBrowser`，并启用 iTunes 文件共享。卸载 DEB 不主动删除下载文件，分享前可自行清理；UI 中删除任务会删除对应文件。下载可在后台继续，但用户强制划掉 App 可能让系统取消任务；任务不存在时会显示失败，可手动重新下载。暂停后若系统或设备重启丢失该任务，重试会从头下载。

## Xcode 7.3.1 构建

打开 `ArchiveBrowser.xcodeproj`，选择 ArchiveBrowser target。项目部署目标 iOS 9.0，设备架构 armv7 + arm64，无第三方依赖。若通过 Xcode 正常安装，请设置自己的签名。当前项目的默认设置关闭了签名，以匹配越狱部署。

也可在项目目录执行：

```sh
./build.sh
python3 scripts/deploy.py 192.168.1.18
python3 scripts/package.py
```

`build.sh` 默认使用 `/Volumes/OS X/Applications/Xcode.app/Contents/Developer` 的 9.3 SDK，可用 `AB_DEVELOPER_DIR` 覆盖。部署脚本通过 SSH 交互登录，不保存密码；停掉本 App 后用新 inode 原子替换程序，再刷新图标并启动。需要目标设备已有 ldid、SSH、su、uicache。部署会取回设备伪签名后的二进制，打包脚本才会使用它们生成 DEB / IPA。可传 `--socket <SSH 控制套接字>` 复用连接。

`scripts/Icons.m` 使用 AppKit 绘制图标与启动图片；资源已经生成。`scripts/create-xcode-project.py` 可重新生成 Xcode 工程。工程内容：

- `Sources/ABCore.m`：有界网络请求、API/路径处理、缩略图、下载和播放器。
- `Sources/ABUI.m`：搜索、条目、下载和说明界面。
- `Sources/ABSearch.m`：相关性查询、排序、真实文件后缀核对。
- `Sources/ABPanels.m`：高级搜索与说明弹窗。
- `Sources/App.m`：App 入口和生命周期。
- `tests/Integration.m`：只在 `./build.sh --testing` 时包含的真机测试；发行构建不会自动操作设备。

## 首版的下载与基础播放验证

第二轮真机原始报告位于 `build/device-test-2/report.json`（源码发行包中也有 `tests/results/ipad3-ios9.json`）。

| 项目 | 结果 |
| --- | --- |
| 搜索 | Big Buck Bunny 查询返回 125 项，首批显示 25 项 |
| 文件列表 | 正确读取示例条目全部 29 个文件 |
| 缩略图 | 180 × 124，解码后最大边限制 192 |
| ZIP 下载 | 198,820 字节，ZIP 文件头正确；额外校验压缩包内部与服务器给出的 MD5 |
| 在线视频 | 连续播放采样约 15 秒，访问日志 0 stalls / 0 dropped frames |
| 拖动进度 | 跳到 60 秒后继续至约 70 秒，0 stalls，访问日志记录 3 个丢帧 |
| 在线 MP3 | 播放时间持续推进，第二轮采样 0 stalls |
| 离线 MP3 | 本地文件正常进入 ready 状态并持续播放 |
| 取消与暂停 | 任务可暂停，取消后从记录中移除 |
| 内存 | 第二轮结束约 29 MB resident；不是长期峰值测量 |

以上是短时样本测试，不能证明所有存档编码、所有 CDN 或所有网络环境都流畅。后台传输采用 iOS 原生下载服务；本次未做重启设备后继续下载的大文件耐久测试。

数据接口参考：[Internet Archive Metadata API](https://archive.org/developers/md-read.html)。搜索使用 `/advancedsearch.php`，缩略图使用 `/services/img/<identifier>`，下载和播放使用公开 `/download/<identifier>/<file>` 链接；保留默认系统 TLS 校验。
