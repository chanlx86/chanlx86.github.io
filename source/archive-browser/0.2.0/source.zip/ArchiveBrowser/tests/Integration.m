// Compiled only into the diagnostic build, never the release.
#import "ABUI.h"
#import "ABSearch.h"
#import "ABPanels.h"
#import <AVFoundation/AVFoundation.h>
#import <mach/mach.h>
@interface ABBrowseController (Testing)
- (void)submitSearch;
- (void)showAdvanced;
- (void)loadNext;
- (void)updateAdvancedTitle;
@end
@interface ABItemController (Testing)
- (void)playRecommended;
- (void)enterFullscreen;
- (void)closePlayer;
@end
@interface ABIntegration : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@property(nonatomic,strong) ABItemController *item;
@property(nonatomic,strong) ABPlayer *player;
@property(nonatomic,strong) NSMutableDictionary *report;
@property(nonatomic,strong) NSDate *started;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) ABFileScan *scan;
@property(nonatomic) NSInteger stage;
@property(nonatomic) double beforeFullscreen;
@property(nonatomic) BOOL visualOnly;
@end
static ABIntegration *test;
@implementation ABIntegration
- (void)save { struct mach_task_basic_info info; mach_msg_type_number_t n=MACH_TASK_BASIC_INFO_COUNT; if(task_info(mach_task_self(),MACH_TASK_BASIC_INFO,(task_info_t)&info,&n)==KERN_SUCCESS)_report[@"residentMB"]=@(info.resident_size/1048576.0); _report[@"stage"]=@(_stage); NSData *d=[NSJSONSerialization dataWithJSONObject:_report options:NSJSONWritingPrettyPrinted error:nil]; [d writeToFile:@"/var/mobile/Media/ArchiveBrowser-Test/report.json" atomically:YES]; }
- (void)snapshot:(NSString *)name { UIGraphicsBeginImageContextWithOptions(_window.bounds.size,YES,1); [_window drawViewHierarchyInRect:_window.bounds afterScreenUpdates:YES]; NSData *png=UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext()); UIGraphicsEndImageContext(); [png writeToFile:[@"/var/mobile/Media/ArchiveBrowser-Test/" stringByAppendingString:[name stringByAppendingString:@".png"]] atomically:YES]; }
- (void)next:(NSInteger)s { _stage=s; _started=[NSDate date]; [self save]; }
- (void)query:(NSString *)text sort:(NSInteger)sort extension:(NSString *)ext titleOnly:(BOOL)title {
    [_browse setValue:@(sort) forKey:@"sort"]; [_browse setValue:ext forKey:@"extension"]; [_browse setValue:@(title) forKey:@"titleOnly"]; UITextField *field=[_browse valueForKey:@"search"]; field.text=text; [_browse updateAdvancedTitle]; [_browse submitSearch];
}
- (NSDictionary *)playback { AVPlayerItem *i=_player.player.currentItem; NSMutableDictionary *d=[@{@"status":@(i.status),@"time":@(isfinite(CMTimeGetSeconds(i.currentTime))?CMTimeGetSeconds(i.currentTime):0),@"rate":@(_player.player.rate),@"embedded":@(_player.parentViewController==_item),@"error":i.error.localizedDescription?:@""} mutableCopy]; AVPlayerItemAccessLogEvent *e=i.accessLog.events.lastObject; if(e) {d[@"stalls"]=@(e.numberOfStalls);d[@"droppedFrames"]=@(e.numberOfDroppedVideoFrames);} return d; }
- (void)begin {
    [UIApplication sharedApplication].idleTimerDisabled=YES; _report=[NSMutableDictionary dictionary]; _report[@"version"]=@"0.2.0";
    _report[@"query"]=ABSearchQuery(@"Big Buck Bunny",NO,nil,nil); _report[@"path"]=ABSearchPath(_report[@"query"],1,0);
    _report[@"extensions"]=@{@"dot":ABNormalizeExtension(@" .IPA ")?:@"invalid",@"wildcard":ABNormalizeExtension(@"*.zip")?:@"invalid",@"reject":@(!ABNormalizeExtension(@"../zip"))};
    _visualOnly=[[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/ui-only"]; [[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/ui-only" error:nil]; [self snapshot:@"home"]; ABShowHelp(_browse); _timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES]; [self next:1];
}
- (void)tick {
    double elapsed=-[_started timeIntervalSinceNow]; if(elapsed>130) { _report[@"failure"]=[NSString stringWithFormat:@"timeout stage %ld",(long)_stage]; [_timer invalidate]; [self save]; return; }
    if(_stage==1&&elapsed>2) {
        UINavigationController *nav=(id)_browse.presentedViewController; _report[@"help"]=@{@"modal":@(nav!=nil),@"sections":@([(UITableViewController *)nav.topViewController numberOfSectionsInTableView:((UITableViewController *)nav.topViewController).tableView])}; [self snapshot:@"help"];
        [_browse dismissViewControllerAnimated:NO completion:^{[self.browse showAdvanced];[self next:2];}];
    } else if(_stage==2&&elapsed>2) {
        [self snapshot:@"advanced"]; if(_visualOnly) { [_browse dismissViewControllerAnimated:NO completion:^{[self.browse openIdentifier:@"BigBuckBunny_328"];self.item=(id)self.browse.navigationController.topViewController;[self next:7];}]; return; } [_browse dismissViewControllerAnimated:NO completion:^{[self query:@"Big Buck Bunny" sort:0 extension:@"" titleOnly:NO];[self next:3];}];
    } else if(_stage==3&&elapsed>5&&![[_browse valueForKey:@"loading"] boolValue]) {
        NSArray *a=[_browse valueForKey:@"items"]; NSMutableArray *titles=[NSMutableArray array]; for(NSDictionary *d in a) {if(titles.count==5)break;[titles addObject:ABString(d[@"title"])];} _report[@"relevance"]=@{@"count":@(a.count),@"topTitles":titles,@"found":[_browse valueForKey:@"found"]}; [self snapshot:@"search"];
        [_browse loadNext]; [self next:4];
    } else if(_stage==4&&elapsed>3&&![[_browse valueForKey:@"loading"] boolValue]) {
        NSArray *a=[_browse valueForKey:@"items"]; NSMutableSet *ids=[NSMutableSet set];for(NSDictionary *d in a)[ids addObject:ABString(d[@"identifier"])]; _report[@"pagination"]=@{@"count":@(a.count),@"unique":@(ids.count==a.count)};
        [self query:@"Big Buck Bunny" sort:1 extension:@"" titleOnly:NO];[self next:5];
    } else if(_stage==5&&elapsed>3&&![[_browse valueForKey:@"loading"] boolValue]) {
        NSArray *a=[_browse valueForKey:@"items"]; BOOL ordered=YES; NSString *previous=nil; for(NSDictionary *d in a) {NSString *date=ABString(d[@"addeddate"]);if(previous.length&&date.length&&[previous compare:date]==NSOrderedAscending)ordered=NO;previous=date;}
        _report[@"latest"]=@{@"count":@(a.count),@"ordered":@(ordered)};
        [self query:@"mp3 test file" sort:0 extension:@"zip" titleOnly:YES];[self next:6];
    } else if(_stage==6&&elapsed>3&&![[_browse valueForKey:@"loading"] boolValue]) {
        NSArray *a=[_browse valueForKey:@"items"]; BOOL contains=NO; NSMutableArray *ids=[NSMutableArray array];for(NSDictionary *d in a) { [ids addObject:ABString(d[@"identifier"])]; if([ABString(d[@"identifier"]) isEqual:@"testmp3testfile"])contains=YES; }
        _report[@"suffix"]=@{@"count":@(a.count),@"checked":[_browse valueForKey:@"checked"],@"failed":[_browse valueForKey:@"failedChecks"],@"containsKnownZIP":@(contains),@"identifiers":ids}; [self snapshot:@"suffix"];
        [_browse setValue:@"" forKey:@"extension"]; [_browse openIdentifier:@"BigBuckBunny_328"]; _item=(id)_browse.navigationController.topViewController; [self next:7];
    } else if(_stage==7&&elapsed>4) {
        NSArray *files=[_item valueForKey:@"files"],*collections=[_item valueForKey:@"collections"]; if(files.count&&collections.count) { _report[@"collections"]=collections;[self snapshot:@"collections"];[_item playRecommended];_player=[_item valueForKey:@"inlinePlayer"];[self next:8]; }
    } else if(_stage==8&&elapsed>16) {
        _report[@"inline"]=[self playback]; _beforeFullscreen=CMTimeGetSeconds(_player.player.currentTime); [_item enterFullscreen]; [self next:9];
    } else if(_stage==9&&elapsed>5) {
        _report[@"fullscreen"]=[self playback]; _report[@"samePlayer"]=@(_item.presentedViewController==_player); [_player dismissViewControllerAnimated:YES completion:^{[self next:10];}];
    } else if(_stage==10&&elapsed>3) {
        _report[@"returnedInline"]=[self playback]; _report[@"progressPreserved"]=@(CMTimeGetSeconds(_player.player.currentTime)>=_beforeFullscreen); [_player.player pause]; [self snapshot:@"inline"];
        if(_visualOnly) { [self next:12]; return; } [_item closePlayer]; [_item tableView:_item.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]]; [self next:11];
    } else if(_stage==12&&elapsed>15) { [_item closePlayer]; [self finish];
    } else if(_stage==11&&elapsed>6) {
        ABBrowseController *collection=(id)_browse.navigationController.topViewController;
        if([collection isKindOfClass:[ABBrowseController class]]&& ![[collection valueForKey:@"loading"] boolValue]) { _report[@"collectionBrowse"]=@{@"scope":[collection valueForKey:@"collection"]?:@"",@"count":@([[collection valueForKey:@"items"] count])}; [self snapshot:@"collection-browse"]; [self finish]; }
    }
}
- (void)finish { [_timer invalidate]; _timer=nil; [_browse.navigationController popToRootViewControllerAnimated:NO]; [_browse setValue:@"" forKey:@"extension"];[_browse setValue:@0 forKey:@"sort"];[_browse setValue:@NO forKey:@"titleOnly"]; _report[@"downloadRecords"]=@([ABDownloads shared].records.count); _report[@"complete"]=@YES; [self save]; [UIApplication sharedApplication].idleTimerDisabled=NO; }
@end
void ABStartIntegration(UIWindow *window,ABBrowseController *browse) { test=[ABIntegration new];test.window=window;test.browse=browse;[test begin]; }
