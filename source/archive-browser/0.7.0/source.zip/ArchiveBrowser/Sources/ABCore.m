#import "ABCore.h"
#import "ABExtras.h"
#import "ABMedia.h"
#import "ABSession.h"
#import "ABPlayback.h"
#import "ABVault.h"
#import <ImageIO/ImageIO.h>
#import <CommonCrypto/CommonDigest.h>
#import <AVFoundation/AVFoundation.h>

NSString * const ABDownloadsChanged = @"ABDownloadsChanged";
NSString *ABString(id v) {
    if ([v isKindOfClass:[NSString class]]) return v;
    if ([v isKindOfClass:[NSNumber class]]) return [v stringValue];
    if ([v isKindOfClass:[NSArray class]]) { NSMutableArray *a=[NSMutableArray array]; for(id x in v) if(ABString(x).length) [a addObject:ABString(x)]; return [a componentsJoinedByString:@" · "]; }
    return @"";
}
NSString *ABEncode(NSString *v) { return [v stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"]]; }
NSString *ABIdentifier(NSString *input) {
    NSString *s=[input stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([s rangeOfString:@"://"].location!=NSNotFound) {
        NSURL *u=[NSURL URLWithString:s]; NSString *h=u.host.lowercaseString;
        if (![h isEqualToString:@"archive.org"] && ![h isEqualToString:@"www.archive.org"]) return nil;
        NSArray *p=u.path.pathComponents;
        if(p.count<3 || ![@[@"details",@"download",@"metadata"] containsObject:p[1]]) return nil;
        s=p[2];
    }
    if (!s.length || s.length>200 || [s isEqualToString:@"."] || [s isEqualToString:@".."] || [s rangeOfCharacterFromSet:[[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._"] invertedSet]].location!=NSNotFound) return nil;
    return s;
}
NSURL *ABFileURL(NSString *identifier,NSString *name) {
    if(!ABIdentifier(identifier) || !name.length) return nil;
    NSMutableArray *a=[NSMutableArray array]; for(NSString *p in [name componentsSeparatedByString:@"/"]) [a addObject:ABEncode(p)];
    return [NSURL URLWithString:[NSString stringWithFormat:@"https://archive.org/download/%@/%@",ABEncode(identifier),[a componentsJoinedByString:@"/"]]];
}
NSString *ABSize(long long b) { return b>0?[NSByteCountFormatter stringFromByteCount:b countStyle:NSByteCountFormatterCountStyleFile]:@"大小未知"; }
BOOL ABPlayable(NSString *s) {NSString *ext=s.pathExtension.lowercaseString;if(ABAudioFile(s))return [ext isEqual:@"mp3"];return [@[@"mp4",@"m4v",@"mov",@"3gp",@"3g2",@"m3u8"] containsObject:ext];}
BOOL ABPrivate(NSDictionary *f) { NSString *p=ABString(f[@"private"]).lowercaseString; return [@[@"true",@"1",@"yes"] containsObject:p]; }
UIColor *ABTint(void) { return [UIColor colorWithRed:0.05 green:0.39 blue:0.55 alpha:1]; }
void ABAlert(UIViewController *vc,NSString *title,NSString *message) { if(vc.presentedViewController) return; UIAlertController *a=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert]; [a addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]]; [vc presentViewController:a animated:YES completion:nil]; }
static BOOL ABDeferSheet(UIViewController *vc,void (^retry)(void)) {UIViewController *previous=vc.presentedViewController;if(!previous)return NO;if(![previous isKindOfClass:[UIAlertController class]])return YES;id<UIViewControllerTransitionCoordinator> transition=previous.transitionCoordinator;if((previous.isBeingDismissed||previous.isBeingPresented)&&transition){[transition animateAlongsideTransition:nil completion:^(id<UIViewControllerTransitionCoordinatorContext> context){dispatch_async(dispatch_get_main_queue(),retry);}];}else [vc dismissViewControllerAnimated:NO completion:retry];return YES;}
void ABPresentBarSheet(UIViewController *vc,UIAlertController *sheet,UIBarButtonItem *item) {if(ABDeferSheet(vc,^{ABPresentBarSheet(vc,sheet,item);}))return;UIPopoverPresentationController *p=sheet.popoverPresentationController;if(item){p.barButtonItem=item;p.permittedArrowDirections=[vc.toolbarItems containsObject:item]?UIPopoverArrowDirectionDown:UIPopoverArrowDirectionUp;}else{p.sourceView=vc.view;CGRect r=vc.view.bounds;p.sourceRect=CGRectMake(CGRectGetMidX(r),CGRectGetMaxY(r)-1,1,1);p.permittedArrowDirections=UIPopoverArrowDirectionDown;}[vc presentViewController:sheet animated:YES completion:nil];}
void ABPresentSheet(UIViewController *vc,UIAlertController *sheet,UIView *anchor) {if(!anchor||!anchor.window){UIBarButtonItem *item=vc.navigationItem.rightBarButtonItem;if(!vc.navigationController.toolbarHidden)for(UIBarButtonItem *candidate in vc.toolbarItems)if([candidate.title isEqual:@"移动"]){item=candidate;break;}ABPresentBarSheet(vc,sheet,item);return;}if(ABDeferSheet(vc,^{ABPresentSheet(vc,sheet,anchor);}))return;UIPopoverPresentationController *p=sheet.popoverPresentationController;p.sourceView=anchor;CGRect visible=[anchor convertRect:anchor.window.bounds fromView:anchor.window];CGRect rect=CGRectIntersection(anchor.bounds,visible);p.sourceRect=CGRectIsEmpty(rect)?anchor.bounds:rect;p.permittedArrowDirections=UIPopoverArrowDirectionAny;[vc presentViewController:sheet animated:YES completion:nil];}
NSString *ABDocuments(void) { NSString *p=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"ArchiveBrowser"]; [[NSFileManager defaultManager] createDirectoryAtPath:p withIntermediateDirectories:YES attributes:nil error:nil]; return p; }
static NSError *ABError(NSString *text) { return [NSError errorWithDomain:@"ArchiveBrowser" code:1 userInfo:@{NSLocalizedDescriptionKey:text?:@"请求失败"}]; }

@interface ABHTTP ()
@property(nonatomic,strong) NSURLSession *session;
@property(nonatomic,strong) NSMutableDictionary *jobs;
@end
@implementation ABHTTP
+ (instancetype)shared { static ABHTTP *s; static dispatch_once_t t; dispatch_once(&t,^{s=[self new];}); return s; }
- (instancetype)init { if((self=[super init])) { _jobs=[NSMutableDictionary dictionary]; NSURLSessionConfiguration *c=[NSURLSessionConfiguration ephemeralSessionConfiguration]; c.timeoutIntervalForRequest=35; c.timeoutIntervalForResource=90; c.HTTPMaximumConnectionsPerHost=4; c.HTTPAdditionalHeaders=@{@"User-Agent":@"ArchiveBrowser-iOS/0.6 (public archive client)"}; _session=[NSURLSession sessionWithConfiguration:c delegate:self delegateQueue:[NSOperationQueue mainQueue]]; } return self; }
- (NSURLSessionDataTask *)get:(NSURL *)url limit:(NSUInteger)limit completion:(ABDataBlock)block {
    if(!url) { dispatch_async(dispatch_get_main_queue(),^{block(nil,ABError(@"无效地址"));}); return nil; }
    NSURLSessionDataTask *t=[_session dataTaskWithURL:url]; _jobs[@(t.taskIdentifier)]=[@{@"data":[NSMutableData data],@"limit":@(limit),@"block":[block copy]} mutableCopy]; [t resume]; return t;
}
- (NSURLSessionDataTask *)request:(NSURLRequest *)request limit:(NSUInteger)limit completion:(void (^)(NSData *,NSHTTPURLResponse *,NSError *))block {NSURLSessionDataTask *t=[_session dataTaskWithRequest:request];_jobs[@(t.taskIdentifier)]=[@{@"data":[NSMutableData data],@"limit":@(limit),@"reply":[block copy]} mutableCopy];[t resume];return t;}
- (NSURLSessionDataTask *)json:(NSString *)path completion:(ABJSONBlock)block {
    return [self get:[NSURL URLWithString:[@"https://archive.org" stringByAppendingString:path]] limit:4*1024*1024 completion:^(NSData *d,NSError *e) { id j=nil; if(!e) j=[NSJSONSerialization JSONObjectWithData:d options:0 error:&e]; if([j isKindOfClass:[NSDictionary class]] && j[@"error"]) e=ABError(ABString(j[@"error"])); block(j,e); }];
}
- (void)URLSession:(NSURLSession *)s dataTask:(NSURLSessionDataTask *)t didReceiveResponse:(NSURLResponse *)r completionHandler:(void (^)(NSURLSessionResponseDisposition))handler {
    NSMutableDictionary *j=_jobs[@(t.taskIdentifier)]; NSInteger status=[(NSHTTPURLResponse *)r statusCode];
    if(status<200 || status>=300 || r.expectedContentLength>[j[@"limit"] longLongValue]) { j[@"error"]=ABError(status>=400?[NSString stringWithFormat:@"服务器返回 HTTP %ld。受限条目请在官方网站处理。",(long)status]:@"响应过大，请缩小查询范围。"); handler(NSURLSessionResponseCancel); } else handler(NSURLSessionResponseAllow);
}
- (void)URLSession:(NSURLSession *)s dataTask:(NSURLSessionDataTask *)t didReceiveData:(NSData *)data { NSMutableDictionary *j=_jobs[@(t.taskIdentifier)]; NSMutableData *d=j[@"data"]; if(d.length+data.length>[j[@"limit"] unsignedIntegerValue]) { j[@"error"]=ABError(@"响应过大，请缩小查询范围。"); [t cancel]; } else [d appendData:data]; }
- (void)URLSession:(NSURLSession *)s task:(NSURLSessionTask *)t didCompleteWithError:(NSError *)e { NSMutableDictionary *j=_jobs[@(t.taskIdentifier)]; if(!j)return; [_jobs removeObjectForKey:@(t.taskIdentifier)]; if(j[@"reply"]){void(^b)(NSData *,NSHTTPURLResponse *,NSError *)=j[@"reply"];b(j[@"data"],(id)t.response,j[@"error"]?:e);}else{ABDataBlock b=j[@"block"];b(j[@"data"],j[@"error"]?:e);} }
@end

@interface ABImages ()
@property(nonatomic,strong) NSMutableDictionary *cache;
@property(nonatomic,strong) NSMutableArray *imageOrder;
@property(nonatomic) NSUInteger imageCost;
@property(nonatomic,strong) NSMutableDictionary *waiting;
@property(nonatomic,copy) NSString *folder;
@property(nonatomic) dispatch_queue_t io;
@end
@implementation ABImages
+ (instancetype)shared { static ABImages *s; static dispatch_once_t t; dispatch_once(&t,^{s=[self new];}); return s; }
- (instancetype)init { if((self=[super init])) { _cache=[NSMutableDictionary dictionary]; _imageOrder=[NSMutableArray array]; _waiting=[NSMutableDictionary dictionary]; _io=dispatch_queue_create("local.archive.images",DISPATCH_QUEUE_SERIAL); _folder=[NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES).firstObject stringByAppendingPathComponent:@"ArchiveBrowser/Thumbnails"]; [[NSFileManager defaultManager] createDirectoryAtPath:_folder withIntermediateDirectories:YES attributes:nil error:nil]; dispatch_async(_io,^{[self trimFor:0];}); } return self; }
- (void)clearMemory { [_cache removeAllObjects]; [_imageOrder removeAllObjects]; _imageCost=0; }
- (void)trimFor:(NSUInteger)incoming { NSFileManager *fm=[NSFileManager defaultManager];NSMutableArray *files=[NSMutableArray array];unsigned long long total=0;for(NSString *name in [fm contentsOfDirectoryAtPath:_folder error:nil]){NSString *path=[_folder stringByAppendingPathComponent:name];NSDictionary *a=[fm attributesOfItemAtPath:path error:nil];total+=a.fileSize;[files addObject:@{@"path":path,@"size":@(a.fileSize),@"date":a[NSFileModificationDate]?:[NSDate distantPast]}];}[files sortUsingComparator:^NSComparisonResult(NSDictionary *a,NSDictionary *b){return [a[@"date"] compare:b[@"date"]];}];for(NSDictionary *f in files){if(total+incoming<=8*1024*1024)break;if([fm removeItemAtPath:f[@"path"] error:nil])total-=[f[@"size"] unsignedLongLongValue];} }
- (void)deliver:(UIImage *)im key:(NSString *)key { if(im){NSUInteger cost=CGImageGetBytesPerRow(im.CGImage)*CGImageGetHeight(im.CGImage);if(cost<=1536*1024){while(_imageOrder.count&&_imageCost+cost>1536*1024){NSString *old=_imageOrder.firstObject;UIImage *image=_cache[old];_imageCost-=CGImageGetBytesPerRow(image.CGImage)*CGImageGetHeight(image.CGImage);[_cache removeObjectForKey:old];[_imageOrder removeObjectAtIndex:0];}_cache[key]=im;[_imageOrder addObject:key];_imageCost+=cost;}} NSArray *blocks=[_waiting[key] copy]; [_waiting removeObjectForKey:key]; for(void (^b)(UIImage *) in blocks) b(im); }
- (void)image:(NSString *)key completion:(void (^)(UIImage *))block {
    if(!ABIdentifier(key)) { block(nil); return; }
    [self imageURL:[NSURL URLWithString:[@"https://archive.org/services/img/" stringByAppendingString:ABEncode(key)]] completion:block];
}
- (void)privateImage:(NSURL *)url completion:(void (^)(UIImage *))block {[[ABHTTP shared] get:url limit:2*1024*1024 completion:^(NSData *data,NSError *error){dispatch_async(self.io,^{UIImage *image=nil;if(data&&!error){CGImageSourceRef source=CGImageSourceCreateWithData((__bridge CFDataRef)data,NULL);if(source){NSDictionary *options=@{(id)kCGImageSourceCreateThumbnailFromImageAlways:@YES,(id)kCGImageSourceThumbnailMaxPixelSize:@384,(id)kCGImageSourceCreateThumbnailWithTransform:@YES};CGImageRef cg=CGImageSourceCreateThumbnailAtIndex(source,0,(__bridge CFDictionaryRef)options);if(cg){image=[UIImage imageWithCGImage:cg];CGImageRelease(cg);}CFRelease(source);}}dispatch_async(dispatch_get_main_queue(),^{if(ABPrivateActive())block(image);});});}];}
- (void)imageURL:(NSURL *)url completion:(void (^)(UIImage *))block {
    if(!url||![url.scheme isEqual:@"https"]||![url.host isEqual:@"archive.org"]) {block(nil);return;}
    if(ABPrivateActive()){[self privateImage:url completion:block];return;}
    NSString *key=url.absoluteString;
    NSData *hashData=[key dataUsingEncoding:NSUTF8StringEncoding]; unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256(hashData.bytes,(CC_LONG)hashData.length,digest); NSMutableString *hash=[NSMutableString string];for(int i=0;i<CC_SHA256_DIGEST_LENGTH;i++)[hash appendFormat:@"%02x",digest[i]];
    UIImage *im=[_cache objectForKey:key]; if(im) { [_imageOrder removeObject:key];[_imageOrder addObject:key]; block(im); return; }
    if(_waiting[key]) { [_waiting[key] addObject:[block copy]]; return; } _waiting[key]=[NSMutableArray arrayWithObject:[block copy]];
    NSString *path=[_folder stringByAppendingPathComponent:[hash stringByAppendingString:@".jpg"]];
    dispatch_async(_io,^{ UIImage *disk=[UIImage imageWithContentsOfFile:path]; dispatch_async(dispatch_get_main_queue(),^{ if(disk) { [self deliver:disk key:key]; return; }
        [[ABHTTP shared] get:url limit:2*1024*1024 completion:^(NSData *d,NSError *e){
            dispatch_async(self.io,^{ UIImage *small=nil; if(!e && d.length) { CGImageSourceRef source=CGImageSourceCreateWithData((__bridge CFDataRef)d,NULL); if(source) { NSDictionary *opts=@{(id)kCGImageSourceCreateThumbnailFromImageAlways:@YES,(id)kCGImageSourceThumbnailMaxPixelSize:@384,(id)kCGImageSourceCreateThumbnailWithTransform:@YES}; CGImageRef image=CGImageSourceCreateThumbnailAtIndex(source,0,(__bridge CFDictionaryRef)opts); if(image) { small=[UIImage imageWithCGImage:image]; CGImageRelease(image); NSData *jpeg=UIImageJPEGRepresentation(small,0.82);[self trimFor:jpeg.length];[jpeg writeToFile:path atomically:YES]; } CFRelease(source); } } dispatch_async(dispatch_get_main_queue(),^{[self deliver:small key:key];}); });
        }];
    }); });
}
@end

@interface ABDownloads ()
@property(nonatomic,strong) NSURLSession *session;
@property(nonatomic,strong) NSMutableDictionary *tasks;
@property(nonatomic,copy) NSString *folder;
@property(nonatomic,copy) NSString *indexPath;
@property(nonatomic,strong) NSDate *lastNotification;
@end
@implementation ABDownloads
+ (instancetype)shared { static ABDownloads *s; static dispatch_once_t t; dispatch_once(&t,^{s=[self new];}); return s; }
- (instancetype)init { if((self=[super init])) {
    _folder=[ABDocuments() stringByAppendingPathComponent:@"Downloads"]; [[NSFileManager defaultManager] createDirectoryAtPath:_folder withIntermediateDirectories:YES attributes:nil error:nil];
    _indexPath=[ABDocuments() stringByAppendingPathComponent:@"downloads.json"]; id j=[NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:_indexPath]?:[NSData data] options:NSJSONReadingMutableContainers error:nil]; _records=[j isKindOfClass:[NSArray class]]?j:[NSMutableArray array]; _tasks=[NSMutableDictionary dictionary];
    NSURLSessionConfiguration *c=[NSURLSessionConfiguration backgroundSessionConfigurationWithIdentifier:@"local.ArchiveBrowser.downloads.v1"]; c.HTTPMaximumConnectionsPerHost=2; c.timeoutIntervalForRequest=60; c.timeoutIntervalForResource=7*24*3600; c.discretionary=NO; c.sessionSendsLaunchEvents=YES;
    _session=[NSURLSession sessionWithConfiguration:c delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    [_session getAllTasksWithCompletionHandler:^(NSArray *a){ dispatch_async(dispatch_get_main_queue(),^{ for(NSURLSessionTask *t in a) { if([self record:t.taskDescription]) self.tasks[t.taskDescription]=t; else [t cancel]; } for(NSMutableDictionary *r in self.records) { if([@[@"downloading",@"paused",@"waiting"] containsObject:r[@"status"]] && !self.tasks[r[@"id"]]) { r[@"status"]=@"failed"; r[@"error"]=@"下载已中断，点击可重试。"; } if([r[@"status"] isEqual:@"complete"] && ![[NSFileManager defaultManager] fileExistsAtPath:[self localURL:r].path]) { r[@"status"]=@"failed"; r[@"error"]=@"文件不存在，请重新下载。"; } } [self save]; [self notify]; }); }];
} return self; }
- (NSMutableDictionary *)record:(NSString *)key { for(NSMutableDictionary *r in _records) if([r[@"id"] isEqual:key]) return r; return nil; }
- (void)save { NSData *d=[NSJSONSerialization dataWithJSONObject:_records options:0 error:nil]; [d writeToFile:_indexPath atomically:YES]; }
- (void)notify { _lastNotification=[NSDate date]; [[NSNotificationCenter defaultCenter] postNotificationName:ABDownloadsChanged object:self]; }
- (NSURL *)localURL:(NSDictionary *)r { NSString *rid=ABString(r[@"id"]); if(![[NSUUID alloc] initWithUUIDString:rid]) return nil; NSString *name=ABString(r[@"name"]).lastPathComponent; if(!name.length || [name isEqual:@"."] || [name isEqual:@".."]) return nil; return [NSURL fileURLWithPath:[[_folder stringByAppendingPathComponent:rid] stringByAppendingPathComponent:name]]; }
- (void)start:(NSMutableDictionary *)r {
    NSURL *url=ABFileURL(r[@"identifier"],r[@"name"]); if(!url) { r[@"status"]=@"failed"; r[@"error"]=@"无效文件地址"; [self save]; [self notify]; return; }
    NSDictionary *disk=[[NSFileManager defaultManager] attributesOfFileSystemForPath:_folder error:nil];
    long long remaining=MAX(0,[r[@"total"] longLongValue]);
    if([disk[NSFileSystemFreeSize] unsignedLongLongValue]<(unsigned long long)remaining+100*1024*1024) { r[@"status"]=@"failed"; r[@"error"]=@"可用空间不足，请释放空间后重试。"; [self save]; [self notify]; return; }
    NSURLSessionDownloadTask *t=[_session downloadTaskWithURL:url]; t.taskDescription=r[@"id"]; _tasks[r[@"id"]]=t; r[@"status"]=@"downloading"; r[@"bytes"]=@0; [r removeObjectForKey:@"error"]; [self save]; [t resume]; [self notify];
}
- (NSDictionary *)add:(NSString *)identifier file:(NSDictionary *)file title:(NSString *)title {
    NSString *name=ABString(file[@"name"]); if(!ABFileURL(identifier,name) || ABPrivate(file)) return nil;
    for(NSDictionary *r in _records) if([r[@"identifier"] isEqual:identifier] && [r[@"name"] isEqual:name]) return r;
    long long size=[ABString(file[@"size"]) longLongValue]; NSDictionary *disk=[[NSFileManager defaultManager] attributesOfFileSystemForPath:_folder error:nil];
    unsigned long long free=[disk[NSFileSystemFreeSize] unsignedLongLongValue]; long long reserved=0; for(NSDictionary *r in _records) if([@[@"downloading",@"paused"] containsObject:r[@"status"]]) reserved+=MAX(0,[r[@"total"] longLongValue]-[r[@"bytes"] longLongValue]);
    NSMutableDictionary *r=[@{@"id":[NSUUID UUID].UUIDString,@"identifier":identifier,@"name":name,@"title":title?:identifier,@"total":@(size),@"bytes":@0,@"created":@([[NSDate date] timeIntervalSince1970]),@"status":@"waiting"} mutableCopy]; [_records insertObject:r atIndex:0];
    if(free<(unsigned long long)MAX(0,size+reserved)+100*1024*1024) { r[@"status"]=@"failed"; r[@"error"]=@"可用空间不足。请释放空间后重试，建议保留至少 100 MB。"; [self save]; [self notify]; } else [self start:r]; return r;
}
- (NSDictionary *)importURL:(NSURL *)url identifier:(NSString *)identifier name:(NSString *)name title:(NSString *)title {
 if(!url.isFileURL||!ABIdentifier(identifier)||!name.lastPathComponent.length)return nil;uint64_t size=[[[NSFileManager defaultManager] attributesOfItemAtPath:url.path error:nil][NSFileSize] unsignedLongLongValue];NSDictionary *disk=[[NSFileManager defaultManager] attributesOfFileSystemForPath:_folder error:nil];if([disk[NSFileSystemFreeSize] unsignedLongLongValue]<size+100*1024*1024)return nil;NSMutableDictionary *r=[@{@"id":[NSUUID UUID].UUIDString,@"identifier":identifier,@"name":name,@"title":title?:identifier,@"total":@(size),@"bytes":@(size),@"created":@([[NSDate date] timeIntervalSince1970]),@"status":@"complete"} mutableCopy];NSURL *dest=[self localURL:r];NSError *error=nil;[[NSFileManager defaultManager] createDirectoryAtURL:[dest URLByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:&error];if(!error)[[NSFileManager defaultManager] copyItemAtURL:url toURL:dest error:&error];if(error)return nil;[_records insertObject:r atIndex:0];[self save];[self notify];return r;
}
- (void)toggle:(NSDictionary *)record { NSMutableDictionary *r=[self record:record[@"id"]]; if(!r || [r[@"status"] isEqual:@"complete"])return; NSURLSessionTask *t=_tasks[r[@"id"]]; if([r[@"status"] isEqual:@"downloading"] && t) { [t suspend]; r[@"status"]=@"paused"; } else if([r[@"status"] isEqual:@"paused"] && t) { [t resume]; r[@"status"]=@"downloading"; } else { [self start:r]; } [self save]; [self notify]; }
- (void)remove:(NSDictionary *)r { [_tasks[r[@"id"]] cancel]; [_tasks removeObjectForKey:r[@"id"]]; NSURL *url=[self localURL:r]; if(url) [[NSFileManager defaultManager] removeItemAtURL:[url URLByDeletingLastPathComponent] error:nil]; [_records removeObject:r]; [self save]; [self notify]; }
- (void)URLSession:(NSURLSession *)s downloadTask:(NSURLSessionDownloadTask *)t didWriteData:(int64_t)b totalBytesWritten:(int64_t)written totalBytesExpectedToWrite:(int64_t)total { NSMutableDictionary *r=[self record:t.taskDescription]; if(!r)return; r[@"bytes"]=@(written); if(total>0)r[@"total"]=@(total); if(!_lastNotification || -[_lastNotification timeIntervalSinceNow]>0.5) [self notify]; }
- (void)URLSession:(NSURLSession *)s downloadTask:(NSURLSessionDownloadTask *)t didFinishDownloadingToURL:(NSURL *)location {
    NSMutableDictionary *r=[self record:t.taskDescription]; if(!r)return;
    NSInteger code=[(NSHTTPURLResponse *)t.response statusCode]; NSError *e=nil; NSURL *dest=[self localURL:r];
    if(code<200 || code>=300) e=ABError([NSString stringWithFormat:@"HTTP %ld；文件可能受限或已移除。",(long)code]);
    else if([t.response.MIMEType.lowercaseString isEqual:@"text/html"] && ![@[@"html",@"htm"] containsObject:ABString(r[@"name"]).pathExtension.lowercaseString]) e=ABError(@"服务器返回了网页，未将其保存为下载文件。请在官网检查该文件的访问权限。");
    else if(!dest) e=ABError(@"文件名无效");
    else { [[NSFileManager defaultManager] createDirectoryAtURL:[dest URLByDeletingLastPathComponent] withIntermediateDirectories:YES attributes:nil error:&e]; if(!e) [[NSFileManager defaultManager] moveItemAtURL:location toURL:dest error:&e]; }
    if(e) { r[@"status"]=@"failed"; r[@"error"]=e.localizedDescription; } else { r[@"status"]=@"complete"; r[@"bytes"]=@([[[NSFileManager defaultManager] attributesOfItemAtPath:dest.path error:nil] fileSize]); r[@"total"]=r[@"bytes"]; }
    [self save]; [self notify];
}
- (void)URLSession:(NSURLSession *)s task:(NSURLSessionTask *)t didCompleteWithError:(NSError *)e { NSMutableDictionary *r=[self record:t.taskDescription]; [_tasks removeObjectForKey:t.taskDescription?:@""]; if(!r)return; if(e && ![r[@"status"] isEqual:@"complete"]) { r[@"status"]=@"failed"; r[@"error"]=e.localizedDescription; } [self save]; [self notify]; }
- (void)URLSessionDidFinishEventsForBackgroundURLSession:(NSURLSession *)s { if(_backgroundCompletion) { void (^b)(void)=_backgroundCompletion; _backgroundCompletion=nil; b(); } }
@end

@implementation ABPlayer {
    BOOL _observing;
    BOOL _closing;
    AVPlayerItem *_observedItem;
    ABStream *_stream; NSURL *_sourceURL; id _positionObserver; BOOL _restored; BOOL _directFallback; BOOL _resumePending;
}
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title {return [self initWithURL:url title:title privateMode:NO];}
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title privateMode:(BOOL)privateMode {
    if((self=[super init])) { _privateMode=privateMode;self.mediaName=title; self.player=[AVPlayer new];self.player.actionAtItemEnd=AVPlayerActionAtItemEndNone;[self configureURL:url]; self.title=title; self.modalPresentationStyle=UIModalPresentationFullScreen; }
    return self;
}
- (void)configureURL:(NSURL *)url {_sourceURL=url;self.preparationText=nil;if(ABAudioFile(url.path)&&![url.pathExtension.lowercaseString isEqual:@"mp3"]){[self.player pause];[self.player replaceCurrentItemWithPlayerItem:nil];self.preparationText=@"音频预览仅支持 MP3；其他格式可下载后在其他播放器打开。";return;}[self configureReadyURL:url];}
- (void)configureReadyURL:(NSURL *)url {[self.player pause];[self.player replaceCurrentItemWithPlayerItem:nil];[_stream cancel];_stream=nil;_restored=NO;_resumePending=NO;self.cacheFailure=nil;_directFallback=NO;BOOL cache=!_privateMode&&[url.scheme isEqual:@"https"]&&[url.host isEqual:@"archive.org"]&&![url.pathExtension.lowercaseString isEqual:@"m3u8"];if(cache)_stream=[[ABStream alloc] initWithURL:url];AVPlayerItem *item=_stream?[AVPlayerItem playerItemWithAsset:_stream.asset]:[AVPlayerItem playerItemWithURL:url];[self.player replaceCurrentItemWithPlayerItem:item];}
- (void)restart {_resumePending=NO;[self.player seekToTime:kCMTimeZero];}
- (void)savePosition {if(!_privateMode&&_restored&&!_resumePending)[[ABPositions shared] store:_sourceURL seconds:CMTimeGetSeconds(self.player.currentTime) duration:CMTimeGetSeconds(self.player.currentItem.duration)];}
- (void)viewDidLoad {
    [super viewDidLoad];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    // AVKit owns buffering and paused-state UI; no second timer or spinner overlay.
    [self observeItem];[self observeProgress];[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(savePosition) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [self.player play];
}
- (void)observeProgress {__weak ABPlayer *weak=self;_positionObserver=[self.player addPeriodicTimeObserverForInterval:CMTimeMake(5,1) queue:dispatch_get_main_queue() usingBlock:^(CMTime t){[weak savePosition];}];}
- (void)observeItem {
    _observedItem=self.player.currentItem;_observing=YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ended:) name:AVPlayerItemDidPlayToEndTimeNotification object:_observedItem];
    [_observedItem addObserver:self forKeyPath:@"status" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionInitial context:NULL];
}
- (void)unobserveItem {if(_observing){[_observedItem removeObserver:self forKeyPath:@"status"];_observing=NO;}[[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:_observedItem];_observedItem=nil;}
- (void)loadURL:(NSURL *)url title:(NSString *)title {
    [self savePosition];[self unobserveItem];if(_positionObserver){[self.player removeTimeObserver:_positionObserver];_positionObserver=nil;}
    [self.player pause];[self.player replaceCurrentItemWithPlayerItem:nil];[_stream cancel];_stream=nil;
    // iOS 9 can invalidate a player when replacing a custom-resource item at EOF.
    // Keep the controller/window, recreate the stopped playback engine for the new track.
    self.player=[AVPlayer new];self.player.actionAtItemEnd=AVPlayerActionAtItemEndNone;self.mediaName=title;self.title=title;[self configureURL:url];
    if(self.isViewLoaded){[self observeItem];[self observeProgress];[self.player play];}
}
- (void)ended:(NSNotification *)note {__weak ABPlayer *weak=self;AVPlayerItem *item=note.object;dispatch_async(dispatch_get_main_queue(),^{ABPlayer *s=weak;if(s&&s.player.currentItem==item){[s.player pause];if(s.finished)s.finished();}});}
- (void)observeValueForKeyPath:(NSString *)path ofObject:(id)obj change:(NSDictionary *)change context:(void *)ctx {
    if(obj==self.player.currentItem) {
        if(self.player.currentItem.status==AVPlayerItemStatusReadyToPlay&&!_restored){_restored=YES;double t=_privateMode?0:[[ABPositions shared] position:_sourceURL],d=CMTimeGetSeconds(self.player.currentItem.duration);if(t>2&&(!isfinite(d)||t<d-2)){_resumePending=YES;__weak ABPlayer *weak=self;AVPlayerItem *item=self.player.currentItem;[self.player seekToTime:CMTimeMakeWithSeconds(t,600) toleranceBefore:CMTimeMake(1,1) toleranceAfter:CMTimeMake(1,1) completionHandler:^(BOOL done){ABPlayer *s=weak;if(done&&s&&s.player.currentItem==item)s->_resumePending=NO;}];}}

        if(self.player.currentItem.status==AVPlayerItemStatusFailed) {
            if(_stream&&!_directFallback){self.cacheFailure=[NSString stringWithFormat:@"%@ (%ld) %@",self.player.currentItem.error.localizedDescription,(long)self.player.currentItem.error.code,self.player.currentItem.error.userInfo];[self savePosition];_restored=NO;_directFallback=YES;[self unobserveItem];[_stream cancel];_stream=nil;[self.player replaceCurrentItemWithPlayerItem:[AVPlayerItem playerItemWithURL:_sourceURL]];[self observeItem];[self.player play];return;}
            ABAlert(self,@"无法播放",[NSString stringWithFormat:@"%@\n\n可尝试该条目的较小 MP4 / MP3 衍生版本。iOS 9 不能解码所有 Archive 格式。",self.player.currentItem.error.localizedDescription?:@"服务器或编码不兼容"]);
        }
    } else [super observeValueForKeyPath:path ofObject:obj change:change context:ctx];
}
- (void)viewWillDisappear:(BOOL)animated { [super viewWillDisappear:animated]; _closing=!_embeddedMode&&self.isBeingDismissed; }
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    if(_closing&&[ABSession shared].content!=self) { _closing=NO; if(_returnedFromFullscreen) { void (^b)(void)=[_returnedFromFullscreen copy]; dispatch_async(dispatch_get_main_queue(),b); } else { [self.player pause]; [[AVAudioSession sharedInstance] setActive:NO withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:nil]; } }
}
- (void)dealloc { [self savePosition];if(_positionObserver)[self.player removeTimeObserver:_positionObserver];[[NSNotificationCenter defaultCenter] removeObserver:self];[self unobserveItem];[_stream cancel]; }
@end
