#import "ABSession.h"
#import "ABPlayback.h"
#import "ABMedia.h"
#import "ABVisual.h"
NSString * const ABSessionChanged=@"ABSessionChanged";
static char ABRateContext;
@interface ABAudioStage : UIViewController
@property(nonatomic,strong) UIImageView *cover;
@property(nonatomic,strong) UILabel *heading;
@property(nonatomic,strong) ABAudioBar *controls;
@property(nonatomic,strong) UIButton *previous;
@property(nonatomic,strong) UIButton *doneButton;
@property(nonatomic,strong) UIButton *next;
@end
@interface ABSession ()
@property(nonatomic,strong) ABPlayer *content;
@property(nonatomic,strong) UIViewController<ABSessionOwner> *owner;
@property(nonatomic,weak) UINavigationController *sourceNavigation;
@property(nonatomic,strong) UIImage *artwork;
@property(nonatomic,strong) MPMediaItemArtwork *systemArtwork;
@property(nonatomic,copy) NSString *title;
@property(nonatomic,copy) NSString *artist;
@property(nonatomic) BOOL audio;
@property(nonatomic) BOOL visible;
@property(nonatomic) BOOL stopping;
@property(nonatomic,strong) AVPlayer *observed;
@property(nonatomic,strong) id clock;
@property(nonatomic) NSUInteger generation;
@property(nonatomic,strong) UIView *bar;
@property(nonatomic,strong) UIButton *returnButton;
@property(nonatomic,strong) UIButton *toggleButton;
@property(nonatomic,weak) ABAudioStage *audioStage;
@property(nonatomic) BOOL resumeAfterInterruption;
@end
@implementation ABSession
+ (instancetype)shared {static ABSession *s;static dispatch_once_t once;dispatch_once(&once,^{s=[self new];});return s;}
- (instancetype)init {
 if((self=[super init])){
  MPRemoteCommandCenter *c=[MPRemoteCommandCenter sharedCommandCenter];
  [c.playCommand addTarget:self action:@selector(remotePlay:)];[c.pauseCommand addTarget:self action:@selector(remotePause:)];
  [c.togglePlayPauseCommand addTarget:self action:@selector(remoteToggle:)];[c.stopCommand addTarget:self action:@selector(remoteStop:)];
  [c.nextTrackCommand addTarget:self action:@selector(remoteNext:)];[c.previousTrackCommand addTarget:self action:@selector(remotePrevious:)];
  [c.changePlaybackPositionCommand addTarget:self action:@selector(remoteSeek:)];
  c.skipForwardCommand.enabled=c.skipBackwardCommand.enabled=c.seekForwardCommand.enabled=c.seekBackwardCommand.enabled=NO;
  [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(interrupted:) name:AVAudioSessionInterruptionNotification object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(routeChanged:) name:AVAudioSessionRouteChangeNotification object:nil];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(layoutBar) name:UIApplicationDidChangeStatusBarOrientationNotification object:nil];
  [self refresh];
 }return self;
}
- (void)unobserve {if(_clock){[_observed removeTimeObserver:_clock];_clock=nil;}if(_observed){[_observed removeObserver:self forKeyPath:@"rate" context:&ABRateContext];_observed=nil;}}
- (void)bind:(ABPlayer *)player owner:(UIViewController<ABSessionOwner> *)owner audio:(BOOL)audio title:(NSString *)title artist:(NSString *)artist artwork:(UIImage *)image artworkURL:(NSURL *)url {
 if(_owner&&_owner!=owner)[self stop];[self unobserve];_generation++;NSUInteger generation=_generation;
 _owner=owner;_content=player;_audio=audio;_title=title?:@"正在播放";_artist=artist?:@"";_artwork=image;_systemArtwork=image?[[MPMediaItemArtwork alloc] initWithImage:image]:nil;
 if(owner.navigationController)_sourceNavigation=owner.navigationController;
 _visible=owner.view.window!=nil;_observed=player.player;
 [_observed addObserver:self forKeyPath:@"rate" options:0 context:&ABRateContext];
 __weak ABSession *weak=self;_clock=[_observed addPeriodicTimeObserverForInterval:CMTimeMake(2,1) queue:dispatch_get_main_queue() usingBlock:^(CMTime time){[weak publish];}];
 [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:nil];[[AVAudioSession sharedInstance] setActive:YES error:nil];
 [self refresh];if(url)[[ABImages shared] imageURL:url completion:^(UIImage *art){ABSession *s=weak;if(s&&s.generation==generation&&art){s.artwork=art;s.systemArtwork=[[MPMediaItemArtwork alloc] initWithImage:art];[s refresh];}}];
}
- (void)forget:(UIViewController *)owner {if(_owner!=owner)return;[self unobserve];_generation++;_content=nil;_owner=nil;_sourceNavigation=nil;_artwork=nil;_systemArtwork=nil;_title=nil;_artist=nil;_audio=NO;_visible=NO;[self refresh];}
- (void)stop {if(_stopping)return;_stopping=YES;UIViewController<ABSessionOwner> *owner=_owner;[_content.player pause];[owner playbackClose];if(_owner==owner)[self forget:owner];_stopping=NO;}
- (void)sourceVisible:(BOOL)visible owner:(UIViewController *)owner {if(_owner==owner){_visible=visible;[self refresh];}}
- (void)navigateToOwner {
 UIViewController *owner=_owner;if(!owner)return;UINavigationController *nav=owner.navigationController?:_sourceNavigation;
 UITabBarController *tab=(id)[UIApplication sharedApplication].keyWindow.rootViewController;if(!nav)nav=tab.viewControllers.firstObject;
 if(nav.presentedViewController){[nav dismissViewControllerAnimated:NO completion:^{[self navigateToOwner];}];return;}
 tab.selectedViewController=nav;if([nav.viewControllers containsObject:owner]){if(nav.topViewController!=owner)[nav popToViewController:owner animated:NO];}
 else [nav pushViewController:owner animated:NO];
}
- (void)returnToSource {[_owner playbackReturn];}
- (void)publish {
 if(!_content){[MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo=nil;return;}
 NSMutableDictionary *info=[NSMutableDictionary dictionary];BOOL private=_content.privateMode;
 info[MPMediaItemPropertyTitle]=private?@"私密媒体":_title?:@"正在播放";if(!private&&_artist.length)info[MPMediaItemPropertyArtist]=_artist;
 if(!private&&_systemArtwork)info[MPMediaItemPropertyArtwork]=_systemArtwork;
 double t=CMTimeGetSeconds(_content.player.currentTime),d=CMTimeGetSeconds(_content.player.currentItem.duration);
 if(isfinite(t)&&t>=0)info[MPNowPlayingInfoPropertyElapsedPlaybackTime]=@(t);if(isfinite(d)&&d>0)info[MPMediaItemPropertyPlaybackDuration]=@(d);
 info[MPNowPlayingInfoPropertyPlaybackRate]=@(_content.player.rate);[MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo=info;
}
- (void)refresh {
 MPRemoteCommandCenter *c=[MPRemoteCommandCenter sharedCommandCenter];BOOL active=_content!=nil;
 c.playCommand.enabled=c.pauseCommand.enabled=c.togglePlayPauseCommand.enabled=c.stopCommand.enabled=active;
 c.changePlaybackPositionCommand.enabled=active;c.nextTrackCommand.enabled=active&&[_owner playbackCanNext];c.previousTrackCommand.enabled=active&&[_owner playbackCanPrevious];
 [self publish];[self layoutBar];[[NSNotificationCenter defaultCenter] postNotificationName:ABSessionChanged object:self];
}
- (void)layoutBar {
 BOOL show=_content&&_audio&&!_visible&&!_content.privateMode&&!_audioStage;
 if(!show){[_bar removeFromSuperview];_bar=nil;_returnButton=nil;_toggleButton=nil;return;}
 UIViewController *root=[UIApplication sharedApplication].keyWindow.rootViewController;
 if(!_bar){_bar=[UIView new];_bar.backgroundColor=[UIColor colorWithWhite:0.95 alpha:0.98];_bar.layer.borderColor=[UIColor colorWithWhite:0.8 alpha:1].CGColor;_bar.layer.borderWidth=0.5;
 _returnButton=[UIButton buttonWithType:UIButtonTypeSystem];_returnButton.autoresizingMask=UIViewAutoresizingFlexibleWidth;_returnButton.contentHorizontalAlignment=UIControlContentHorizontalAlignmentLeft;_returnButton.titleLabel.font=[UIFont systemFontOfSize:13];_returnButton.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;[_returnButton addTarget:self action:@selector(returnToSource) forControlEvents:UIControlEventTouchUpInside];[_bar addSubview:_returnButton];
 _toggleButton=[UIButton buttonWithType:UIButtonTypeSystem];_toggleButton.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;[_toggleButton addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];[_bar addSubview:_toggleButton];
 UIButton *close=[UIButton buttonWithType:UIButtonTypeSystem];close.tag=70;close.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;[close setTitle:@"关闭" forState:UIControlStateNormal];[close addTarget:self action:@selector(stop) forControlEvents:UIControlEventTouchUpInside];[_bar addSubview:close];[root.view addSubview:_bar];}
 CGFloat w=root.view.bounds.size.width;_bar.frame=CGRectMake(0,root.view.bounds.size.height-97,w,48);_bar.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin;
 _returnButton.frame=CGRectMake(12,0,w-132,48);_toggleButton.frame=CGRectMake(w-116,0,60,48);[_bar viewWithTag:70].frame=CGRectMake(w-56,0,52,48);
 [_returnButton setTitle:[NSString stringWithFormat:@"♫ %@ · 返回",_title?:@""] forState:UIControlStateNormal];[_toggleButton setTitle:_content.player.rate>0?@"暂停":@"播放" forState:UIControlStateNormal];[root.view bringSubviewToFront:_bar];
}
- (void)onMain:(void (^)(void))block {if([NSThread isMainThread])block();else dispatch_async(dispatch_get_main_queue(),block);}
- (void)toggle {if(_content.player.rate>0)[_content.player pause];else [_content.player play];[self refresh];}
- (MPRemoteCommandHandlerStatus)remotePlay:(MPRemoteCommandEvent *)e {if(!_content)return MPRemoteCommandHandlerStatusNoSuchContent;[self onMain:^{[self.content.player play];[self refresh];}];return MPRemoteCommandHandlerStatusSuccess;}
- (MPRemoteCommandHandlerStatus)remotePause:(MPRemoteCommandEvent *)e {if(!_content)return MPRemoteCommandHandlerStatusNoSuchContent;[self onMain:^{[self.content.player pause];[self refresh];}];return MPRemoteCommandHandlerStatusSuccess;}
- (MPRemoteCommandHandlerStatus)remoteToggle:(MPRemoteCommandEvent *)e {if(!_content)return MPRemoteCommandHandlerStatusNoSuchContent;[self onMain:^{[self toggle];}];return MPRemoteCommandHandlerStatusSuccess;}
- (MPRemoteCommandHandlerStatus)remoteStop:(MPRemoteCommandEvent *)e {[self onMain:^{[self stop];}];return MPRemoteCommandHandlerStatusSuccess;}
- (MPRemoteCommandHandlerStatus)remoteNext:(MPRemoteCommandEvent *)e {__block BOOL ok=NO;void(^action)(void)=^{if([self.owner playbackCanNext]){[self.owner playbackNext];[self refresh];ok=YES;}};if([NSThread isMainThread])action();else dispatch_sync(dispatch_get_main_queue(),action);return ok?MPRemoteCommandHandlerStatusSuccess:MPRemoteCommandHandlerStatusNoSuchContent;}
- (MPRemoteCommandHandlerStatus)remotePrevious:(MPRemoteCommandEvent *)e {__block BOOL ok=NO;void(^action)(void)=^{if([self.owner playbackCanPrevious]){[self.owner playbackPrevious];[self refresh];ok=YES;}};if([NSThread isMainThread])action();else dispatch_sync(dispatch_get_main_queue(),action);return ok?MPRemoteCommandHandlerStatusSuccess:MPRemoteCommandHandlerStatusNoSuchContent;}
- (MPRemoteCommandHandlerStatus)remoteSeek:(MPChangePlaybackPositionCommandEvent *)event {if(!_content||!isfinite(event.positionTime))return MPRemoteCommandHandlerStatusCommandFailed;[self onMain:^{[self.content.player seekToTime:CMTimeMakeWithSeconds(MAX(0,event.positionTime),600)];[self publish];}];return MPRemoteCommandHandlerStatusSuccess;}
- (void)observeValueForKeyPath:(NSString *)key ofObject:(id)object change:(NSDictionary *)change context:(void *)context {if(context==&ABRateContext){[self onMain:^{[self refresh];}];}else [super observeValueForKeyPath:key ofObject:object change:change context:context];}
- (void)interrupted:(NSNotification *)n {if([n.userInfo[AVAudioSessionInterruptionTypeKey] integerValue]==AVAudioSessionInterruptionTypeBegan){_resumeAfterInterruption=_content.player.rate>0;[_content.player pause];}else if(_resumeAfterInterruption&&([n.userInfo[AVAudioSessionInterruptionOptionKey] unsignedIntegerValue]&AVAudioSessionInterruptionOptionShouldResume)){[[AVAudioSession sharedInstance] setActive:YES error:nil];[_content.player play];_resumeAfterInterruption=NO;}[self refresh];}
- (void)routeChanged:(NSNotification *)n {if([n.userInfo[AVAudioSessionRouteChangeReasonKey] integerValue]==AVAudioSessionRouteChangeReasonOldDeviceUnavailable){[_content.player pause];[self refresh];}}
- (void)presentAudioFrom:(UIViewController *)presenter {if(!_content||!_audio)return;ABAudioStage *stage=[ABAudioStage new];_audioStage=stage;[self layoutBar];[presenter presentViewController:stage animated:YES completion:nil];}
@end
@implementation ABAudioStage
- (void)viewDidLoad {[super viewDidLoad];self.view.backgroundColor=[UIColor colorWithWhite:0.06 alpha:1];_cover=[UIImageView new];_cover.contentMode=UIViewContentModeScaleAspectFit;[self.view addSubview:_cover];_heading=[UILabel new];_heading.textColor=[UIColor whiteColor];_heading.textAlignment=NSTextAlignmentCenter;_heading.numberOfLines=2;_heading.font=[UIFont boldSystemFontOfSize:18];[self.view addSubview:_heading];UIButton *done=[UIButton buttonWithType:UIButtonTypeSystem];done.tag=1;_doneButton=done;done.tintColor=[UIColor whiteColor];done.backgroundColor=[UIColor colorWithWhite:0.16 alpha:1];done.layer.cornerRadius=6;done.layer.zPosition=10;done.accessibilityLabel=@"返回播放页";[done setTitle:@"返回" forState:UIControlStateNormal];[done addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:done];_previous=[UIButton buttonWithType:UIButtonTypeSystem];[_previous setImage:ABTransportIcon(NO) forState:UIControlStateNormal];[_previous addTarget:self action:@selector(previousTrack) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:_previous];_next=[UIButton buttonWithType:UIButtonTypeSystem];[_next setImage:ABTransportIcon(YES) forState:UIControlStateNormal];[_next addTarget:self action:@selector(nextTrack) forControlEvents:UIControlEventTouchUpInside];[self.view addSubview:_next];[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refresh) name:ABSessionChanged object:nil];[self refresh];}
- (void)refresh {ABSession *s=[ABSession shared];if(!s.content){[self close];return;}_cover.image=s.artwork;_heading.text=s.title;[_controls stop];[_controls removeFromSuperview];_controls=[[ABAudioBar alloc] initWithPlayer:s.content.player];[self.view addSubview:_controls];_previous.enabled=[s.owner playbackCanPrevious];_next.enabled=[s.owner playbackCanNext];[self.view setNeedsLayout];}
- (void)viewDidLayoutSubviews {[super viewDidLayoutSubviews];CGFloat w=self.view.bounds.size.width,h=self.view.bounds.size.height;_doneButton.frame=CGRectMake(12,22,64,40);if(h<400&&w>h){CGFloat side=MIN(h-86,w*0.42),x=side+32,width=w-x-16;_cover.frame=CGRectMake(16,(h-side)/2,side,side);_heading.frame=CGRectMake(x,66,width,44);_previous.frame=CGRectMake(x+width/2-75,h-202,50,40);_next.frame=CGRectMake(x+width/2+25,h-202,50,40);_controls.frame=CGRectMake(x,h-152,width,140);return;}CGFloat side=MAX(80,MIN(w-32,h-332));_cover.frame=CGRectMake((w-side)/2,66,side,side);_heading.frame=CGRectMake(16,76+side,w-32,44);_previous.frame=CGRectMake(w/2-110,h-202,50,40);_next.frame=CGRectMake(w/2+60,h-202,50,40);_controls.frame=CGRectMake(16,h-152,w-32,140);}

- (void)previousTrack {[[ABSession shared] remotePrevious:nil];}
- (void)nextTrack {[[ABSession shared] remoteNext:nil];}
- (void)close {[self dismissViewControllerAnimated:YES completion:^{[[ABSession shared] layoutBar];}];}
- (void)viewDidDisappear:(BOOL)animated {[super viewDidDisappear:animated];if(self.isBeingDismissed||!self.presentingViewController){[_controls stop];[ABSession shared].audioStage=nil;[[ABSession shared] layoutBar];}}
- (void)dealloc {[[NSNotificationCenter defaultCenter] removeObserver:self];[_controls stop];}
@end
