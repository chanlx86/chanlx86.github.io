#import "ABCore.h"

@interface ABBrowseController : UITableViewController
@property(nonatomic) BOOL privateMode;
- (instancetype)initWithCollection:(NSString *)identifier title:(NSString *)title;
- (void)openIdentifier:(NSString *)identifier;
@end
@interface ABItemController : UITableViewController
@property(nonatomic) BOOL privateMode;
- (instancetype)initWithIdentifier:(NSString *)identifier;
@end
@interface ABDownloadController : UITableViewController
@end
@interface ABAboutController : UITableViewController
@end

void ABOpenItemFrom(UIViewController *presenter,NSString *identifier,BOOL privateMode);
