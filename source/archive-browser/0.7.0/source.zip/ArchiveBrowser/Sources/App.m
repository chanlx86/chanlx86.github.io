#import "ABUI.h"
#import "ABLibrary.h"
#import "ABVault.h"
#import "ABSession.h"
#import <notify.h>

#ifdef AB_TESTING
void ABStartIntegration(UIWindow *window, ABBrowseController *browse);
#endif
@interface ABAppDelegate : UIResponder <UIApplicationDelegate,UITabBarControllerDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@property(nonatomic,strong) UIView *privacyCover;
@property(nonatomic) int lockToken;
@property(nonatomic) int lockCheckToken;
@end
@implementation ABAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    // Only discard our own ephemeral preview files left by a previous process.
    for(NSString *name in [[NSFileManager defaultManager] contentsOfDirectoryAtPath:NSTemporaryDirectory() error:nil])
        if([name hasPrefix:@"ABTransfer-"]||[name hasPrefix:@"ABFLAC-"]||[name hasPrefix:@"ABPreview-"]||[name hasPrefix:@"ABZip-"])
            [[NSFileManager defaultManager] removeItemAtPath:[NSTemporaryDirectory() stringByAppendingPathComponent:name] error:nil];
    [ABDownloads shared];[ABSession shared];
    _lockCheckToken=-1;notify_register_check("com.apple.springboard.lockstate",&_lockCheckToken);int initial=0;notify_check(_lockCheckToken,&initial);
    _lockToken=-1;__weak ABAppDelegate *weak=self;
    notify_register_dispatch("com.apple.springboard.lockcomplete",&_lockToken,dispatch_get_main_queue(),^(int token){[weak deviceDidLock];});
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceDidLock) name:UIApplicationProtectedDataWillBecomeUnavailable object:nil];
    self.window=[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds]; self.window.tintColor=ABTint();
    _browse=[ABBrowseController new]; ABLocalController *downloads=[ABLocalController new];
    NSArray *controllers=@[_browse,downloads]; NSArray *titles=@[@"浏览",@"本地"];
    NSMutableArray *tabs=[NSMutableArray array]; for(NSUInteger i=0;i<controllers.count;i++) { UIViewController *c=controllers[i]; UINavigationController *n=[[UINavigationController alloc] initWithRootViewController:c]; NSString *image=@[@"tab-browse",@"tab-download",@"tab-about"][i]; n.tabBarItem=[[UITabBarItem alloc] initWithTitle:titles[i] image:[UIImage imageNamed:image] tag:i]; [tabs addObject:n]; }
    UITabBarController *t=[UITabBarController new];t.delegate=self; t.viewControllers=tabs; self.window.rootViewController=t; self.window.backgroundColor=[UIColor whiteColor]; [self.window makeKeyAndVisible];
#ifdef AB_TESTING
    if([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/run"]) { [[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/run" error:nil]; dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{ ABStartIntegration(self.window,self.browse); }); }
#endif
    return YES;
}
- (void)showPrivacyCover {if(_privacyCover)return;_privacyCover=[[UIView alloc] initWithFrame:self.window.bounds];_privacyCover.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;_privacyCover.backgroundColor=[UIColor colorWithWhite:0.96 alpha:1];[self.window addSubview:_privacyCover];}
- (void)finishPrivacyCover {if(!_privacyCover)return;UITabBarController *tab=(id)self.window.rootViewController;__weak ABAppDelegate *weak=self;ABClosePrivateBranch(tab.viewControllers[1],^{[weak.privacyCover removeFromSuperview];weak.privacyCover=nil;});}
- (void)tabBarController:(UITabBarController *)tab didSelectViewController:(UIViewController *)controller {if(tab.selectedIndex==0&&ABPrivateActive()){[self showPrivacyCover];[[ABVault shared] conceal];[self finishPrivacyCover];}}
- (void)applicationWillResignActive:(UIApplication *)app {if(ABPrivateActive())[self showPrivacyCover];[[ABVault shared] conceal];}
- (void)deviceDidLock {
#ifdef AB_TESTING
    NSString *probe=@"/var/mobile/Media/ArchiveBrowser-Test/lock-probe.json";
    BOOL watching=[[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/lock-watch"];
    NSDictionary *previous=watching?[NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:probe]?:[NSData data] options:0 error:nil]:nil;
    BOOL hadSession=watching&&([[ABVault shared] valueForKey:@"sessionKey"]!=nil||[previous[@"hadSession"] boolValue]);
#endif
    if(ABPrivateActive())[self showPrivacyCover];[[ABVault shared] lock];
#ifdef AB_TESTING
    if(watching){NSDictionary *result=@{@"hadSession":@(hadSession),@"cleared":@(!ABPrivateActive()&&[[ABVault shared] valueForKey:@"sessionKey"]==nil),@"events":@([previous[@"events"] integerValue]+1)};[[NSJSONSerialization dataWithJSONObject:result options:0 error:nil] writeToFile:probe atomically:YES];}
#endif
}
- (void)applicationDidBecomeActive:(UIApplication *)app {int changed=0;if(_lockCheckToken>=0)notify_check(_lockCheckToken,&changed);if(changed)[self deviceDidLock];[[ABVault shared] expireSession];[self finishPrivacyCover];}
- (void)application:(UIApplication *)app handleEventsForBackgroundURLSession:(NSString *)identifier completionHandler:(void (^)())completionHandler { [ABDownloads shared].backgroundCompletion=completionHandler; }
- (void)applicationDidEnterBackground:(UIApplication *)application { [[ABDownloads shared] save]; }
- (void)applicationWillTerminate:(UIApplication *)application { [[ABDownloads shared] save]; }
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary *)options {
    if(![url.scheme.lowercaseString isEqual:@"archivebrowser"])return NO;
    if(ABPrivateActive()){[self showPrivacyCover];[[ABVault shared] conceal];[self finishPrivacyCover];}
    NSString *identifier=ABIdentifier(url.host); if(!identifier)return NO;
    UITabBarController *t=(id)self.window.rootViewController; t.selectedIndex=0; [_browse.navigationController popToRootViewControllerAnimated:NO]; [_browse openIdentifier:identifier]; return YES;
}
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application { [[ABImages shared] clearMemory]; }
@end
int main(int argc,char *argv[]) { @autoreleasepool { return UIApplicationMain(argc,argv,nil,NSStringFromClass([ABAppDelegate class])); } }
