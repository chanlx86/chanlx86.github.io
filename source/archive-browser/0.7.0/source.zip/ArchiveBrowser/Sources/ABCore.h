#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>

NSString *ABString(id value);
NSString *ABEncode(NSString *value);
NSString *ABIdentifier(NSString *input);
NSURL *ABFileURL(NSString *identifier, NSString *name);
NSString *ABSize(long long bytes);
BOOL ABPlayable(NSString *name);
BOOL ABPrivate(NSDictionary *file);
UIColor *ABTint(void);
void ABAlert(UIViewController *vc, NSString *title, NSString *message);
void ABPresentBarSheet(UIViewController *vc, UIAlertController *sheet, UIBarButtonItem *item);
void ABPresentSheet(UIViewController *vc, UIAlertController *sheet, UIView *anchor);
NSString *ABDocuments(void);

typedef void (^ABDataBlock)(NSData *data, NSError *error);
typedef void (^ABJSONBlock)(id json, NSError *error);
@interface ABHTTP : NSObject <NSURLSessionDataDelegate>
+ (instancetype)shared;
- (NSURLSessionDataTask *)get:(NSURL *)url limit:(NSUInteger)limit completion:(ABDataBlock)completion;
- (NSURLSessionDataTask *)request:(NSURLRequest *)request limit:(NSUInteger)limit completion:(void (^)(NSData *,NSHTTPURLResponse *,NSError *))completion;
- (NSURLSessionDataTask *)json:(NSString *)path completion:(ABJSONBlock)completion;
@end

@interface ABImages : NSObject
+ (instancetype)shared;
- (void)image:(NSString *)identifier completion:(void (^)(UIImage *image))completion;
- (void)clearMemory;
- (void)imageURL:(NSURL *)url completion:(void (^)(UIImage *image))completion;
@end

extern NSString * const ABDownloadsChanged;
@interface ABDownloads : NSObject <NSURLSessionDownloadDelegate>
@property(nonatomic,strong) NSMutableArray *records;
@property(nonatomic,copy) void (^backgroundCompletion)(void);
+ (instancetype)shared;
- (NSDictionary *)add:(NSString *)identifier file:(NSDictionary *)file title:(NSString *)title;
- (NSDictionary *)importURL:(NSURL *)url identifier:(NSString *)identifier name:(NSString *)name title:(NSString *)title;
- (void)toggle:(NSDictionary *)record;
- (void)remove:(NSDictionary *)record;
- (NSURL *)localURL:(NSDictionary *)record;
- (void)save;
@end

@interface ABPlayer : AVPlayerViewController
@property(nonatomic,copy) NSString *mediaName;
@property(nonatomic) BOOL embeddedMode;
@property(nonatomic,readonly) BOOL privateMode;
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title privateMode:(BOOL)privateMode;
@property(nonatomic,copy) NSString *cacheFailure;
@property(nonatomic,copy) NSString *preparationText;
@property(nonatomic,copy) void (^preparationChanged)(NSString *text);
@property(nonatomic,copy) void (^finished)(void);
- (void)loadURL:(NSURL *)url title:(NSString *)title;
- (void)savePosition;
- (void)restart;
@property(nonatomic,copy) void (^returnedFromFullscreen)(void);
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title;
@end
