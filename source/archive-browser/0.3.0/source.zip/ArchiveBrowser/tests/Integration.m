// Diagnostic build only. Test library uses a separate path; user downloads remain untouched.
#import "ABUI.h"
#import "ABLibrary.h"
#import "ABMedia.h"
#import "ABSearch.h"
#import "ABPanels.h"
#import <mach/mach.h>
@interface ABItemController (Test)
- (void)playRecommended;
- (void)play:(NSDictionary *)file;
- (void)enterFullscreen;
- (void)closePlayer;
@end
@interface ABBrowseController (Test)
- (void)submitSearch;
@end
@interface ABIntegration : NSObject
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@property(nonatomic,strong) ABItemController *item;
@property(nonatomic,strong) ABImageController *image;
@property(nonatomic,strong) NSMutableDictionary *report;
@property(nonatomic,strong) NSDate *started;
@property(nonatomic,strong) NSTimer *timer;
@property(nonatomic,strong) AVPlayer *probe;
@property(nonatomic,strong) NSMutableArray *codecs;
@property(nonatomic) NSInteger codecIndex;
@property(nonatomic) NSInteger stage;
@property(nonatomic) double videoBefore;
@end
static ABIntegration *test;
static NSString *Dir=@"/var/mobile/Media/ArchiveBrowser-Test";
@implementation ABIntegration
- (void)save {struct mach_task_basic_info info;mach_msg_type_number_t n=MACH_TASK_BASIC_INFO_COUNT;if(task_info(mach_task_self(),MACH_TASK_BASIC_INFO,(task_info_t)&info,&n)==KERN_SUCCESS)_report[@"residentMB"]=@(info.resident_size/1048576.0);_report[@"stage"]=@(_stage);[[NSJSONSerialization dataWithJSONObject:_report options:NSJSONWritingPrettyPrinted error:nil] writeToFile:[Dir stringByAppendingPathComponent:@"report.json"] atomically:YES];}
- (void)snapshot:(NSString *)name {UIGraphicsBeginImageContextWithOptions(_window.bounds.size,YES,1);[_window drawViewHierarchyInRect:_window.bounds afterScreenUpdates:YES];NSData *d=UIImagePNGRepresentation(UIGraphicsGetImageFromCurrentImageContext());UIGraphicsEndImageContext();[d writeToFile:[Dir stringByAppendingPathComponent:[name stringByAppendingString:@".png"]] atomically:YES];}
- (void)next:(NSInteger)s {_stage=s;_started=[NSDate date];[self save];}
- (id)fixture:(NSString *)name {return [NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:[Dir stringByAppendingPathComponent:[name stringByAppendingString:@".json"]]] options:0 error:nil];}
- (void)modelTests {
 NSString *path=[Dir stringByAppendingPathComponent:@"test-library.json"];[[NSFileManager defaultManager] removeItemAtPath:path error:nil];ABLibrary *l=[[ABLibrary alloc] initWithPath:path];NSString *folder=[l createFolder:@"音乐与电影"],*other=[l createFolder:@"第二个收藏夹"];NSDictionary *e=ABEntry(@"IbertEscales",@"Escales",NO);[l setEntry:e folder:folder present:YES];[l setEntry:e folder:folder present:YES];[l setEntry:e folder:other present:YES];[l setCollection:ABEntry(@"more_animation",@"动画",YES) present:YES];[l renameFolder:folder name:@"已改名"];
 BOOL rejectsCollection=![l setEntry:ABEntry(@"animation",@"动画合集",YES) folder:folder present:YES];
 for(int i=0;i<35;i++)[l visit:ABEntry([NSString stringWithFormat:@"test-%d",i],nil,NO)];[l visit:ABEntry(@"test-10",@"再次打开",NO)];ABLibrary *again=[[ABLibrary alloc] initWithPath:path];NSArray *folders=again.data[@"folders"],*history=again.data[@"history"];
 _report[@"library"]=@{@"persistedFolderName":folders[1][@"name"],@"deduplicated":@([folders[1][@"items"] count]==1),@"separateCollections":@([again.data[@"collections"] count]==1&&rejectsCollection),@"historyCount":@(history.count),@"historyRecent":history.firstObject[@"identifier"],@"historyOldest":history.lastObject[@"identifier"]};
 [again deleteFolder:folder];[again clearHistory];ABLibrary *final=[[ABLibrary alloc] initWithPath:path];_report[@"libraryDeletion"]=@{@"otherFolderRetained":@([final.data[@"folders"][1][@"items"] count]==1),@"collectionRetained":@([final.data[@"collections"] count]==1),@"historyCleared":@([final.data[@"history"] count]==0)};
 NSString *bad=[Dir stringByAppendingPathComponent:@"invalid-library.json"];[@"invalid" writeToFile:bad atomically:YES encoding:NSUTF8StringEncoding error:nil];ABLibrary *invalid=[[ABLibrary alloc] initWithPath:bad];_report[@"corruptionProtected"]=@(![invalid clearHistory]&&[[NSString stringWithContentsOfFile:bad encoding:NSUTF8StringEncoding error:nil] isEqual:@"invalid"]);
 NSArray *files=[self fixture:@"IbertEscales"][@"files"];NSArray *tracks=ABPlaylist(files);NSArray *bunnyFiles=[self fixture:@"BigBuckBunny_328"][@"files"];NSArray *bunny=ABPlaylist(bunnyFiles);NSArray *video=ABPlaylist([self fixture:@"electricsheep-flock-244-80000-9"][@"files"]);
 NSDictionary *avi=nil;for(NSDictionary *f in bunnyFiles)if([ABString(f[@"name"]).pathExtension isEqual:@"avi"])avi=f;
 _report[@"playlists"]=@{@"audioTracks":tracks,@"bunnyCount":@(bunny.count),@"aviResolvedTo":ABString(ABCompatibleFile(avi,bunnyFiles)[@"name"]),@"episodes":@(video.count),@"audioCountCorrect":@(tracks.count==3)};
 _report[@"downloadRecordsPreserved"]=@([ABDownloads shared].records.count);
}
- (void)begin {[UIApplication sharedApplication].idleTimerDisabled=YES;_report=[NSMutableDictionary dictionary];_report[@"version"]=@"0.3.0";[self modelTests];if([[NSFileManager defaultManager] fileExistsAtPath:[Dir stringByAppendingPathComponent:@"focused"]]){[[NSFileManager defaultManager] removeItemAtPath:[Dir stringByAppendingPathComponent:@"focused"] error:nil];_timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self openItem:@"BigBuckBunny_328"];[self next:20];return;}[self snapshot:@"home"];ABAdvancedController *a=[ABAdvancedController new];UINavigationController *n=[[UINavigationController alloc] initWithRootViewController:a];n.modalPresentationStyle=UIModalPresentationFormSheet;[_browse presentViewController:n animated:NO completion:nil];_report[@"advancedSections"]=@([a numberOfSectionsInTableView:a.tableView]);_timer=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(tick) userInfo:nil repeats:YES];[self next:1];}
- (NSDictionary *)playback {ABPlayer *p=[_item valueForKey:@"inlinePlayer"];AVPlayerItem *i=p.player.currentItem;double t=CMTimeGetSeconds(i.currentTime);return @{@"status":@(i.status),@"time":@(isfinite(t)?t:0),@"rate":@(p.player.rate),@"file":ABString([_item valueForKey:@"currentFile"][@"name"]),@"error":i.error.localizedDescription?:@""};}
- (void)openItem:(NSString *)identifier {[_browse.navigationController popToRootViewControllerAnimated:NO];_item=[[ABItemController alloc] initWithIdentifier:identifier];[_browse.navigationController pushViewController:_item animated:NO];}
- (void)startProbe {NSArray *names=@[@"h264.mp4",@"mpeg1.mpg",@"mpeg2.vob",@"mpeg2.ts",@"h264.ts"];_probe=[AVPlayer playerWithURL:[NSURL fileURLWithPath:[Dir stringByAppendingPathComponent:names[_codecIndex]]]];_probe.muted=YES;[_probe play];_started=[NSDate date];}
- (void)tick {double elapsed=-[_started timeIntervalSinceNow];if(elapsed>70){_report[@"timeout"]=@(_stage);[self finish];return;}switch(_stage){
 case 1:if(elapsed>1){[self snapshot:@"advanced"];[_browse dismissViewControllerAnimated:NO completion:nil];UITabBarController *tabs=(id)_window.rootViewController;tabs.selectedIndex=1;[self next:2];}break;
 case 2:if(elapsed>1){[self snapshot:@"local"];UITabBarController *tabs=(id)_window.rootViewController;UINavigationController *nav=tabs.viewControllers[1];UITableViewController *local=(id)nav.topViewController;[local tableView:local.tableView didSelectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];[self next:3];}break;
 case 3:if(elapsed>1){[self snapshot:@"favorites"];((UITabBarController *)_window.rootViewController).selectedIndex=0;UITextField *f=[_browse valueForKey:@"search"];f.text=@"Big Buck Bunny";[_browse submitSearch];[self next:4];}break;
 case 4:if(![[_browse valueForKey:@"loading"] boolValue]){_report[@"search"]=@{@"count":@([[_browse valueForKey:@"items"] count]),@"noSuffixScan":@(![_browse respondsToSelector:NSSelectorFromString(@"scan")])};[self openItem:@"IbertEscales"];[self next:5];}break;
 case 5:if([[_item valueForKey:@"playlist"] count]==3){[_item playRecommended];[self next:6];}break;
 case 6:if(elapsed>9){_report[@"audio"]=self.playback;[self snapshot:@"audio-playlist"];ABPlayer *p=[_item valueForKey:@"inlinePlayer"];double duration=CMTimeGetSeconds(p.player.currentItem.duration);if(isfinite(duration)&&duration>2)[p.player seekToTime:CMTimeMakeWithSeconds(duration-1,600) toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];[self next:7];}break;
 case 7:if(elapsed>8){_report[@"autoNext"]=self.playback;_report[@"autoNextPassed"]=@([ABString([_item valueForKey:@"currentFile"][@"name"]) hasPrefix:@"02."]);[_item closePlayer];[self openItem:@"BigBuckBunny_328"];[self next:8];}break;
 case 8:if([[_item valueForKey:@"playlist"] count]){[_item playRecommended];[self next:9];}break;
 case 9:if(elapsed>9){_report[@"video"]=self.playback;[self snapshot:@"video-playlist"];[_item enterFullscreen];[self next:10];}break;
 case 10:if(elapsed>3){_report[@"fullscreen"]=self.playback;_videoBefore=[_report[@"fullscreen"][@"time"] doubleValue];[_item dismissViewControllerAnimated:NO completion:nil];[self next:11];}break;
 case 11:if(elapsed>2){_report[@"inlineReturned"]=self.playback;ABPlayer *p=[_item valueForKey:@"inlinePlayer"];_report[@"fullscreenProgressPreserved"]=@(p.parentViewController==_item&&[self.playback[@"time"] doubleValue]>=_videoBefore);[_item closePlayer];_image=[[ABImageController alloc] initWithURL:ABFileURL(@"IbertEscales",@"01.I.Palermo.png") title:@"音频波形 PNG"];[_item.navigationController pushViewController:_image animated:NO];[self next:12];}break;
 case 12:if(elapsed>4&&[[_image valueForKey:@"image"] image]){_report[@"pngLoaded"]=@YES;[self snapshot:@"png"];[_item.navigationController popViewControllerAnimated:NO];_image=[[ABImageController alloc] initWithURL:[NSURL fileURLWithPath:[Dir stringByAppendingPathComponent:@"animated.gif"]] title:@"GIF 动画测试"];[_item.navigationController pushViewController:_image animated:NO];[self next:13];}break;
 case 13:if(elapsed>2){_report[@"gifFrames"]=@([[_image valueForKey:@"count"] unsignedIntegerValue]);_report[@"gifFrameFirst"]=[_image valueForKey:@"frame"]?:@0;[self snapshot:@"gif-1"];[self next:14];}break;
 case 14:if(elapsed>1.5){_report[@"gifFrameLater"]=[_image valueForKey:@"frame"]?:@0;_report[@"gifDecoded"]=@([[_image valueForKey:@"image"] image]!=nil);[self snapshot:@"gif-2"];[_item.navigationController popViewControllerAnimated:NO];_image=nil;ABBrowseController *c=[[ABBrowseController alloc] initWithCollection:@"more_animation" title:@"动画合集"];[_item.navigationController pushViewController:c animated:NO];[self next:15];}break;
 case 15:if(elapsed>3){ABBrowseController *c=(id)_browse.navigationController.topViewController;if([[c valueForKey:@"loading"] boolValue])break;_report[@"collection"]=@{@"sort":[c valueForKey:@"sort"],@"rows":@([[c valueForKey:@"items"] count])};[self snapshot:@"collection"];_codecIndex=0;_codecs=[NSMutableArray array];[self startProbe];[self next:16];}break;
 case 20:if([[_item valueForKey:@"playlist"] count]){NSArray *list=[_item valueForKey:@"playlist"];_report[@"selectedVideoThumbnail"]=list[0][@"_art"]?:@"";[_item playRecommended];[self next:21];}break;
 case 21:if(elapsed>12){_report[@"videoFinal"]=self.playback;[self snapshot:@"video-final"];[_item closePlayer];_image=[[ABImageController alloc] initWithURL:ABFileURL(@"BigBuckBunny_328",[[_item valueForKey:@"playlist"] firstObject][@"_art"]) title:@"JPEG 图片预览"];[_item.navigationController pushViewController:_image animated:NO];[self next:22];}break;
 case 22:if(elapsed>4&&[[_image valueForKey:@"image"] image]){_report[@"jpegLoaded"]=@YES;[self snapshot:@"jpeg"];UIScrollView *scroll=[_image valueForKey:@"scroll"];[scroll setZoomScale:2 animated:NO];_report[@"imageZoom"]=@(scroll.zoomScale);[_item.navigationController popViewControllerAnimated:NO];_image=nil;[self openItem:@"IbertEscales"];[self next:23];}break;
 case 23:if([[_item valueForKey:@"playlist"] count]==3){[_item playRecommended];[self next:24];}break;
 case 24:if(elapsed>10){_report[@"audioFinal"]=self.playback;[self snapshot:@"audio-final"];ABPlayer *p=[_item valueForKey:@"inlinePlayer"];double duration=CMTimeGetSeconds(p.player.currentItem.duration);if(isfinite(duration)&&duration>2)[p.player seekToTime:CMTimeMakeWithSeconds(duration-1,600) toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];[self next:25];}break;
 case 25:if(elapsed>8){_report[@"autoNextFinal"]=self.playback;_report[@"autoNextPassed"]=@([ABString([_item valueForKey:@"currentFile"][@"name"]) hasPrefix:@"02."]);[self finish];}break;
 case 16:if(elapsed>5){AVPlayerItem *i=_probe.currentItem;double t=CMTimeGetSeconds(i.currentTime);[_codecs addObject:@{@"file":@[@"h264.mp4",@"mpeg1.mpg",@"mpeg2.vob",@"mpeg2.ts",@"h264.ts"][_codecIndex],@"status":@(i.status),@"time":@(isfinite(t)?t:0),@"error":i.error.localizedDescription?:@"",@"code":@(i.error.code)}];[_probe pause];_probe=nil;_codecIndex++;if(_codecIndex<5)[self startProbe];else{_report[@"nativeCodecs"]=_codecs;[self finish];}}break;
}}
- (void)finish {[_timer invalidate];_timer=nil;[_probe pause];[_item closePlayer];[_browse.navigationController popToRootViewControllerAnimated:NO];[UIApplication sharedApplication].idleTimerDisabled=NO;_report[@"complete"]=@YES;[self save];}
@end
void ABStartIntegration(UIWindow *w,ABBrowseController *b){test=[ABIntegration new];test.window=w;test.browse=b;[test begin];}
