# 存档浏览器 0.3.0

独立的 Objective-C Internet Archive 公开资源客户端。原生 UIKit、AVFoundation、ImageIO；兼容 iOS 9.0 起、ARMv7 / ARM64、iPhone / iPad。项目与录屏大师、J2ME 模拟器完全分开。实测设备为 iPad 3、iOS 9.3.6。

## 本次更新

- 高级搜索移除后缀筛选及逐条文件核对请求；保留相关性、最新收录、作品日期与仅标题匹配。默认使用 `_score desc` 并提高标题权重。
- 音视频条目在播放器下方显示带缩略图的播放列表，按碟号、曲目号、自然文件名排序。根据 `original` 链合并同内容的不同编码，优先较小的 MP4 / MP3。未提供关联关系的文件不会凭名称盲目合并。
- 顺序播放下一项；到已加载列表结尾时按需加载下一批。非兼容格式不会无限跳过或重复播放。列表仍保留“加载更多”，大条目每批 200 个文件。
- 条状音频播放器：播放/暂停、拖动进度、时长；存在关联 PNG 时显示站点提供的静态波形/频谱图，不伪造实时频谱。视频缩略图优先使用关联截图的中间一张，没有则使用条目封面。
- PNG、JPEG、GIF 可在线或离线查看、缩放。GIF 按帧延时逐帧后台解码，不一次性展开全部帧。TIFF/BMP 交由系统 ImageIO，当前只有首图；这些额外格式尚未逐一真机验证。
- 底部“下载”改为“本地”，包含收藏、下载、历史浏览。
- 收藏夹可新建、自定义命名、重命名、删除，条目可加入多个收藏夹、取消收藏，也可按官方链接/编号添加。删除收藏记录不删下载文件。
- 站点合集单独收藏，不混入个人收藏夹；合集内容只读。打开合集默认最新收录优先，下拉刷新获取在线结果，也可改作品日期等排序。
- 历史去重，重复浏览移到最前，最多保留 30 项，可逐项删除或清空。收藏/合集/历史原子写入 `library.json`，读取损坏文件时阻止覆盖原件并提示。

## 播放兼容边界

播放器使用 AVPlayer，不包含 FFmpeg/VLC 软件解码器，也不做本机或代理转码。支持尝试系统 MP4/M4V/MOV、MP3/M4A/AAC/WAV/AIFF/CAF、3GP/3G2 与 HLS；具体编码、分辨率和网络仍会限制播放，并非所有扩展名都保证可播。

2026-10-24 真机短样本测试（320×240、3 秒）：

| 文件/编码 | iPad 3 / iOS 9.3.6 直接播放 |
|---|---|
| MP4，H.264 Baseline + AAC | ready，播放到 3 秒 |
| MPG，MPEG-1 + MP2 | 拒绝，AVFoundation -11828 |
| VOB，MPEG-2 + MP2 | 拒绝，-11828 |
| TS，MPEG-2 + MP2 | 拒绝，-11828 |
| 单独 TS，H.264 + AAC | 拒绝，-11828 |

TS 是容器，不代表支持 MPEG-2 视频；单独 TS 与 HLS 播放列表不是同一条播放路径。上述结果是本设备、这几份样本的结果，不能外推所有 iOS 版本和所有编码。

点击旧格式时，若已加载元数据中存在明确同源的 MP4/MP3，App 会使用它并显示“兼容衍生版”；原文件仍可下载。没有匹配版本时，提供系统播放尝试、继续加载文件，以及下载后在其他播放器打开的途径。不会把另一集/另一首歌冒充对应版本，不宣称已经加入 MPEG-1/2 解码。

## 播放列表数据来源

实际检查了 `IbertEscales` 的 `_files.xml` 与 Metadata API，二者都含同样的 `track`、`title` 信息。JSON API 的 `files` 同时提供 `length`、`original`、格式和关联图片，因此不需再为每个条目下载 XML。

- `IbertEscales`：3 首 MP3，各有曲目号和关联波形 PNG。
- `BigBuckBunny_328`：原 AVI、MP4、OGV、GIF、截图关联到同一源，播放列表合并为 1 项。
- `electricsheep-flock-244-80000-9`：多组原件和衍生版合并为 89 项。
- `_meta.xml` 是条目资料，`_files.xml` 是文件清单；SQLite/数据库可能是上传软件的数据，并无统一“播放列表数据库”约定。本 App 不执行或盲目导入这些文件。
- M3U/CUE 等自定义播放列表目前不单独解析；元数据缺失时退回文件名自然排序，不能恢复未知的章节结构。

接口依据：[Internet Archive Metadata API](https://archive.org/developers/md-read.html)、[元数据模式](https://archive.org/developers/metadata-schema/index.html)。

## 内存和存储

- 文件列表每批 200 项、搜索每页 25 条；搜索不再逐项扫描文件后缀。
- 缩略图后台解码最大边长 384；内存缓存约 3 MB，磁盘约 12 MB，超过后清理到约 10 MB。
- 图片预览最多读取 20 MB，最大解码边长 1280；大图可下载后交其他应用。GIF 同时只保留当前帧及待显示帧，不对整段音频进行 FFT。
- 下载经系统后台 NSURLSession，不把整个音视频装入 RAM；支持暂停、继续、删除、分享、离线播放。强制结束或重启后任务若丢失会提示重新下载，不承诺断点数据跨重启保存。
- 本次集成测试结束约 41 MB resident，不是长期峰值或全部格式的性能保证。

## 安装与数据位置

推荐越狱设备用 Filza/Cydia 安装 `dist/存档浏览器_0.3.0_iphoneos-arm.deb`。IPA 也已伪签名，但仍依赖设备安装环境支持；不是普通开发者签名安装包。安装脚本只注册本 App，不装全局插件、不改系统证书、不重启桌面。已有下载及收藏保留，卸载 DEB 不主动删除用户数据。

系统 App 安装路径：

```
/Applications/ArchiveBrowser.app
/var/mobile/Documents/ArchiveBrowser/library.json
/var/mobile/Documents/ArchiveBrowser/downloads.json
/var/mobile/Documents/ArchiveBrowser/Downloads/<任务 UUID>/<文件名>
/var/mobile/Library/Caches/ArchiveBrowser/Thumbnails
```

普通沙盒安装使用自身 Documents/ArchiveBrowser，支持 iTunes 文件共享。所有下载分 UUID 文件夹，避免同名覆盖；不绕过受限资源，不自动安装 IPA。联网保留系统 TLS 校验。

## 构建和验证

Xcode 7.3.1、iPhoneOS 9.3 SDK，打开 `ArchiveBrowser.xcodeproj`。如正规签名安装，需自行设置证书。命令行：

```sh
./build.sh
python3 scripts/deploy.py 192.168.1.18
python3 scripts/package.py
```

可通过 `AB_DEVELOPER_DIR` 指定 Xcode。部署先停止自己的 App，使用新 inode 原子替换程序，设备 `ldid` 签名后取回签名二进制打包。`--socket` 可复用已认证 SSH；不保存密码。发行包拒绝混入测试自动操作代码。

`./build.sh --testing` 包含 `tests/Integration.m`。测试使用独立的 `ArchiveBrowser-Test/test-library.json`，验证收藏增删改、持久化、去重、30 项历史、损坏文件保护、同源合并、实际在线曲目续播、全屏往返、PNG/GIF、集合最新排序和本地编码样本。测试文件不纳入发布 App。

完整结果见 `tests/results/ipad3-ios9-030.json`；最终小范围回归见 `tests/results/ipad3-ios9-030-final.json`。旧版基础下载校验报告继续保留。没有宣称做过 iPhone 真机测试或长时/超大资源压力测试。

源码：

- `ABCore`：网络、缩略图、下载、AVPlayer。
- `ABUI`：搜索/条目/下载/说明。
- `ABSearch`、`ABPanels`：索引查询、高级搜索弹窗。
- `ABMedia`：同源播放列表、兼容版本选择、图片查看、音频条。
- `ABLibrary`：本地收藏/合集/历史存储与界面。
