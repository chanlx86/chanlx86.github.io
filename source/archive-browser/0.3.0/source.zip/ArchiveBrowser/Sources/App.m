#import "ABUI.h"
#import "ABLibrary.h"
#ifdef AB_TESTING
void ABStartIntegration(UIWindow *window, ABBrowseController *browse);
#endif
@interface ABAppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) ABBrowseController *browse;
@end
@implementation ABAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    [ABDownloads shared];
    self.window=[[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds]; self.window.tintColor=ABTint();
    _browse=[ABBrowseController new]; ABLocalController *downloads=[ABLocalController new];
    NSArray *controllers=@[_browse,downloads]; NSArray *titles=@[@"浏览",@"本地"];
    NSMutableArray *tabs=[NSMutableArray array]; for(NSUInteger i=0;i<controllers.count;i++) { UIViewController *c=controllers[i]; UINavigationController *n=[[UINavigationController alloc] initWithRootViewController:c]; NSString *image=@[@"tab-browse",@"tab-download",@"tab-about"][i]; n.tabBarItem=[[UITabBarItem alloc] initWithTitle:titles[i] image:[UIImage imageNamed:image] tag:i]; [tabs addObject:n]; }
    UITabBarController *t=[UITabBarController new]; t.viewControllers=tabs; self.window.rootViewController=t; self.window.backgroundColor=[UIColor whiteColor]; [self.window makeKeyAndVisible];
#ifdef AB_TESTING
    if([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/run"]) { [[NSFileManager defaultManager] removeItemAtPath:@"/var/mobile/Media/ArchiveBrowser-Test/run" error:nil]; dispatch_after(dispatch_time(DISPATCH_TIME_NOW,2*NSEC_PER_SEC),dispatch_get_main_queue(),^{ ABStartIntegration(self.window,self.browse); }); }
#endif
    return YES;
}
- (void)application:(UIApplication *)app handleEventsForBackgroundURLSession:(NSString *)identifier completionHandler:(void (^)())completionHandler { [ABDownloads shared].backgroundCompletion=completionHandler; }
- (void)applicationDidEnterBackground:(UIApplication *)application { [[ABDownloads shared] save]; }
- (void)applicationWillTerminate:(UIApplication *)application { [[ABDownloads shared] save]; }
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary *)options {
    if(![url.scheme.lowercaseString isEqual:@"archivebrowser"])return NO;
    NSString *identifier=ABIdentifier(url.host); if(!identifier)return NO;
    UITabBarController *t=(id)self.window.rootViewController; t.selectedIndex=0; [_browse.navigationController popToRootViewControllerAnimated:NO]; [_browse openIdentifier:identifier]; return YES;
}
- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application { [[ABImages shared] clearMemory]; }
@end
int main(int argc,char *argv[]) { @autoreleasepool { return UIApplicationMain(argc,argv,nil,NSStringFromClass([ABAppDelegate class])); } }
