#import <UIKit/UIKit.h>
#import <AVKit/AVKit.h>

NSString *ABString(id value);
NSString *ABEncode(NSString *value);
NSString *ABIdentifier(NSString *input);
NSURL *ABFileURL(NSString *identifier, NSString *name);
NSString *ABSize(long long bytes);
BOOL ABPlayable(NSString *name);
BOOL ABPrivate(NSDictionary *file);
UIColor *ABTint(void);
void ABAlert(UIViewController *vc, NSString *title, NSString *message);
void ABPresentSheet(UIViewController *vc, UIAlertController *sheet, UIView *anchor);
NSString *ABDocuments(void);

typedef void (^ABDataBlock)(NSData *data, NSError *error);
typedef void (^ABJSONBlock)(id json, NSError *error);
@interface ABHTTP : NSObject <NSURLSessionDataDelegate>
+ (instancetype)shared;
- (NSURLSessionDataTask *)get:(NSURL *)url limit:(NSUInteger)limit completion:(ABDataBlock)completion;
- (NSURLSessionDataTask *)json:(NSString *)path completion:(ABJSONBlock)completion;
@end

@interface ABImages : NSObject
+ (instancetype)shared;
- (void)image:(NSString *)identifier completion:(void (^)(UIImage *image))completion;
- (void)clearMemory;
- (void)imageURL:(NSURL *)url completion:(void (^)(UIImage *image))completion;
@end

extern NSString * const ABDownloadsChanged;
@interface ABDownloads : NSObject <NSURLSessionDownloadDelegate>
@property(nonatomic,strong) NSMutableArray *records;
@property(nonatomic,copy) void (^backgroundCompletion)(void);
+ (instancetype)shared;
- (NSDictionary *)add:(NSString *)identifier file:(NSDictionary *)file title:(NSString *)title;
- (void)toggle:(NSDictionary *)record;
- (void)remove:(NSDictionary *)record;
- (NSURL *)localURL:(NSDictionary *)record;
- (void)save;
@end

@interface ABPlayer : AVPlayerViewController
@property(nonatomic,copy) NSString *mediaName;
@property(nonatomic) BOOL embeddedMode;
@property(nonatomic,copy) void (^finished)(void);
- (void)loadURL:(NSURL *)url title:(NSString *)title;
@property(nonatomic,copy) void (^returnedFromFullscreen)(void);
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title;
@end
