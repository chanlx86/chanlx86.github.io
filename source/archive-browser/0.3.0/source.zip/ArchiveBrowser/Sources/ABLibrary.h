#import "ABCore.h"
extern NSString * const ABLibraryChanged;
NSDictionary *ABEntry(NSString *identifier, NSString *title, BOOL collection);
@interface ABLibrary : NSObject
@property(nonatomic,readonly) NSDictionary *data;
@property(nonatomic,readonly) NSString *error;
+ (instancetype)shared;
- (instancetype)initWithPath:(NSString *)path;
- (BOOL)visit:(NSDictionary *)entry;
- (BOOL)clearHistory;
- (NSString *)createFolder:(NSString *)name;
- (BOOL)renameFolder:(NSString *)folder name:(NSString *)name;
- (BOOL)deleteFolder:(NSString *)folder;
- (BOOL)setEntry:(NSDictionary *)entry folder:(NSString *)folder present:(BOOL)present;
- (BOOL)setCollection:(NSDictionary *)entry present:(BOOL)present;
- (BOOL)removeHistory:(NSString *)identifier;
@end
@interface ABLocalController : UITableViewController
@end
void ABFavorite(UIViewController *presenter, NSDictionary *entry);
