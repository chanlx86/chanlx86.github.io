#import "ABCore.h"

@interface ABBrowseController : UITableViewController
- (instancetype)initWithCollection:(NSString *)identifier title:(NSString *)title;
- (void)openIdentifier:(NSString *)identifier;
@end
@interface ABItemController : UITableViewController
- (instancetype)initWithIdentifier:(NSString *)identifier;
@end
@interface ABDownloadController : UITableViewController
@end
@interface ABAboutController : UITableViewController
@end
