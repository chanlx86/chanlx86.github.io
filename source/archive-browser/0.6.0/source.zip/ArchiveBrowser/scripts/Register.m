#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <dlfcn.h>
#include <string.h>
int main(int argc,char **argv) { @autoreleasepool {
    dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",RTLD_NOW);
    id w=((id(*)(id,SEL))objc_msgSend)(NSClassFromString(@"LSApplicationWorkspace"),NSSelectorFromString(@"defaultWorkspace"));
    BOOL remove=argc>1 && !strcmp(argv[1],"--unregister");
    SEL action=NSSelectorFromString(remove?@"unregisterApplication:":@"registerApplication:");
    BOOL reg=((BOOL(*)(id,SEL,id))objc_msgSend)(w,action,[NSURL fileURLWithPath:@"/Applications/ArchiveBrowser.app"]);
    printf("registration=%d\n",reg);
    if(remove || (argc>1&&!strcmp(argv[1],"--register-only")))return reg?0:2;
    BOOL launch=((BOOL(*)(id,SEL,id))objc_msgSend)(w,NSSelectorFromString(@"openApplicationWithBundleID:"),@"local.ArchiveBrowser");
    printf("launch=%d\n",launch); return launch?0:2;
} }
