#import "ABPanels.h"
#import "ABSearch.h"
#import "ABUI.h"

@implementation ABAdvancedController
- (instancetype)init { return [super initWithStyle:UITableViewStyleGrouped]; }
- (void)viewDidLoad {
    [super viewDidLoad]; self.title=@"高级搜索";
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStylePlain target:self action:@selector(close)];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"应用" style:UIBarButtonItemStyleDone target:self action:@selector(apply)];
    self.tableView.keyboardDismissMode=UIScrollViewKeyboardDismissModeOnDrag;
}
- (void)close { [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)apply {void (^callback)(NSInteger,BOOL)=_applied;NSInteger sort=_sort;BOOL title=_titleOnly;[self dismissViewControllerAnimated:YES completion:^{if(callback)callback(sort,title);}];}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)table {return 2;}
- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section {return section==0?4:2;}
- (NSString *)tableView:(UITableView *)table titleForHeaderInSection:(NSInteger)section {return @[@"结果排序",@"关键词匹配"][section];}
- (NSString *)tableView:(UITableView *)table titleForFooterInSection:(NSInteger)section {return @[@"最新收录按加入 Archive 的时间排序；作品日期使用条目提供的原始日期。下拉可刷新。",@"默认优先匹配标题，并要求包含所有关键词。后缀筛选已移除，搜索直接使用站点索引。"][section];}
- (UITableViewCell *)tableView:(UITableView *)table cellForRowAtIndexPath:(NSIndexPath *)p {
 UITableViewCell *c=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];c.textLabel.font=[UIFont systemFontOfSize:16];
 if(p.section==0){c.textLabel.text=@[@"相关性最高",@"最新收录优先",@"作品日期：由新到旧",@"作品日期：由旧到新"][p.row];c.accessoryType=p.row==_sort?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;}
 else {c.textLabel.text=@[@"名称优先，兼顾简介和作者",@"仅在标题中匹配"][p.row];c.accessoryType=p.row==(_titleOnly?1:0)?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;}return c;
}
- (void)tableView:(UITableView *)table didSelectRowAtIndexPath:(NSIndexPath *)p { [table deselectRowAtIndexPath:p animated:YES]; if(p.section==0)_sort=p.row; if(p.section==1)_titleOnly=p.row==1; if(p.section<2)[table reloadSections:[NSIndexSet indexSetWithIndex:p.section] withRowAnimation:UITableViewRowAnimationNone]; }
@end

void ABShowHelp(UIViewController *presenter) {
    ABAboutController *help=[ABAboutController new];
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:help];
    nav.modalPresentationStyle=UIModalPresentationFormSheet; nav.preferredContentSize=CGSizeMake(540,640);
    [presenter presentViewController:nav animated:YES completion:nil];
}
