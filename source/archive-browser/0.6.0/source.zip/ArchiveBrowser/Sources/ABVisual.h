#import "ABCore.h"
UIImage *ABTransportIcon(BOOL next);
UIImage *ABGlyph(NSString *kind);
void ABThumbnail(UIImageView *view, NSDictionary *entry);
@interface ABThumbCell : UITableViewCell
@property(nonatomic,strong) NSDictionary *entry;
@end
@interface ABEqualizer : UIView
@property(nonatomic) BOOL playing;
@end
