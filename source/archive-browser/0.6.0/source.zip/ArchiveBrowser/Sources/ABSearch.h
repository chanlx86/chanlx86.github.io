#import "ABCore.h"

NSString *ABSearchQuery(NSString *text, BOOL titleOnly, NSString *collection, NSString *type);
NSString *ABSearchPath(NSString *query, NSInteger page, NSInteger sort);
