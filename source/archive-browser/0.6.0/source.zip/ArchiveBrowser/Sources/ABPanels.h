#import "ABCore.h"
@interface ABAdvancedController : UITableViewController
@property(nonatomic) NSInteger sort;
@property(nonatomic) BOOL titleOnly;
@property(nonatomic,copy) void (^applied)(NSInteger sort,BOOL titleOnly);
@end
void ABShowHelp(UIViewController *presenter);
