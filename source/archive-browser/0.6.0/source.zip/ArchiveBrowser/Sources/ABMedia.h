#import "ABCore.h"
#import <AVFoundation/AVFoundation.h>
BOOL ABImageFile(NSString *name);
BOOL ABAudioFile(NSString *name);
BOOL ABMediaFile(NSString *name);
NSArray *ABPlaylist(NSArray *files);
NSDictionary *ABCompatibleFile(NSDictionary *file, NSArray *files);
@interface ABImageController : UIViewController
- (instancetype)initWithURL:(NSURL *)url title:(NSString *)title;
@end
@interface ABAudioBar : UIView
- (instancetype)initWithPlayer:(AVPlayer *)player;
- (void)setArtwork:(NSURL *)url;
- (void)stop;
@end
