#import "ABSearch.h"

static NSString *ABQuote(NSString *s) {
    s=[s stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"];
    s=[s stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    return [NSString stringWithFormat:@"\"%@\"",s];
}
NSString *ABSearchQuery(NSString *text,BOOL titleOnly,NSString *collection,NSString *type) {
    NSString *t=[text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *q=@"*:*";
    if(t.length) {
        NSMutableArray *words=[NSMutableArray array];
        for(NSString *w in [t componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]])if(w.length)[words addObject:ABQuote(w)];
        NSString *all=[words componentsJoinedByString:@" AND "];
        q=titleOnly?[NSString stringWithFormat:@"title:(%@)",all]:[NSString stringWithFormat:@"(title:%@^12 OR title:(%@)^6 OR (%@))",ABQuote(t),all,all];
    }
    if(collection.length)q=[NSString stringWithFormat:@"(%@) AND collection:%@",q,ABQuote(collection)];
    if(type.length)q=[NSString stringWithFormat:@"(%@) AND mediatype:%@",q,ABQuote(type)];
    return q;
}
NSString *ABSearchPath(NSString *query,NSInteger page,NSInteger sort) {
    NSString *path=[NSString stringWithFormat:@"/advancedsearch.php?q=%@&output=json&rows=25&page=%ld&fl%%5B%%5D=identifier&fl%%5B%%5D=title&fl%%5B%%5D=creator&fl%%5B%%5D=mediatype&fl%%5B%%5D=date&fl%%5B%%5D=addeddate",ABEncode(query),(long)page];
    // The proxy accepts _score, not score; without it relevance boosts may be ignored.
    NSArray *sorts=@[@"_score desc",@"addeddate desc",@"date desc",@"date asc"];
    if(sort>=0&&sort<(NSInteger)sorts.count)path=[path stringByAppendingFormat:@"&sort%%5B%%5D=%@&sort%%5B%%5D=identifier%%20asc",ABEncode(sorts[sort])];
    return path;
}

