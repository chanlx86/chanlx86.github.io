#import "ABCore.h"
@interface ABZIPReader : NSObject
@property(nonatomic,readonly) NSArray *entries;
@property(nonatomic,readonly) uint64_t totalSize;
- (instancetype)initWithURL:(NSURL *)url;
- (void)open:(void (^)(NSError *))completion;
- (void)extract:(NSDictionary *)entry completion:(void (^)(NSURL *,NSError *))completion;
- (void)cancel;
@end
BOOL ABZIPSafePath(NSString *name);
@interface ABZIPController : UITableViewController
- (instancetype)initWithURL:(NSURL *)url identifier:(NSString *)identifier name:(NSString *)name privateMode:(BOOL)privateMode;
@end
