#!/usr/bin/env python3
"""Public metadata and synthetic codec fixtures; never included in the App bundle."""
import argparse,json,pathlib,subprocess,tarfile,urllib.request
p=argparse.ArgumentParser();p.add_argument('--ffmpeg',required=True);args=p.parse_args()
root=pathlib.Path(__file__).resolve().parent.parent/'build/test-fixtures-030';root.mkdir(parents=True,exist_ok=True)
base=[args.ffmpeg,'-y','-v','error','-f','lavfi','-i','testsrc2=size=320x240:rate=25','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','3']
formats=[('h264.mp4',['-c:v','libx264','-profile:v','baseline','-pix_fmt','yuv420p','-c:a','aac']),('mpeg1.mpg',['-c:v','mpeg1video','-c:a','mp2','-f','mpeg']),('mpeg2.vob',['-c:v','mpeg2video','-c:a','mp2','-f','vob']),('mpeg2.ts',['-c:v','mpeg2video','-c:a','mp2','-f','mpegts']),('h264.ts',['-c:v','libx264','-profile:v','baseline','-c:a','aac','-f','mpegts'])]
for name,options in formats:subprocess.run(base+options+[str(root/name)],check=True)
subprocess.run([args.ffmpeg,'-v','error','-y','-f','lavfi','-i','testsrc2=size=320x240:rate=8','-t','3',str(root/'animated.gif')],check=True)
for identifier in ['IbertEscales','BigBuckBunny_328','testmp3testfile','electricsheep-flock-244-80000-9']:
 with urllib.request.urlopen('https://archive.org/metadata/'+identifier,timeout=30) as r:data=r.read(4*1024*1024+1)
 if len(data)>4*1024*1024:raise ValueError('Metadata exceeds test fixture limit')
 json.loads(data);(root/(identifier+'.json')).write_bytes(data)
with tarfile.open(root/'fixtures.tgz','w:gz') as t:
 for file in sorted(root.iterdir()):
  if file.suffix!='.tgz':t.add(file,arcname=file.name)
print(root/'fixtures.tgz')
print('Upload/extract into /var/mobile/Media/ArchiveBrowser-Test, owned by mobile. Then deploy.py --testing. Requires unlocked device.')
