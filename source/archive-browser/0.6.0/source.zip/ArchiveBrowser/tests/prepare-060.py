#!/usr/bin/env python3
import pathlib,wave,math,struct,zipfile,subprocess,tarfile
p=pathlib.Path(__file__).resolve().parent.parent/'build/test-fixtures-060';p.mkdir(exist_ok=True,parents=True)
with wave.open(str(p/'tone.wav'),'wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(44100)
 w.writeframes(b''.join(struct.pack('<hh',int(6000*math.sin(i*2*math.pi*440/44100)),int(6000*math.sin(i*2*math.pi*660/44100))) for i in range(3*44100)))
for ext,fmt,codec in [('flac','flac','flac'),('m4a','m4af','alac')]:subprocess.run(['afconvert','-f',fmt,'-d',codec,str(p/'tone.wav'),str(p/('tone.'+ext))],check=True)
(p/'book.txt').write_text('Archive Browser 0.6.0\n中文文本预览测试\nUTF-8 / ZIP / PDF / EPUB / FLAC / ALAC',encoding='utf-8')
# Small self-contained PDF, no dependency on host document renderers.
objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 320 240] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>']
stream=b'BT /F1 20 Tf 25 180 Td (Archive Browser PDF preview) Tj ET';objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'\nendstream')
b=bytearray(b'%PDF-1.4\n');offsets=[0]
for i,o in enumerate(objects,1):offsets.append(len(b));b+=str(i).encode()+b' 0 obj\n'+o+b'\nendobj\n'
x=len(b);b+=b'xref\n0 6\n0000000000 65535 f \n'+b''.join(f'{n:010} 00000 n \n'.encode() for n in offsets[1:]);b+=f'trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n{x}\n%%EOF\n'.encode();(p/'book.pdf').write_bytes(b)
with zipfile.ZipFile(p/'book.epub','w') as z:
 z.writestr('mimetype','application/epub+zip')
 z.writestr('META-INF/container.xml','<?xml version="1.0"?><container xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OPS/book.opf"/></rootfiles></container>',compress_type=8)
 z.writestr('OPS/book.opf','<?xml version="1.0"?><package xmlns="http://www.idpf.org/2007/opf" version="2.0"><manifest><item id="a" href="chapter1.xhtml" media-type="application/xhtml+xml"/><item id="b" href="chapter2.xhtml" media-type="application/xhtml+xml"/></manifest><spine><itemref idref="a"/><itemref idref="b"/></spine></package>',compress_type=8)
 for i in [1,2]:z.writestr(f'OPS/chapter{i}.xhtml',f'<html xmlns="http://www.w3.org/1999/xhtml"><head><title>Chapter {i}</title></head><body><h1>EPUB 章节 {i}</h1><p>Archive Browser chapter {i}.</p></body></html>',compress_type=8)
with zipfile.ZipFile(p/'files.zip','w') as z:
 for n in ['book.txt','book.pdf','book.epub','tone.wav','tone.flac','tone.m4a']:z.write(p/n,'folder/'+n,compress_type=8)
 z.writestr('../outside.txt','must never extract',compress_type=8)
 z.writestr('stored.txt','Stored entry',compress_type=0)
 z.writestr('empty.txt','',compress_type=8)
# Corrupt stored bytes to verify CRC rejection.
b=bytearray((p/'files.zip').read_bytes());at=b.index(b'Stored entry');b[at]^=1;(p/'corrupt.zip').write_bytes(b)
with tarfile.open(p/'fixtures.tgz','w:gz') as t:
 for f in sorted(p.iterdir()):
  if f.suffix!='.tgz':t.add(f,arcname=f.name)
print(p/'fixtures.tgz')
