#import <Foundation/Foundation.h>
int main(){@autoreleasepool{
 NSFileManager *fm=[NSFileManager defaultManager];NSString *stage=@"/var/mobile/troubadour-stage";
 if(![@[@"/var/mobile/troubadour-stage",@"/private/var/mobile/troubadour-stage"] containsObject:stage.stringByResolvingSymlinksInPath])return 2;
 NSSet *allowed=[NSSet setWithArray:@[@"Device",@"Device.next",@"Capture",@"Capture.next",@"Capture.entitlements",@"homepage.png",@"Troubadour-release.ipa",@"Cleanup"]];
 for(NSString *name in [fm contentsOfDirectoryAtPath:stage error:nil])if(![allowed containsObject:name])return 3;
 NSError *error=nil;if(![fm removeItemAtPath:stage error:&error]){NSLog(@"%@",error);return 4;}
 puts("Removed only Troubadour deployment staging and temporary capture.");return 0;
}}
