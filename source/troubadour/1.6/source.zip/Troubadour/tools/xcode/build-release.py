#!/usr/bin/env python3
"""Build the generated project's Release configuration with Xcode 7's tools.
Also works when the host macOS cannot initialize the old Xcode IDE frameworks.
"""
from pathlib import Path
import subprocess,plistlib,concurrent.futures,json,shutil,sys,os
r=Path(__file__).resolve().parents[2];build=r/'build';build.mkdir(exist_ok=True)
dev=Path(os.environ.get('TROUBADOUR_DEVELOPER_DIR','/Volumes/OS X/Applications/Xcode.app/Contents/Developer'))
cc=dev/'Toolchains/XcodeDefault.xctoolchain/usr/bin/clang';sdk=dev/'Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk';lipo=dev/'Toolchains/XcodeDefault.xctoolchain/usr/bin/lipo'
pbx=plistlib.loads(subprocess.check_output(['/usr/bin/plutil','-convert','xml1','-o','-',str(r/'Troubadour.xcodeproj/project.pbxproj')]))
objects=pbx['objects'];project=objects[pbx['rootObject']]
def release(owner):return next(objects[c]['buildSettings'] for c in objects[owner['buildConfigurationList']]['buildConfigurations'] if objects[c]['name']=='Release')
def paths(target,phase):
 return [objects[objects[f]['fileRef']]['path'] for p in target['buildPhases'] if objects[p]['isa']==phase for f in objects[p]['files']]
def resolve(value):return value.replace('$(SRCROOT)',str(r))
def flags(values):return [resolve(v) for v in values if v!='$(inherited)']
app=next(objects[t] for t in project['targets'] if objects[t]['name']=='Troubadour');helper=next(objects[t] for t in project['targets'] if objects[t]['name']=='iconswitch')
settings=release(project).copy();settings.update(release(app));sources=paths(app,'PBXSourcesBuildPhase');resources=paths(app,'PBXResourcesBuildPhase')
assert set(sources)=={p.relative_to(r).as_posix() for p in (r/'src').rglob('*.m')}|{p.relative_to(r).as_posix() for p in (r/'src/warp').glob('*.c')}
assert set(resources)=={p.relative_to(r).as_posix() for p in (r/'Resources').iterdir() if p.name!='Info.plist'}
architectures=settings['ARCHS'];frameworks=[Path(p).stem for p in paths(app,'PBXFrameworksBuildPhase')]
report={'compiler':subprocess.check_output([str(cc),'--version'],text=True).splitlines()[0],'sdk':str(sdk),'architectures':architectures,'deploymentTarget':settings['IPHONEOS_DEPLOYMENT_TARGET'],'sources':sources,'resources':resources,'defines':flags(settings['GCC_PREPROCESSOR_DEFINITIONS']),'frameworks':frameworks,'logCallsRemoved':True,'insecureTLS':False,'privateWarpConfig':(r/'src/warp/AWGSecrets.h').exists()}
common=['-isysroot',str(sdk),'-miphoneos-version-min='+settings['IPHONEOS_DEPLOYMENT_TARGET'],'-Os','-fblocks','-fvisibility=hidden','-Wall','-Wno-deprecated-declarations','-Wno-unused-variable','-fno-modules']+sum([['-I',resolve(p)] for p in flags(settings['HEADER_SEARCH_PATHS'])],[])+['-D'+v for v in report['defines']]+['-include',resolve(settings['GCC_PREFIX_HEADER'])]
def run(args,log):
 p=subprocess.run(args,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 log.write_bytes(p.stdout)
 if p.returncode:raise RuntimeError(str(log)+'\n'+p.stdout.decode(errors='replace')[-7000:])
for arch in architectures:
 out=build/'native-release'/arch;out.mkdir(parents=True,exist_ok=True)
 def compile(source):
  dest=out/(source.replace('/','_')+'.o');args=[str(cc),'-arch',arch]+common+(['-fobjc-arc'] if source.endswith('.m') else ['-std=gnu99'])+['-c',source,'-o',str(dest)]
  run(args,dest.with_suffix('.log'));return str(dest)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:objectsBuilt=list(pool.map(compile,sources))
 run([str(cc),'-arch',arch,'-isysroot',str(sdk),'-miphoneos-version-min='+settings['IPHONEOS_DEPLOYMENT_TARGET']]+objectsBuilt+sum([['-framework',f] for f in frameworks],[])+flags(settings['OTHER_LDFLAGS'])+['-o',str(out/'Troubadour')],out/'link.log')
 run([str(cc),'-arch',arch,'-isysroot',str(sdk),'-miphoneos-version-min='+settings['IPHONEOS_DEPLOYMENT_TARGET'],'-Os','-Wall','src/helper/iconswitch.c','-o',str(out/'iconswitch')],out/'helper.log')
 print('Compiled and linked',arch,flush=True)
product=build/'Release-iphoneos/Troubadour.app';product.parent.mkdir(parents=True,exist_ok=True)
if product.exists():shutil.rmtree(product)
shutil.copytree(r/'Resources',product)
for name in ['Troubadour','iconswitch']:
 subprocess.run([str(lipo),'-create']+[str(build/'native-release'/a/name) for a in architectures]+['-output',str(product/name)],check=True)
 (product/name).chmod(0o755)
original=product/'Icons/troubadour';original.mkdir(parents=True,exist_ok=True)
for icon in product.glob('Icon-*.png'):shutil.copy2(icon,original/icon.name)
shutil.copy2(product/'Info.plist',original/'Info.plist')
for loc in product.glob('*.lproj'):
 if (loc/'InfoPlist.strings').exists():(original/loc.name).mkdir(exist_ok=True);shutil.copy2(loc/'InfoPlist.strings',original/loc.name/'InfoPlist.strings')
(product/'iconswitch').chmod(0o4755);(product/'PkgInfo').write_bytes(b'APPL????')
report['app']=str(product);(build/'release-build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Built Release:',product)
