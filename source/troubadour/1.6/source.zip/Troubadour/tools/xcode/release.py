#!/usr/bin/env python3
"""Terminal-only Release build/sign/check/package with Xcode 7.3.1 tools."""
from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parents[2]
def run(script):subprocess.run([sys.executable,str(r/'tools/xcode'/script)],cwd=r,check=True)
if not (r/'Troubadour.xcodeproj/project.pbxproj').exists():run('generate.py')
run('build-release.py')
for executable,identifier in [('iconswitch','ru.computershik.troubadour.iconswitch'),('Troubadour','ru.computershik.troubadour')]:
 subprocess.run(['/usr/bin/codesign','--force','--sign','-','--identifier',identifier,'--digest-algorithm=sha1,sha256','--timestamp=none',str(r/'build/Release-iphoneos/Troubadour.app'/executable)],check=True)
run('check-release.py');run('package.py')
