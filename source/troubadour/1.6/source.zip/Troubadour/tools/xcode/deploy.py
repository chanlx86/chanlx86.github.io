#!/usr/bin/env python3
"""Install the verified IPA using the device's existing AppSync/ipainstaller."""
from pathlib import Path
import subprocess,json,hashlib,shlex,time,os,argparse
r=Path(__file__).resolve().parents[2];parser=argparse.ArgumentParser();parser.add_argument('--host',default='192.168.1.18');args=parser.parse_args()
ssh=['ssh','-S',os.environ.get('TROUBADOUR_SSH_SOCKET','/private/tmp/troubadour-ipad.socket'),'-o','BatchMode=yes','-o','ConnectTimeout=8','root@'+args.host]
stage='/var/mobile/troubadour-stage';quote=shlex.quote
def remote(command,**kwargs):return subprocess.run(ssh+['cd /var/mobile; '+command],check=True,**kwargs)
def info():return json.loads(remote(stage+'/Device info',stdout=subprocess.PIPE).stdout)
def upload(local,name):
 with Path(local).open('rb') as stream:remote('mkdir -p '+stage+'; cat > '+quote(stage+'/'+name),stdin=stream)
ipa=r/'packages/Troubadour_1.6_Xcode7_Release.ipa';assert ipa.is_file();assert (r/'build/release-check.json').exists()
dev=Path(os.environ.get('TROUBADOUR_DEVELOPER_DIR','/Volumes/OS X/Applications/Xcode.app/Contents/Developer'))
subprocess.run([str(dev/'Toolchains/XcodeDefault.xctoolchain/usr/bin/clang'),'-arch','armv7','-isysroot',str(dev/'Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS9.3.sdk'),'-miphoneos-version-min=9.0','-fobjc-arc','-framework','Foundation',str(r/'tools/xcode/Device.m'),'-o',str(r/'build/Device')],check=True)
upload(r/'build/Device','Device.next');remote('set -e; ldid -S '+stage+'/Device.next; chmod 755 '+stage+'/Device.next; mv '+stage+'/Device.next '+stage+'/Device')
before=info();report={'host':args.host,'previous':before,'ipaSHA256':hashlib.sha256(ipa.read_bytes()).hexdigest()}
if before.get('bundleURL'):
 backup='/var/mobile/Library/TroubadourDevelopment/Backups';remote('mkdir -p '+backup+'; chmod 700 '+backup)
 bundle=Path(before['bundleURL']);remote('set -e; test ! -e '+backup+'/before-xcode-app.tar.gz; tar -czf '+backup+'/before-xcode-app.tar.gz -C '+quote(str(bundle.parent))+' '+quote(bundle.name)+'; chmod 600 '+backup+'/before-xcode-app.tar.gz')
 if before.get('dataContainerURL'):
  data=before['dataContainerURL'];assert '/Containers/Data/Application/' in data
  remote('set -e; test ! -e '+backup+'/before-xcode-data.tar.gz; tar -czf '+backup+'/before-xcode-data.tar.gz -C '+quote(data)+' .; chmod 600 '+backup+'/before-xcode-data.tar.gz')
 report['backup']=backup
upload(ipa,'Troubadour-release.ipa')
remote('killall Troubadour 2>/dev/null || true')
p=subprocess.run(ssh+['cd /var/mobile; ipainstaller '+stage+'/Troubadour-release.ipa'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(r/'build/device-installer.log').write_text(p.stdout);print(p.stdout)
assert 'successfully' in p.stdout,'Installer did not report success; see build/device-installer.log'
after=info();assert after.get('bundleURL');report['installed']=after;report['binaryMatches']={}
for name in ['Troubadour','iconswitch']:
 actual=remote('cat '+quote(after['bundleURL']+'/'+name),stdout=subprocess.PIPE).stdout
 local=(r/'build/Release-iphoneos/Troubadour.app'/name).read_bytes();assert actual==local,name
 report['binaryMatches'][name]=hashlib.sha256(actual).hexdigest()
p=remote('su mobile -c '+quote(stage+'/Device launch'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
report['launchResponse']=p.stdout.decode(errors='replace').strip()
for n in range(8):
 time.sleep(1);front=remote(stage+'/Device front',stdout=subprocess.PIPE).stdout.decode().strip();report['front']=front
 if front=='ru.computershik.troubadour':break
(r/'build/device-install.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
