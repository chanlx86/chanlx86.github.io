#!/usr/bin/env python3
"""Reuse upstream checks with Apple's real arm64 minimum (iOS 7.0)."""
from pathlib import Path
import importlib.util,sys,hashlib,plistlib,json,subprocess
r=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('upstream_macho',r/'tools/check-macho.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.EXPECTED_MIN={'armv7':(5,1),'arm64':(7,0)}
app=r/'build/Release-iphoneos/Troubadour.app';errors=[]
for binary,identifier in [('Troubadour','ru.computershik.troubadour'),('iconswitch','ru.computershik.troubadour.iconswitch')]:
 m.BUNDLE_IDENTIFIER=identifier;m.check(str(app/binary),errors)
 data=(app/binary).read_bytes();assert b'/build/host-compat' not in data
for source in (r/'Resources').rglob('*'):
 if source.is_file():
  target=app/source.relative_to(r/'Resources');assert target.is_file() and target.read_bytes()==source.read_bytes(),source
info=plistlib.loads((app/'Info.plist').read_bytes());assert info['UIDeviceFamily']==[1,2] and info['MinimumOSVersion']=='5.1'
assert not errors,errors
# Linkage of NSObject must remain compatible with iOS 5 on armv7.
nm=Path('/Volumes/OS X/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/nm')
undefined=subprocess.check_output([str(nm),'-arch','armv7','-m','-u',str(app/'Troubadour')],text=True)
classes=[line for line in undefined.splitlines() if '_OBJC_CLASS_$_NSObject' in line or '_OBJC_METACLASS_$_NSObject' in line]
assert len(classes)==2 and all('CoreFoundation' in line or 'dynamically looked up' in line for line in classes)
report={'armv7Minimum':'5.1','arm64Minimum':'7.0','sdk':'9.3','dualHashSignatures':True,'originalResourcesMatch':True,'resourceFiles':sum(p.is_file() for p in (r/'Resources').rglob('*')),'NSObjectCompatibleLinkage':classes,'sha256':{name:hashlib.sha256((app/name).read_bytes()).hexdigest() for name in ['Troubadour','iconswitch']}}
(r/'build/release-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Native Release checks passed; original upstream checker expects arm64 minimum 5.1, whereas the Apple linker emits 7.0.')
