#!/usr/bin/env python3
"""Generate an Xcode 7 project from the same sources/resources as the Theos target."""
from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[2]
objects={}
def uid(name):return hashlib.sha1(name.encode()).hexdigest()[:24].upper()
def obj(identifier,isa,**fields):
 k=uid(identifier);objects[k]={'isa':isa,**fields};return k
def configlist(name,settings):
 configs=[]
 for mode in ['Debug','Release']:
  values=dict(settings)
  if mode=='Debug':values.update(GCC_OPTIMIZATION_LEVEL='0',DEBUG_INFORMATION_FORMAT='dwarf',GCC_PREPROCESSOR_DEFINITIONS=['$(inherited)','DEBUG=1'])
  else:values.update(GCC_OPTIMIZATION_LEVEL='s',DEBUG_INFORMATION_FORMAT='dwarf-with-dsym',GCC_PREPROCESSOR_DEFINITIONS=['$(inherited)','YT_NO_LOG=1'])
  configs.append(obj(name+mode,'XCBuildConfiguration',name=mode,buildSettings=values))
 return obj(name+'configs','XCConfigurationList',buildConfigurations=configs,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
files=[];sourceBuild=[];resourceBuild=[];frameworkBuild=[];resourceRefs=[];frameworkRefs=[]
for path in sorted(r.joinpath('src').rglob('*')):
 if not path.is_file() or path.suffix not in ['.m','.c','.h']:continue
 rel=path.relative_to(r).as_posix();ref=obj('file:'+rel,'PBXFileReference',path=rel,sourceTree='<group>',lastKnownFileType={'.m':'sourcecode.c.objc','.c':'sourcecode.c.c','.h':'sourcecode.c.h'}[path.suffix]);files.append(ref)
 if path.suffix=='.m' or path.suffix=='.c' and path.parent==r/'src/warp':sourceBuild.append(obj('build:'+rel,'PBXBuildFile',fileRef=ref))
for path in sorted((r/'Resources').iterdir()):
 if path.name=='Info.plist':continue
 rel=path.relative_to(r).as_posix();kind='folder' if path.is_dir() else {'.png':'image.png','.strings':'text.plist.strings','.json':'text.json'}.get(path.suffix,'file')
 ref=obj('file:'+rel,'PBXFileReference',path=rel,sourceTree='<group>',lastKnownFileType=kind);resourceRefs.append(ref);resourceBuild.append(obj('build:'+rel,'PBXBuildFile',fileRef=ref))
for name in ['Foundation','UIKit','CoreGraphics','QuartzCore','ImageIO','AVFoundation','CoreMedia','MediaPlayer','Security','SystemConfiguration','CoreText']:
 ref=obj('framework:'+name,'PBXFileReference',name=name+'.framework',path='System/Library/Frameworks/'+name+'.framework',sourceTree='SDKROOT',lastKnownFileType='wrapper.framework');frameworkRefs.append(ref);frameworkBuild.append(obj('link:'+name,'PBXBuildFile',fileRef=ref))
appProduct=obj('appProduct','PBXFileReference',path='Troubadour.app',sourceTree='BUILT_PRODUCTS_DIR',explicitFileType='wrapper.application',includeInIndex=0)
toolProduct=obj('toolProduct','PBXFileReference',path='iconswitch',sourceTree='BUILT_PRODUCTS_DIR',explicitFileType='compiled.mach-o.executable',includeInIndex=0)
appSettings={'PRODUCT_NAME':'Troubadour','PRODUCT_BUNDLE_IDENTIFIER':'ru.computershik.troubadour','INFOPLIST_FILE':'Resources/Info.plist','TARGETED_DEVICE_FAMILY':'1,2','CLANG_ENABLE_OBJC_ARC':'YES','GCC_PREFIX_HEADER':'$(SRCROOT)/src/YTLog.h','GCC_PRECOMPILE_PREFIX_HEADER':'NO','HEADER_SEARCH_PATHS':['$(inherited)']+['$(SRCROOT)/'+p.relative_to(r).as_posix() for p in sorted((r/'src').rglob('*')) if p.is_dir()]+['$(SRCROOT)/src'],'GCC_SYMBOLS_PRIVATE_EXTERN':'YES','WARNING_CFLAGS':['-Wall','-Wno-deprecated-declarations','-Wno-unused-variable'],'OTHER_LDFLAGS':['$(inherited)','-weak_framework','AVKit','-lz','-Wl,-U,_OBJC_CLASS_$_NSObject','-Wl,-U,_OBJC_METACLASS_$_NSObject'],'SKIP_INSTALL':'NO'}
toolSettings={'PRODUCT_NAME':'iconswitch','EXECUTABLE_PREFIX':'','EXECUTABLE_EXTENSION':'','GCC_C_LANGUAGE_STANDARD':'gnu99','WARNING_CFLAGS':['-Wall'],'SKIP_INSTALL':'YES'}
projectSettings={'SDKROOT':'iphoneos9.3','SUPPORTED_PLATFORMS':'iphoneos','ARCHS':['armv7','arm64'],'VALID_ARCHS':'armv7 arm64','ONLY_ACTIVE_ARCH':'NO','IPHONEOS_DEPLOYMENT_TARGET':'5.1','CODE_SIGN_IDENTITY':'','CODE_SIGNING_REQUIRED':'NO','CODE_SIGNING_ALLOWED':'NO','ENABLE_BITCODE':'NO','GCC_C_LANGUAGE_STANDARD':'gnu99','SYMROOT':'$(SRCROOT)/build/xcode','OBJROOT':'$(SRCROOT)/build/xcode-obj','CLANG_ENABLE_MODULES':'NO'}
sourcePhase=obj('appSources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=sourceBuild,runOnlyForDeploymentPostprocessing=0)
resourcePhase=obj('appResources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=resourceBuild,runOnlyForDeploymentPostprocessing=0)
frameworkPhase=obj('appFrameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=frameworkBuild,runOnlyForDeploymentPostprocessing=0)
toolSource=obj('toolSource','PBXSourcesBuildPhase',buildActionMask=2147483647,files=[obj('toolBuild','PBXBuildFile',fileRef=uid('file:src/helper/iconswitch.c'))],runOnlyForDeploymentPostprocessing=0)
toolTarget=obj('toolTarget','PBXNativeTarget',name='iconswitch',productName='iconswitch',productReference=toolProduct,productType='com.apple.product-type.tool',buildConfigurationList=configlist('tool',toolSettings),buildPhases=[toolSource],buildRules=[],dependencies=[])
proxy=obj('toolProxy','PBXContainerItemProxy',containerPortal=uid('project'),proxyType=1,remoteGlobalIDString=toolTarget,remoteInfo='iconswitch')
dep=obj('toolDependency','PBXTargetDependency',target=toolTarget,targetProxy=proxy)
copyPhase=obj('copyTool','PBXCopyFilesBuildPhase',buildActionMask=2147483647,dstPath='',dstSubfolderSpec=1,files=[obj('copyToolBuild','PBXBuildFile',fileRef=toolProduct)],name='Embed iconswitch',runOnlyForDeploymentPostprocessing=0)
script='''set -eu
app="${TARGET_BUILD_DIR}/${WRAPPER_NAME}"
mkdir -p "$app/Icons/troubadour"
cp "$app"/Icon-*.png "$app/Icons/troubadour/"
cp "$app/Info.plist" "$app/Icons/troubadour/Info.plist"
for loc in "$app"/*.lproj; do
    [ -f "$loc/InfoPlist.strings" ] || continue
    mkdir -p "$app/Icons/troubadour/$(basename "$loc")"
    cp "$loc/InfoPlist.strings" "$app/Icons/troubadour/$(basename "$loc")/InfoPlist.strings"
done
chmod 4755 "$app/iconswitch"
'''
stagePhase=obj('stagePhase','PBXShellScriptBuildPhase',buildActionMask=2147483647,files=[],inputPaths=[],outputPaths=[],name='Prepare original icon restore resources',runOnlyForDeploymentPostprocessing=0,shellPath='/bin/sh',shellScript=script)
appTarget=obj('appTarget','PBXNativeTarget',name='Troubadour',productName='Troubadour',productReference=appProduct,productType='com.apple.product-type.application',buildConfigurationList=configlist('app',appSettings),buildPhases=[sourcePhase,frameworkPhase,resourcePhase,copyPhase,stagePhase],buildRules=[],dependencies=[dep])
infoRef=obj('file:Resources/Info.plist','PBXFileReference',path='Resources/Info.plist',sourceTree='<group>',lastKnownFileType='text.plist.xml');resourceRefs.insert(0,infoRef)
def source_group(directory):
 children=[]
 for path in sorted(directory.iterdir()):
  if path.is_dir():children.append(source_group(path))
  elif path.suffix in ['.m','.c','.h']:children.append(uid('file:'+path.relative_to(r).as_posix()))
 return obj('group:'+directory.relative_to(r).as_posix(),'PBXGroup',name='Sources' if directory==r/'src' else directory.name,sourceTree='<group>',children=children)
sourceGroup=source_group(r/'src')
mainGroup=obj('mainGroup' ,'PBXGroup',sourceTree='<group>',children=[sourceGroup,obj('resourceGroup','PBXGroup',name='Resources',sourceTree='<group>',children=resourceRefs),obj('frameworkGroup','PBXGroup',name='Frameworks',sourceTree='<group>',children=frameworkRefs),obj('productGroup','PBXGroup',name='Products',sourceTree='<group>',children=[appProduct,toolProduct])])
project=obj('project','PBXProject',attributes={'LastUpgradeCheck':'0730'},buildConfigurationList=configlist('project',projectSettings),compatibilityVersion='Xcode 3.2',developmentRegion='en',hasScannedForEncodings=0,knownRegions=['en','ru'],mainGroup=mainGroup,productRefGroup=uid('productGroup'),projectDirPath='',projectRoot='',targets=[appTarget,toolTarget])
def emit(value,indent=0):
 pad='\t'*indent
 if isinstance(value,dict):return '{\n'+''.join('\t'*(indent+1)+emit(str(k))+' = '+emit(v,indent+1)+';\n' for k,v in value.items())+pad+'}'
 if isinstance(value,list):return '(\n'+''.join('\t'*(indent+1)+emit(v,indent+1)+',\n' for v in value)+pad+')'
 if isinstance(value,int):return str(value)
 return json.dumps(value,ensure_ascii=False)
p=r/'Troubadour.xcodeproj';p.mkdir(exist_ok=True)
(p/'project.pbxproj').write_text('// !$*UTF8*$!\n'+emit({'archiveVersion':1,'classes':{},'objectVersion':46,'objects':objects,'rootObject':project})+'\n')
shared=p/'xcshareddata/xcschemes';shared.mkdir(parents=True,exist_ok=True)
(shared/'Troubadour.xcscheme').write_text('''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="0730" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="'''+appTarget+'''" BuildableName="Troubadour.app" BlueprintName="Troubadour" ReferencedContainer="container:Troubadour.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction><TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.DebuggerFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"/><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.DebuggerFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="'''+appTarget+'''" BuildableName="Troubadour.app" BlueprintName="Troubadour" ReferencedContainer="container:Troubadour.xcodeproj"/></BuildableProductRunnable></LaunchAction><ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"/><AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>
''')
print('Generated',p,'with',len(sourceBuild),'app sources and',len(resourceBuild),'resource entries')
