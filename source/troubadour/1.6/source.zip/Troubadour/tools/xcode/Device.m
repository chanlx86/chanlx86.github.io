#import <Foundation/Foundation.h>
#import <objc/message.h>
#include <dlfcn.h>
int main(int argc,char **argv){@autoreleasepool{
 NSString *identifier=@"ru.computershik.troubadour";NSString *command=argc>1?@(argv[1]):@"info";
 dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices",RTLD_NOW);
 id workspace=((id(*)(id,SEL))objc_msgSend)(NSClassFromString(@"LSApplicationWorkspace"),NSSelectorFromString(@"defaultWorkspace"));
 if([command isEqual:@"launch"]){BOOL ok=((BOOL(*)(id,SEL,id))objc_msgSend)(workspace,NSSelectorFromString(@"openApplicationWithBundleID:"),identifier);printf("launch=%d\n",ok);return ok?0:2;}
 if([command isEqual:@"front"]){void*h=dlopen("/System/Library/PrivateFrameworks/SpringBoardServices.framework/SpringBoardServices",RTLD_NOW);CFStringRef(*front)(void)=h?dlsym(h,"SBSCopyFrontmostApplicationDisplayIdentifier"):NULL;printf("%s\n",front?[CFBridgingRelease(front()) UTF8String]:"unknown");return 0;}
 id proxy=((id(*)(id,SEL,id))objc_msgSend)(NSClassFromString(@"LSApplicationProxy"),NSSelectorFromString(@"applicationProxyForIdentifier:"),identifier);
 NSMutableDictionary *info=[NSMutableDictionary dictionary];for(NSString *key in @[@"bundleURL",@"dataContainerURL"]){id value=[proxy respondsToSelector:NSSelectorFromString(key)]?[proxy valueForKey:key]:nil;if([value isKindOfClass:[NSURL class]])info[key]=[value path];}
 if(info[@"bundleURL"]){NSDictionary *plist=[NSDictionary dictionaryWithContentsOfFile:[info[@"bundleURL"] stringByAppendingPathComponent:@"Info.plist"]];info[@"version"]=plist[@"CFBundleVersion"]?:@"";}
 NSData *data=[NSJSONSerialization dataWithJSONObject:info options:0 error:nil];fwrite(data.bytes,1,data.length,stdout);puts("");return 0;
}}
