# Troubadour 1.6（修复构建 1.6.1）：Xcode 7.3.1 工程与 Release 构建

上游提交：`f70230a8c0a8e16dff5992903e5471c589e7a7e5`。
在 Xcode 工程基础上修正 `src/ui/YTShortsView.m` 的 7 个按钮回调生命周期：进入临时 NSArray 之前显式 copy Block，避免旧 Clang 7 ARC 将后续可变参数中的捕获回调留在栈上。其余运行时源码保持上游；Info.plist 的内部构建号为 1.6.1，显示版本沿用 1.6。保留 GPL-3.0 及各第三方许可。

## 工程

打开 `Troubadour.xcodeproj`，共享 Scheme 为 `Troubadour`。包含应用与 `iconswitch` 两个 Target；应用保留上游的 79 个 Objective-C 文件、3 个加密 C 文件及全部 Resources，helper 独立编译。

Release 对齐公开源码的设置：ARC、`-Os`、隐藏符号、`YT_NO_LOG=1`、强制包含 `src/YTLog.h`、原有系统框架、AVKit 弱链接和 zlib。不启用 `YT_INSECURE_TLS`，不替换或简化任何模块。

iPhoneOS9.3 SDK 来自 Xcode 7.3.1 原始 SDK，没有修改 Xcode 或系统文件。Apple SDK 已带旧系统符号隐藏/导出信息，因此不执行用于 Theos 再生成 SDK 的 `patch-sdk.sh`。验证确认 armv7 的 NSObject 仍从 CoreFoundation 解析，避免绑定到旧系统没有该类的 libobjc。

## 本机终端一条命令构建

```bash
cd /Users/luoxian/Documents/Troubadour
python3 tools/xcode/release.py
```

脚本直接读取工程文件里的 Release 源码、资源、宏和链接配置，调用 Xcode 7.3.1 自带 Clang 7.3 与链接器，随后签名、检查并打包。无需启动 Xcode 图形界面，也不安装 Theos。

默认 Xcode 路径为本机的：

`/Volumes/OS X/Applications/Xcode.app/Contents/Developer`

其他机器可以指定：

```bash
export TROUBADOUR_DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
python3 tools/xcode/release.py
```

需要 Python 3，以及支持双哈希参数的 macOS codesign。输出：

- `build/Release-iphoneos/Troubadour.app`
- `packages/Troubadour_1.6.1_Xcode7_Release.ipa`
- `build/release-build.json`：实际编译配置与输入清单。
- `build/release-check.json`：签名、资源及符号核验。

`tools/xcode/generate.py` 可重新扫描源码生成工程；已经手动修改工程后，不要随意重新生成，以免覆盖工程设置。

## 标准 xcodebuild 入口与本机限制

在 Xcode 7.3.1 可正常初始化、且已由用户本人确认许可的系统上，可以直接使用工程：

```bash
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
  /Applications/Xcode.app/Contents/Developer/usr/bin/xcodebuild \
  -project Troubadour.xcodeproj -scheme Troubadour \
  -configuration Release -sdk iphoneos \
  CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build
```

该路径输出到 `build/xcode/Release-iphoneos/`，本机的一条命令脚本则输出到 `build/Release-iphoneos/`。Xcode 内置构建按默认规则会处理 Info.plist；终端脚本保留上游原始资源。

当前 macOS 已移除 Xcode 7 需要的 libauto 和 Python 2.7。研究时仅在忽略的 `build/host-compat` 中使用独立库/框架路径，使 xcodebuild 能报告版本并走到许可检查；没有改系统或 Xcode。该工具仍要求当前系统确认许可，本次未自动代用户接受条款。因此，本次交付是 **按工程 Release 配置调用 Xcode 7.3.1 编译器的完整构建**，不宣称已完成本机 xcodebuild 全流程或 GUI 调试验证。工程做过 plist 和引用/输入一致性检查。

## 兼容性和签名

- 通用包：armv7 + arm64。
- armv7 最低系统 5.1；Apple 链接器将 arm64 最低系统设为 7.0。64 位 iOS 设备本就从 iOS 7 开始，iPad3 的 armv7 不受影响。
- 主程序、helper 均是 adhoc 签名，含 SHA-1 和 SHA-256，签名标识与各自程序一致。
- 上游 `tools/check-macho.py` 把 arm64 的最低系统也写死成 5.1，所以直接运行会报告这一项差异。新增 `tools/xcode/check-release.py` 复用其平台、架构、签名检查，明确将 Apple arm64 最低系统期望设为 7.0；没有篡改 Mach-O 去伪装 5.1。
- 无普通 Apple 开发证书、无设备 UDID 绑定；本 IPA 面向当前已有 AppSync／伪签名安装能力的越狱设备，不是可任意安装的 App Store 包。

## IPA 安装

使用已有 SSH 控制连接，不在脚本或源码中保存密码：

```bash
ssh -M -S /private/tmp/troubadour-ipad.socket \
  -o ControlPersist=1800 root@192.168.1.18 /var/mobile/lsr-ssh-budget
python3 tools/xcode/deploy.py --host 192.168.1.18
```

本机 `lsr-ssh-budget` 是测试设备已有的 SSH 内存上限辅助程序；其他设备没有它时，可先建立普通 SSH 控制连接，再执行部署脚本。设备需要 ipainstaller、ldid 和可安装 adhoc IPA 的越狱环境。

脚本先查询同一包标识的已有安装；有旧版本时将程序和容器数据备份到数据分区的 `/var/mobile/Library/TroubadourDevelopment/Backups/`，不清空数据。若该备份已存在会停止，避免覆盖既有恢复点。初次安装时设备上没有 Troubadour；本次 Shorts 修复更新前，已在该目录保留上一版程序与应用数据备份。备份留在设备数据分区，不导出账号令牌。

通过 `ipainstaller` 实际安装 IPA，核对明确成功输出，再对比设备上的两个可执行文件是否与本地发布包逐字节相同，并检查应用前台启动。

## 和作者发布包的边界

这里的“一致”是与**公开源码的 Release 逻辑和显式配置对齐**，不是与作者另一套工具链产物逐字节相同。

- 作者未公开的 WARP 私有配置不在仓库，本包使用代码自带的无私有配置回退；不能保证与作者预置配置的网络表现一致。
- 保留了原始 helper 和图标恢复资源，但 helper 写死 `/Applications/Troubadour.app` 并依赖 root/setuid。IPA 容器安装不执行 DEB 的 postinst，因此不保证原有 root 辅助安装/图标功能可用。这是原有 IPA 与 DEB 安装方式的差异，本次未扩展其权限或改变 helper 逻辑。
- 未修改前次研究发现的 60 fps 默认选择；本轮保持源码行为。
- 首次启动显示账号登录页是原始设计；中文界面已正常显示。初次安装没有代用户登录；用户随后已确认登录和普通视频播放正常。本次修复回归不会读取账号令牌、触发点赞或发布评论。

## 已完成的检查

两个架构全部源码均编译、链接成功，无编译警告。校验通过 iOS 平台、最低系统、双架构、adhoc 双哈希签名、原始资源文件一致性和 armv7 NSObject 链接归属。程序已通过 IPA 在 iPad3 / iOS9.3.6 安装、前台启动，并核对设备可执行文件哈希。

翻译检查仍有上游已有的 6 个冗余键报告；没有缺失翻译或格式占位符错误，本次未因此改动翻译表。

## Shorts 闪退修复

2026-10-25 两份真机日志均显示主线程在自动释放池清理时 EXC_BAD_ACCESS。独立的 `tests/ShortsBlocksProbe.m` 在同一台 iPad 上复现：原始可变参数数组包含 __NSStackBlock__，覆盖旧栈并释放临时数组后退出码 139；显式 copy 后数组均为 __NSMallocBlock__，退出码 0 且回调正常执行。

新增 `tests/ShortsIntegration.m` 只用于临时、限定本应用的真机验证，不链接进 IPA。它对实际 Shorts 控件反复创建和释放，并进入真实 Shorts、切换视频和栏目；只记录页数、播放器状态和时间，不保存推荐内容、账号信息或视频 URL。验证后卸除诊断动态库。

修复版 1.6.1 的真机回归通过：实际控件创建／释放 20 轮、真实 Shorts 加载 17 页、切换至下一条、栏目切换 5 次，未再崩溃。播放器曾进入 ready 状态并推进播放时间，但这轮主要验证闪退和页面生命周期，不代表长时间播放稳定性测试。临时诊断动态库、验证结果目录和安装暂存文件均已移除；应用已在无诊断插件的情况下重新启动，两个可执行文件仍与发布包哈希一致。
