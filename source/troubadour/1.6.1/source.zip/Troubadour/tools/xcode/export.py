#!/usr/bin/env python3
"""Export this Release IPA, editable Xcode project/source and verification report."""
from pathlib import Path
import zipfile,shutil,json,hashlib,subprocess,plistlib
r=Path(__file__).resolve().parents[2];out=r/'packages';downloads=Path.home()/'Downloads';out.mkdir(exist_ok=True)
changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','src','Resources','Makefile','control'],cwd=r,text=True).splitlines();assert set(changed)<={'src/ui/YTShortsView.m','Resources/Info.plist'},changed
version=plistlib.loads((r/'Resources/Info.plist').read_bytes())['CFBundleVersion']
ipa=out/('Troubadour_'+version+'_Xcode7_Release.ipa');assert ipa.is_file()
source=out/('Troubadour_'+version+'_Xcode7_工程与源码.zip');excluded={'.git','build','packages','__pycache__','xcuserdata'};private={'src/warp/AWGSecrets.h','Resources/warp_bootstrap.json','Resources/warp_verified_seeds.json'}
with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
 for file in sorted(r.rglob('*')):
  rel=file.relative_to(r)
  if file.is_file() and not any(part in excluded for part in rel.parts) and rel.as_posix() not in private and file.name!='.DS_Store' and file.suffix not in ['.pyc','.xcuserstate']:
   z.write(file,'Troubadour/'+rel.as_posix())
with zipfile.ZipFile(source) as z:assert z.testzip() is None
readme=out/('Troubadour_'+version+'_Xcode7_说明.md');shutil.copy2(r/'XCODE7-BUILD.md',readme)
report={'upstreamCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'build':json.loads((r/'build/release-build.json').read_text()),'checks':json.loads((r/'build/release-check.json').read_text()),'device':json.loads((r/'build/device-install.json').read_text()),'upstreamRuntimeSourcesUnchanged':False,'changedRuntimeSources':[p for p in changed if p.startswith('src/')],'xcodebuildNativePipelineVerified':False,'onlinePlaybackVerified':False}
report['shortsRegression']=json.loads((r/'build/shorts-crash/runtime-regression.json').read_text());report['blockLifetimeProbe']=json.loads((r/'build/shorts-crash/block-probe.json').read_text())
reportPath=out/('Troubadour_'+version+'_Xcode7_核验.json');reportPath.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
artifacts=[ipa,source,readme,reportPath];manifest=out/('Troubadour_'+version+'_Xcode7_SHA256.json');manifest.write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts},ensure_ascii=False,indent=2)+'\n')
for p in artifacts+[manifest]:shutil.copy2(p,downloads/p.name);print(p.name+': '+str(p.stat().st_size)+' bytes')
