#!/usr/bin/env python3
from pathlib import Path
import subprocess,zipfile,json,hashlib,shutil,plistlib
r=Path(__file__).resolve().parents[2];app=r/'build/Release-iphoneos/Troubadour.app';dest=r/'packages';dest.mkdir(exist_ok=True)
assert (r/'build/release-check.json').exists()
version=plistlib.loads((app/'Info.plist').read_bytes())['CFBundleVersion'];ipa=dest/('Troubadour_'+version+'_Xcode7_Release.ipa')
with zipfile.ZipFile(ipa,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(app.rglob('*')):
  if f.is_file():z.write(f,'Payload/Troubadour.app/'+f.relative_to(app).as_posix())
with zipfile.ZipFile(ipa) as z:assert z.testzip() is None
print(ipa)
