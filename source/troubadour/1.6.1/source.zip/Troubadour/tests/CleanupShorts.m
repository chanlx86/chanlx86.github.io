#import <Foundation/Foundation.h>

// Remove only the temporary files created by this Shorts verification run.
static BOOL removeDirectory(NSString *path, NSArray *allowed) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:path]) return YES;
    NSString *resolved = path.stringByResolvingSymlinksInPath;
    NSString *alternate = [path hasPrefix:@"/private/var/"] ? [path substringFromIndex:8] : [@"/private" stringByAppendingString:path];
    if (![resolved isEqualToString:path] && ![resolved isEqualToString:alternate]) return NO;
    for (NSString *name in [fm contentsOfDirectoryAtPath:path error:nil])
        if (![allowed containsObject:name]) return NO;
    return [fm removeItemAtPath:path error:nil];
}

int main(int argc, char **argv) { @autoreleasepool {
    if (argc != 3) return 2;
    NSString *mode = @(argv[1]), *container = @(argv[2]);
    NSString *prefix = @"/private/var/mobile/Containers/Data/Application/";
    if (![container hasPrefix:prefix] ||
        ![[NSUUID alloc] initWithUUIDString:[container substringFromIndex:prefix.length]] ||
        ![@[container, [container substringFromIndex:8]] containsObject:container.stringByResolvingSymlinksInPath]) return 3;
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([mode isEqualToString:@"diagnostic"]) {
        for (NSString *name in @[@"TroubadourShortsVerification20261025.dylib", @"TroubadourShortsVerification20261025.plist"]) {
            NSString *path = [@"/Library/MobileSubstrate/DynamicLibraries" stringByAppendingPathComponent:name];
            if ([fm fileExistsAtPath:path] && ![fm removeItemAtPath:path error:nil]) return 4;
        }
        if (!removeDirectory([container stringByAppendingPathComponent:@"Library/TroubadourShortsVerification"], @[@"run", @"result.json"])) return 5;
    } else if ([mode isEqualToString:@"staging"]) {
        if (!removeDirectory(@"/var/mobile/troubadour-stage", @[@"Device", @"Troubadour-release.ipa"])) return 6;
        if (!removeDirectory(@"/var/mobile/troubadour-shorts-test", @[@"ShortsBlocksProbe", @"run", @"result.json", @"CleanupShorts"])) return 7;
    } else return 8;
    puts("Removed only allowlisted Troubadour verification files.");
    return 0;
}}
