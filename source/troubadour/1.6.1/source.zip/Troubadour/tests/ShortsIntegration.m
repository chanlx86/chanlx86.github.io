/* Temporary, bundle-scoped device regression; never linked into the IPA. */
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <objc/message.h>
static NSString *Directory;
static NSMutableDictionary *Report;static id Shell,Shorts;static NSInteger Tick,Switches;static double PeakTime;static NSTimer *Timer;
static void Save(void){[[NSJSONSerialization dataWithJSONObject:Report options:NSJSONWritingPrettyPrinted error:nil] writeToFile:[Directory stringByAppendingPathComponent:@"result.json"] atomically:YES];}
__attribute__((noinline))static void Overwrite(void){volatile unsigned char bytes[8192];for(NSUInteger i=0;i<sizeof(bytes);i++)bytes[i]=0xa5;__asm__ volatile("" : : "r"(bytes) : "memory");}
static id FindShell(UIViewController *controller){if([controller isKindOfClass:NSClassFromString(@"YTShellViewController")])return controller;for(UIViewController *child in controller.childViewControllers){id found=FindShell(child);if(found)return found;}return nil;}
static void Select(NSInteger index){((void(*)(id,SEL,NSInteger))objc_msgSend)(Shell,NSSelectorFromString(@"selectTab:"),index);}
static void Finish(NSString *result){[Timer invalidate];Timer=nil;Report[@"done"]=@YES;Report[@"result"]=result;Report[@"tabSwitches"]=@(Switches);Report[@"peakPlaybackTime"]=@(PeakTime);Select(0);Save();}
@interface ShortsVerification:NSObject
+ (void)sample:(NSTimer *)timer;
@end
@implementation ShortsVerification
+ (void)sample:(NSTimer *)timer {
 Tick++;NSArray *items=[Shorts valueForKey:@"items"],*pages=[Shorts valueForKey:@"pages"];AVPlayer *player=[Shorts valueForKey:@"player"];
 Report[@"feedItems"]=@(items.count);Report[@"pageCount"]=@(pages.count);Report[@"playerExists"]=@(player!=nil);
 if(player){double t=CMTimeGetSeconds(player.currentTime);if(isfinite(t)&&t>PeakTime)PeakTime=t;Report[@"playerItemStatus"]=@(player.currentItem.status);Report[@"playerRate"]=@(player.rate);if(player.currentItem.error)Report[@"playerErrorCode"]=@(player.currentItem.error.code);}
 Report[@"ticks"]=@(Tick);Save();
 if(Tick==8&&items.count>1){((void(*)(id,SEL,NSInteger))objc_msgSend)(Shorts,NSSelectorFromString(@"showPage:"),1);UIScrollView *pager=[Shorts valueForKey:@"pager"];[pager setContentOffset:CGPointMake(0,pager.bounds.size.height) animated:NO];Report[@"advancedToSecondShort"]=@YES;}
 if(Tick>=12&&Tick<=28&&Tick%4==0){Select((Switches%2)==0?0:1);Switches++;}
 if(Tick>=34){Finish(items.count&&pages.count?@"passed":@"no-feed-data");}
}
@end
__attribute__((constructor))static void Start(void){if(![[[NSBundle mainBundle] bundleIdentifier] isEqual:@"ru.computershik.troubadour"])return;
 dispatch_after(dispatch_time(DISPATCH_TIME_NOW,6*NSEC_PER_SEC),dispatch_get_main_queue(),^{
 Directory=[[NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,NSUserDomainMask,YES) firstObject] stringByAppendingPathComponent:@"TroubadourShortsVerification"];
 NSString *flag=[Directory stringByAppendingPathComponent:@"run"];if(![[NSFileManager defaultManager] fileExistsAtPath:flag])return;[[NSFileManager defaultManager] removeItemAtPath:flag error:nil];
 Report=[NSMutableDictionary dictionary];Report[@"started"]=@YES;Save();
 for(int i=0;i<20;i++){@autoreleasepool{
  UIView *view=[[NSClassFromString(@"YTShortsView") alloc] initWithFrame:CGRectMake(0,0,320,480)];NSMutableArray *items=[view valueForKey:@"items"];
  for(int j=0;j<2;j++){id item=[NSClassFromString(@"YTVideoItem") new];[item setValue:@"Synthetic Shorts regression" forKey:@"title"];[items addObject:item];}
  ((void(*)(id,SEL))objc_msgSend)(view,NSSelectorFromString(@"rebuild"));if([[view valueForKey:@"pages"] count]!=2){Report[@"syntheticFailed"]=@YES;Save();return;}Overwrite();
 }}
 Report[@"syntheticAllocationCycles"]=@20;Save();Shell=FindShell([UIApplication sharedApplication].keyWindow.rootViewController);
 if(!Shell){Report[@"shellMissing"]=@YES;Report[@"done"]=@YES;Save();return;}
 Select(1);Shorts=[[Shell valueForKey:@"sections"] objectAtIndex:1];Timer=[NSTimer timerWithTimeInterval:1 target:[ShortsVerification class] selector:@selector(sample:) userInfo:nil repeats:YES];[[NSRunLoop mainRunLoop] addTimer:Timer forMode:NSRunLoopCommonModes];
 });
}
