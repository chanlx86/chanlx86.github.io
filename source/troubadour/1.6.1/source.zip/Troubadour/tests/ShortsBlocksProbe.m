#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <string.h>
@interface ProbeOwner:NSObject
@property(nonatomic,copy) void (^action)(void);
@property(nonatomic,assign) NSUInteger calls;
- (void)setActions:(NSArray *)actions;
@end
@implementation ProbeOwner
- (void)setActions:(NSArray *)actions {
 for(id block in actions){printf("array-block-class=%s\n",object_getClassName(block));self.action=block;}
}
@end
__attribute__((noinline))static void Make(ProbeOwner *owner,BOOL copied){
 __weak ProbeOwner *weakOwner=owner;
 if(copied)[owner setActions:[NSArray arrayWithObjects:[^{weakOwner.calls++;} copy],[^{weakOwner.calls++;} copy],nil]];
 else [owner setActions:[NSArray arrayWithObjects:(dispatch_block_t)^{weakOwner.calls++;},(dispatch_block_t)^{weakOwner.calls++;},nil]];
}
__attribute__((noinline))static void Overwrite(void){volatile unsigned char bytes[8192];for(size_t i=0;i<sizeof(bytes);i++)bytes[i]=0xa5;__asm__ volatile("" : : "r"(bytes) : "memory");}
int main(int argc,char **argv){setbuf(stdout,NULL);BOOL copied=argc>1&&!strcmp(argv[1],"copied");
 @autoreleasepool{ProbeOwner *owner=[ProbeOwner new];@autoreleasepool{Make(owner,copied);Overwrite();puts("draining-temporary-array");}owner.action();printf("completed calls=%lu\n",(unsigned long)owner.calls);}
 return 0;
}
